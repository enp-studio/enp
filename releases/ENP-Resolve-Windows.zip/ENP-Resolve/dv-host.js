/* ENP for DaVinci Resolve — the Resolve side.
   The panel was written for Premiere: every tool asks the editor program for things through small
   functions named cr_* (give me the timeline size, put this file on the timeline, what's under the playhead…).
   This file answers the same questions with DaVinci Resolve's scripting API, so the panel itself stays the same.
   Every function takes a plain object and returns a plain object ({ ok: true, … } or { ok: false, error }). */
'use strict';
const path = require('path'), fs = require('fs'), os = require('os');

module.exports = function makeHost(getResolve) {
  const OURS = /^(Carousel3D|AmarText|AmarGlass|ENP)[_ ]/;
  const norm = p => String(p || '').replace(/\\/g, '/').toLowerCase();
  const arr = v => { if (!v) return []; if (Array.isArray(v)) return v; if (typeof v === 'object') return Object.keys(v).sort((a, b) => a - b).map(k => v[k]); return []; };
  const has = (o, f) => !!o && typeof o[f] === 'function';
  const safe = async (fn, dflt) => { try { const v = await fn(); return v === undefined || v === null ? dflt : v; } catch (e) { return dflt; } };

  /* ---------- timecode ---------- */
  function tcToFrames(tc, fps) {
    const m = /^(\d+)[:;](\d+)[:;](\d+)([:;.])(\d+)$/.exec(String(tc || '').trim()); if (!m) return 0;
    const nom = Math.round(fps), h = +m[1], mi = +m[2], s = +m[3], f = +m[5];
    let fr = ((h * 60 + mi) * 60 + s) * nom + f;
    if (m[4] === ';') { const d = Math.round(nom / 15), tm = h * 60 + mi; fr -= d * (tm - Math.floor(tm / 10)); }   // drop-frame
    return fr;
  }
  function framesToTc(fr, fps, drop) {
    const nom = Math.round(fps); fr = Math.max(0, Math.round(fr));
    if (drop) { const d = Math.round(nom / 15), perMin = nom * 60 - d, per10 = nom * 600 - d * 9, t = Math.floor(fr / per10), r = fr % per10; fr += d * 9 * t + (r > d ? d * Math.floor((r - d) / perMin) : 0); }
    const p = n => (n < 10 ? '0' : '') + n, f = fr % nom, s = Math.floor(fr / nom) % 60, m = Math.floor(fr / nom / 60) % 60, h = Math.floor(fr / nom / 3600);
    return p(h) + ':' + p(m) + ':' + p(s) + (drop ? ';' : ':') + p(f);
  }

  /* ---------- the project + timeline we're working on ---------- */
  async function ctx() {
    const resolve = await getResolve();
    const pm = await resolve.GetProjectManager(), project = pm ? await pm.GetCurrentProject() : null;
    const c = { resolve, pm, project, tl: null, mp: null };
    if (!project) return c;
    c.mp = await project.GetMediaPool();
    c.tl = await project.GetCurrentTimeline();
    if (!c.tl) return c;
    c.fps = parseFloat(await safe(() => c.tl.GetSetting('timelineFrameRate'), 0)) || parseFloat(await safe(() => project.GetSetting('timelineFrameRate'), 24)) || 24;
    c.w = parseInt(await safe(() => c.tl.GetSetting('timelineResolutionWidth'), 0), 10) || parseInt(await safe(() => project.GetSetting('timelineResolutionWidth'), 1920), 10) || 1920;
    c.h = parseInt(await safe(() => c.tl.GetSetting('timelineResolutionHeight'), 0), 10) || parseInt(await safe(() => project.GetSetting('timelineResolutionHeight'), 1080), 10) || 1080;
    c.start = Number(await safe(() => c.tl.GetStartFrame(), 0)) || 0;
    c.sec = f => (Number(f) - c.start) / c.fps;
    c.frame = s => Math.round(Number(s) * c.fps) + c.start;
    c.name = await safe(() => c.tl.GetName(), '');
    return c;
  }
  async function playhead(c) {
    const tc = String(await safe(() => c.tl.GetCurrentTimecode(), '') || '');
    c.drop = tc.indexOf(';') >= 0;
    return Math.max(0, c.sec(tcToFrames(tc, c.fps)));
  }
  /* every clip on the video (or audio) tracks: [[{ it, a, b }, …] per track] — a/b in seconds from the timeline's first frame */
  async function tracks(c, type) {
    const n = Number(await safe(() => c.tl.GetTrackCount(type), 0)) || 0, out = [];
    for (let i = 1; i <= n; i++) {
      const list = arr(await safe(() => c.tl.GetItemListInTrack(type, i), [])), row = [];
      for (const it of list) row.push({ it, a: c.sec(await it.GetStart()), b: c.sec(await it.GetEnd()) });
      out.push(row);
    }
    return out;
  }
  async function mpInfo(it) {
    const mpi = await safe(() => it.GetMediaPoolItem(), null);
    if (!mpi) return { mpi: null, path: '', name: '', fps: 0 };
    return { mpi, path: String(await safe(() => mpi.GetClipProperty('File Path'), '') || ''), name: String(await safe(() => mpi.GetName(), '') || ''),
      fps: parseFloat(await safe(() => mpi.GetClipProperty('FPS'), 0)) || 0 };
  }
  async function inPoint(c, it, m) {
    if (has(it, 'GetSourceStartTime')) { const s = await safe(() => it.GetSourceStartTime(), null); if (typeof s === 'number') return s; }
    if (has(it, 'GetSourceStartFrame')) { const f = await safe(() => it.GetSourceStartFrame(), null); if (typeof f === 'number') return f / (m.fps || c.fps); }
    return (Number(await safe(() => it.GetLeftOffset(), 0)) || 0) / c.fps;
  }
  async function prop(it, k, d) { const v = await safe(() => it.GetProperty(k), d); return typeof v === 'number' ? v : (parseFloat(v) || d); }
  /* what the panel knows about one clip (same fields Premiere's side gives) */
  async function clipInfo(c, row, ti) {
    const it = row.it, m = row.m || await mpInfo(it);
    const o = { track: ti, start: row.a, end: row.b, inPoint: await inPoint(c, it, m), name: m.name || String(await safe(() => it.GetName(), '')), id: String(await safe(() => it.GetUniqueId(), '') || ''), path: m.path, speed: 1, keyed: false, uniform: true };
    const zx = await prop(it, 'ZoomX', 1), pan = await prop(it, 'Pan', 0), tilt = await prop(it, 'Tilt', 0);
    o.scale = zx * 100; o.pos = [.5 + pan / c.w, .5 - tilt / c.h]; o.anchor = [.5, .5];
    o.rot = -(await prop(it, 'RotationAngle', 0)); o.opacity = await prop(it, 'Opacity', 100);
    return o;
  }
  /* the top clip under time t that isn't one of ENP's own renders */
  async function topAt(c, t, V, opt) {
    V = V || await tracks(c, 'video');
    for (let i = V.length - 1; i >= 0; i--) for (const row of V[i]) {
      if (row.a <= t + 0.0005 && row.b > t) {
        const m = await mpInfo(row.it); row.m = m;
        if (!(opt && opt.ours) && OURS.test(m.name)) continue;
        if (opt && opt.ours && !OURS.test(m.name)) continue;
        if (m.path || (opt && opt.nested)) return { row, track: i };
      }
    }
    return null;
  }
  async function findRef(c, ref, type) {
    const T = await tracks(c, type === 'a' ? 'audio' : 'video');
    if (ref && ref.id) for (let i = 0; i < T.length; i++) for (const row of T[i]) if (String(await safe(() => row.it.GetUniqueId(), '')) === String(ref.id)) return { row, track: i };
    const tr = ref ? T[ref.track] : null;
    if (tr) for (const row of tr) if (Math.abs(row.a - ref.start) < 0.5 / c.fps + 0.002) return { row, track: ref.track };
    return null;
  }
  const free = (rows, a, b) => !rows.some(r => r.a < b - 0.001 && r.b > a + 0.001);

  /* ---------- media pool ---------- */
  async function bin(c, name) {
    const root = await c.mp.GetRootFolder();
    for (const f of arr(await safe(() => root.GetSubFolderList(), []))) if (await safe(() => f.GetName(), '') === name) return f;
    return (await safe(() => c.mp.AddSubFolder(root, name), null)) || root;
  }
  async function findInFolder(folder, p) {
    const want = norm(p);
    for (const clip of arr(await safe(() => folder.GetClipList(), []))) if (norm(await safe(() => clip.GetClipProperty('File Path'), '')) === want) return clip;
    return null;
  }
  /* bring files into a bin (and give back their media-pool items, in the same order) */
  async function importTo(c, binName, paths) {
    const folder = await bin(c, binName), was = await safe(() => c.mp.GetCurrentFolder(), null), out = [];
    await safe(() => c.mp.SetCurrentFolder(folder), null);
    const need = []; for (const p of paths) { const f = await findInFolder(folder, p); out.push(f); if (!f) need.push(p); }
    if (need.length) {
      const got = arr(await safe(() => c.mp.ImportMedia(need), []));
      for (let i = 0; i < paths.length; i++) if (!out[i]) {
        out[i] = await findInFolder(folder, paths[i]);
        if (!out[i]) for (const g of got) if (norm(await safe(() => g.GetClipProperty('File Path'), '')) === norm(paths[i])) out[i] = g;
      }
    }
    /* ENP's own renders carry straight alpha (not premultiplied) */
    for (const it of out) if (it) { const nm = String(await safe(() => it.GetName(), '') || ''); if (OURS.test(nm) && /\.mov$/i.test(nm)) await safe(() => it.SetClipProperty('Alpha mode', 'Straight'), null); }
    if (was) await safe(() => c.mp.SetCurrentFolder(was), null);
    return out;
  }
  async function clipFrames(c, mpi) {
    const n = parseInt(await safe(() => mpi.GetClipProperty('Frames'), 0), 10); if (n > 0) return n;
    const d = String(await safe(() => mpi.GetClipProperty('Duration'), '') || '');
    return tcToFrames(d, c.fps) || 0;
  }
  async function addTrack(c, type) { return !!(await safe(() => c.tl.AddTrack(type), false)); }
  /* lay one media-pool item on a track at t0. type: 'video' | 'audio'. durSec: only for audio / stills when we know it */
  async function lay(c, mpi, type, trackIdx, t0, durSec) {
    let n = await clipFrames(c, mpi);
    if (durSec > 0) { const want = Math.round(durSec * c.fps); if (!(n > 0) || want < n) n = want; }
    if (!(n > 0)) n = Math.round(c.fps * 5);
    const base = { mediaPoolItem: mpi, startFrame: 0, trackIndex: trackIdx + 1, recordFrame: c.frame(t0), mediaType: type === 'audio' ? 2 : 1 };
    let got = arr(await safe(() => c.mp.AppendToTimeline([Object.assign({}, base, { endFrame: n })]), []));
    if (!got.length) got = arr(await safe(() => c.mp.AppendToTimeline([Object.assign({}, base, { endFrame: n - 1 })]), []));
    return got[0] || null;
  }
  /* first free track above index `above` for [a, b]; adds a track when there isn't one */
  async function trackAbove(c, T, type, above, a, b) {
    for (let i = above + 1; i < T.length; i++) if (free(T[i], a, b)) return i;
    if (await addTrack(c, type)) { T.push([]); return T.length - 1 > above ? T.length - 1 : -1; }
    return -1;
  }
  async function removeNamed(c, names) {
    const set = {}; (names || []).forEach(n => { set[n] = 1; });
    const V = await tracks(c, 'video'), kill = [];
    for (const tr of V) for (const row of tr) { const nm = String(await safe(() => row.it.GetName(), '') || ''); if (nm && set[nm]) kill.push(row.it); }
    if (kill.length && has(c.tl, 'DeleteClips')) await safe(() => c.tl.DeleteClips(kill, false), null);
    return kill.length;
  }

  /* =========================== the functions the panel calls =========================== */
  const F = {};
  const noSeq = { ok: false, error: 'no_sequence' };

  /* Resolve projects live in a database, not a folder: renders go to Videos/ENP/<project> so they never vanish with the temp folder */
  const ascii = s => /^[\x20-\x7E]*$/.test(String(s));
  let dirCache = {};
  async function projDir(c) {
    const raw = c.project ? String(await safe(() => c.project.GetName(), '') || '') : '';
    if (dirCache[raw]) return dirCache[raw];
    let name = raw.replace(/[^A-Za-z0-9 _.-]+/g, '').trim() || 'Project';
    if (name !== raw && raw) { let h = 0; for (let i = 0; i < raw.length; i++) h = (h * 31 + raw.charCodeAt(i)) | 0; name += '-' + (h >>> 0).toString(36); }
    let base = path.join(os.homedir(), process.platform === 'darwin' ? 'Movies' : 'Videos', 'ENP');
    if (process.platform === 'win32' && !ascii(base)) base = 'C:\\Users\\Public\\ENP';
    const d = path.join(base, name);
    try { fs.mkdirSync(d, { recursive: true }); } catch (e) { return ''; }
    return (dirCache[raw] = d);
  }
  F.cr_info = async () => {
    const c = await ctx();
    if (!c.tl) return { ok: true, hasSequence: false, dir: c.project ? await projDir(c) : '' };
    return { ok: true, hasSequence: true, t: await playhead(c), w: c.w, h: c.h, fps: c.fps, dir: await projDir(c), name: c.name };
  };
  F.cr_appInfo = async () => {
    const c = await ctx(), o = { ok: true, version: '', build: 'DaVinci Resolve', project: '', saved: true, seq: !!c.tl, seqName: c.name || '', w: c.w || 0, h: c.h || 0 };
    o.version = String(await safe(() => c.resolve.GetVersionString(), '') || '');
    o.project = c.project ? String(await safe(() => c.project.GetName(), '') || '') : '';
    return o;
  };
  F.cr_seek = async a => { const c = await ctx(); if (!c.tl) return noSeq; await playhead(c); await c.tl.SetCurrentTimecode(framesToTc(c.frame(a.t), c.fps, c.drop)); return { ok: true }; };
  F.cr_markers = async a => {
    const c = await ctx(); if (!c.tl) return noSeq;
    const mk = (await safe(() => c.tl.GetMarkers(), {})) || {}, out = [];
    Object.keys(mk).forEach(k => { const t = Number(k) / c.fps; if (t >= a.from - 0.001 && t <= a.to + 0.001) out.push(t); });
    return { ok: true, markers: out.sort((x, y) => x - y) };
  };

  /* --- what's on the timeline --- */
  F.cr_under = async () => {
    const c = await ctx(); if (!c.tl) return noSeq;
    const t = await playhead(c), top = await topAt(c, t);
    if (!top) return { ok: true, none: true };
    return { ok: true, path: top.row.m.path, src: t - top.row.a + await inPoint(c, top.row.it, top.row.m) };
  };
  F.cr_under2 = async a => {
    const c = await ctx(); if (!c.tl) return noSeq;
    const t = (a.t !== undefined && a.t !== null) ? Number(a.t) + 0.001 : await playhead(c), top = await topAt(c, t);
    if (!top) return { ok: true, none: true, t };
    const o = await clipInfo(c, top.row, top.track); o.src = (t - top.row.a) + o.inPoint;
    return { ok: true, clip: o, t, w: c.w, h: c.h, fps: c.fps };
  };
  /* Resolve doesn't tell scripts which clips are selected, so "the selected clip" = the clip under the playhead */
  F.cr_clips = async a => {
    const c = await ctx(); if (!c.tl) return noSeq;
    const t = await playhead(c), out = [];
    if (a.fallback !== false) { const top = await topAt(c, t, null, { nested: true }); if (top) out.push(await clipInfo(c, top.row, top.track)); }
    return { ok: true, clips: out, t, w: c.w, h: c.h, fps: c.fps, selected: 0 };
  };
  F.cr_selclips = async () => {
    const c = await ctx(); if (!c.tl) return noSeq;
    const t = await playhead(c), top = await topAt(c, t);
    const out = top ? [{ at: top.row.a, dur: top.row.b - top.row.a, name: top.row.m.name }] : [];
    return { ok: true, count: out.length, clips: out };
  };
  F.cr_sel1 = async () => {
    const c = await ctx(); if (!c.tl) return noSeq;
    const t = await playhead(c), top = await topAt(c, t, null, { ours: true });
    if (!top) return { ok: false, error: 'no_selection' };
    return { ok: true, count: 1, path: top.row.m.path, name: top.row.m.name, at: top.row.a, dur: top.row.b - top.row.a, ref: { id: String(await safe(() => top.row.it.GetUniqueId(), '') || '') } };
  };
  F.cr_pick = async a => {
    const c = await ctx(), out = [];
    if (a.from === 'project') {
      if (!c.mp) return { ok: true, items: out };
      const seen = {};
      for (const clip of arr(await safe(() => c.mp.GetSelectedClips(), []))) { const p = String(await safe(() => clip.GetClipProperty('File Path'), '') || ''); if (p && !seen[p]) { seen[p] = 1; out.push({ path: p, name: await safe(() => clip.GetName(), '') }); } }
      return { ok: true, items: out };
    }
    if (!c.tl) return noSeq;
    const t = await playhead(c), top = await topAt(c, t);
    if (top) out.push({ path: top.row.m.path, from: await inPoint(c, top.row.it, top.row.m), at: top.row.a, name: top.row.m.name });
    return { ok: true, items: out };
  };
  F.cr_findNamed = async a => {
    const c = await ctx(); if (!c.tl) return noSeq;
    const set = {}; (a.names || []).forEach(n => { set[n] = 1; });
    const V = await tracks(c, 'video');
    for (let i = 0; i < V.length; i++) for (const row of V[i]) { const nm = String(await safe(() => row.it.GetName(), '') || ''); if (nm && set[nm]) return { ok: true, clip: await clipInfo(c, row, i) }; }
    return { ok: true, clip: null };
  };
  F.cr_cutAt = async a => {
    const c = await ctx(); if (!c.tl) return noSeq;
    const t = await playhead(c), V = await tracks(c, 'video'); let best = null;
    for (let i = V.length - 1; i >= 0; i--) {
      const tr = V[i].slice().sort((x, y) => x.a - y.a);
      for (let j = 0; j + 1 < tr.length; j++) {
        const A = tr[j], B = tr[j + 1]; if (Math.abs(A.b - B.a) > 0.02) continue;
        const d = Math.abs(B.a - t); if (best && d >= best.d - 1e-6) continue;
        A.m = A.m || await mpInfo(A.it); B.m = B.m || await mpInfo(B.it); if (!A.m.path || !B.m.path) continue;
        best = { d, a: A, b: B, track: i };
      }
      if (best && best.d < 0.05) break;
    }
    if (!best || best.d > (a.within || 3)) return { ok: true, none: true, t };
    return { ok: true, cut: best.b.a, track: best.track, a: await clipInfo(c, best.a, best.track), b: await clipInfo(c, best.b, best.track), w: c.w, h: c.h, fps: c.fps };
  };

  /* --- putting things on the timeline --- */
  F.cr_place = async a => {
    const c = await ctx(); if (!c.tl) return noSeq;
    if (a.replace && a.replace.length) await removeNamed(c, a.replace);
    const paths = [a.front]; if (a.back) paths.push(a.back);
    const got = await importTo(c, a.bin || 'ENP Carousel', paths), front = got[0], back = a.back ? got[1] : null;
    if (!front || (a.back && !back)) return { ok: false, error: 'import_failed' };
    const t0 = Number(a.at) || 0, t1 = t0 + (Number(a.duration) || 1), V = await tracks(c, 'video');
    let top = -1, under = -1;
    for (let i = 0; i < V.length; i++) { if (!free(V[i], t0, t1)) top = i; if (under < 0 && V[i].some(r => r.a <= t0 + 0.001 && r.b > t0)) under = i; }
    const res = { ok: true, names: [await front.GetName()], backAbove: false };
    if (back) {
      const speaker = under >= 0 ? under : top; let bi = -1;
      for (let b = speaker - 1; b >= 0; b--) if (free(V[b], t0, t1)) { bi = b; break; }
      if (bi < 0) { bi = await trackAbove(c, V, 'video', top, t0, t1); if (bi < 0) return { ok: false, error: 'no_free_track' }; res.backAbove = true; }
      if (!await lay(c, back, 'video', bi, t0, 0)) return { ok: false, error: 'place_failed' };
      V[bi].push({ a: t0, b: t1 }); res.back = 'V' + (bi + 1); res.names.push(await back.GetName()); if (bi > top) top = bi;
    }
    const fi = await trackAbove(c, V, 'video', top, t0, t1);
    if (fi < 0) return { ok: false, error: 'no_free_track' };
    const item = await lay(c, front, 'video', fi, t0, 0);
    if (!item) return { ok: false, error: 'place_failed' };
    res.track = 'V' + (fi + 1);
    res.ref = { track: fi, start: c.sec(await safe(() => item.GetStart(), c.frame(t0))), id: String(await safe(() => item.GetUniqueId(), '') || '') };
    return res;
  };
  F.cr_placeSeq = async a => {
    const c = await ctx(); if (!c.tl) return noSeq;
    if (a.replace && a.replace.length) await removeNamed(c, a.replace);
    const items = a.items || [], got = await importTo(c, a.bin || 'ENP Captions', items.map(x => x.path)), V = await tracks(c, 'video');
    let top = -1; for (let i = 0; i < V.length; i++) if (items.some(x => !free(V[i], x.at, x.at + x.dur))) top = i;
    const ti = await trackAbove(c, V, 'video', top, 0, 1e9); if (ti < 0) return { ok: false, error: 'no_free_track' };
    const names = []; let n = 0;
    for (let k = 0; k < items.length; k++) { if (!got[k]) continue; if (await lay(c, got[k], 'video', ti, items[k].at, 0)) { n++; names.push(await got[k].GetName()); } }
    return { ok: true, track: 'V' + (ti + 1), placed: n, names };
  };
  F.cr_remove = async a => { const c = await ctx(); if (!c.tl) return noSeq; return { ok: true, removed: await removeNamed(c, a.names || []) }; };
  F.cr_importLay = async a => {
    const c = await ctx(); if (!c.mp) return { ok: false, error: 'no_project' };
    const it = (await importTo(c, a.bin || 'ENP Items', [a.path]))[0];
    if (!it) return { ok: false, error: 'import_failed' };
    const name = await it.GetName();
    if (!a.place) return { ok: true, imported: true, name };
    if (!c.tl) return { ok: true, imported: true, name, noSeq: true };
    const t0 = a.at != null ? Number(a.at) : await playhead(c), dur = Number(a.dur) || ((await clipFrames(c, it)) / c.fps) || 5, V = await tracks(c, 'video');
    let top = -1; for (let i = 0; i < V.length; i++) if (!free(V[i], t0, t0 + dur)) top = i;
    const ti = await trackAbove(c, V, 'video', top, t0, t0 + dur); if (ti < 0) return { ok: false, error: 'no_free_track' };
    const placed = arr(await safe(() => c.mp.AppendToTimeline([{ mediaPoolItem: it, startFrame: 0, endFrame: Math.max(1, Math.round(dur * c.fps)), trackIndex: ti + 1, recordFrame: c.frame(t0) }]), []));
    return placed.length ? { ok: true, track: 'V' + (ti + 1), name, imported: true } : { ok: false, error: 'place_failed' };
  };
  F.cr_swapMedia = async a => {
    const c = await ctx(); if (!c.mp) return { ok: false, error: 'no_project' };
    let hit = null;
    const walk = async f => { for (const clip of arr(await safe(() => f.GetClipList(), []))) { if (await safe(() => clip.GetName(), '') === a.name) { hit = clip; return; } } for (const s of arr(await safe(() => f.GetSubFolderList(), []))) { if (hit) return; await walk(s); } };
    await walk(await c.mp.GetRootFolder());
    if (!hit) return { ok: false, error: 'not_found' };
    const ok = await safe(() => hit.ReplaceClip(a.path), false);
    await safe(() => hit.SetClipProperty('Clip Name', a.name), null);
    return { ok: ok !== false };
  };
  /* position / scale as plain values (Resolve's scripting can't write keyframes) */
  F.cr_keys = async a => {
    const c = await ctx(); if (!c.tl) return noSeq;
    if (a.keys && a.keys.length) return { ok: false, error: 'no_keyframes_in_resolve' };
    const f = await findRef(c, a.clip, 'v'); if (!f) return { ok: false, error: 'clip_moved' };
    const v = a.value;
    if (v !== undefined && v !== null) {
      if (a.prop === 'pos') { await safe(() => f.row.it.SetProperty('Pan', (v[0] - .5) * c.w), null); await safe(() => f.row.it.SetProperty('Tilt', (.5 - v[1]) * c.h), null); }
      else if (a.prop === 'scale') { await safe(() => f.row.it.SetProperty('ZoomX', v / 100), null); await safe(() => f.row.it.SetProperty('ZoomY', v / 100), null); }
      else if (a.prop === 'rot') await safe(() => f.row.it.SetProperty('RotationAngle', -v), null);
    }
    return { ok: true, n: 0 };
  };
  F.cr_unkey = async () => ({ ok: true });
  F.cr_disable = async a => {
    const c = await ctx(); if (!c.tl) return noSeq; let n = 0;
    for (const r of (a.refs || [])) { const f = await findRef(c, r, r.type); if (f && has(f.row.it, 'SetClipEnabled')) { await safe(() => f.row.it.SetClipEnabled(a.on === false), null); n++; } }
    return { ok: true, n };
  };

  /* --- sound --- */
  async function audioRows(c) {
    const A = await tracks(c, 'audio'), tr = [], clips = []; let end = 0;
    for (let i = 0; i < A.length; i++) {
      let n = 0;
      for (const row of A[i]) {
        if (row.b > end) end = row.b;
        const m = await mpInfo(row.it), on = has(row.it, 'GetClipEnabled') ? await safe(() => row.it.GetClipEnabled(), true) : true;
        if (!m.path || on === false) continue;
        clips.push({ track: i, start: row.a, end: row.b, inPoint: await inPoint(c, row.it, m), path: m.path, speed: 1, name: m.name, id: String(await safe(() => row.it.GetUniqueId(), '') || ''), on: true }); n++;
      }
      const en = has(c.tl, 'GetIsTrackEnabled') ? await safe(() => c.tl.GetIsTrackEnabled('audio', i + 1), true) : true;
      tr.push({ i, name: String(await safe(() => c.tl.GetTrackName('audio', i + 1), '') || ('A' + (i + 1))), muted: en === false, n });
    }
    return { tracks: tr, clips, end, A };
  }
  F.cr_audioClips = async () => {
    const c = await ctx(); if (!c.tl) return noSeq;
    const r = await audioRows(c); let end = r.end;
    for (const tr of await tracks(c, 'video')) for (const row of tr) if (row.b > end) end = row.b;
    return { ok: true, name: c.name, id: String(await safe(() => c.tl.GetUniqueId(), '') || c.name), fps: c.fps, w: c.w, h: c.h, end, t: await playhead(c), sel: null, inout: null, tracks: r.tracks, clips: r.clips };
  };
  F.cr_selAudio = async () => {
    const c = await ctx(); if (!c.tl) return noSeq;
    const t = await playhead(c), r = await audioRows(c);
    const out = r.clips.filter(x => x.start <= t + 0.0005 && x.end > t).map((x, j) => Object.assign({ idx: j }, x));
    return { ok: true, clips: out, t, n: r.tracks.length };
  };
  async function layAudio(c, binName, list, mute) {
    const got = await importTo(c, binName, list.map(x => x.path)), A = await tracks(c, 'audio');
    const freeAll = rows => list.every(x => free(rows, x.at, x.at + (x.dur || 1)));
    let idx = -1; for (let i = 0; i < A.length; i++) if (freeAll(A[i])) { idx = i; break; }
    if (idx < 0 && await addTrack(c, 'audio')) idx = A.length;
    if (idx < 0) return { ok: false, error: 'no_free_track' };
    let placed = 0, muted = 0; const names = [];
    for (let k = 0; k < list.length; k++) {
      if (!got[k]) continue;
      if (await lay(c, got[k], 'audio', idx, list[k].at, list[k].dur || 0)) { placed++; names.push(await got[k].GetName()); }
      if (mute && list[k].src) { const f = await findRef(c, list[k].src, 'a'); if (f && has(f.row.it, 'SetClipEnabled')) { await safe(() => f.row.it.SetClipEnabled(false), null); muted++; } }
    }
    return placed ? { ok: true, track: 'A' + (idx + 1), placed, muted, names } : { ok: false, error: 'import_failed' };
  }
  F.cr_sfx = async a => {
    const c = await ctx(); if (!c.tl) return noSeq;
    const t0 = a.at !== undefined && a.at !== null ? Number(a.at) : await playhead(c);
    const r = await layAudio(c, 'SFX', [{ path: a.path, at: t0, dur: Number(a.dur) || 0 }], false);
    return r.ok ? { ok: true, track: r.track, at: t0 } : r;
  };
  F.cr_placeClean = async a => { const c = await ctx(); if (!c.tl) return noSeq; return layAudio(c, 'ENP Clean Audio', a.items || [], !!a.mute); };

  /* --- captions as a subtitle file --- */
  F.cr_srtCaptions = async a => {
    const c = await ctx(); if (!c.tl) return noSeq;
    const it = (await importTo(c, 'ENP Captions', [a.path]))[0];
    if (!it) return { ok: false, error: 'import_failed' };
    const got = arr(await safe(() => c.mp.AppendToTimeline([it]), []));
    return { ok: true, track: got.length > 0 };
  };

  /* --- silence cutter: read the whole timeline, then open the rebuilt one --- */
  F.cr_seqDump = async () => {
    const c = await ctx(); if (!c.tl) return noSeq;
    const out = { ok: true, name: c.name, id: String(await safe(() => c.tl.GetUniqueId(), '') || c.name), fps: c.fps, w: c.w, h: c.h, v: [], a: [], skipped: 0, sr: 48000 };
    for (const g of [['v', 'video'], ['a', 'audio']]) {
      const T = await tracks(c, g[1]);
      for (let i = 0; i < T.length; i++) {
        const list = []; let j = 0;
        for (const row of T[i].slice().sort((x, y) => x.a - y.a)) {
          const m = await mpInfo(row.it); if (!m.path) { out.skipped++; j++; continue; }
          const ip = await inPoint(c, row.it, m), on = has(row.it, 'GetClipEnabled') ? await safe(() => row.it.GetClipEnabled(), true) : true;
          list.push({ j: j++, start: row.a, end: row.b, inPoint: ip, outPoint: ip + (row.b - row.a), path: m.path, name: m.name, id: String(await safe(() => row.it.GetUniqueId(), '') || ''), speed: 1, on: on !== false });
        }
        const locked = has(c.tl, 'GetIsTrackLocked') ? await safe(() => c.tl.GetIsTrackLocked(g[1], i + 1), false) : false;
        const en = has(c.tl, 'GetIsTrackEnabled') ? await safe(() => c.tl.GetIsTrackEnabled(g[1], i + 1), true) : true;
        out[g[0]].push({ i, name: String(await safe(() => c.tl.GetTrackName(g[1], i + 1), '') || ''), locked: !!locked, muted: g[0] === 'a' ? en === false : false, clips: list });
      }
    }
    return out;
  };
  F.cr_importXml = async a => {
    const c = await ctx(); if (!c.mp) return { ok: false, error: 'no_project' };
    const tl = await safe(() => c.mp.ImportTimelineFromFile(a.path, { timelineName: a.name || 'ENP Cut' }), null);
    if (!tl) return { ok: false, error: 'import_failed' };
    await safe(() => c.project.SetCurrentTimeline(tl), null);
    return { ok: true, id: String(await safe(() => tl.GetUniqueId(), '') || ''), name: String(await safe(() => tl.GetName(), a.name) || '') };
  };
  F.cr_copyParams = async () => ({ ok: true, done: 0, fx: 0 });
  F.cr_cutMarkers = async a => {
    const c = await ctx(); if (!c.tl) return noSeq; let done = 0;
    for (const cut of (a.cuts || [])) { const f = Math.round(cut[0] * c.fps), d = Math.max(1, Math.round((cut[1] - cut[0]) * c.fps)); if (await safe(() => c.tl.AddMarker(f, 'Red', 'ENP', 'silence', d), false)) done++; }
    return { ok: true, done };
  };

  /* --- media pool tidy-up --- */
  F.cr_projSave = async () => { const c = await ctx(); if (!c.pm) return { ok: false, error: 'no_project' }; await safe(() => c.pm.SaveProject(), null); return { ok: true, path: '' }; };
  F.cr_organize = async a => {
    const c = await ctx(); if (!c.mp) return { ok: false, error: 'no_project' };
    const root = await c.mp.GetRootFolder(), names = a.names || {}, topNames = {}; Object.keys(names).forEach(k => { topNames[names[k]] = 1; });
    const items = [], plan = {}, COLOR = { seq: 'Orange', video: 'Blue', audio: 'Green', image: 'Yellow', gfx: 'Purple', enp: 'Pink', unused: 'Brown', other: 'Beige' };
    const kindOf = async clip => {
      const nm = String(await safe(() => clip.GetName(), '') || ''), type = String(await safe(() => clip.GetClipProperty('Type'), '') || ''), p = String(await safe(() => clip.GetClipProperty('File Path'), '') || '');
      if (/timeline/i.test(type)) return 'seq';
      if (OURS.test(nm)) return 'enp';
      const ext = (/\.([a-z0-9]+)$/i.exec(p || nm) || ['', ''])[1].toLowerCase();
      if (/^(wav|mp3|aac|m4a|aif|aiff|flac|ogg|wma|opus|bwf)$/.test(ext) || /^audio$/i.test(type)) return 'audio';
      if (/^(jpg|jpeg|png|gif|bmp|tif|tiff|psd|webp|heic|tga|exr|svg|dpx|jfif)$/.test(ext) || /still/i.test(type)) return 'image';
      if (/^(mp4|mov|mxf|avi|mkv|m4v|mts|m2ts|webm|r3d|braw|mpg|mpeg|wmv|3gp|dv|vob|ts|crm|ari)$/.test(ext) || /video/i.test(type)) return 'video';
      if (!p) return 'gfx';
      return 'other';
    };
    const walk = async (f, depth) => {
      for (const clip of arr(await safe(() => f.GetClipList(), []))) items.push({ it: clip, kind: null });
      for (const s of arr(await safe(() => f.GetSubFolderList(), []))) { const nm = await safe(() => s.GetName(), ''); if (depth === 0 && topNames[nm]) continue; if (a.scope === 'all') await walk(s, depth + 1); }
    };
    await walk(root, 0);
    for (const x of items) {
      let kind = await kindOf(x.it);
      if (a.unused && kind !== 'seq') { const u = parseInt(await safe(() => x.it.GetClipProperty('Usage'), '0'), 10) || 0; if (!u) kind = 'unused'; }
      x.kind = kind; plan[kind] = (plan[kind] || 0) + 1;
    }
    if (a.dry) return { ok: true, dry: true, plan, total: items.length };
    const bins = {}; let moved = 0, colored = 0, removed = 0;
    for (const x of items) {
      const nm = names[x.kind] || x.kind; if (!bins[nm]) bins[nm] = await bin(c, nm);
      if (await safe(() => c.mp.MoveClips([x.it], bins[nm]), false)) moved++;
      if (a.colors && COLOR[x.kind] && await safe(() => x.it.SetClipColor(COLOR[x.kind]), false)) colored++;
    }
    if (a.empty) {
      const clean = async f => { for (const s of arr(await safe(() => f.GetSubFolderList(), []))) { await clean(s); const n = arr(await safe(() => s.GetClipList(), [])).length + arr(await safe(() => s.GetSubFolderList(), [])).length; if (!n && await safe(() => c.mp.DeleteFolders([s]), false)) removed++; } };
      await clean(root);
    }
    return { ok: true, plan, moved, colored, removed };
  };

  async function run(fn, args) {
    const f = F[fn];
    if (!f) return { ok: false, error: 'not_in_resolve', detail: fn };
    try { return await f(args || {}); } catch (e) { return { ok: false, error: String(e && e.message ? e.message : e) }; }
  }
  return { run, names: Object.keys(F), _tc: { tcToFrames, framesToTc } };
};
