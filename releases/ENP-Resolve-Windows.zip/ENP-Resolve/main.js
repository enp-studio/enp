/* ENP for DaVinci Resolve — the window. Resolve starts this file (Workspace ▸ Workflow Integrations ▸ ENP).
   It opens the panel and passes its questions to Resolve (dv-host.js). */
'use strict';
const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path'), fs = require('fs'), os = require('os');
const PLUGIN_ID = 'com.enp.studio.resolve';
const LOG = path.join(os.tmpdir(), 'ENP-Resolve.log');
function log() { try { fs.appendFileSync(LOG, new Date().toISOString() + ' ' + [].slice.call(arguments).map(String).join(' ') + '\n'); } catch (e) {} }
try { fs.writeFileSync(LOG, ''); } catch (e) {}
process.on('uncaughtException', e => log('uncaught', e && e.stack || e));
process.on('unhandledRejection', e => log('unhandled', e && e.stack || e));

/* Resolve's own bridge. It ships with Resolve; the installer copies it next to this file, and we also look in Resolve's folders. */
let WI = null, wiErr = '';
(function () {
  const pd = process.env.PROGRAMDATA || 'C:\\ProgramData', tail = ['Workflow Integrations', 'Examples', 'SamplePlugin', 'WorkflowIntegration.node'];
  const places = [
    path.join(__dirname, 'WorkflowIntegration.node'),
    path.join.apply(path, [pd, 'Blackmagic Design', 'DaVinci Resolve', 'Support', 'Developer'].concat(tail)),
    path.join.apply(path, ['/Library/Application Support/Blackmagic Design/DaVinci Resolve/Developer'].concat(tail)),
    path.join.apply(path, ['/opt/resolve/Developer'].concat(tail))
  ];
  for (const p of places) { try { if (fs.existsSync(p)) { WI = require(p); log('bridge', p); return; } } catch (e) { wiErr = String(e && e.message || e); log('bridge failed', p, wiErr); } }
  if (!WI && !wiErr) wiErr = 'WorkflowIntegration.node not found';
})();

let resolveObj = null, initDone = false;
async function getResolve() {
  if (resolveObj) return resolveObj;
  if (!WI) throw new Error('no_bridge: ' + wiErr);
  if (!initDone) { const ok = await WI.Initialize(PLUGIN_ID); log('Initialize', ok); if (!ok) throw new Error('resolve_init_failed'); initDone = true; }
  resolveObj = await WI.GetResolve();
  if (!resolveObj) throw new Error('resolve_not_running');
  return resolveObj;
}
const host = require('./dv-host.js')(getResolve);

/* one question at a time: Resolve's API isn't happy with overlapping calls */
let chain = Promise.resolve();
ipcMain.handle('enp-host', (e, fn, args) => {
  const job = chain.then(() => host.run(fn, args)).then(r => { if (r && r.ok === false) log(fn, JSON.stringify(r)); return JSON.stringify(r); }, err => { log(fn, 'threw', err && err.stack || err); return JSON.stringify({ ok: false, error: String(err && err.message || err) }); });
  chain = job.catch(() => {});
  return job;
});
/* file pickers the panel expects to answer straight away */
ipcMain.on('enp-dialog', (e, o) => {
  let out = null;
  try {
    const w = BrowserWindow.fromWebContents(e.sender);
    if (o.kind === 'save') out = dialog.showSaveDialogSync(w, { title: o.title || '', defaultPath: o.name || '', filters: o.exts && o.exts.length ? [{ name: o.friendly || 'Files', extensions: o.exts }] : [] }) || '';
    else out = dialog.showOpenDialogSync(w, { title: o.title || '', defaultPath: o.initial || undefined,
      properties: [o.dir ? 'openDirectory' : 'openFile'].concat(o.multi ? ['multiSelections'] : []),
      filters: !o.dir && o.exts && o.exts.length ? [{ name: 'Files', extensions: o.exts }] : [] }) || [];
  } catch (err) { log('dialog', err); out = o.kind === 'save' ? '' : []; }
  e.returnValue = out;
});
ipcMain.on('enp-open', (e, u) => { try { /^https?:/i.test(u) ? shell.openExternal(u) : shell.openPath(u); } catch (err) {} });
ipcMain.on('enp-log', (e, s) => log('panel', s));
ipcMain.on('enp-env', e => { e.returnValue = { dir: __dirname, bridge: !!WI, bridgeErr: wiErr, log: LOG }; });

app.commandLine.appendSwitch('ignore-gpu-blocklist');
app.commandLine.appendSwitch('enable-webgl');
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');
let win = null;
function createWindow() {
  win = new BrowserWindow({
    width: 470, height: 900, minWidth: 380, minHeight: 500, title: 'ENP', backgroundColor: '#120a10', autoHideMenuBar: true,
    icon: path.join(__dirname, 'icons', 'icon.png'),
    webPreferences: { nodeIntegration: true, contextIsolation: false, sandbox: false, webSecurity: false, backgroundThrottling: false, spellcheck: false }
  });
  try { win.setMenuBarVisibility(false); } catch (e) {}
  win.webContents.on('console-message', (ev, level, msg, line, src) => { if (level >= 2) log('console', msg, src + ':' + line); });
  win.webContents.setWindowOpenHandler(d => { try { shell.openExternal(d.url); } catch (e) {} return { action: 'deny' }; });
  win.loadFile(path.join(__dirname, 'index.html'));
  if (fs.existsSync(path.join(__dirname, 'debug.txt'))) win.webContents.openDevTools({ mode: 'detach' });
  win.on('closed', () => { win = null; });
}
app.whenReady().then(() => { log('ready', 'electron', process.versions.electron, 'node', process.versions.node); createWindow(); });
app.on('window-all-closed', () => { try { if (WI && initDone) WI.CleanUp(); } catch (e) {} app.quit(); });
