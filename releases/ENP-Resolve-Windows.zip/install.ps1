# ENP - installer for DaVinci Resolve Studio (Workflow Integration plugin)
$ErrorActionPreference = 'Stop'
$src = Join-Path $PSScriptRoot 'ENP-Resolve'
$sup = Join-Path $env:PROGRAMDATA 'Blackmagic Design\DaVinci Resolve\Support'
$root = Join-Path $sup 'Workflow Integration Plugins'
$dst = Join-Path $root 'ENP'
Write-Host ''
Write-Host '   ENP - Editing Power Tools for DaVinci Resolve' -ForegroundColor Magenta
Write-Host '   ------------------------------------------------'
if (-not (Test-Path (Join-Path $src 'main.js'))) { Write-Host '   Unzip everything first, then run this again.' -ForegroundColor Red; pause; exit 1 }
if (-not (Test-Path $sup)) { Write-Host '   DaVinci Resolve was not found on this computer (install it and open it once first).' -ForegroundColor Red; pause; exit 1 }

Write-Host '   [1/3] Installing the plugin...'
New-Item -ItemType Directory -Force -Path $root | Out-Null
if (Test-Path $dst) { Get-ChildItem $dst -Force | Where-Object { $_.Name -ne '_backup' -and $_.Name -ne 'runtime' } | Remove-Item -Recurse -Force }
New-Item -ItemType Directory -Force -Path $dst | Out-Null
Copy-Item -Path (Join-Path $src '*') -Destination $dst -Recurse -Force
New-Item -ItemType Directory -Force -Path (Join-Path $dst 'runtime') | Out-Null
# let the panel update itself / keep ffmpeg without asking for admin every time
try { & icacls $dst /grant '*S-1-5-32-545:(OI)(CI)M' /T /Q | Out-Null } catch { }

Write-Host "   [2/3] Connecting it to DaVinci Resolve..."
$node = Join-Path $sup 'Developer\Workflow Integrations\Examples\SamplePlugin\WorkflowIntegration.node'
if (Test-Path $node) { Copy-Item $node (Join-Path $dst 'WorkflowIntegration.node') -Force; Write-Host '         ready.' -ForegroundColor Green }
else {
  Write-Host '         Resolve''s plugin bridge was not found.' -ForegroundColor Yellow
  Write-Host '         Workflow Integration plugins need DaVinci Resolve STUDIO (the paid version).' -ForegroundColor Yellow
}

Write-Host '   [3/3] ffmpeg...'
$ff = Join-Path $dst 'runtime\ffmpeg.exe'
if (-not (Test-Path $ff)) {
  foreach ($c in @((Join-Path $env:APPDATA 'Adobe\CEP\extensions\ENP\runtime\ffmpeg.exe'), (Join-Path $env:APPDATA 'ENP-Engine\ffmpeg.exe'))) { if (-not (Test-Path $ff) -and (Test-Path $c)) { Copy-Item $c $ff -Force } }
  if (-not (Test-Path $ff)) { $cmd = Get-Command ffmpeg.exe -ErrorAction SilentlyContinue; if ($cmd) { Copy-Item $cmd.Source $ff -Force } }
}
if (Test-Path $ff) { Write-Host '         ready.' -ForegroundColor Green } else { Write-Host '         ENP will download it by itself the first time you render.' -ForegroundColor Yellow }
Write-Host ''
Write-Host '   Installed. Restart DaVinci Resolve, then: Workspace > Workflow Integrations > ENP' -ForegroundColor Green
Write-Host ''
pause
