@echo off
chcp 65001 >nul
rem ENP for DaVinci Resolve - asks for administrator once (Resolve keeps its plugins in ProgramData)
net session >nul 2>&1
if %errorlevel% neq 0 (
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
