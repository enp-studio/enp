/* Carousel 3D — Premiere Pro side (ExtendScript).
   Every function takes one JSON string and returns a JSON string. */

function cr__q(s) {
  return '"' + String(s).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\r/g, '\\r').replace(/\n/g, '\\n').replace(/\t/g, '\\t') + '"';
}
function cr__json(v) {
  if (v === null || v === undefined) return 'null';
  var t = typeof v;
  if (t === 'number') return isFinite(v) ? String(v) : 'null';
  if (t === 'boolean') return v ? 'true' : 'false';
  if (t === 'string') return cr__q(v);
  if (v instanceof Array) { var a = []; for (var i = 0; i < v.length; i++) a.push(cr__json(v[i])); return '[' + a.join(',') + ']'; }
  var o = [];
  for (var k in v) if (v.hasOwnProperty(k)) o.push(cr__q(k) + ':' + cr__json(v[k]));
  return '{' + o.join(',') + '}';
}
function cr__args(s) { try { return s ? eval('(' + s + ')') : {}; } catch (e) { return {}; } }
function cr__fail(e) { return cr__json({ ok: false, error: String(e && e.message ? e.message : e) }); }
function cr__norm(p) { return String(p || '').replace(/\\/g, '/').toLowerCase(); }
function cr__fps(seq) {
  try { var tb = Number(seq.timebase); if (tb > 0) return 254016000000 / tb; } catch (e) {}
  try { var st = seq.getSettings(); return 1 / st.videoFrameRate.seconds; } catch (e2) {}
  return 30;
}

/* sequence, playhead, frame size, frame rate, project folder */
function cr_info() {
  try {
    var seq = app.project.activeSequence, dir = '';
    try { var pp = String(app.project.path || ''); dir = pp.replace(/[\\\/][^\\\/]*$/, ''); } catch (e) {}
    if (!seq) return cr__json({ ok: true, hasSequence: false, dir: dir });
    return cr__json({
      ok: true, hasSequence: true, t: seq.getPlayerPosition().seconds,
      w: Number(seq.frameSizeHorizontal), h: Number(seq.frameSizeVertical), fps: cr__fps(seq), dir: dir, name: seq.name
    });
  } catch (e) { return cr__fail(e); }
}

/* pictures / clips the editor has selected */
function cr_pick(s) {
  try {
    var a = cr__args(s), out = [], seen = {};
    if (a.from === 'project') {
      var sel = app.getCurrentProjectViewSelection ? app.getCurrentProjectViewSelection() : null;
      if (sel) for (var i = 0; i < sel.length; i++) {
        var pi = sel[i], mp = '';
        try { mp = pi.getMediaPath(); } catch (e) {}
        if (mp && !seen[mp]) { seen[mp] = 1; out.push({ path: mp, name: pi.name }); }
      }
      return cr__json({ ok: true, items: out });
    }
    var seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var items = seq.getSelection(), list = [];
    for (var j = 0; j < items.length; j++) {
      var ti = items[j], p2 = '';
      try { if (ti.mediaType && ti.mediaType !== 'Video') continue; } catch (e) {}
      try { p2 = ti.projectItem ? ti.projectItem.getMediaPath() : ''; } catch (e) {}
      if (!p2) continue;
      var key = p2 + '|' + ti.inPoint.seconds;
      if (seen[key]) continue; seen[key] = 1;
      list.push({ path: p2, from: ti.inPoint.seconds, at: ti.start.seconds, name: ti.name });
    }
    list.sort(function (x, y) { return x.at - y.at; });
    return cr__json({ ok: true, items: list });
  } catch (e) { return cr__fail(e); }
}

/* sequence markers between two times */
function cr_markers(s) {
  try {
    var a = cr__args(s), seq = app.project.activeSequence, out = [];
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var ms = seq.markers, m = ms.getFirstMarker(), guard = 0;
    while (m && guard++ < 2000) {
      var t = m.start.seconds;
      if (t >= a.from - 0.001 && t <= a.to + 0.001) out.push(t);
      m = ms.getNextMarker(m);
    }
    out.sort(function (x, y) { return x - y; });
    return cr__json({ ok: true, markers: out });
  } catch (e) { return cr__fail(e); }
}

/* the picture under the playhead (top clip that isn't one of ours) */
function cr_under(s) {
  try {
    var seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var t = seq.getPlayerPosition().seconds, vt = seq.videoTracks;
    for (var i = vt.numTracks - 1; i >= 0; i--) {
      var tr = vt[i];
      for (var j = 0; j < tr.clips.numItems; j++) {
        var c = tr.clips[j];
        if (c.start.seconds <= t && c.end.seconds > t && c.projectItem) {
          if (/^(Carousel3D|AmarText|AmarGlass|ENP)_/.test(c.projectItem.name)) continue;
          var p = ''; try { p = c.projectItem.getMediaPath(); } catch (e) {}
          if (!p) continue;
          return cr__json({ ok: true, path: p, src: t - c.start.seconds + c.inPoint.seconds });
        }
      }
    }
    return cr__json({ ok: true, none: true });
  } catch (e) { return cr__fail(e); }
}

function cr__bin(name) {
  var root = app.project.rootItem;
  for (var i = 0; i < root.children.numItems; i++) {
    var c = root.children[i];
    if (c.name === name && c.type === 2) return c;   // 2 = bin
  }
  return root.createBin(name);
}
function cr__findItem(bin, p) {
  var want = cr__norm(p);
  for (var i = bin.children.numItems - 1; i >= 0; i--) {
    var c = bin.children[i], mp = '';
    try { mp = c.getMediaPath(); } catch (e) {}
    if (cr__norm(mp) === want) return c;
  }
  return null;
}
function cr__free(track, a, b) {
  for (var i = 0; i < track.clips.numItems; i++) {
    var c = track.clips[i];
    if (c.start.seconds < b - 0.001 && c.end.seconds > a + 0.001) return false;
  }
  return true;
}
function cr__addTrack(seq) {
  try {
    app.enableQE();
    var q = qe.project.getActiveSequence();
    q.addTracks(1, seq.videoTracks.numTracks, 0);
    return true;
  } catch (e) { return false; }
}
/* first free track above index `above`, adding one when needed */
function cr__trackAbove(seq, above, a, b) {
  for (var i = above + 1; i < seq.videoTracks.numTracks; i++) if (cr__free(seq.videoTracks[i], a, b)) return i;
  if (cr__addTrack(seq)) {
    var n = seq.videoTracks.numTracks - 1;
    if (n > above && cr__free(seq.videoTracks[n], a, b)) return n;
  }
  return -1;
}
function cr__removeNamed(seq, names) {
  var n = 0, set = {};
  for (var k = 0; k < names.length; k++) set[names[k]] = 1;
  for (var i = 0; i < seq.videoTracks.numTracks; i++) {
    var tr = seq.videoTracks[i];
    for (var j = tr.clips.numItems - 1; j >= 0; j--) {
      var c = tr.clips[j];
      try { if (c.projectItem && set[c.projectItem.name]) { c.remove(false, true); n++; } } catch (e) {}
    }
  }
  return n;
}

/* import the rendered file(s) and lay them on the timeline at `at` */
function cr_place(s) {
  try {
    var a = cr__args(s), seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    if (a.replace && a.replace.length) cr__removeNamed(seq, a.replace);
    var bin = cr__bin(a.bin || 'ENP Carousel');
    var paths = [a.front]; if (a.back) paths.push(a.back);
    app.project.importFiles(paths, true, bin, false);
    var front = cr__findItem(bin, a.front), back = a.back ? cr__findItem(bin, a.back) : null;
    if (!front || (a.back && !back)) return cr__json({ ok: false, error: 'import_failed' });

    var t0 = Number(a.at) || 0, t1 = t0 + (Number(a.duration) || 1);
    var vt = seq.videoTracks, top = -1, under = -1;
    for (var i = 0; i < vt.numTracks; i++) {
      if (!cr__free(vt[i], t0, t1)) top = i;
      if (under < 0) {
        for (var j = 0; j < vt[i].clips.numItems; j++) { var c = vt[i].clips[j]; if (c.start.seconds <= t0 + 0.001 && c.end.seconds > t0) { under = i; break; } }
      }
    }
    var at = new Time(); at.seconds = t0;
    var res = { ok: true, names: [front.name], backAbove: false };

    if (back) {
      /* the back layer goes under the speaker's clip if there is a free track below it */
      var speaker = under >= 0 ? under : top, bi = -1;
      for (var b = speaker - 1; b >= 0; b--) if (cr__free(vt[b], t0, t1)) { bi = b; break; }
      if (bi < 0) {
        bi = cr__trackAbove(seq, top, t0, t1);
        if (bi < 0) return cr__json({ ok: false, error: 'no_free_track' });
        res.backAbove = true;
      }
      seq.videoTracks[bi].overwriteClip(back, at);
      res.back = 'V' + (bi + 1); res.names.push(back.name);
      if (bi > top) top = bi;
    }
    var fi = cr__trackAbove(seq, top, t0, t1);
    if (fi < 0) return cr__json({ ok: false, error: 'no_free_track' });
    seq.videoTracks[fi].overwriteClip(front, at);
    res.track = 'V' + (fi + 1);
    try { var placed = cr__findClip(seq, { track: fi, start: t0 }); if (placed) res.ref = { track: fi, start: placed.start.seconds, id: String(placed.nodeId) }; } catch (e) {}
    return cr__json(res);
  } catch (e) { return cr__fail(e); }
}

function cr_remove(s) {
  try {
    var a = cr__args(s), seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    return cr__json({ ok: true, removed: cr__removeNamed(seq, a.names || []) });
  } catch (e) { return cr__fail(e); }
}

/* ===================== shared: clips, Motion, keyframes ===================== */
function cr_seek(s) {
  try {
    var a = cr__args(s), seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    seq.setPlayerPosition(String(Math.round(Number(a.t) * 254016000000)));
    return cr__json({ ok: true });
  } catch (e) { return cr__fail(e); }
}
function cr__motion(clip) {
  for (var i = 0; i < clip.components.numItems; i++) {
    var c = clip.components[i];
    try { if (c.matchName === 'AE.ADBE Motion') return c; } catch (e) {}
  }
  for (var j = 0; j < clip.components.numItems; j++) if (clip.components[j].displayName === 'Motion') return clip.components[j];
  return null;
}
/* Motion parameters by position: 0 Position, 1 Scale, 2 Scale Width, 3 Uniform, 4 Rotation, 5 Anchor Point */
function cr__param(clip, which) {
  var m = cr__motion(clip); if (!m) return null;
  var idx = { pos: 0, scale: 1, rot: 4, anchor: 5 }[which];
  return m.properties[idx];
}
function cr__clipInfo(clip, ti) {
  var o = { track: ti, start: clip.start.seconds, end: clip.end.seconds, inPoint: clip.inPoint.seconds, name: clip.name, id: '', path: '' };
  try { o.id = String(clip.nodeId); } catch (e) {}
  try { o.path = clip.projectItem ? clip.projectItem.getMediaPath() : ''; } catch (e) {}
  try {
    var ps = cr__param(clip, 'scale'), pp = cr__param(clip, 'pos'), pa = cr__param(clip, 'anchor');
    o.keyed = !!(ps.isTimeVarying() || pp.isTimeVarying());
    o.scale = ps.getValue();
    if (ps.isTimeVarying()) { try { o.scale = ps.getValueAtTime(clip.inPoint.seconds); } catch (e3) {} }
    if (typeof o.scale !== 'number' || !(o.scale > 0)) o.scale = 100;
    var pv = pp.getValue(), av = pa.getValue();
    o.pos = [pv[0], pv[1]]; o.anchor = [av[0], av[1]];
  } catch (e2) { o.noMotion = true; }
  return o;
}
function cr__findClip(seq, ref) {
  var tr = seq.videoTracks[ref.track];
  if (tr) {
    for (var i = 0; i < tr.clips.numItems; i++) {
      var c = tr.clips[i];
      try { if (ref.id && String(c.nodeId) === ref.id) return c; } catch (e) {}
    }
    for (var j = 0; j < tr.clips.numItems; j++) if (Math.abs(tr.clips[j].start.seconds - ref.start) < 0.002) return tr.clips[j];
  }
  return null;
}
function cr__topAt(seq, t) {
  for (var i = seq.videoTracks.numTracks - 1; i >= 0; i--) {
    var tr = seq.videoTracks[i];
    for (var j = 0; j < tr.clips.numItems; j++) {
      var c = tr.clips[j];
      if (c.start.seconds <= t + 0.0005 && c.end.seconds > t && c.projectItem) {
        var mp = ''; try { mp = c.projectItem.getMediaPath(); } catch (e) {}
        if (mp && !/^(Carousel3D|AmarText|AmarGlass|ENP)_/.test(c.projectItem.name)) return { clip: c, track: i };
      }
    }
  }
  return null;
}
/* selected video clips; if none, the top clip under the playhead */
function cr_clips(s) {
  try {
    var a = cr__args(s), seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var out = [], sel = seq.getSelection(), seen = {};
    for (var i = 0; i < sel.length; i++) {
      var ti = sel[i];
      try { if (ti.mediaType && ti.mediaType !== 'Video') continue; } catch (e) {}
      for (var k = 0; k < seq.videoTracks.numTracks; k++) {
        var tr = seq.videoTracks[k];
        for (var j = 0; j < tr.clips.numItems; j++) {
          var c = tr.clips[j];
          if (Math.abs(c.start.seconds - ti.start.seconds) < 0.0005 && c.name === ti.name && !seen[k + '|' + j]) { seen[k + '|' + j] = 1; out.push(cr__clipInfo(c, k)); }
        }
      }
    }
    var t = seq.getPlayerPosition().seconds;
    if (!out.length && a.fallback !== false) { var top = cr__topAt(seq, t); if (top) out.push(cr__clipInfo(top.clip, top.track)); }
    return cr__json({
      ok: true, clips: out, t: t, w: Number(seq.frameSizeHorizontal), h: Number(seq.frameSizeVertical), fps: cr__fps(seq), selected: sel.length
    });
  } catch (e) { return cr__fail(e); }
}
/* the clip under the playhead, for tracking */
function cr_under2(s) {
  try {
    var a = cr__args(s), seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var t = (a.t !== undefined && a.t !== null) ? Number(a.t) + 0.001 : seq.getPlayerPosition().seconds, top = cr__topAt(seq, t);
    if (!top) return cr__json({ ok: true, none: true, t: t });
    var o = cr__clipInfo(top.clip, top.track);
    o.src = t - top.clip.start.seconds + top.clip.inPoint.seconds;
    return cr__json({ ok: true, clip: o, t: t, w: Number(seq.frameSizeHorizontal), h: Number(seq.frameSizeVertical), fps: cr__fps(seq) });
  } catch (e) { return cr__fail(e); }
}
function cr__addKey(p, kt) { try { p.addKey(kt); } catch (e) { var tm = new Time(); tm.seconds = kt; p.addKey(tm); } }
function cr__setKey(p, kt, v, ui) { try { p.setValueAtKey(kt, v, ui); } catch (e) { var tm = new Time(); tm.seconds = kt; p.setValueAtKey(tm, v, ui); } }
/* keys: [[seqSeconds, value], ...]; value = number (scale) or [x, y] (position, 0..1 of the frame)
   reset: wipe the parameter's keyframes first. Key times are in the clip's media time. */
function cr_keys(s) {
  try {
    var a = cr__args(s), seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var clip = cr__findClip(seq, a.clip);
    if (!clip) return cr__json({ ok: false, error: 'clip_moved' });
    var p = cr__param(clip, a.prop);
    if (!p) return cr__json({ ok: false, error: 'no_motion' });
    if (a.reset) { if (p.isTimeVarying()) p.setTimeVarying(false); }
    if (a.value !== undefined && a.value !== null) p.setValue(a.value, true);
    var keys = a.keys || [];
    if (keys.length) {
      if (!p.isTimeVarying()) p.setTimeVarying(true);
      var off = clip.inPoint.seconds - clip.start.seconds, n = 0;
      for (var i = 0; i < keys.length; i++) {
        var kt = keys[i][0] + off;
        cr__addKey(p, kt); cr__setKey(p, kt, keys[i][1], i === keys.length - 1); n++;
      }
      return cr__json({ ok: true, n: n });
    }
    return cr__json({ ok: true, n: 0 });
  } catch (e) { return cr__fail(e); }
}
/* back to how it was: no keyframes, the saved values */
function cr_unkey(s) {
  try {
    var a = cr__args(s), seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var clip = cr__findClip(seq, a.clip);
    if (!clip) return cr__json({ ok: false, error: 'clip_moved' });
    var props = a.props || ['scale', 'pos'];
    for (var i = 0; i < props.length; i++) {
      var p = cr__param(clip, props[i]); if (!p) continue;
      if (p.isTimeVarying()) p.setTimeVarying(false);
      if (a.base && a.base[props[i]] !== undefined && a.base[props[i]] !== null) p.setValue(a.base[props[i]], true);
    }
    return cr__json({ ok: true });
  } catch (e) { return cr__fail(e); }
}

/* ===================== sound effects ===================== */
function cr_sfx(s) {
  try {
    var a = cr__args(s), seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var bin = cr__bin('SFX'), item = cr__findItem(bin, a.path);
    if (!item) { app.project.importFiles([a.path], true, bin, false); item = cr__findItem(bin, a.path); }
    if (!item) return cr__json({ ok: false, error: 'import_failed' });
    var t0 = a.at !== undefined && a.at !== null ? Number(a.at) : seq.getPlayerPosition().seconds;
    var dur = Number(a.dur) || 0;
    try { if (!dur) dur = item.getOutPoint().seconds - item.getInPoint().seconds; } catch (e) {}
    if (!(dur > 0)) dur = 1;
    var at = seq.audioTracks, idx = -1;
    for (var i = 0; i < at.numTracks; i++) if (cr__free(at[i], t0, t0 + dur)) { idx = i; break; }
    if (idx < 0) {
      try { app.enableQE(); qe.project.getActiveSequence().addTracks(0, 0, 1, 1, at.numTracks); } catch (e) {}
      for (var j = 0; j < seq.audioTracks.numTracks; j++) if (cr__free(seq.audioTracks[j], t0, t0 + dur)) { idx = j; break; }
    }
    if (idx < 0) return cr__json({ ok: false, error: 'no_free_track' });
    var tm = new Time(); tm.seconds = t0;
    seq.audioTracks[idx].overwriteClip(item, tm);
    return cr__json({ ok: true, track: 'A' + (idx + 1), at: t0 });
  } catch (e) { return cr__fail(e); }
}

/* ===================== keyframe curves ===================== */
function cr__isNumVal(v) {
  if (typeof v === 'number') return isFinite(v);
  if (v && v.length !== undefined && v.length > 0 && v.length <= 4) { for (var i = 0; i < v.length; i++) if (typeof v[i] !== 'number') return false; return true; }
  return false;
}
function cr__trackItemRef(seq, ti) {
  var groups = [['v', seq.videoTracks], ['a', seq.audioTracks]];
  for (var g = 0; g < groups.length; g++) {
    var tracks = groups[g][1];
    for (var k = 0; k < tracks.numTracks; k++) {
      var tr = tracks[k];
      for (var j = 0; j < tr.clips.numItems; j++) {
        var c = tr.clips[j];
        if (Math.abs(c.start.seconds - ti.start.seconds) < 0.0005 && c.name === ti.name) {
          var id = ''; try { id = String(c.nodeId); } catch (e) {}
          return { type: groups[g][0], track: k, start: c.start.seconds, inPoint: c.inPoint.seconds, end: c.end.seconds, id: id, name: c.name, clip: c };
        }
      }
    }
  }
  return null;
}
function cr__findAny(seq, ref) {
  var tracks = ref.type === 'a' ? seq.audioTracks : seq.videoTracks, tr = tracks[ref.track];
  if (!tr) return null;
  for (var i = 0; i < tr.clips.numItems; i++) { var c = tr.clips[i]; try { if (ref.id && String(c.nodeId) === ref.id) return c; } catch (e) {} }
  for (var j = 0; j < tr.clips.numItems; j++) if (Math.abs(tr.clips[j].start.seconds - ref.start) < 0.002) return tr.clips[j];
  return null;
}
function cr__secs(t) { return (t && t.seconds !== undefined) ? t.seconds : Number(t); }
function cr_kfList(s) {
  try {
    var seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var sel = seq.getSelection(), out = [], seen = {};
    for (var i = 0; i < sel.length; i++) {
      var ref = cr__trackItemRef(seq, sel[i]); if (!ref) continue;
      var key = ref.type + ref.track + '|' + ref.start; if (seen[key]) continue; seen[key] = 1;
      var c = ref.clip; delete ref.clip;
      for (var ci = 0; ci < c.components.numItems; ci++) {
        var comp = c.components[ci];
        for (var pi = 0; pi < comp.properties.numItems; pi++) {
          var p = comp.properties[pi], tv = false;
          try { tv = p.isTimeVarying(); } catch (e) {}
          if (!tv) continue;
          var ks = []; try { ks = p.getKeys() || []; } catch (e) { ks = []; }
          if (ks.length < 2) continue;
          var keys = [], okv = true;
          for (var k = 0; k < ks.length; k++) {
            var v; try { v = p.getValueAtKey(ks[k]); } catch (e) { okv = false; break; }
            if (!cr__isNumVal(v)) { okv = false; break; }
            var vv = typeof v === 'number' ? v : []; if (typeof v !== 'number') for (var q = 0; q < v.length; q++) vv.push(v[q]);
            keys.push([cr__secs(ks[k]), vv]);
          }
          if (!okv) continue;
          out.push({ clip: ref, comp: ci, prop: pi, cname: comp.displayName, pname: p.displayName, keys: keys });
        }
      }
    }
    return cr__json({ ok: true, params: out, t: seq.getPlayerPosition().seconds, fps: cr__fps(seq), selected: sel.length });
  } catch (e) { return cr__fail(e); }
}
function cr__param2(seq, a) {
  var c = cr__findAny(seq, a.clip); if (!c) return null;
  var comp = c.components[a.comp]; if (!comp) return null;
  return comp.properties[a.prop] || null;
}
function cr_kfAdd(s) {
  try {
    var a = cr__args(s), seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var p = cr__param2(seq, a); if (!p) return cr__json({ ok: false, error: 'clip_moved' });
    var keys = a.keys || [];
    for (var i = 0; i < keys.length; i++) {
      cr__addKey(p, keys[i][0]); cr__setKey(p, keys[i][0], keys[i][1], i === keys.length - 1);
      if (a.linear) { try { p.setInterpolationTypeAtKey(keys[i][0], 0, false); } catch (e) {} }
    }
    return cr__json({ ok: true, n: keys.length });
  } catch (e) { return cr__fail(e); }
}
function cr_kfRemove(s) {
  try {
    var a = cr__args(s), seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var p = cr__param2(seq, a); if (!p) return cr__json({ ok: false, error: 'clip_moved' });
    var n = 0, ts = a.times || [];
    for (var i = 0; i < ts.length; i++) {
      try { p.removeKey(ts[i]); n++; } catch (e) { try { var tm = new Time(); tm.seconds = ts[i]; p.removeKey(tm); n++; } catch (e2) {} }
    }
    return cr__json({ ok: true, n: n });
  } catch (e) { return cr__fail(e); }
}

/* ===================== smart cut (silences) ===================== */
function cr_clone(s) {
  try {
    var seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var name = seq.name;
    seq.clone();
    return cr__json({ ok: true, name: name + ' Copy' });
  } catch (e) { return cr__fail(e); }
}
function cr__tc(seq, sec) {
  var t = new Time(); t.seconds = sec;
  var st = seq.getSettings();
  return t.getFormatted(st.videoFrameRate, st.videoDisplayFormat);
}
function cr__locked(tr) { try { return tr.isLocked(); } catch (e) { return false; } }
/* Smart cut, in two steps so nothing depends on Premiere's ripple / sync-lock settings:
   1) cr_cutRazor: split every track at each cut's edges and delete what lies inside (no ripple)
   2) cr_cutCompact: slide every clip left by the time removed before it, checking each one landed */
function cr_cutMarkers(s) {
  try {
    var a = cr__args(s), seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var cuts = a.cuts || [], n = 0;
    for (var m = 0; m < cuts.length; m++) {
      var mk = seq.markers.createMarker(cuts[m][0]);
      try { mk.name = 'سكتة'; var et = new Time(); et.seconds = cuts[m][1]; mk.end = et; } catch (e) {}
      try { mk.setColorByIndex(1); } catch (e2) {}
      n++;
    }
    return cr__json({ ok: true, done: n });
  } catch (e) { return cr__fail(e); }
}
function cr__groups(seq) {
  app.enableQE();
  var q = qe.project.getActiveSequence();
  return [[seq.videoTracks, function (i) { return q.getVideoTrackAt(i); }], [seq.audioTracks, function (i) { return q.getAudioTrackAt(i); }]];
}
function cr_cutRazor(s) {
  try {
    var a = cr__args(s), seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var cuts = a.cuts || [], eps = 0.0005, groups = cr__groups(seq), removed = 0;
    for (var c = 0; c < cuts.length; c++) {
      var t0 = cuts[c][0], t1 = cuts[c][1];
      if (!(t1 - t0 > 0.01)) continue;
      var tc0 = cr__tc(seq, t0), tc1 = cr__tc(seq, t1);
      for (var g = 0; g < groups.length; g++) {
        var tracks = groups[g][0];
        for (var i = 0; i < tracks.numTracks; i++) {
          var tr = tracks[i]; if (cr__locked(tr)) continue;
          var sp0 = false, sp1 = false;
          for (var j = 0; j < tr.clips.numItems; j++) {
            var cl = tr.clips[j];
            if (cl.start.seconds < t0 - eps && cl.end.seconds > t0 + eps) sp0 = true;
            if (cl.start.seconds < t1 - eps && cl.end.seconds > t1 + eps) sp1 = true;
          }
          var qt = groups[g][1](i);
          if (sp1) qt.razor(tc1);
          if (sp0) qt.razor(tc0);
          for (var k = tr.clips.numItems - 1; k >= 0; k--) {
            var it = tr.clips[k];
            if (it.start.seconds >= t0 - eps && it.end.seconds <= t1 + eps) { it.remove(false, false); removed++; }
          }
        }
      }
    }
    return cr__json({ ok: true, removed: removed });
  } catch (e) { return cr__fail(e); }
}
function cr_cutCompact(s) {
  try {
    var a = cr__args(s), seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var cuts = (a.cuts || []).slice().sort(function (x, y) { return x[0] - y[0]; }), eps = 0.0005;
    function shiftAt(t) { var sh = 0; for (var i = 0; i < cuts.length; i++) if (cuts[i][1] <= t + eps) sh += cuts[i][1] - cuts[i][0]; return sh; }
    var all = [seq.videoTracks, seq.audioTracks], plan = [];
    for (var g = 0; g < all.length; g++) {
      for (var i = 0; i < all[g].numTracks; i++) {
        var tr = all[g][i]; if (cr__locked(tr)) continue;
        for (var j = 0; j < tr.clips.numItems; j++) {
          var st0 = tr.clips[j].start.seconds, sh = shiftAt(st0);
          if (sh > 0.0005) plan.push({ tr: tr, k: j, orig: st0, want: st0 - sh });
        }
      }
    }
    /* earliest first, across all tracks, so a clip never lands on one that hasn't moved yet */
    plan.sort(function (x, y) { return x.orig - y.orig; });
    var moved = 0;
    for (var p = 0; p < plan.length; p++) {
      var P = plan[p], it = P.tr.clips[P.k], delta = P.want - it.start.seconds;
      if (Math.abs(delta) < 0.001) continue;          // already there (it moved with its linked clip)
      var tm = new Time(); tm.seconds = delta; it.move(tm);   // move() shifts by an offset
      if (Math.abs(P.tr.clips[P.k].start.seconds - P.want) > 0.002) {
        // stop before anything gets overwritten; the gaps stay and can be closed by hand
        return cr__json({ ok: false, error: 'move_failed', moved: moved });
      }
      moved++;
    }
    return cr__json({ ok: true, moved: moved });
  } catch (e) { return cr__fail(e); }
}

/* a clip we placed, by its project item name */
function cr_findNamed(s) {
  try {
    var a = cr__args(s), seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var set = {}; for (var i = 0; i < (a.names || []).length; i++) set[a.names[i]] = 1;
    for (var k = 0; k < seq.videoTracks.numTracks; k++) {
      var tr = seq.videoTracks[k];
      for (var j = 0; j < tr.clips.numItems; j++) { var c = tr.clips[j]; try { if (c.projectItem && set[c.projectItem.name]) return cr__json({ ok: true, clip: cr__clipInfo(c, k) }); } catch (e) {} }
    }
    return cr__json({ ok: true, clip: null });
  } catch (e) { return cr__fail(e); }
}

/* captions: put an .srt in as Premiere's own caption track (2021+), or just import it */
function cr_srtCaptions(s) {
  try {
    var a = cr__args(s), seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var bin = cr__bin('ENP Captions');
    app.project.importFiles([a.path], true, bin, false);
    var item = cr__findItem(bin, a.path);
    if (!item) return cr__json({ ok: false, error: 'import_failed' });
    var at = new Time(); at.seconds = Number(a.at) || 0;
    try {
      var fmt = (typeof Sequence !== 'undefined' && Sequence.CAPTION_FORMAT_SUBTITLE !== undefined) ? Sequence.CAPTION_FORMAT_SUBTITLE : 'Subtitle';
      seq.createCaptionTrack(item, at.seconds, fmt);
      return cr__json({ ok: true, track: true });
    } catch (e) { return cr__json({ ok: true, track: false, detail: String(e) }); }
  } catch (e) { return cr__fail(e); }
}
