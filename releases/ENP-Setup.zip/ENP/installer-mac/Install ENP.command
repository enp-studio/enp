#!/bin/bash
# ENP — installer for Adobe Premiere Pro on macOS (no admin rights needed)
cd "$(dirname "$0")"
SRC="$(pwd)/ENP"
ROOT="$HOME/Library/Application Support/Adobe/CEP/extensions"
DST="$ROOT/ENP"
echo ""
echo "   ENP - Editing Power Tools for Premiere Pro"
echo "   ---------------------------------------------"
if [ ! -f "$SRC/CSXS/manifest.xml" ]; then echo "   Unzip everything first, then run this again."; read -n1 -r -p "   Press any key..."; exit 1; fi
mkdir -p "$ROOT"

# keep an ffmpeg we already have
KEEP=""
if [ -x "$DST/runtime/ffmpeg" ]; then KEEP="$(mktemp -t enpff)"; cp "$DST/runtime/ffmpeg" "$KEEP"; fi

echo "   [1/4] Installing the panel..."
if [ -d "$DST" ]; then find "$DST" -mindepth 1 -maxdepth 1 ! -name "_backup" -exec rm -rf {} +; fi
mkdir -p "$DST"
cp -R "$SRC/." "$DST/"
mkdir -p "$DST/runtime"
if [ -n "$KEEP" ]; then cp "$KEEP" "$DST/runtime/ffmpeg"; rm -f "$KEEP"; fi
xattr -dr com.apple.quarantine "$DST" 2>/dev/null

echo "   [2/4] Allowing the panel to load..."
for v in 9 10 11 12 13 14; do defaults write "com.adobe.CSXS.$v" PlayerDebugMode 1; done

echo "   [3/4] ffmpeg..."
FF="$DST/runtime/ffmpeg"
if [ ! -x "$FF" ]; then
  for c in /opt/homebrew/bin/ffmpeg /usr/local/bin/ffmpeg /opt/local/bin/ffmpeg; do if [ -x "$c" ]; then cp "$c" "$FF"; break; fi; done
fi
if [ ! -x "$FF" ]; then
  ARCH="$(uname -m)"; TMP="$(mktemp -d)"
  if [ "$ARCH" = "arm64" ]; then URLS="https://ffmpeg.martin-riedl.de/redirect/latest/macos/arm64/release/ffmpeg.zip https://evermeet.cx/ffmpeg/getrelease/ffmpeg/zip"
  else URLS="https://ffmpeg.martin-riedl.de/redirect/latest/macos/amd64/release/ffmpeg.zip https://evermeet.cx/ffmpeg/getrelease/ffmpeg/zip"; fi
  for u in $URLS; do
    echo "         downloading: $u"
    if curl -L --fail --progress-bar --connect-timeout 20 --retry 2 -o "$TMP/ff.zip" "$u"; then
      (cd "$TMP" && unzip -o -q ff.zip) && F="$(find "$TMP" -type f -name ffmpeg | head -1)" && [ -n "$F" ] && cp "$F" "$FF" && break
    fi
  done
  rm -rf "$TMP"
fi
if [ -f "$FF" ]; then chmod +x "$FF"; xattr -d com.apple.quarantine "$FF" 2>/dev/null; echo "         ready."; else echo "         put ffmpeg in: $DST/runtime  (or: brew install ffmpeg)"; fi

echo "   [4/4] Speech engine for automatic captions (optional)..."
if command -v whisper-cli >/dev/null 2>&1 || [ -x /opt/homebrew/bin/whisper-cli ] || [ -x /usr/local/bin/whisper-cli ]; then echo "         already installed."
else
  BREW="$(command -v brew || ls /opt/homebrew/bin/brew /usr/local/bin/brew 2>/dev/null | head -1)"
  if [ -n "$BREW" ]; then
    read -r -p "         Install it now with Homebrew? (y/n) " a
    if [ "$a" = "y" ] || [ "$a" = "Y" ]; then "$BREW" install whisper-cpp; fi
  else echo "         later: install Homebrew (brew.sh), then run: brew install whisper-cpp"; fi
fi
echo ""
echo "   Installed. Restart Premiere Pro, then: Window > Extensions > ENP"
echo ""
read -n1 -r -p "   Press any key to close..."
