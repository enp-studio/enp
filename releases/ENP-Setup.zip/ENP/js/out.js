/* Amar Studio — render a 2D/GL-drawn graphic to ProRes 4444 (alpha) and put it on the timeline. */
(function (G) {
  'use strict';
  function stamp() {
    var d = new Date(); function p(n) { return ('0' + n).slice(-2); }
    return String(d.getFullYear()).slice(2) + p(d.getMonth() + 1) + p(d.getDate()) + '_' + p(d.getHours()) + p(d.getMinutes()) + p(d.getSeconds());
  }
  /* job: { prefix, bin, w, h, fps, dur, prepare(): Promise, frame(t, i): Promise|void -> returns Uint8ClampedArray RGBA (top-down, straight alpha),
            onProgress(p), cancelled(), replace: [names] } */
  function renderAndPlace(job) {
    var info = null, t0 = Date.now(), enc = null, out = '';
    return Sys.ffAvailable().then(function (ok) {
      if (!ok) throw new Error('no_ffmpeg');
      return Sys.call('cr_info');
    }).then(function (r) {
      if (!r || !r.ok || !r.hasSequence) throw new Error('no_seq');
      info = r; if (job.at !== undefined && job.at !== null) info.t = job.at;
      var W = job.w || r.w, H = job.h || r.h, fps = job.fps || r.fps || 30, n = Math.max(2, Math.round(job.dur * fps));
      var dir = r.dir ? Sys.join(r.dir, 'ENP Renders') : Sys.join(Sys.workDir(), 'renders'); Sys.mkdirp(dir);
      out = Sys.join(dir, job.prefix + '_' + stamp() + '.mov');
      return Promise.resolve(job.prepare ? job.prepare({ w: W, h: H, fps: fps, t: info.t }) : null).then(function () {
        enc = Sys.encoder(out, W, H, fps, { flip: job.flip === true, codec: job.codec });
        var i = 0;
        function step() {
          if (job.cancelled && job.cancelled()) throw new Error('cancelled');
          if (i >= n) return Promise.resolve();
          return Promise.resolve(job.frame(i / fps, i, { w: W, h: H, fps: fps })).then(function (px) {
            return enc.write(px.buffer ? new Uint8Array(px.buffer, px.byteOffset, px.byteLength) : px);
          }).then(function () {
            i++; if (job.onProgress) job.onProgress(i / n);
            return i % 6 === 0 ? new Promise(function (res) { setTimeout(res, 0); }).then(step) : step();
          });
        }
        return step().then(function () { return enc.end(); }).then(function () { return { dur: n / fps }; });
      });
    }).then(function (res) {
      return Sys.call('cr_place', { front: out, back: '', at: info.t, duration: res.dur, replace: job.replace || [], bin: job.bin || 'ENP' }).then(function (r) {
        if (!r || !r.ok) throw new Error(r && (r.error || r.detail) || 'place_failed');
        return { track: r.track, names: r.names || [], ref: r.ref || null, at: info.t, fps: info.fps, ms: Date.now() - t0, path: out };
      });
    }).catch(function (e) { if (enc) enc.kill(); if (out) Sys.remove(out); throw e; });
  }
  /* render only (no timeline): job as above plus w, h, fps; -> { path, dur } */
  function renderFile(job) {
    var enc = null, out = '';
    return Sys.ffAvailable().then(function (ok) {
      if (!ok) throw new Error('no_ffmpeg');
      var W = job.w, H = job.h, fps = job.fps || 30, n = Math.max(2, Math.round(job.dur * fps));
      var dir = job.dir || Sys.join(Sys.workDir(), 'renders'); Sys.mkdirp(dir);
      out = Sys.join(dir, job.prefix + '_' + stamp() + '_' + Math.floor(Math.random() * 1000) + '.mov');
      return Promise.resolve(job.prepare ? job.prepare({ w: W, h: H, fps: fps }) : null).then(function () {
        enc = Sys.encoder(out, W, H, fps, { flip: job.flip === true, codec: job.codec });
        var i = 0;
        function step() {
          if (job.cancelled && job.cancelled()) throw new Error('cancelled');
          if (i >= n) return Promise.resolve();
          return Promise.resolve(job.frame(i / fps, i, { w: W, h: H, fps: fps })).then(function (px) {
            return enc.write(px.buffer ? new Uint8Array(px.buffer, px.byteOffset, px.byteLength) : px);
          }).then(function () { i++; if (job.onProgress) job.onProgress(i / n); return i % 6 === 0 ? new Promise(function (res) { setTimeout(res, 0); }).then(step) : step(); });
        }
        return step().then(function () { return enc.end(); }).then(function () { return { path: out, dur: n / fps }; });
      });
    }).catch(function (e) { if (enc) enc.kill(); if (out) Sys.remove(out); throw e; });
  }
  function errText(e) {
    var m = e && e.message || String(e);
    return { no_ffmpeg: 'مش لاقي ffmpeg.', no_seq: 'افتح سيكوينس الأول.', cancelled: 'اتوقف.' }[m] || ('حصلت مشكلة [' + m.slice(0, 160) + ']');
  }
  /* the picture under the playhead, as a file path to show behind a preview */
  function underFrame(w, h) {
    return Sys.call('cr_under').then(function (r) {
      if (!r || !r.ok || r.none || !r.path) return null;
      return Sys.grabFrame(r.path, r.src, Math.round(w), Math.round(h));
    });
  }
  G.Out = { renderAndPlace: renderAndPlace, renderFile: renderFile, errText: errText, underFrame: underFrame };
})(window);
