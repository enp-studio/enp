/* Carousel 3D — point/box tracker for grey frames.
   Normalised cross-correlation of a sampled template, searched around a
   constant-velocity prediction, coarse then fine, with optional scale. */
(function (G) {
  'use strict';
  function Tracker(w, h, box, opt) {
    opt = opt || {};
    this.w = w; this.h = h; this.scaleOn = !!opt.scale;
    this.cx = box.x + box.w / 2; this.cy = box.y + box.h / 2; this.s = 1; this.vx = 0; this.vy = 0;
    this.bw = box.w; this.bh = box.h;
    var n = Math.max(1, box.w * box.h), stride = Math.max(1, Math.round(Math.sqrt(n / 900)));
    var ox = [], oy = [];
    for (var y = -box.h / 2 + stride / 2; y < box.h / 2; y += stride) for (var x = -box.w / 2 + stride / 2; x < box.w / 2; x += stride) { ox.push(x); oy.push(y); }
    this.ox = new Float32Array(ox); this.oy = new Float32Array(oy); this.n = ox.length;
    this.tpl = new Float32Array(this.n); this.tpl0 = null; this.lostRun = 0;
  }
  function sample(img, w, h, x, y) {
    var xi = x | 0, yi = y | 0;
    if (xi < 0) xi = 0; else if (xi >= w) xi = w - 1;
    if (yi < 0) yi = 0; else if (yi >= h) yi = h - 1;
    return img[yi * w + xi];
  }
  /* zero-mean, unit-norm values at (cx,cy,s) */
  Tracker.prototype.patch = function (img, cx, cy, s, out) {
    var n = this.n, sum = 0, sq = 0, i, v;
    for (i = 0; i < n; i++) { v = sample(img, this.w, this.h, cx + this.ox[i] * s, cy + this.oy[i] * s); out[i] = v; sum += v; }
    var m = sum / n;
    for (i = 0; i < n; i++) { out[i] -= m; sq += out[i] * out[i]; }
    var nr = Math.sqrt(sq) || 1;
    for (i = 0; i < n; i++) out[i] /= nr;
    return Math.sqrt(sq / n);  // contrast
  };
  Tracker.prototype.init = function (img) {
    this.patch(img, this.cx, this.cy, 1, this.tpl);
    this.tpl0 = new Float32Array(this.tpl);
    return { cx: this.cx, cy: this.cy, s: 1, score: 1 };
  };
  Tracker.prototype.score = function (img, cx, cy, s) {
    var n = this.n, sum = 0, sq = 0, dot = 0, i, v, w = this.w, h = this.h, ox = this.ox, oy = this.oy, T = this.tpl;
    for (i = 0; i < n; i++) {
      v = sample(img, w, h, cx + ox[i] * s, cy + oy[i] * s);
      sum += v; sq += v * v; dot += v * T[i];
    }
    var varr = sq - sum * sum / n;
    if (varr <= 1e-6) return 0;
    return dot / Math.sqrt(varr);   // template is zero-mean & unit-norm
  };
  Tracker.prototype.search = function (img, px, py, s, R, step) {
    var best = -2, bx = px, by = py;
    for (var dy = -R; dy <= R; dy += step) for (var dx = -R; dx <= R; dx += step) {
      var sc = this.score(img, px + dx, py + dy, s);
      if (sc > best) { best = sc; bx = px + dx; by = py + dy; }
    }
    return { x: bx, y: by, sc: best };
  };
  Tracker.prototype.step = function (img) {
    var px = this.cx + this.vx, py = this.cy + this.vy;
    var R = Math.max(10, Math.round(Math.max(this.bw, this.bh) * this.s * .55 + Math.hypot(this.vx, this.vy)));
    var coarse = R > 24 ? 3 : 2;
    var b = this.search(img, px, py, this.s, R, coarse);
    b = this.search(img, b.x, b.y, this.s, coarse, 1);
    var bs = this.s;
    if (this.scaleOn) {
      [.965, 1.035].forEach(function (k) {
        var s2 = this.s * k, c = this.search(img, b.x, b.y, s2, 2, 1);
        if (c.sc > b.sc + .004) { b = c; bs = s2; }
      }, this);
    }
    /* half-pixel refine (parabola on x and y) */
    var l = this.score(img, b.x - 1, b.y, bs), r = this.score(img, b.x + 1, b.y, bs), u = this.score(img, b.x, b.y - 1, bs), d = this.score(img, b.x, b.y + 1, bs);
    var fx = b.x, fy = b.y, den;
    den = l - 2 * b.sc + r; if (den < 0) fx += Math.max(-.5, Math.min(.5, .5 * (l - r) / den));
    den = u - 2 * b.sc + d; if (den < 0) fy += Math.max(-.5, Math.min(.5, .5 * (u - d) / den));
    var ok = b.sc > .5;
    if (ok) {
      this.vx = .6 * this.vx + .4 * (fx - this.cx); this.vy = .6 * this.vy + .4 * (fy - this.cy);
      this.cx = fx; this.cy = fy; this.s = bs; this.lostRun = 0;
      if (b.sc > .75) { // adapt slowly, anchored to the first look
        var cur = new Float32Array(this.n); this.patch(img, fx, fy, bs, cur);
        var T = this.tpl, T0 = this.tpl0, sq = 0, i;
        for (i = 0; i < this.n; i++) { T[i] = .8 * T[i] + .12 * cur[i] + .08 * T0[i]; sq += T[i] * T[i]; }
        var m = 0; for (i = 0; i < this.n; i++) m += T[i]; m /= this.n; sq = 0;
        for (i = 0; i < this.n; i++) { T[i] -= m; sq += T[i] * T[i]; }
        var nr = Math.sqrt(sq) || 1; for (i = 0; i < this.n; i++) T[i] /= nr;
      }
    } else {
      this.lostRun++;
      this.cx = px; this.cy = py;    // coast on the prediction for a moment
    }
    return { cx: this.cx, cy: this.cy, s: this.s, score: b.sc, lost: this.lostRun >= 4, ok: ok };
  };

  /* smooth a list of numbers (gaussian, edges held) */
  function smooth(arr, sigma) {
    if (!(sigma > .3) || arr.length < 3) return arr.slice();
    var r = Math.ceil(sigma * 2.5), k = [], i, j, s = 0;
    for (i = -r; i <= r; i++) { var v = Math.exp(-i * i / (2 * sigma * sigma)); k.push(v); s += v; }
    k = k.map(function (v) { return v / s; });
    var out = new Array(arr.length);
    for (i = 0; i < arr.length; i++) {
      var acc = 0;
      for (j = -r; j <= r; j++) {
        var q = i + j, n1 = arr.length - 1, v2;
        /* odd reflection at the ends keeps a steady motion steady (no lag at the first/last frame) */
        if (q < 0) v2 = 2 * arr[0] - arr[Math.min(n1, -q)];
        else if (q > n1) v2 = 2 * arr[n1] - arr[Math.max(0, 2 * n1 - q)];
        else v2 = arr[q];
        acc += v2 * k[j + r];
      }
      out[i] = acc;
    }
    return out;
  }

  G.CarTracker = { Tracker: Tracker, smooth: smooth };
})(typeof window !== 'undefined' ? window : globalThis);
