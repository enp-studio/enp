/* Carousel 3D — automatic zoom on speech.
   Hears where each sentence starts (the silences between them, from the clip's
   own audio) and changes the zoom a little on each one: Scale / Position
   keyframes on the clip's Motion effect. */
(function (G) {
  'use strict';
  var K = G.K, h = K.h, st = K.store('c3d_zm_');
  var L = {
    intro: 'زووم خفيف بيتغيّر مع كل جملة عشان اللقطة الطويلة ماتبقاش مملة. بيتحط كيفريمز Scale (وPosition لو الشخص مش في النص) على الكليب نفسه.',
    pick: 'اختار الكليبات في التايملاين (أو سيب المؤشر على الكليب) واضغط «اسمع الكلام».',
    analyze: 'اسمع الكلام', analyzing: 'بسمع {n}…', apply: 'حط الزووم', clear: 'شيل الزووم', shuffle: 'غيّرلي التوزيعة',
    map: 'سلّم الزووم', map_hint: 'البنفسجي كلام، والخط اللي فوقه الزووم. دوس في أي مكان عشان المؤشر يروحله.',
    k_moves: 'حركة', k_peak: 'أعلى زووم', k_every: 'واحدة كل', k_keys: 'كيفريم',
    look: 'شكل الزووم', strength: 'أقصى زووم', step: 'فرق الدرجة', motion: 'شكل التغيير', m_smooth: 'بحركة', m_cut: 'قطع (من غير حركة)',
    movems: 'مدة الحركة', reset: 'يرجع للأصل كل', moves_u: 'حركات', drift: 'زحف بطيء جوه الجملة الطويلة', driftamt: 'مقدار الزحف',
    anchor: 'الشخص قاعد فين في الكادر؟', anchor_hint: 'الزووم بيروح ناحية النقطة دي.',
    ears: 'سماع الجمل', noise: 'السكوت أقل من', boundary: 'السكتة اللي تعتبر آخر جملة', mingap: 'أقل مسافة بين حركتين', minrun: 'أقصر كلام يستاهل حركة',
    no_seq: 'افتح سيكوينس الأول.', no_clips: 'مفيش كليب فيديو مختار ولا تحت المؤشر.', no_audio: '«{n}» مالوش صوت — اختار الكليب اللي فيه الكلام.',
    keyed: 'تنبيه: {n} عليه كيفريمز Scale/Position قبل كده، وهيتشالوا.',
    ready: 'جاهز — {n} حركة. بص على السلّم وبعدين «حط الزووم».', none: 'ملقتش جمل كفاية — قلّل «أقصر كلام» أو «أقل مسافة».',
    applying: 'بحط الكيفريمز… {p}%', done: 'تمام — {n} حركة على {c} كليب ({k} كيفريم).', capped: 'الكليب طويل فقللت الحركات عشان الكيفريمز ماتتقلش.',
    cleared: 'الزووم اتشال من {n} كليب ورجع زي ما كان.', clear_none: 'مفيش زووم مننا على الكليبات المختارة.',
    failed: 'حصلت مشكلة', moved: 'الكليب اتحرّك من مكانه — اعمل «اسمع الكلام» تاني.'
  };
  function t(k, v) { var s = L[k] || k; if (v) for (var x in v) s = s.replace('{' + x + '}', v[x]); return s; }
  var DEF = { strength: 15, step: 6, motion: 'smooth', movems: .3, reset: 4, drift: true, driftamt: 3, ax: .5, ay: .4,
    noise: -34, boundary: .3, mingap: 1.4, minrun: .8, seed: 1 };
  var P = (function () { var s = st.get('set', {}), o = {}; for (var k in DEF) o[k] = s[k] !== undefined ? s[k] : DEF[k]; return o; })();
  function save() { st.set('set', P); }
  var A = null;      // analysis: { clips:[{info, speech:[{a,b}] (sequence s)}], fps, w, h }
  var plans = [];    // per clip: { pts:[[t,z]], moves, keysN, capped }
  var ui = {};

  /* ---------- planning ---------- */
  function rng(seed) { var a = seed >>> 0; return function () { a = (a + 0x6D2B79F5) | 0; var t2 = Math.imul(a ^ (a >>> 15), 1 | a); t2 = (t2 + Math.imul(t2 ^ (t2 >>> 7), 61 | t2)) ^ t2; return ((t2 ^ (t2 >>> 14)) >>> 0) / 4294967296; }; }
  function eio(x) { return x < .5 ? 2 * x * x : 1 - Math.pow(-2 * x + 2, 2) / 2; }
  function planClip(cl, fps, gapMul) {
    var c = cl.info, t0 = c.start, t1 = c.end, fr = 1 / (fps || 30);
    var maxK = Math.max(1, Math.round(P.strength / Math.max(1, P.step)));
    var zOf = function (k) { return 1 + Math.min(P.strength, k * P.step) / 100; };
    var R = rng(P.seed * 7919 + Math.round(c.start * 100));
    var gap = P.mingap * (gapMul || 1);
    /* where moves go: the start of each sentence long enough, far enough from the last move */
    var bounds = [], last = t0;
    cl.speech.forEach(function (s, i) {
      if (s.b - s.a < P.minrun) return;
      if (i === 0 && s.a - t0 < .4) return;           // already talking at the clip's start
      if (s.a - last < gap || t1 - s.a < .6) return;
      bounds.push(s.a); last = s.a;
    });
    var levels = [0], cur = 0, since = 0;
    bounds.forEach(function () {
      var nx;
      if (since >= P.reset - 1 && cur !== 0) { nx = 0; since = 0; }
      else { do { nx = 1 + Math.floor(R() * maxK); } while (nx === cur && maxK > 1); since++; }
      levels.push(nx); cur = nx;
    });
    /* zoom curve as points [t, z] */
    var pts = [[t0, zOf(levels[0])]], md = P.motion === 'cut' ? 0 : Math.max(fr * 2, P.movems);
    var holdStart = t0, zHold = zOf(levels[0]);
    function holdTo(tEnd) { // drift while holding a level
      var len = tEnd - holdStart, z = zHold;
      if (P.drift && len > 2.2) { z = zHold * (1 + (P.driftamt / 100) * Math.min(1, len / 6)); pts.push([tEnd, z]); }
      else pts.push([tEnd, zHold]);
      return z;
    }
    bounds.forEach(function (b, i) {
      var zNew = zOf(levels[i + 1]);
      if (md <= 0) { var zp = holdTo(Math.max(holdStart + fr, b - fr)); pts.push([b, zNew]); void zp; }
      else {
        var a = Math.max(holdStart + fr, b - md * .6), e = b + md * .4;
        var zFrom = holdTo(a);
        for (var j = 1; j <= 4; j++) { var k = j / 4; pts.push([a + (e - a) * k, zFrom + (zNew - zFrom) * eio(k)]); }
        b = e;
      }
      holdStart = b; zHold = zNew;
    });
    holdTo(t1 - fr);
    return { pts: pts, moves: bounds.length, peak: Math.max.apply(null, pts.map(function (p) { return p[1]; })) };
  }
  function planAll() {
    plans = [];
    if (!A) return;
    A.clips.forEach(function (cl) {
      var mul = 1, p = planClip(cl, A.fps, mul), capped = false;
      while (p.pts.length > 400 && mul < 6) { mul *= 1.3; p = planClip(cl, A.fps, mul); capped = true; }
      p.capped = capped; plans.push(p);
    });
  }
  function keysFor(cl, p) {
    var c = cl.info, base = c.scale || 100, P0 = c.pos || [.5, .5], ax = P.ax, ay = P.ay;
    var usePos = Math.abs(ax - P0[0]) > .001 || Math.abs(ay - P0[1]) > .001;
    var scale = p.pts.map(function (q) { return [q[0], Math.round(base * q[1] * 100) / 100]; });
    var pos = usePos ? p.pts.map(function (q) { return [q[0], [ax + (P0[0] - ax) * q[1], ay + (P0[1] - ay) * q[1]]]; }) : null;
    return { scale: scale, pos: pos };
  }

  /* ---------- map ---------- */
  function drawMap() {
    var cv = ui.map, w = cv.clientWidth || 300, hh = 96, dpr = Math.min(2, G.devicePixelRatio || 1);
    cv.width = Math.round(w * dpr); cv.height = Math.round(hh * dpr);
    var x = cv.getContext('2d'); x.setTransform(dpr, 0, 0, dpr, 0, 0); x.clearRect(0, 0, w, hh);
    if (!A || !A.clips.length) return;
    var t0 = Math.min.apply(null, A.clips.map(function (c) { return c.info.start; })), t1 = Math.max.apply(null, A.clips.map(function (c) { return c.info.end; }));
    var X = function (tt) { return (tt - t0) / Math.max(.01, t1 - t0) * w; };
    var zMax = 1 + P.strength / 100 + P.driftamt / 100;
    var Y = function (z) { return hh - 22 - (z - 1) / Math.max(.01, zMax - 1) * (hh - 34); };
    x.fillStyle = 'rgba(255,255,255,.04)'; x.fillRect(0, hh - 18, w, 14);
    A.clips.forEach(function (cl, i) {
      x.fillStyle = 'rgba(178,54,94,.8)';
      cl.speech.forEach(function (s) { x.fillRect(X(s.a), hh - 17, Math.max(1, X(s.b) - X(s.a)), 12); });
      var p = plans[i]; if (!p) return;
      x.strokeStyle = '#e48aa6'; x.lineWidth = 2; x.beginPath();
      p.pts.forEach(function (q, j) { var px = X(q[0]), py = Y(q[1]); j ? x.lineTo(px, py) : x.moveTo(px, py); });
      x.stroke();
    });
    if (ui.playT !== undefined) { x.fillStyle = '#ff6b6b'; x.fillRect(X(ui.playT) - 1, 0, 2, hh); }
    var moves = plans.reduce(function (a, p) { return a + p.moves; }, 0), peak = plans.reduce(function (a, p) { return Math.max(a, p.peak); }, 1);
    var keys = A.clips.reduce(function (a, cl, i) { var k = keysFor(cl, plans[i]); return a + k.scale.length + (k.pos ? k.pos.length : 0); }, 0);
    var tot = A.clips.reduce(function (a, cl) { return a + cl.info.end - cl.info.start; }, 0);
    ui.stats.innerHTML = '';
    [[moves, t('k_moves')], [Math.round((peak - 1) * 100) + '%', t('k_peak')], [moves ? (tot / moves).toFixed(1) + 'ث' : '—', t('k_every')], [keys, t('k_keys')]]
      .forEach(function (s) { ui.stats.appendChild(h('div', { class: 'kpi' }, [h('b', { text: String(s[0]) }), h('span', { text: s[1] })])); });
    ui.mapWrap.classList.remove('hide');
  }
  function replan() { save(); planAll(); drawMap(); }

  /* ---------- actions ---------- */
  function analyze() {
    ui.status.show('busy', t('analyzing', { n: '' }));
    Sys.call('cr_clips').then(function (r) {
      if (!r || !r.ok) throw new Error(r && r.error === 'no_sequence' ? t('no_seq') : (r && (r.error || r.detail)) || 'host');
      if (!r.clips.length) throw new Error(t('no_clips'));
      var res = { clips: [], fps: r.fps, w: r.w, h: r.h }, keyed = [];
      return r.clips.reduce(function (pr, c) {
        return pr.then(function () {
          ui.status.show('busy', t('analyzing', { n: c.name }));
          if (c.keyed) keyed.push(c.name);
          return Sys.silences(c.path, c.inPoint, c.end - c.start, P.noise, P.boundary).then(function (sp) {
            res.clips.push({ info: c, speech: sp.map(function (s) { return { a: c.start + s.a, b: c.start + s.b }; }) });
          }, function (e) { if (String(e.message) === 'no_audio') throw new Error(t('no_audio', { n: c.name })); throw e; });
        });
      }, Promise.resolve()).then(function () {
        A = res; ui.playT = r.t; planAll(); drawMap();
        var n = plans.reduce(function (a, p) { return a + p.moves; }, 0);
        ui.applyBtn.disabled = !n;
        ui.status.show(n ? 'ok' : 'warn', (n ? t('ready', { n: n }) : t('none')) + (keyed.length ? '  ' + t('keyed', { n: keyed.join('، ') }) : ''));
      });
    }).catch(function (e) { ui.status.show('err', e.message || String(e)); });
  }
  function apply() {
    if (!A || !plans.length) return;
    ui.applyBtn.disabled = true;
    var jobs = [], total = 0, bases = st.get('bases', {});
    A.clips.forEach(function (cl, i) {
      var k = keysFor(cl, plans[i]), ref = { track: cl.info.track, start: cl.info.start, id: cl.info.id };
      var bk = cl.info.path + '|' + cl.info.start.toFixed(3);
      if (!bases[bk]) bases[bk] = { scale: cl.info.scale, pos: cl.info.pos };
      jobs.push({ ref: ref, prop: 'scale', keys: k.scale }); total += k.scale.length;
      if (k.pos) { jobs.push({ ref: ref, prop: 'pos', keys: k.pos }); total += k.pos.length; }
    });
    st.set('bases', bases);
    var done = 0;
    ui.prog.set(0);
    jobs.reduce(function (pr, j) {
      return pr.then(function () {
        var first = true;
        return K.chunks(j.keys, 60, function (part) {
          var r0 = first; first = false;
          return Sys.call('cr_keys', { clip: j.ref, prop: j.prop, keys: part, reset: r0 }).then(function (r) {
            if (!r || !r.ok) throw new Error(r && r.error === 'clip_moved' ? t('moved') : t('failed') + ' [' + (r && (r.error || r.detail)) + ']');
            done += part.length; ui.prog.set(done / total); ui.status.show('busy', t('applying', { p: Math.round(done / total * 100) }));
          });
        });
      });
    }, Promise.resolve()).then(function () {
      var moves = plans.reduce(function (a, p) { return a + p.moves; }, 0);
      ui.status.show('ok', t('done', { n: moves, c: A.clips.length, k: total }) + (plans.some(function (p) { return p.capped; }) ? '  ' + t('capped') : ''));
    }).catch(function (e) { ui.status.show('err', e.message || String(e)); }).then(function () { ui.prog.done(); ui.applyBtn.disabled = false; });
  }
  function clear() {
    Sys.call('cr_clips', { fallback: true }).then(function (r) {
      if (!r || !r.ok) throw new Error(t('no_seq'));
      var bases = st.get('bases', {}), n = 0;
      return r.clips.reduce(function (pr, c) {
        return pr.then(function () {
          var bk = c.path + '|' + c.start.toFixed(3), b = bases[bk];
          if (!b && !c.keyed) return;
          return Sys.call('cr_unkey', { clip: { track: c.track, start: c.start, id: c.id }, props: ['scale', 'pos'], base: b || {} }).then(function (x) {
            if (x && x.ok) { n++; delete bases[bk]; }
          });
        });
      }, Promise.resolve()).then(function () { st.set('bases', bases); ui.status.show(n ? 'ok' : 'warn', n ? t('cleared', { n: n }) : t('clear_none')); });
    }).catch(function (e) { ui.status.show('err', e.message || String(e)); });
  }

  /* ---------- build ---------- */
  function pctf(v) { return Math.round(v) + '%'; }
  function secf(v) { return (+v).toFixed(2).replace(/0$/, '') + ' ث'; }
  function sl(key, label, min, max, step, fmt, live) {
    return K.slider({ label: t(label), min: min, max: max, step: step, value: P[key], fmt: fmt, onInput: function (v) { P[key] = v; if (live) replan(); else save(); } });
  }
  function anchorGrid() {
    var box = h('div', { class: 'agrid' });
    [.3, .5, .7].forEach(function (y) {
      [.3, .5, .7].forEach(function (x) {
        var b = h('button', { type: 'button', class: 'acell', onclick: function () { P.ax = x; P.ay = y === .3 ? .3 : y === .5 ? .4 : .62; mark(); replan(); } }, [h('i')]);
        b.__x = x; b.__y = y; box.appendChild(b);
      });
    });
    function mark() { [].forEach.call(box.children, function (b) { b.classList.toggle('on', Math.abs(b.__x - P.ax) < .01 && Math.abs((b.__y === .3 ? .3 : b.__y === .5 ? .4 : .62) - P.ay) < .01); }); }
    mark(); return box;
  }
  function build(root) {
    ui.status = K.status(); ui.prog = K.progress();
    ui.map = h('canvas', { class: 'zmap' });
    ui.map.addEventListener('click', function (e) {
      if (!A) return;
      var r = ui.map.getBoundingClientRect(), k = (e.clientX - r.left) / r.width;
      var t0 = Math.min.apply(null, A.clips.map(function (c) { return c.info.start; })), t1 = Math.max.apply(null, A.clips.map(function (c) { return c.info.end; }));
      ui.playT = t0 + k * (t1 - t0); drawMap(); Sys.call('cr_seek', { t: ui.playT });
    });
    ui.stats = h('div', { class: 'kpis' });
    ui.mapWrap = h('div', { class: 'sec hide' }, [h('div', { class: 'sb', style: 'padding-top:10px' }, [
      h('div', { style: 'font-weight:600', text: t('map') }), h('div', { class: 'hint', text: t('map_hint') }), ui.map, ui.stats,
      h('div', { class: 'adds', style: 'margin-top:8px' }, [K.btn(t('shuffle'), { icon: 'refresh', onClick: function () { P.seed = (P.seed * 31 + 7) % 100000; replan(); } })])
    ])]);
    ui.applyBtn = K.btn(t('apply'), { cls: 'pri', icon: 'spark', onClick: apply }); ui.applyBtn.disabled = true;

    var lookSec = K.section(t('look'), [
      sl('strength', 'strength', 4, 40, 1, pctf, true), sl('step', 'step', 2, 15, 1, pctf, true),
      K.field(t('motion'), K.seg({ items: [{ v: 'smooth', label: t('m_smooth') }, { v: 'cut', label: t('m_cut') }], value: P.motion, onChange: function (v) { P.motion = v; replan(); } })),
      sl('movems', 'movems', .1, 1.2, .05, secf, true),
      K.slider({ label: t('reset'), min: 2, max: 8, step: 1, value: P.reset, fmt: function (v) { return v + ' ' + t('moves_u'); }, onInput: function (v) { P.reset = v; replan(); } }),
      K.toggle(t('drift'), P.drift, function (v) { P.drift = v; replan(); }), sl('driftamt', 'driftamt', 1, 8, .5, pctf, true),
      K.field(t('anchor'), h('div', {}, [anchorGrid(), h('div', { class: 'hint', text: t('anchor_hint') })]))
    ], true, 'zm_look');
    var earSec = K.section(t('ears'), [
      sl('noise', 'noise', -55, -18, 1, function (v) { return v + ' dB'; }), sl('boundary', 'boundary', .12, 1, .02, secf),
      sl('mingap', 'mingap', .4, 5, .1, secf, true), sl('minrun', 'minrun', .2, 3, .1, secf, true),
      h('div', { class: 'hint', style: 'margin-top:6px', text: 'لو غيّرت «السكوت» أو «السكتة» اضغط «اسمع الكلام» تاني.' })
    ], false, 'zm_ears');

    [h('div', { class: 'hint intro', text: t('intro') }),
      h('div', { class: 'out' }, [h('div', { class: 'hint', text: t('pick') }), h('div', { style: 'margin-top:8px' }, [K.btn(t('analyze'), { cls: 'pri', icon: 'target', onClick: analyze })])]),
      ui.mapWrap, lookSec, earSec,
      h('div', { class: 'out' }, [ui.applyBtn, h('div', { class: 'tk' }, [K.btn(t('clear'), { cls: 'ghost', icon: 'undo', onClick: clear })]), ui.prog, ui.status])
    ].forEach(function (el) { root.appendChild(el); });
    G.addEventListener('resize', function () { if (A) drawMap(); });
  }

  G.ZoomTab = { build: build, _plan: function (a, p) { A = a; for (var k in (p || {})) P[k] = p[k]; planAll(); return plans; }, keysFor: keysFor };
})(window);
