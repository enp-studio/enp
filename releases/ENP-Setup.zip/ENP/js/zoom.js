/* Carousel 3D — automatic zoom on speech.
   Hears where each sentence starts (the silences between them, from the clip's
   own audio) and changes the zoom a little on each one: Scale / Position
   keyframes on the clip's Motion effect. */
(function (G) {
  'use strict';
  var K = G.K, h = K.h, st = K.store('c3d_zm_');
  var L = {
    intro: 'زووم خفيف بيتغيّر مع كل جملة عشان اللقطة الطويلة ماتبقاش مملة. بيتحط كيفريمز Scale (وPosition لو الشخص مش في النص) على الكليب نفسه.',
    pick: 'اختار الكليبات في التايملاين (أو سيب المؤشر على الكليب) واضغط «اسمع الكلام».',
    analyze: 'اسمع الكلام', analyzing: 'بسمع {n}…', apply: 'حط الزووم', clear: 'شيل الزووم', shuffle: 'غيّرلي التوزيعة',
    map: 'سلّم الزووم', map_hint: 'البنفسجي كلام، والخط اللي فوقه الزووم. دوس في أي مكان عشان المؤشر يروحله.',
    k_moves: 'حركة', k_peak: 'أعلى زووم', k_every: 'واحدة كل', k_keys: 'كيفريم',
    look: 'شكل الزووم', strength: 'أقصى زووم', step: 'فرق الدرجة', motion: 'شكل التغيير', m_smooth: 'بحركة', m_cut: 'قطع (من غير حركة)', feel: 'إحساس الحركة', f_silk: 'ناعم جدًا', f_smooth: 'سلس', f_live: 'حيوي', f_punch: 'حاد (بانش)', mode: 'الزووم بيتغيّر', md_speech: 'مع كل جملة', md_cuts: 'مع كل كات (جمب كات)', auto: 'حد الكلام تلقائي (من غير ما تحدد مستوى صوت)', sens: 'الحساسية',
    movems: 'مدة الحركة', reset: 'يرجع للأصل كل', moves_u: 'حركات', drift: 'زحف بطيء جوه الجملة الطويلة', driftamt: 'مقدار الزحف',
    anchor: 'الشخص قاعد فين في الكادر؟', anchor_hint: 'الزووم بيروح ناحية النقطة دي.',
    ears: 'سماع الجمل', noise: 'السكوت أقل من', boundary: 'السكتة اللي تعتبر آخر جملة', mingap: 'أقل مسافة بين حركتين', minrun: 'أقصر كلام يستاهل حركة',
    no_seq: 'افتح سيكوينس الأول.', no_clips: 'مفيش كليب فيديو مختار ولا تحت المؤشر.', no_audio: '«{n}» مالوش صوت — اختار الكليب اللي فيه الكلام.',
    keyed: 'تنبيه: {n} عليه كيفريمز Scale/Position قبل كده، وهيتشالوا.',
    ready: 'جاهز — {n} حركة. بص على السلّم وبعدين «حط الزووم».', none: 'ملقتش جمل كفاية — قلّل «أقصر كلام» أو «أقل مسافة».',
    applying: 'بحط الكيفريمز… {p}%', done: 'تمام — {n} حركة على {c} كليب ({k} كيفريم).', capped: 'الكليب طويل فقللت الحركات عشان الكيفريمز ماتتقلش.',
    cleared: 'الزووم اتشال من {n} كليب ورجع زي ما كان.', clear_none: 'مفيش زووم مننا على الكليبات المختارة.',
    failed: 'حصلت مشكلة', moved: 'الكليب اتحرّك من مكانه — اعمل «اسمع الكلام» تاني.'
  };
  function t(k, v) { var s = L[k] || k; if (v) for (var x in v) s = s.replace('{' + x + '}', v[x]); return s; }
  var DEF = { feel: 'smooth', mode: 'speech', auto: true, sens: .5, strength: 12, step: 5, motion: 'smooth', movems: .9, reset: 4, drift: true, driftamt: 3, ax: .5, ay: .4,
    noise: -34, boundary: .3, mingap: 1.4, minrun: .8, seed: 1 };
  var P = (function () { var s = st.get('set', {}), o = {}; if (s.feel === undefined) { delete s.movems; delete s.strength; delete s.step; delete s.noise; } for (var k in DEF) o[k] = s[k] !== undefined ? s[k] : DEF[k]; return o; })();
  function save() { st.set('set', P); }
  var A = null;      // analysis: { clips:[{info, speech:[{a,b}] (sequence s)}], fps, w, h }
  var plans = [];    // per clip: { pts:[[t,z]], moves, keysN, capped }
  var ui = {};

  /* ---------- planning ---------- */
  function rng(seed) { var a = seed >>> 0; return function () { a = (a + 0x6D2B79F5) | 0; var t2 = Math.imul(a ^ (a >>> 15), 1 | a); t2 = (t2 + Math.imul(t2 ^ (t2 >>> 7), 61 | t2)) ^ t2; return ((t2 ^ (t2 >>> 14)) >>> 0) / 4294967296; }; }
  function eio(x) { return x < .5 ? 2 * x * x : 1 - Math.pow(-2 * x + 2, 2) / 2; }
  function sine(x) { return -(Math.cos(Math.PI * x) - 1) / 2; }
  function quint(x) { return x < .5 ? 16 * x * x * x * x * x : 1 - Math.pow(-2 * x + 2, 5) / 2; }
  function outExpo(x) { return x >= 1 ? 1 : 1 - Math.pow(2, -10 * x); }
  /* how a move feels: length multiplier, easing, how much of it happens before the word */
  var FEEL = { silk: { k: 1.6, ease: sine, lead: .7 }, smooth: { k: 1, ease: sine, lead: .6 }, live: { k: .55, ease: quint, lead: .5 }, punch: { k: .25, ease: outExpo, lead: .15 } };
  function planClip(cl, fps, gapMul) {
    var c = cl.info, t0 = c.start, t1 = c.end, fr = 1 / (fps || 30);
    var maxK = Math.max(1, Math.round(P.strength / Math.max(1, P.step)));
    var zOf = function (k) { return 1 + Math.min(P.strength, k * P.step) / 100; };
    var R = rng(P.seed * 7919 + Math.round(c.start * 100));
    var gap = P.mingap * (gapMul || 1);
    /* where moves go: the start of each sentence long enough, far enough from the last move */
    var bounds = [], last = t0;
    cl.speech.forEach(function (s, i) {
      if (s.b - s.a < P.minrun) return;
      if (i === 0 && s.a - t0 < .4) return;           // already talking at the clip's start
      if (s.a - last < gap || t1 - s.a < .6) return;
      bounds.push(s.a); last = s.a;
    });
    var levels = [0], cur = 0, since = 0;
    bounds.forEach(function () {
      var nx;
      if (since >= P.reset - 1 && cur !== 0) { nx = 0; since = 0; }
      else { do { nx = 1 + Math.floor(R() * maxK); } while (nx === cur && maxK > 1); since++; }
      levels.push(nx); cur = nx;
    });
    /* zoom curve as points [t, z] */
    var F = FEEL[P.feel] || FEEL.smooth, md = F.cut ? 0 : Math.max(fr * 2, P.movems * F.k), ease = F.ease;
    var pts = [[t0, zOf(levels[0])]];
    var holdStart = t0, zHold = zOf(levels[0]);
    function holdTo(tEnd) { // drift while holding a level
      var len = tEnd - holdStart, z = zHold;
      if (P.drift && len > 2.2) {
        var zEnd = zHold * (1 + (P.driftamt / 100) * Math.min(1, len / 6)), nd = Math.max(2, Math.min(12, Math.round(len / .8)));
        for (var d = 1; d <= nd; d++) { var u = d / nd; pts.push([holdStart + len * u, zHold + (zEnd - zHold) * (F.cut ? u : sine(u))]); }
        z = zEnd;
      }
      else pts.push([tEnd, zHold]);
      return z;
    }
    bounds.forEach(function (b, i) {
      var zNew = zOf(levels[i + 1]);
      if (md <= 0) { var zp = holdTo(Math.max(holdStart + fr, b - fr)); pts.push([b, zNew]); void zp; }
      else {
        var a = Math.max(holdStart + fr, b - md * F.lead), e = b + md * (1 - F.lead);
        var zFrom = holdTo(a), ns = Math.max(4, Math.min(24, Math.round((e - a) / (fr * 2))));
        for (var j = 1; j <= ns; j++) { var k = j / ns; pts.push([a + (e - a) * k, zFrom + (zNew - zFrom) * ease(k)]); }
        b = e;
      }
      holdStart = b; zHold = zNew;
    });
    holdTo(t1 - fr);
    return { pts: pts, moves: bounds.length, peak: Math.max.apply(null, pts.map(function (p) { return p[1]; })) };
  }
  /* jump-cut timelines: every clip is its own shot, so alternate the zoom per clip (with a slow push inside) */
  function planCut(cl, idx, fps) {
    var c = cl.info, fr = 1 / (fps || 30), lv = idx % 2 ? 1 + P.strength / 100 : 1, pts = [[c.start, lv]];
    var len = c.end - c.start - fr;
    if (P.drift && len > 1.2) { var zEnd = lv * (1 + P.driftamt / 100 * Math.min(1, len / 5)), nd = Math.max(2, Math.min(10, Math.round(len / .8))); for (var d = 1; d <= nd; d++) { var u = d / nd; pts.push([c.start + len * u, lv + (zEnd - lv) * sine(u)]); } }
    else pts.push([c.start + len, lv]);
    return { pts: pts, moves: 1, peak: Math.max.apply(null, pts.map(function (p) { return p[1]; })) };
  }
  function planAll() {
    plans = [];
    if (!A) return;
    var order = A.clips.map(function (c, i) { return i; }).sort(function (x, y) { return A.clips[x].info.start - A.clips[y].info.start; }), rank = {};
    order.forEach(function (ci, r) { rank[ci] = r; });
    A.clips.forEach(function (cl, ci) {
      if (P.mode === 'cuts') { plans.push(planCut(cl, rank[ci], A.fps)); return; }
      var mul = 1, p = planClip(cl, A.fps, mul), capped = false;
      while (p.pts.length > 900 && mul < 6) { mul *= 1.3; p = planClip(cl, A.fps, mul); capped = true; }
      p.capped = capped; plans.push(p);
    });
  }
  function keysFor(cl, p) {
    var c = cl.info, base = c.scale || 100, P0 = c.pos || [.5, .5], ax = P.ax, ay = P.ay;
    var usePos = Math.abs(ax - P0[0]) > .001 || Math.abs(ay - P0[1]) > .001;
    var scale = p.pts.map(function (q) { return [q[0], Math.round(base * q[1] * 100) / 100]; });
    var pos = usePos ? p.pts.map(function (q) { return [q[0], [ax + (P0[0] - ax) * q[1], ay + (P0[1] - ay) * q[1]]]; }) : null;
    return { scale: scale, pos: pos };
  }

  /* ---------- map ---------- */
  function drawMap() {
    var cv = ui.map, w = cv.clientWidth || 300, hh = 96, dpr = Math.min(2, G.devicePixelRatio || 1);
    cv.width = Math.round(w * dpr); cv.height = Math.round(hh * dpr);
    var x = cv.getContext('2d'); x.setTransform(dpr, 0, 0, dpr, 0, 0); x.clearRect(0, 0, w, hh);
    if (!A || !A.clips.length) return;
    var t0 = Math.min.apply(null, A.clips.map(function (c) { return c.info.start; })), t1 = Math.max.apply(null, A.clips.map(function (c) { return c.info.end; }));
    var X = function (tt) { return (tt - t0) / Math.max(.01, t1 - t0) * w; };
    var zMax = 1 + P.strength / 100 + P.driftamt / 100;
    var Y = function (z) { return hh - 22 - (z - 1) / Math.max(.01, zMax - 1) * (hh - 34); };
    x.fillStyle = 'rgba(255,255,255,.04)'; x.fillRect(0, hh - 18, w, 14);
    A.clips.forEach(function (cl, i) {
      x.fillStyle = 'rgba(178,54,94,.8)';
      cl.speech.forEach(function (s) { x.fillRect(X(s.a), hh - 17, Math.max(1, X(s.b) - X(s.a)), 12); });
      var p = plans[i]; if (!p) return;
      x.strokeStyle = '#e48aa6'; x.lineWidth = 2; x.beginPath();
      p.pts.forEach(function (q, j) { var px = X(q[0]), py = Y(q[1]); j ? x.lineTo(px, py) : x.moveTo(px, py); });
      x.stroke();
    });
    if (ui.playT !== undefined) { x.fillStyle = '#ff6b6b'; x.fillRect(X(ui.playT) - 1, 0, 2, hh); }
    var moves = plans.reduce(function (a, p) { return a + p.moves; }, 0), peak = plans.reduce(function (a, p) { return Math.max(a, p.peak); }, 1);
    var keys = A.clips.reduce(function (a, cl, i) { var k = keysFor(cl, plans[i]); return a + k.scale.length + (k.pos ? k.pos.length : 0); }, 0);
    var tot = A.clips.reduce(function (a, cl) { return a + cl.info.end - cl.info.start; }, 0);
    ui.stats.innerHTML = '';
    [[moves, t('k_moves')], [Math.round((peak - 1) * 100) + '%', t('k_peak')], [moves ? (tot / moves).toFixed(1) + 'ث' : '—', t('k_every')], [keys, t('k_keys')]]
      .forEach(function (s) { ui.stats.appendChild(h('div', { class: 'kpi' }, [h('b', { text: String(s[0]) }), h('span', { text: s[1] })])); });
    ui.mapWrap.classList.remove('hide');
  }
  function replan() { save(); planAll(); drawMap(); }

  /* ---------- actions ---------- */
  function analyze() {
    ui.status.show('busy', t('analyzing', { n: '' }));
    Sys.call('cr_clips').then(function (r) {
      if (!r || !r.ok) throw new Error(r && r.error === 'no_sequence' ? t('no_seq') : (r && (r.error || r.detail)) || 'host');
      if (!r.clips.length) throw new Error(t('no_clips'));
      var keyed = r.clips.filter(function (c) { return c.keyed; }).map(function (c) { return c.name; });
      var t0 = Math.min.apply(null, r.clips.map(function (c) { return c.start; })), t1 = Math.max.apply(null, r.clips.map(function (c) { return c.end; }));
      return SeqAudio.collect({ range: 'all' }).then(function (col) {
        col.t0 = t0; col.t1 = t1;
        col.clips = col.clips.filter(function (c) { return c.end > t0 && c.start < t1; });
        if (!col.clips.length && P.mode !== 'cuts') throw new Error(t('no_audio', { n: r.clips[0].name }));
        return col.clips.length ? SeqAudio.mix(col, 8000) : null;
      }).then(function (m) {
        var sp = m ? SeqAudio.vad(m, { threshold: P.auto ? 'auto' : P.noise, sens: P.sens, minSil: P.boundary, minSpeech: .1 }).speech : [];
        var res = { clips: [], fps: r.fps, w: r.w, h: r.h };
        r.clips.forEach(function (c) {
          res.clips.push({ info: c, speech: sp.filter(function (q) { return q.b > c.start && q.a < c.end; }).map(function (q) { return { a: Math.max(c.start, q.a), b: Math.min(c.end, q.b) }; }) });
        });
        A = res; ui.playT = r.t; planAll(); drawMap();
        var n = plans.reduce(function (a, p) { return a + p.moves; }, 0);
        ui.applyBtn.disabled = !n;
        ui.status.show(n ? 'ok' : 'warn', (n ? t('ready', { n: n }) : t('none')) + (keyed.length ? '  ' + t('keyed', { n: keyed.join('، ') }) : ''));
      });
    }).catch(function (e) { ui.status.show('err', SeqAudio.errText(e)); });
  }
  function apply() {
    if (!A || !plans.length) return;
    ui.applyBtn.disabled = true;
    var jobs = [], total = 0, bases = st.get('bases', {});
    A.clips.forEach(function (cl, i) {
      var k = keysFor(cl, plans[i]), ref = { track: cl.info.track, start: cl.info.start, id: cl.info.id };
      var bk = cl.info.path + '|' + cl.info.start.toFixed(3);
      if (!bases[bk]) bases[bk] = { scale: cl.info.scale, pos: cl.info.pos };
      jobs.push({ ref: ref, prop: 'scale', keys: k.scale }); total += k.scale.length;
      if (k.pos) { jobs.push({ ref: ref, prop: 'pos', keys: k.pos }); total += k.pos.length; }
    });
    st.set('bases', bases);
    var done = 0;
    ui.prog.set(0);
    jobs.reduce(function (pr, j) {
      return pr.then(function () {
        var first = true;
        return K.chunks(j.keys, 60, function (part) {
          var r0 = first; first = false;
          return Sys.call('cr_keys', { clip: j.ref, prop: j.prop, keys: part, reset: r0 }).then(function (r) {
            if (!r || !r.ok) throw new Error(r && r.error === 'clip_moved' ? t('moved') : t('failed') + ' [' + (r && (r.error || r.detail)) + ']');
            done += part.length; ui.prog.set(done / total); ui.status.show('busy', t('applying', { p: Math.round(done / total * 100) }));
          });
        });
      });
    }, Promise.resolve()).then(function () {
      var moves = plans.reduce(function (a, p) { return a + p.moves; }, 0);
      ui.status.show('ok', t('done', { n: moves, c: A.clips.length, k: total }) + (plans.some(function (p) { return p.capped; }) ? '  ' + t('capped') : ''));
    }).catch(function (e) { ui.status.show('err', e.message || String(e)); }).then(function () { ui.prog.done(); ui.applyBtn.disabled = false; });
  }
  function clear() {
    Sys.call('cr_clips', { fallback: true }).then(function (r) {
      if (!r || !r.ok) throw new Error(t('no_seq'));
      var bases = st.get('bases', {}), n = 0;
      return r.clips.reduce(function (pr, c) {
        return pr.then(function () {
          var bk = c.path + '|' + c.start.toFixed(3), b = bases[bk];
          if (!b && !c.keyed) return;
          return Sys.call('cr_unkey', { clip: { track: c.track, start: c.start, id: c.id }, props: ['scale', 'pos'], base: b || {} }).then(function (x) {
            if (x && x.ok) { n++; delete bases[bk]; }
          });
        });
      }, Promise.resolve()).then(function () { st.set('bases', bases); ui.status.show(n ? 'ok' : 'warn', n ? t('cleared', { n: n }) : t('clear_none')); });
    }).catch(function (e) { ui.status.show('err', e.message || String(e)); });
  }

  /* ---------- build ---------- */
  function pctf(v) { return Math.round(v) + '%'; }
  function secf(v) { return (+v).toFixed(2).replace(/0$/, '') + ' ث'; }
  function sl(key, label, min, max, step, fmt, live) {
    return K.slider({ label: t(label), min: min, max: max, step: step, value: P[key], fmt: fmt, onInput: function (v) { P[key] = v; if (live) replan(); else save(); } });
  }
  function anchorGrid() {
    var box = h('div', { class: 'agrid' });
    [.3, .5, .7].forEach(function (y) {
      [.3, .5, .7].forEach(function (x) {
        var b = h('button', { type: 'button', class: 'acell', onclick: function () { P.ax = x; P.ay = y === .3 ? .3 : y === .5 ? .4 : .62; mark(); replan(); } }, [h('i')]);
        b.__x = x; b.__y = y; box.appendChild(b);
      });
    });
    function mark() { [].forEach.call(box.children, function (b) { b.classList.toggle('on', Math.abs(b.__x - P.ax) < .01 && Math.abs((b.__y === .3 ? .3 : b.__y === .5 ? .4 : .62) - P.ay) < .01); }); }
    mark(); return box;
  }
  function build(root) {
    ui.status = K.status(); ui.prog = K.progress();
    ui.map = h('canvas', { class: 'zmap' });
    ui.map.addEventListener('click', function (e) {
      if (!A) return;
      var r = ui.map.getBoundingClientRect(), k = (e.clientX - r.left) / r.width;
      var t0 = Math.min.apply(null, A.clips.map(function (c) { return c.info.start; })), t1 = Math.max.apply(null, A.clips.map(function (c) { return c.info.end; }));
      ui.playT = t0 + k * (t1 - t0); drawMap(); Sys.call('cr_seek', { t: ui.playT });
    });
    ui.stats = h('div', { class: 'kpis' });
    ui.mapWrap = h('div', { class: 'sec hide' }, [h('div', { class: 'sb', style: 'padding-top:10px' }, [
      h('div', { style: 'font-weight:600', text: t('map') }), h('div', { class: 'hint', text: t('map_hint') }), ui.map, ui.stats,
      h('div', { class: 'adds', style: 'margin-top:8px' }, [K.btn(t('shuffle'), { icon: 'refresh', onClick: function () { P.seed = (P.seed * 31 + 7) % 100000; replan(); } })])
    ])]);
    ui.applyBtn = K.btn(t('apply'), { cls: 'pri', icon: 'spark', onClick: apply }); ui.applyBtn.disabled = true;

    var feelSeg = K.seg({ items: [{ v: 'silk', label: t('f_silk') }, { v: 'smooth', label: t('f_smooth') }, { v: 'live', label: t('f_live') }, { v: 'punch', label: t('f_punch') }], value: P.feel, onChange: function (v) { P.feel = v; replan(); } });
    var modeSeg = K.seg({ items: [{ v: 'speech', label: t('md_speech') }, { v: 'cuts', label: t('md_cuts') }], value: P.mode, onChange: function (v) { P.mode = v; replan(); } });
    var lookSec = K.section(t('look'), [K.field(t('feel'), feelSeg), K.field(t('mode'), modeSeg),
      sl('strength', 'strength', 4, 40, 1, pctf, true), sl('step', 'step', 2, 15, 1, pctf, true),
      sl('movems', 'movems', .2, 2, .05, secf, true),
      K.slider({ label: t('reset'), min: 2, max: 8, step: 1, value: P.reset, fmt: function (v) { return v + ' ' + t('moves_u'); }, onInput: function (v) { P.reset = v; replan(); } }),
      K.toggle(t('drift'), P.drift, function (v) { P.drift = v; replan(); }), sl('driftamt', 'driftamt', 1, 8, .5, pctf, true),
      K.field(t('anchor'), h('div', {}, [anchorGrid(), h('div', { class: 'hint', text: t('anchor_hint') })]))
    ], true, 'zm_look');
    var noiseSl = sl('noise', 'noise', -55, -18, 1, function (v) { return v + ' dB'; }), sensSl = K.slider({ label: t('sens'), min: 0, max: 1, step: .05, value: P.sens, fmt: function (v) { return Math.round(v * 100) + '%'; }, onInput: function (v) { P.sens = v; save(); } });
    K.show(noiseSl, !P.auto); K.show(sensSl, P.auto);
    var earSec = K.section(t('ears'), [
      K.toggle(t('auto'), P.auto, function (v) { P.auto = v; save(); K.show(noiseSl, !v); K.show(sensSl, v); }), sensSl, noiseSl, sl('boundary', 'boundary', .12, 1, .02, secf),
      sl('mingap', 'mingap', .4, 5, .1, secf, true), sl('minrun', 'minrun', .2, 3, .1, secf, true),
      h('div', { class: 'hint', style: 'margin-top:6px', text: 'لو غيّرت «السكوت» أو «السكتة» اضغط «اسمع الكلام» تاني.' })
    ], false, 'zm_ears');

    [h('div', { class: 'hint intro', text: t('intro') }),
      h('div', { class: 'out' }, [h('div', { class: 'hint', text: t('pick') }), h('div', { style: 'margin-top:8px' }, [K.btn(t('analyze'), { cls: 'pri', icon: 'target', onClick: analyze })])]),
      ui.mapWrap, lookSec, earSec,
      h('div', { class: 'out' }, [ui.applyBtn, h('div', { class: 'tk' }, [K.btn(t('clear'), { cls: 'ghost', icon: 'undo', onClick: clear })]), ui.prog, ui.status])
    ].forEach(function (el) { root.appendChild(el); });
    G.addEventListener('resize', function () { if (A) drawMap(); });
  }

  G.ZoomTab = { build: build, _plan: function (a, p) { A = a; for (var k in (p || {})) P[k] = p[k]; planAll(); return plans; }, keysFor: keysFor };
})(window);
