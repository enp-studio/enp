/* ENP — speech to text on this computer (whisper.cpp). Nothing is uploaded, no credits.
   The engine (≈3 MB) and one model (190–574 MB) are downloaded once into ENP-Engine. */
(function (G) {
  'use strict';
  var S = G.Sys, req = S && S.req;
  if (!req) { G.Whisper = null; return; }
  var fs = req('fs'), path = req('path'), os = req('os'), cp = req('child_process'), proc = req('process');
  var BIN_URL = 'https://github.com/ggml-org/whisper.cpp/releases/download/v1.9.1/whisper-bin-x64.zip';
  var MODELS = {
    fast: { file: 'ggml-small-q5_1.bin', mb: 190, label: 'سريع' },
    best: { file: 'ggml-large-v3-turbo-q5_0.bin', mb: 574, label: 'دقيق' }
  };
  function modelUrl(f) { return 'https://huggingface.co/ggerganov/whisper.cpp/resolve/main/' + f; }
  function home() {
    var d = S.isWin ? path.join(proc.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming'), 'ENP-Engine') : path.join(os.homedir(), 'Library', 'Application Support', 'ENP-Engine');
    if (S.isWin && !S.isAscii(d)) d = 'C:\\Users\\Public\\ENP-Engine';
    S.mkdirp(d); return d;
  }
  function find(dir, name, depth) {
    if (depth > 4) return '';
    var items; try { items = fs.readdirSync(dir, { withFileTypes: true }); } catch (e) { return ''; }
    for (var i = 0; i < items.length; i++) if (items[i].isFile() && items[i].name.toLowerCase() === name) return path.join(dir, items[i].name);
    for (var j = 0; j < items.length; j++) if (items[j].isDirectory()) { var r = find(path.join(dir, items[j].name), name, depth + 1); if (r) return r; }
    return '';
  }
  function cli() {
    var exe = S.isWin ? 'whisper-cli.exe' : 'whisper-cli';
    var p = find(path.join(home(), 'bin'), exe, 0);
    if (p) return p;
    if (!S.isWin) { var c = ['/opt/homebrew/bin/whisper-cli', '/usr/local/bin/whisper-cli']; for (var i = 0; i < c.length; i++) if (fs.existsSync(c[i])) return c[i]; }
    return '';
  }
  function model(q) {
    var m = MODELS[q] || MODELS.best, p = path.join(home(), 'models', m.file);
    try { if (fs.statSync(p).size > m.mb * 1024 * 1024 * .9) return p; } catch (e) {}
    return '';
  }
  function status() { return { cli: cli(), fast: model('fast'), best: model('best'), home: home() }; }

  /* download with progress (follows redirects) into file, via a .part file */
  function download(url, file, onProg, hops) {
    hops = hops || 0;
    return new Promise(function (resolve, reject) {
      if (hops > 8) return reject(new Error('redirects'));
      var mod = req(/^https:/.test(url) ? 'https' : 'http');
      var r = mod.get(url, { headers: { 'User-Agent': 'ENP' } }, function (res) {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) { res.resume(); return resolve(download(new URL(res.headers.location, url).toString(), file, onProg, hops + 1)); }
        if (res.statusCode !== 200) { res.resume(); return reject(new Error('HTTP ' + res.statusCode)); }
        var total = +res.headers['content-length'] || 0, got = 0, part = file + '.part';
        S.mkdirp(path.dirname(file));
        var ws = fs.createWriteStream(part);
        res.on('data', function (d) { got += d.length; if (onProg && total) onProg(got / total, got, total); });
        res.pipe(ws);
        ws.on('finish', function () { ws.close(function () { try { if (fs.existsSync(file)) fs.unlinkSync(file); fs.renameSync(part, file); resolve(file); } catch (e) { reject(e); } }); });
        ws.on('error', reject); res.on('error', reject);
      });
      r.on('error', reject); r.setTimeout(60000, function () { r.destroy(new Error('timeout')); });
    });
  }
  function unzip(zip, to) {
    return new Promise(function (res, rej) {
      S.mkdirp(to);
      var p = S.isWin ? cp.spawn('powershell', ['-NoProfile', '-Command', 'Expand-Archive -LiteralPath "' + zip + '" -DestinationPath "' + to + '" -Force'], { windowsHide: true }) : cp.spawn('unzip', ['-o', '-q', zip, '-d', to]);
      p.on('close', function (c) { c === 0 ? res() : rej(new Error('unzip ' + c)); }); p.on('error', rej);
    });
  }
  function install(q, onProg) {
    var steps = Promise.resolve();
    if (!cli()) {
      if (!S.isWin) return Promise.reject(new Error('على الماك: نزّل whisper.cpp (brew install whisper-cpp) وبعدين جرّب تاني.'));
      var zip = path.join(home(), 'whisper-bin.zip');
      steps = steps.then(function () { return download(BIN_URL, zip, function (p) { onProg('engine', p); }); })
        .then(function () { return unzip(zip, path.join(home(), 'bin')); }).then(function () { try { fs.unlinkSync(zip); } catch (e) {} if (!cli()) throw new Error('المحرك اتنزّل بس مش لاقي whisper-cli.exe'); });
    }
    if (!model(q)) {
      var m = MODELS[q] || MODELS.best;
      steps = steps.then(function () { return download(modelUrl(m.file), path.join(home(), 'models', m.file), function (p) { onProg('model', p); }); });
    }
    return steps.then(status);
  }

  var PROMPTS = {
    ar: 'مرحبًا بكم، سنتحدث اليوم عن موضوع مهم جدًا.',
    eg: 'إزيكم يا جماعة، النهاردة هنتكلم عن حاجة مهمة أوي، يعني بصراحة الموضوع ده محتاج تركيز.',
    sa: 'هلا والله، اليوم بنتكلم عن شي مهم مره، يعني صراحة الموضوع هذا يبي له تركيز.',
    en: 'Hi everyone, today we are going to talk about something really important.'
  };
  /* -> [{ w, a, b }] word timings in seconds from the start of `wav` */
  function transcribe(wav, lang, q, onProg, isStopped) {
    var exe = cli(), m = model(q);
    if (!exe || !m) return Promise.reject(new Error('engine_missing'));
    var out = path.join(path.dirname(wav), 'enp-asr-' + Date.now());
    var code = lang === 'en' ? 'en' : lang === 'auto' ? 'auto' : 'ar';
    var args = ['-m', m, '-f', wav, '-l', code, '-t', String(Math.max(2, Math.min(16, os.cpus().length))), '-ml', '1', '-sow', '-oj', '-osrt', '-of', out, '-pp'];
    if (PROMPTS[lang]) args.push('--prompt', PROMPTS[lang]);
    return new Promise(function (resolve, reject) {
      var p = cp.spawn(exe, args, { windowsHide: true, cwd: path.dirname(exe) }), err = '';
      var tick = setInterval(function () { if (isStopped && isStopped()) { try { p.kill(); } catch (e) {} } }, 300);
      function feed(d) { var s = String(d); err += s; if (err.length > 50000) err = err.slice(-20000); var mm = s.match(/progress\s*=\s*(\d+)%/g); if (mm && onProg) onProg(+mm[mm.length - 1].replace(/\D/g, '') / 100); }
      p.stdout.on('data', feed); p.stderr.on('data', feed);
      p.on('error', function (e) { clearInterval(tick); reject(e); });
      p.on('close', function (c) {
        clearInterval(tick);
        if (isStopped && isStopped()) return reject(new Error('cancelled'));
        var words = null;
        try { words = fromJson(JSON.parse(fs.readFileSync(out + '.json', 'utf8'))); } catch (e) { words = null; }
        if (!words || !words.length) { try { words = fromSrt(fs.readFileSync(out + '.srt', 'utf8')); } catch (e) { words = null; } }
        [out + '.json', out + '.srt'].forEach(function (f) { try { fs.unlinkSync(f); } catch (e) {} });
        if (!words) return reject(new Error('whisper: ' + (err.trim().split(/\r?\n/).slice(-2).join(' ') || 'exit ' + c)));
        resolve(words);
      });
    });
  }
  /* long audio in pieces (cut at pauses), one whisper run per piece: a long single run can stop
     after the first sentence or drift. chunks: [[a,b]] seconds in the wav. -> words [{w,a,b}] */
  function transcribeChunks(wav, lang, q, chunks, onProg, isStopped) {
    var all = [], i = 0, total = chunks.reduce(function (s, c) { return s + c[1] - c[0]; }, 0) || 1, doneDur = 0;
    function one(c, noPrompt) {
      return runOnce(wav, lang, q, { ot: Math.round(c[0] * 1000), d: Math.round((c[1] - c[0]) * 1000), noPrompt: noPrompt }, function (p) {
        if (onProg) onProg((doneDur + p * (c[1] - c[0])) / total);
      }, isStopped).then(function (ws) {
        if (ws.length) { var mx = Math.max.apply(null, ws.map(function (w) { return w.b; })); if (mx < c[0] - .5) ws.forEach(function (w) { w.a += c[0]; w.b += c[0]; }); }
        return ws.filter(function (w) { return w.a < c[1] + .3 && w.b > c[0] - .3; });
      });
    }
    function next() {
      if (i >= chunks.length) return Promise.resolve(all);
      var c = chunks[i++];
      return one(c, false).then(function (ws) { return ws.length || (c[1] - c[0]) < 1 ? ws : one(c, true); }).then(function (ws) {
        ws.forEach(function (w) { w.a = Math.max(c[0], w.a); w.b = Math.min(c[1] + .2, Math.max(w.a + .05, w.b)); });
        all = all.concat(ws); doneDur += c[1] - c[0]; return next();
      });
    }
    return next();
  }
  function runOnce(wav, lang, q, o, onProg, isStopped) {
    var exe = cli(), m = model(q);
    if (!exe || !m) return Promise.reject(new Error('engine_missing'));
    var out = path.join(path.dirname(wav), 'enp-asr-' + Date.now() + '-' + Math.floor(Math.random() * 1e4));
    var code = lang === 'en' ? 'en' : lang === 'auto' ? 'auto' : 'ar';
    var args = ['-m', m, '-f', wav, '-l', code, '-t', String(Math.max(2, Math.min(16, os.cpus().length))), '-ml', '1', '-sow', '-oj', '-osrt', '-of', out, '-pp', '-mc', '0'];
    if (o.ot) args.push('-ot', String(o.ot));
    if (o.d) args.push('-d', String(o.d));
    if (PROMPTS[lang] && !o.noPrompt) args.push('--prompt', PROMPTS[lang]);
    return new Promise(function (resolve, reject) {
      var p = cp.spawn(exe, args, { windowsHide: true, cwd: path.dirname(exe) }), err = '';
      var tick = setInterval(function () { if (isStopped && isStopped()) { try { p.kill(); } catch (e) {} } }, 300);
      function feed(d) { var s = String(d); err += s; if (err.length > 50000) err = err.slice(-20000); var mm = s.match(/progress\s*=\s*(\d+)%/g); if (mm && onProg) onProg(+mm[mm.length - 1].replace(/\D/g, '') / 100); }
      p.stdout.on('data', feed); p.stderr.on('data', feed);
      p.on('error', function (e) { clearInterval(tick); reject(e); });
      p.on('close', function (c) {
        clearInterval(tick);
        if (isStopped && isStopped()) return reject(new Error('cancelled'));
        var words = null;
        try { words = fromJson(JSON.parse(fs.readFileSync(out + '.json', 'utf8'))); } catch (e) { words = null; }
        if (!words || !words.length) { try { words = fromSrt(fs.readFileSync(out + '.srt', 'utf8')); } catch (e) { words = null; } }
        [out + '.json', out + '.srt'].forEach(function (f) { try { fs.unlinkSync(f); } catch (e) {} });
        if (!words && c !== 0) return reject(new Error('whisper: ' + (err.trim().split(/\r?\n/).slice(-2).join(' ') || 'exit ' + c)));
        resolve(words || []);
      });
    });
  }
  /* speech parts -> chunks of at most `max` seconds, cut in the pauses */
  function plan(speech, t0, max) {
    max = max || 26; var out = [], cur = null;
    speech.forEach(function (s) {
      var a = Math.max(0, s.a - t0 - .15), b = s.b - t0 + .15;
      while (b - a > max) { if (cur) { out.push(cur); cur = null; } out.push([a, a + max]); a += max - .5; }
      if (cur && b - cur[0] <= max && a - cur[1] < 3) cur[1] = b; else { if (cur) out.push(cur); cur = [a, b]; }
    });
    if (cur) out.push(cur);
    return out;
  }
  function clean(t) { return String(t || '').replace(/\[[^\]]*\]|\([^)]*\)/g, '').replace(/\s+/g, ' ').trim(); }
  function fromJson(j) {
    return (j.transcription || []).map(function (s) { return { w: clean(s.text), a: (s.offsets ? s.offsets.from : 0) / 1000, b: (s.offsets ? s.offsets.to : 0) / 1000 }; })
      .filter(function (x) { return x.w && !/^[\s.,،؟?!…-]+$/.test(x.w); });
  }
  function fromSrt(t) {
    var out = [], re = /(\d+):(\d+):(\d+)[,.](\d+)\s*-->\s*(\d+):(\d+):(\d+)[,.](\d+)\s*\n([\s\S]*?)(?:\n\n|\n*$)/g, m;
    function sec(h, mi, s, ms) { return (+h) * 3600 + (+mi) * 60 + (+s) + (+ms) / 1000; }
    while ((m = re.exec(t.replace(/\r/g, '')))) { var w = clean(m[9]); if (w) out.push({ w: w, a: sec(m[1], m[2], m[3], m[4]), b: sec(m[5], m[6], m[7], m[8]) }); }
    return out;
  }
  function extractWav(src, from, dur) {
    var dir = path.join(S.workDir(), 'asr'); S.mkdirp(dir);
    var wav = path.join(dir, 'a' + Date.now() + '.wav');
    return S.run(['-y', '-hide_banner', '-loglevel', 'error', '-ss', String(from), '-t', String(dur), '-i', src, '-vn', '-ac', '1', '-ar', '16000', '-c:a', 'pcm_s16le', wav], { timeout: 600000 })
      .then(function () { if (!fs.existsSync(wav)) throw new Error('no_audio'); return wav; });
  }
  G.Whisper = { status: status, install: install, transcribe: transcribe, transcribeChunks: transcribeChunks, plan: plan, extractWav: extractWav, MODELS: MODELS, home: home, _fromJson: fromJson, _fromSrt: fromSrt };
})(window);
