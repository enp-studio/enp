/* Carousel 3D — WebGL renderer.
   Draws what CarEngine.frame() returns: rounded cards with border,
   shadow, floor reflection, thickness, back-face modes, depth blur
   (mipmap bias), dimming, glow and a background. Output is
   premultiplied RGBA (transparent where nothing is drawn). */
(function (G) {
  'use strict';
  var E = function () { return G.CarEngine; };

  var VS = [
    'attribute vec2 aPos;',
    'uniform mat4 uMVP; uniform vec2 uSize; uniform vec2 uGrow; uniform vec2 uOff; uniform float uFlipY;',
    'varying vec2 vLocal; varying vec2 vUV;',
    'void main(){',
    '  vec2 loc = aPos * (uSize + uGrow) + uOff;',
    '  vLocal = loc - uOff;',
    '  vec2 uvp = (loc - uOff) / uSize;',
    '  vUV = vec2(uvp.x + 0.5, 0.5 - uvp.y);',
    '  gl_Position = uMVP * vec4(loc.x, loc.y * uFlipY, 0.0, 1.0);',
    '}'].join('\n');

  var FS = [
    '#ifdef GL_OES_standard_derivatives',
    '#extension GL_OES_standard_derivatives : enable',
    '#endif',
    'precision highp float;',
    'varying vec2 vLocal; varying vec2 vUV;',
    'uniform sampler2D uTex; uniform int uMode; uniform int uHasTex;',
    'uniform vec2 uSize; uniform float uCorner; uniform float uBorder; uniform vec3 uBorderColor;',
    'uniform vec4 uUV; uniform int uContain; uniform float uOp; uniform float uDim; uniform float uBias;',
    'uniform vec3 uColor; uniform float uSoft; uniform int uBack; uniform vec3 uBackColor; uniform float uAA;',
    'float sdRound(vec2 p, vec2 b, float r){ vec2 q = abs(p) - b + r; return length(max(q,0.0)) + min(max(q.x,q.y),0.0) - r; }',
    'vec4 img(vec2 uv){',
    '  vec2 t = (uv - 0.5) * uUV.xy + 0.5 + uUV.zw;',
    '  if (uContain == 1 && (t.x < 0.0 || t.x > 1.0 || t.y < 0.0 || t.y > 1.0)) return vec4(0.07,0.07,0.09,1.0);',
    '  if (uHasTex == 0) return vec4(0.2,0.2,0.24,1.0);',
    '  return texture2D(uTex, clamp(t, 0.0, 1.0), uBias);',
    '}',
    'void main(){',
    '  float aa = uAA;',
    '#ifdef GL_OES_standard_derivatives',
    '  aa = max(fwidth(vLocal.x), fwidth(vLocal.y)) * 1.2;',
    '#endif',
    '  vec2 half_ = uSize * 0.5;',
    '  float r = min(uCorner, min(half_.x, half_.y));',
    '  float d = sdRound(vLocal, half_, r);',
    '  if (uMode == 1) {', // soft shadow / glow
    '    float a = 1.0 - smoothstep(-uSoft * 0.5, uSoft, d);',
    '    gl_FragColor = vec4(uColor, a * a * uOp); return;',
    '  }',
    '  if (uMode == 4) {', // solid side of a thick card
    '    gl_FragColor = vec4(uColor * (1.0 - uDim), uOp); return;',
    '  }',
    '  if (uMode == 5) {', // background picture
    '    vec4 c = uHasTex == 1 ? texture2D(uTex, (vUV - 0.5) * uUV.xy + 0.5, uBias) : vec4(0.0);',
    '    gl_FragColor = vec4(c.rgb * 0.8, uOp); return;',
    '  }',
    '  float cover = 1.0 - smoothstep(-aa, aa, d);',
    '  if (cover <= 0.0) discard;',
    '  vec2 uv = vUV;',
    '  vec3 col;',
    '  bool front = gl_FrontFacing;',
    '  if (uMode == 2) front = true;',
    '  if (!front && uBack == 3) discard;',
    '  if (!front && uBack == 2) col = uBackColor;',
    '  else { col = img(uv).rgb; if (!front && uBack == 1) col *= 0.3; }',
    '  if (uBorder > 0.0) { float b = 1.0 - smoothstep(-aa, aa, d + uBorder); col = mix(uBorderColor, col, b); }',
    '  col *= (1.0 - uDim);',
    '  float a = cover * uOp;',
    '  if (uMode == 2) {', // reflection fades away from the card
    '    float k = clamp(1.0 - (vLocal.y + half_.y) / (uSize.y * 0.55), 0.0, 1.0);',
    '    a *= k * k;',
    '  }',
    '  gl_FragColor = vec4(col, a);',
    '}'].join('\n');

  function pot(n) { var p = 1; while (p < n) p *= 2; return p; }

  function create(canvas) {
    var opt = { alpha: true, premultipliedAlpha: true, antialias: true, preserveDrawingBuffer: true };
    var gl = canvas.getContext('webgl', opt) || canvas.getContext('experimental-webgl', opt);
    if (!gl) return null;
    var deriv = gl.getExtension('OES_standard_derivatives');
    var aniso = gl.getExtension('EXT_texture_filter_anisotropic');
    function sh(type, src) {
      var s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error('shader: ' + gl.getShaderInfoLog(s));
      return s;
    }
    var prog = gl.createProgram();
    gl.attachShader(prog, sh(gl.VERTEX_SHADER, VS));
    gl.attachShader(prog, sh(gl.FRAGMENT_SHADER, deriv ? FS : FS.replace(/#ifdef GL_OES[\s\S]*?#endif\n/, '')));
    gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error('link: ' + gl.getProgramInfoLog(prog));
    gl.useProgram(prog);
    var U = {};
    ['uMVP','uSize','uGrow','uOff','uFlipY','uTex','uMode','uHasTex','uCorner','uBorder','uBorderColor','uUV','uContain','uOp','uDim','uBias',
     'uColor','uSoft','uBack','uBackColor','uAA'].forEach(function (n) { U[n] = gl.getUniformLocation(prog, n); });
    var buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-.5,-.5, .5,-.5, -.5,.5, .5,.5]), gl.STATIC_DRAW);
    var aPos = gl.getAttribLocation(prog, 'aPos');
    gl.enableVertexAttribArray(aPos);
    gl.vertexAttribPointer(aPos, 2, gl.FLOAT, false, 0, 0);
    gl.uniform1i(U.uTex, 0);

    var tex = {};   // key -> { t: WebGLTexture, w, h (source size) }
    var scratch = document.createElement('canvas');
    var MAXT = 1024;

    function upload(key, src, sw, sh2) {
      var e = tex[key];
      if (!e) { e = tex[key] = { t: gl.createTexture() }; }
      var tw = Math.min(MAXT, pot(Math.min(sw, MAXT))), th = Math.min(MAXT, pot(Math.min(sh2, MAXT)));
      // keep textures small-ish but power of two so mipmaps (depth blur) work everywhere
      tw = Math.max(64, tw); th = Math.max(64, th);
      if (scratch.width !== tw || scratch.height !== th) { scratch.width = tw; scratch.height = th; }
      var cx = scratch.getContext('2d');
      cx.clearRect(0, 0, tw, th);
      cx.drawImage(src, 0, 0, tw, th);
      gl.bindTexture(gl.TEXTURE_2D, e.t);
      gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
      gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, scratch);
      gl.generateMipmap(gl.TEXTURE_2D);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      if (aniso) gl.texParameterf(gl.TEXTURE_2D, aniso.TEXTURE_MAX_ANISOTROPY_EXT, 4);
      e.w = sw; e.h = sh2;
    }

    function setImage(key, img) {
      var w = img.naturalWidth || img.videoWidth || img.width, h = img.naturalHeight || img.videoHeight || img.height;
      if (!w || !h) return;
      upload(key, img, w, h);
    }
    function drop(key) { if (tex[key]) { gl.deleteTexture(tex[key].t); delete tex[key]; } }

    function uvFor(key, cardAr, fit) {
      var e = tex[key]; if (!e) return [1, 1, 0, 0];
      var ia = e.w / e.h;
      if (fit === 'contain') return ia > cardAr ? [1, ia / cardAr, 0, 0] : [cardAr / ia, 1, 0, 0];
      return ia > cardAr ? [cardAr / ia, 1, 0, 0] : [1, ia / cardAr, 0, 0];
    }

    function bindTex(key) {
      var e = key && tex[key];
      if (e) { gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, e.t); gl.uniform1i(U.uHasTex, 1); }
      else gl.uniform1i(U.uHasTex, 0);
      return !!e;
    }

    function quad(mvp, w, h, o) {
      o = o || {};
      gl.uniformMatrix4fv(U.uMVP, false, new Float32Array(mvp));
      gl.uniform2f(U.uSize, w, h);
      gl.uniform2f(U.uGrow, o.grow || 0, o.grow || 0);
      gl.uniform2f(U.uOff, o.ox || 0, o.oy || 0);
      gl.uniform1f(U.uFlipY, o.flip ? -1 : 1);
      gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    }

    /* opts: { media: [key|null per media index], placeholder: fn(i)->key, bg: {mode,color,alpha}, layerBg: bool } */
    function draw(fr, opts) {
      var s = fr.s, M = E().mat, hex = E().hex;
      gl.viewport(0, 0, canvas.width, canvas.height);
      var bgc = hex(s.bgColor), ba = +s.bgAlpha || 0;
      var paintBg = opts.layerBg !== false;
      if (paintBg && s.bg === 'color') gl.clearColor(bgc[0] * ba, bgc[1] * ba, bgc[2] * ba, ba);
      else gl.clearColor(0, 0, 0, 0);
      gl.clear(gl.COLOR_BUFFER_BIT);
      gl.disable(gl.DEPTH_TEST);
      gl.disable(gl.CULL_FACE);
      gl.enable(gl.BLEND);
      gl.blendFuncSeparate(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA, gl.ONE, gl.ONE_MINUS_SRC_ALPHA);

      var media = opts.media || [], nM = media.length;
      function keyOf(slot) {
        if (nM) { var k = media[slot % nM]; if (k) return k; }
        return opts.placeholder ? opts.placeholder(slot) : null;
      }
      var W = fr.W, H = fr.H, cardAr = fr.ar;
      var wpp = 1 / Math.max(1, fr.cam.s * canvas.height); // world units per pixel at the front card
      gl.uniform1f(U.uAA, wpp * 1.5);
      var corner = (+s.corner || 0) * Math.min(W, H) * 2;
      var border = (+s.border || 0) * W * .006;
      var bcol = hex(s.borderColor), backc = hex(s.backColor), glowc = hex(s.glowColor);
      var thick = (+s.thick || 0) * W, tcol = hex(s.thickColor || '#e8e8ee');
      var backMode = { mirror: 0, dim: 1, color: 2, hide: 3 }[s.backs] || 0;
      gl.uniform1f(U.uCorner, corner);
      gl.uniform3f(U.uBorderColor, bcol[0], bcol[1], bcol[2]);
      gl.uniform3f(U.uBackColor, backc[0], backc[1], backc[2]);
      gl.uniform1i(U.uBack, backMode);
      gl.uniform1i(U.uContain, s.fit === 'contain' ? 1 : 0);

      /* background picture: the front card's picture, very blurred */
      if (paintBg && s.bg === 'blur') {
        var fk = keyOf(fr.focusSlot);
        if (bindTex(fk)) {
          var e = tex[fk], ia = e.w / e.h, fa = canvas.width / canvas.height;
          var uv = ia > fa ? [fa / ia, 1, 0, 0] : [1, ia / fa, 0, 0];
          gl.uniform4f(U.uUV, uv[0], uv[1], 0, 0);
          gl.uniform1i(U.uMode, 5); gl.uniform1f(U.uOp, ba); gl.uniform1f(U.uBias, 7);
          gl.uniform2f(U.uSize, 2, 2);
          quad([1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1], 2, 2);
        }
      }

      var shadowA = +s.shadow || 0;
      var refl = fr.reflect;
      var biasMax = 5.5;

      /* reflections first: they lie on the floor, under everything */
      if (refl > 0) {
        fr.cards.forEach(function (c) {
          var key = keyOf(c.slot); bindTex(key);
          var uv = uvFor(key, cardAr, s.fit);
          gl.uniform4f(U.uUV, uv[0], uv[1], 0, 0);
          gl.uniform1i(U.uMode, 2); gl.uniform1f(U.uOp, c.op * refl * .9); gl.uniform1f(U.uDim, Math.min(.9, c.dim + .15));
          gl.uniform1f(U.uBias, c.blur * biasMax + 1); gl.uniform1f(U.uBorder, border);
          var mvp = M.mul(c.MVP, M.T(0, -c.h - c.h * .015, 0));
          quad(mvp, c.w, c.h, { flip: true });
        });
      }

      fr.cards.forEach(function (c) {
        var key = keyOf(c.slot);
        /* shadow: soft dark card behind and below */
        if (shadowA > 0) {
          gl.uniform1i(U.uMode, 1); gl.uniform3f(U.uColor, 0, 0, 0);
          gl.uniform1f(U.uOp, c.op * shadowA * .75); gl.uniform1f(U.uSoft, c.w * .14);
          quad(M.mul(c.MVP, M.T(0, -c.h * .04, -thick / 2 - c.w * .01)), c.w, c.h, { grow: c.w * .16 });
        }
        /* glow around the front card */
        if (c.glow > 0) {
          gl.uniform1i(U.uMode, 1); gl.uniform3f(U.uColor, glowc[0], glowc[1], glowc[2]);
          gl.uniform1f(U.uOp, c.op * c.glow); gl.uniform1f(U.uSoft, c.w * .12);
          quad(M.mul(c.MVP, M.T(0, 0, -thick / 2 - c.w * .005)), c.w, c.h, { grow: c.w * .14 });
        }
        bindTex(key);
        var uv = uvFor(key, cardAr, s.fit);
        gl.uniform4f(U.uUV, uv[0], uv[1], 0, 0);
        gl.uniform1f(U.uBorder, border);
        gl.uniform1f(U.uBias, c.blur * biasMax);
        if (thick > 0) {
          /* a box: draw its faces far to near */
          var faces = [
            { m: M.T(0, 0, -thick / 2), img: true },
            { m: M.T(0, 0, thick / 2), img: true },
            { m: M.mul(M.T(c.w / 2, 0, 0), M.RY(Math.PI / 2)), w: thick, h: c.h, sh: .25 },
            { m: M.mul(M.T(-c.w / 2, 0, 0), M.RY(-Math.PI / 2)), w: thick, h: c.h, sh: .25 },
            { m: M.mul(M.T(0, c.h / 2, 0), M.RX(-Math.PI / 2)), w: c.w, h: thick, sh: 0 },
            { m: M.mul(M.T(0, -c.h / 2, 0), M.RX(Math.PI / 2)), w: c.w, h: thick, sh: .45 }
          ];
          faces.forEach(function (fc) { fc.mvp = M.mul(c.MVP, fc.m); var v = M.xf(fc.mvp, [0, 0, 0, 1]); fc.z = v[2] / v[3]; });
          faces.sort(function (a, b) { return b.z - a.z; });
          faces.forEach(function (fc) {
            if (fc.img) {
              gl.uniform1i(U.uMode, 0); gl.uniform1f(U.uOp, c.op); gl.uniform1f(U.uDim, c.dim);
              gl.uniform1f(U.uCorner, corner);
              quad(fc.mvp, c.w, c.h);
            } else {
              gl.uniform1i(U.uMode, 4); gl.uniform3f(U.uColor, tcol[0], tcol[1], tcol[2]);
              gl.uniform1f(U.uOp, c.op); gl.uniform1f(U.uDim, Math.min(.95, c.dim + fc.sh));
              quad(fc.mvp, fc.w, fc.h);
            }
          });
        } else {
          gl.uniform1i(U.uMode, 0); gl.uniform1f(U.uOp, c.op); gl.uniform1f(U.uDim, c.dim);
          quad(c.MVP, c.w, c.h);
        }
      });
    }

    function readRGBA(out) {
      var w = canvas.width, h = canvas.height;
      var px = out && out.length === w * h * 4 ? out : new Uint8Array(w * h * 4);
      gl.readPixels(0, 0, w, h, gl.RGBA, gl.UNSIGNED_BYTE, px);
      return px;
    }

    return {
      canvas: canvas, gl: gl, setImage: setImage, drop: drop, draw: draw, readRGBA: readRGBA,
      has: function (k) { return !!tex[k]; },
      resize: function (w, h) { if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; } },
      dispose: function () { Object.keys(tex).forEach(drop); }
    };
  }

  /* numbered colour cards so a look can be seen before any picture is added */
  var HUES = [210, 340, 160, 40, 270, 190, 10, 120, 300, 60, 230, 90];
  function placeholderCanvas(i, ar) {
    var w = 360, h = Math.round(w / (ar || 9 / 16));
    if (h > 720) { h = 720; w = Math.round(h * ar); }
    var c = document.createElement('canvas'); c.width = w; c.height = h;
    var x = c.getContext('2d'), hue = HUES[i % HUES.length];
    var g = x.createLinearGradient(0, 0, w, h);
    g.addColorStop(0, 'hsl(' + hue + ',70%,62%)'); g.addColorStop(1, 'hsl(' + (hue + 40) + ',65%,38%)');
    x.fillStyle = g; x.fillRect(0, 0, w, h);
    x.fillStyle = 'rgba(255,255,255,.14)';
    x.beginPath(); x.arc(w * .8, h * .18, w * .35, 0, 7); x.fill();
    x.fillStyle = '#fff'; x.font = 'bold ' + Math.round(Math.min(w, h) * .42) + 'px Arial';
    x.textAlign = 'center'; x.textBaseline = 'middle';
    x.fillText(String(i + 1), w / 2, h / 2);
    return c;
  }

  G.CarGL = { create: create, placeholderCanvas: placeholderCanvas };
})(window);
