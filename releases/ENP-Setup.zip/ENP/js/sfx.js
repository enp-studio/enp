/* Carousel 3D — sound effects library from the editor's own folders. */
(function (G) {
  'use strict';
  var K = G.K, h = K.h, st = K.store('c3d_sfx_');
  var L = {
    intro: 'حدد فولدرات الساوند إيفيكتس بتاعتك — كل فولدر جواها بيبقى قسم. اسمع بالماوس، ودبل كليك يحط الصوت عند المؤشر، أو اسحبه على التايملاين.',
    add: 'ضيف فولدر', rescan: 'حدّث', pick: 'اختار فولدر ساوند إيفيكتس', folders: 'الفولدرات', none: 'لسه مفيش فولدرات — دوس «ضيف فولدر».',
    search: 'دوّر…', all: 'الكل', fav: 'المفضلة', count: '{n} صوت', more: 'اعرض أكتر ({n})', empty: 'مفيش أصوات بالاسم ده.',
    hover: 'سمّع لما أعدّي بالماوس', vol: 'صوت المعاينة', placed: 'اتحط «{n}» على {tr}', failed: 'محطّش', no_seq: 'افتح سيكوينس الأول.',
    scanning: 'بقرا الفولدرات…', remove: 'شيل'
  };
  function t(k, v) { var s = L[k] || k; if (v) for (var x in v) s = s.replace('{' + x + '}', v[x]); return s; }

  var roots = st.get('roots', []), index = [], favs = st.get('favs', {}), cat = st.get('cat', '*'), q = '', limit = 150;
  var hoverPlay = st.get('hover', true), vol = st.get('vol', .8);
  var audio = new Audio(), playing = null, ui = {}, peakQ = [], peakBusy = 0;

  function rescan() {
    ui.status.show('busy', t('scanning'));
    setTimeout(function () {
      index = [];
      roots.forEach(function (r) { index = index.concat(Sys.scan(r)); });
      index.sort(function (a, b) { return a.cat === b.cat ? a.name.localeCompare(b.name) : a.cat.localeCompare(b.cat); });
      ui.status.show('', '');
      renderFolders(); renderCats(); renderList();
    }, 20);
  }
  function addFolder() {
    var p = Sys.pickFolder(t('pick'));
    if (!p || roots.indexOf(p) >= 0) return;
    roots.push(p); st.set('roots', roots); rescan();
  }
  function removeFolder(p) { roots = roots.filter(function (r) { return r !== p; }); st.set('roots', roots); rescan(); }

  function filtered() {
    var words = q.trim().toLowerCase().split(/\s+/).filter(Boolean);
    return index.filter(function (it) {
      if (cat === '♥' && !favs[it.path]) return false;
      if (cat !== '*' && cat !== '♥' && it.cat !== cat) return false;
      if (!words.length) return true;
      var hay = (it.name + ' ' + it.cat + ' ' + it.sub).toLowerCase();
      return words.every(function (w) { return hay.indexOf(w) >= 0; });
    });
  }

  /* ---------- playback ---------- */
  function play(it, row) {
    if (playing && playing.it === it) { stop(); return; }
    stop();
    audio.src = Sys.url(it.path); audio.volume = vol; audio.currentTime = 0;
    var pr = audio.play(); if (pr && pr.catch) pr.catch(function () {});
    playing = { it: it, row: row }; row.classList.add('playing');
    tick();
  }
  function stop() { try { audio.pause(); } catch (e) {} if (playing) { playing.row.classList.remove('playing'); var c = playing.row.querySelector('.ph-line'); if (c) c.style.width = '0'; } playing = null; }
  function tick() {
    if (!playing) return;
    var d = audio.duration || 1, line = playing.row.querySelector('.ph-line');
    if (line) line.style.width = Math.min(100, audio.currentTime / d * 100) + '%';
    if (audio.ended) { stop(); return; }
    (G.requestAnimationFrame || setTimeout)(tick);
  }

  /* ---------- waveform (lazy) ---------- */
  function wantPeaks(it, cv, durEl) {
    peakQ.push({ it: it, cv: cv, d: durEl }); pump();
  }
  function pump() {
    while (peakBusy < 2 && peakQ.length) {
      var j = peakQ.shift(); if (!j.cv.isConnected) continue;
      peakBusy++;
      (function (job) {
        Sys.peaks(job.it.path, 70).then(function (r) { job.it.dur = r.dur; drawWave(job.cv, r.p); job.d.textContent = K.mmss(r.dur); }, function () {})
          .then(function () { peakBusy--; pump(); });
      })(j);
    }
  }
  function drawWave(cv, p) {
    var w = cv.clientWidth || 120, hh = 26, dpr = Math.min(2, G.devicePixelRatio || 1);
    cv.width = Math.round(w * dpr); cv.height = Math.round(hh * dpr);
    var x = cv.getContext('2d'); x.setTransform(dpr, 0, 0, dpr, 0, 0); x.fillStyle = 'rgba(228,138,166,.75)';
    var bw = w / p.length;
    p.forEach(function (v, i) { var bh = Math.max(1, v * (hh - 2)); x.fillRect(i * bw, (hh - bh) / 2, Math.max(1, bw - 1), bh); });
  }
  var io = G.IntersectionObserver ? new IntersectionObserver(function (ents) {
    ents.forEach(function (e) { if (e.isIntersecting) { io.unobserve(e.target); var r = e.target; wantPeaks(r.__it, r.__cv, r.__dur); } });
  }, { rootMargin: '200px' }) : null;

  /* ---------- placing ---------- */
  function place(it) {
    ui.status.show('busy', '…');
    Sys.call('cr_sfx', { path: it.path, dur: it.dur || 0 }).then(function (r) {
      if (!r || !r.ok) throw new Error(r && r.error === 'no_sequence' ? t('no_seq') : t('failed') + ' [' + (r && (r.error || r.detail)) + ']');
      ui.status.show('ok', t('placed', { n: it.name, tr: r.track }));
    }).catch(function (e) { ui.status.show('err', e.message || String(e)); });
  }

  /* ---------- render ---------- */
  function renderFolders() {
    ui.folders.innerHTML = '';
    if (!roots.length) { ui.folders.appendChild(h('div', { class: 'hint', text: t('none') })); return; }
    roots.forEach(function (r) {
      ui.folders.appendChild(h('div', { class: 'frow' }, [h('span', { class: 'fp', title: r, text: Sys.basename(r) }), h('button', { type: 'button', class: 'ibtn sm', title: t('remove'), html: K.ICON.x, onclick: function () { removeFolder(r); } })]));
    });
  }
  function renderCats() {
    var cats = {}; index.forEach(function (it) { cats[it.cat] = (cats[it.cat] || 0) + 1; });
    var names = Object.keys(cats).sort();
    if (cat !== '*' && cat !== '♥' && !cats[cat]) cat = '*';
    ui.cats.innerHTML = '';
    var items = [{ v: '*', label: t('all') + ' ' + index.length }, { v: '♥', label: '★ ' + t('fav') }].concat(names.map(function (n) { return { v: n, label: n + ' ' + cats[n] }; }));
    items.forEach(function (c) {
      ui.cats.appendChild(h('button', { type: 'button', class: 'chip' + (cat === c.v ? ' on' : ''), text: c.label, onclick: function () { cat = c.v; st.set('cat', cat); limit = 150; renderCats(); renderList(); } }));
    });
  }
  function renderList() {
    stop();
    var list = filtered(), box = ui.list; box.innerHTML = '';
    ui.count.textContent = t('count', { n: list.length });
    if (!list.length) { box.appendChild(h('div', { class: 'hint', style: 'padding:10px', text: index.length ? t('empty') : '' })); return; }
    list.slice(0, limit).forEach(function (it) {
      var cv = h('canvas', { class: 'wave' }), dur = h('span', { class: 'dur', text: it.dur ? K.mmss(it.dur) : '' });
      var star = h('button', { type: 'button', class: 'ibtn sm star' + (favs[it.path] ? ' on' : ''), html: favs[it.path] ? K.ICON.starF : K.ICON.star });
      star.addEventListener('click', function (e) {
        e.stopPropagation();
        if (favs[it.path]) delete favs[it.path]; else favs[it.path] = 1;
        st.set('favs', favs); star.classList.toggle('on', !!favs[it.path]); star.innerHTML = favs[it.path] ? K.ICON.starF : K.ICON.star;
        if (cat === '♥') renderList();
      });
      var addB = h('button', { type: 'button', class: 'ibtn sm', title: 'حطه عند المؤشر', html: K.ICON.plus, onclick: function (e) { e.stopPropagation(); place(it); } });
      var row = h('div', { class: 'srow', draggable: 'true', title: it.path }, [
        h('div', { class: 'sname' }, [h('b', { text: it.name }), h('span', { class: 'hint', text: it.cat + (it.sub ? ' / ' + it.sub : '') })]),
        h('div', { class: 'swave' }, [cv, h('i', { class: 'ph-line' })]), dur, star, addB
      ]);
      row.__it = it; row.__cv = cv; row.__dur = dur;
      row.addEventListener('click', function () { play(it, row); });
      row.addEventListener('dblclick', function () { stop(); place(it); });
      row.addEventListener('mouseenter', function () { if (hoverPlay) play(it, row); });
      row.addEventListener('mouseleave', function () { if (hoverPlay && playing && playing.it === it) stop(); });
      row.addEventListener('dragstart', function (e) {
        stop();
        try { e.dataTransfer.setData('com.adobe.cep.dnd.file.0', it.path); } catch (x) {}
        try { e.dataTransfer.setData('text/uri-list', Sys.url(it.path)); e.dataTransfer.setData('text/plain', it.path); } catch (x) {}
        e.dataTransfer.effectAllowed = 'copy';
      });
      box.appendChild(row);
      if (io) io.observe(row); else wantPeaks(it, cv, dur);
    });
    if (list.length > limit) box.appendChild(h('button', { type: 'button', class: 'btn ghost', style: 'width:100%;margin-top:6px', text: t('more', { n: list.length - limit }), onclick: function () { limit += 200; renderList(); } }));
  }

  function build(root) {
    ui.status = K.status();
    ui.folders = h('div', { class: 'folders' });
    ui.cats = h('div', { class: 'chips' });
    ui.list = h('div', { class: 'slist' });
    ui.count = h('span', { class: 'hint' });
    var search = h('input', { type: 'search', class: 'search', placeholder: t('search') });
    var timer = 0;
    search.addEventListener('input', function () { clearTimeout(timer); timer = setTimeout(function () { q = search.value; limit = 150; renderList(); }, 150); });
    audio.addEventListener('error', function () { stop(); });
    [h('div', { class: 'hint intro', text: t('intro') }),
      K.section(t('folders'), [ui.folders, h('div', { class: 'adds', style: 'margin-top:8px' }, [K.btn(t('add'), { icon: 'folder', onClick: addFolder }), K.btn(t('rescan'), { cls: 'ghost', icon: 'refresh', onClick: rescan })]),
        K.toggle(t('hover'), hoverPlay, function (v) { hoverPlay = v; st.set('hover', v); }),
        K.slider({ label: t('vol'), min: 0, max: 1, step: .05, value: vol, fmt: function (v) { return Math.round(v * 100) + '%'; }, onInput: function (v) { vol = v; audio.volume = v; st.set('vol', v); } })
      ], !roots.length, 'sfx_f'),
      h('div', { class: 'sbar' }, [search, ui.count]), ui.cats, ui.list, ui.status
    ].forEach(function (el) { root.appendChild(el); });
    renderFolders();
    if (roots.length) rescan(); else { renderCats(); renderList(); }
  }

  G.SfxTab = { build: build, onHide: stop };
})(window);
