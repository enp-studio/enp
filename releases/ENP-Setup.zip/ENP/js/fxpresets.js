/* ENP — presets for anything already on the timeline (titles, captions, text, pictures).
   Select the clips, click a preset: keyframes are written on each clip's own Motion /
   Opacity (+ Gaussian Blur when needed), fitted to that clip's length. Stack an entrance,
   an exit and a loop on the same clips; «شيل» puts the clips back the way they were. */
(function (G) {
  'use strict';
  var K = G.K, h = K.h, st = K.store('enp_fx_');
  var PI = Math.PI;
  function cl(v, a, b) { return v < a ? a : v > b ? b : v; }
  function lerp(a, b, k) { return a + (b - a) * k; }
  var E = {
    out: function (x) { x = cl(x, 0, 1); return 1 - Math.pow(1 - x, 3); },
    out5: function (x) { x = cl(x, 0, 1); return 1 - Math.pow(1 - x, 5); },
    inC: function (x) { x = cl(x, 0, 1); return x * x * x; },
    io: function (x) { x = cl(x, 0, 1); return x < .5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2; },
    expo: function (x) { x = cl(x, 0, 1); return x >= 1 ? 1 : 1 - Math.pow(2, -10 * x); },
    back: function (x) { x = cl(x, 0, 1); var c = 1.70158 * 1.3; return 1 + (c + 1) * Math.pow(x - 1, 3) + c * Math.pow(x - 1, 2); },
    elastic: function (x) { x = cl(x, 0, 1); if (x === 0 || x === 1) return x; return Math.pow(2, -10 * x) * Math.sin((x * 10 - .75) * (2 * PI / 3)) + 1; },
    bounce: function (x) { x = cl(x, 0, 1); var n = 7.5625, d = 2.75; if (x < 1 / d) return n * x * x; if (x < 2 / d) { x -= 1.5 / d; return n * x * x + .75; } if (x < 2.5 / d) { x -= 2.25 / d; return n * x * x + .9375; } x -= 2.625 / d; return n * x * x + .984375; }
  };
  function rnd(i, k) { var x = Math.sin((i + 1) * 12.9898 + (k || 0) * 78.233) * 43758.5453; return x - Math.floor(x); }
  /* props: o (opacity ×), dx dy (part of the frame), s (scale ×), sw sh (width/height ×), r (deg), blur (px at 1080p) */
  function F(id, name, kind, f, x) { var o = { id: id, name: name, kind: kind, f: f, n: 12 }; for (var k in (x || {})) o[k] = x[k]; return o; }
  var INS = [
    F('fade', 'ظهور هادي', 'in', function (p) { return { o: E.out(p) }; }, { n: 6 }),
    F('pop', 'بوب', 'in', function (p) { return { o: cl(p * 4, 0, 1), s: E.back(p) }; }, { n: 14 }),
    F('pop_soft', 'بوب ناعم', 'in', function (p) { var e = E.out5(p); return { o: e, s: lerp(.85, 1, e) }; }),
    F('apple', 'أبل (بلور طالع)', 'in', function (p) { var e = E.out5(p); return { o: e, blur: (1 - e) * 26, dy: (1 - e) * .025, s: lerp(.96, 1, e) }; }, { n: 14 }),
    F('focus', 'فوكس', 'in', function (p) { var e = E.out(p); return { o: cl(p * 2, 0, 1), blur: (1 - e) * 40, s: lerp(1.12, 1, e) }; }),
    F('blur_in', 'بلور', 'in', function (p) { var e = E.out(p); return { o: e, blur: (1 - e) * 30 }; }),
    F('zoom_in', 'زووم من قريب', 'in', function (p) { var e = E.out5(p); return { o: e, s: lerp(2.2, 1, e), blur: (1 - e) * 18 }; }),
    F('zoom_out', 'زووم من بعيد', 'in', function (p) { var e = E.back(p); return { o: cl(p * 3, 0, 1), s: lerp(.25, 1, e) }; }, { n: 14 }),
    F('rise', 'طالع من تحت', 'in', function (p) { var e = E.out5(p); return { o: e, dy: (1 - e) * .06 }; }),
    F('drop', 'نازل من فوق', 'in', function (p) { var e = E.out5(p); return { o: e, dy: -(1 - e) * .06 }; }),
    F('slide_r', 'داخل من اليمين', 'in', function (p) { var e = E.expo(p); return { o: cl(p * 2, 0, 1), dx: (1 - e) * .5 }; }),
    F('slide_l', 'داخل من الشمال', 'in', function (p) { var e = E.expo(p); return { o: cl(p * 2, 0, 1), dx: -(1 - e) * .5 }; }),
    F('whip_r', 'ويب يمين', 'in', function (p) { var e = E.expo(p); return { o: cl(p * 3, 0, 1), dx: (1 - e) * .8, blur: (1 - e) * 45 }; }),
    F('whip_l', 'ويب شمال', 'in', function (p) { var e = E.expo(p); return { o: cl(p * 3, 0, 1), dx: -(1 - e) * .8, blur: (1 - e) * 45 }; }),
    F('bounce', 'وقعة بتنط', 'in', function (p) { return { o: cl(p * 4, 0, 1), dy: -(1 - E.bounce(p)) * .12 }; }, { n: 22 }),
    F('elastic', 'مطاطي', 'in', function (p) { return { o: cl(p * 5, 0, 1), s: Math.max(.01, E.elastic(p)) }; }, { n: 24 }),
    F('spin', 'بيلف وداخل', 'in', function (p) { var e = E.back(p); return { o: cl(p * 3, 0, 1), r: (1 - e) * -120, s: lerp(.3, 1, E.out(p)) }; }, { n: 16 }),
    F('swing', 'مرجيحة', 'in', function (p) { return { o: cl(p * 3, 0, 1), r: (1 - E.elastic(p)) * 18 }; }, { n: 22 }),
    F('tilt', 'مايل وداخل', 'in', function (p) { var e = E.out5(p); return { o: e, r: (1 - e) * -10, dx: (1 - e) * .12 }; }),
    F('flip_x', 'قلب أفقي', 'in', function (p) { var e = E.back(p); return { o: cl(p * 3, 0, 1), sw: Math.max(.01, e) }; }, { n: 14 }),
    F('flip_y', 'قلب رأسي', 'in', function (p) { var e = E.back(p); return { o: cl(p * 3, 0, 1), sh: Math.max(.01, e) }; }, { n: 14 }),
    F('unfold', 'بيتفرد', 'in', function (p) { var e = E.out5(p); return { o: e, sh: lerp(.05, 1, e), blur: (1 - e) * 14 }; }),
    F('stretch', 'مطّ', 'in', function (p) { var e = E.out5(p); return { o: e, sw: lerp(2.2, 1, e), blur: (1 - e) * 12 }; }),
    F('squash', 'بيترج', 'in', function (p) { var e = E.elastic(p); return { o: cl(p * 4, 0, 1), sw: lerp(1.5, 1, e), sh: Math.max(.05, lerp(.4, 1, e)) }; }, { n: 24 }),
    F('stamp', 'ختم', 'in', function (p) { var e = E.out5(cl(p * 1.6, 0, 1)), land = cl((p - .62) / .38, 0, 1), sh = land > 0 && land < 1 ? Math.sin(land * 40) * (1 - land) * .006 : 0; return { o: cl(p * 5, 0, 1), s: lerp(2.6, 1, e), r: (1 - e) * -8, dx: sh, dy: sh * .7 }; }, { n: 22 }),
    F('glitch', 'جليتش', 'in', function (p) { var k = Math.floor(p * 12), j = p < 1 ? (rnd(k, 3) - .5) * .06 * (1 - p) : 0; return { o: p < 1 ? (rnd(k, 5) > .3 ? 1 : .2) : 1, dx: j, sw: p < 1 ? 1 + (rnd(k, 8) - .5) * .3 * (1 - p) : 1 }; }, { n: 24, hold: true }),
    F('flicker', 'نيون بيرعش', 'in', function (p) { var k = Math.floor(p * 14); return { o: p >= 1 ? 1 : (rnd(k, 2) > .45 ? 1 : .1) }; }, { n: 16, hold: true }),
    F('card', 'كارت بيلف', 'in', function (p) { var e = E.out5(p); return { o: cl(p * 3, 0, 1), sw: Math.max(.02, Math.cos((1 - e) * PI / 2)), dy: (1 - e) * .02 }; }, { n: 14 })
  ];
  var OUTS = [
    F('o_fade', 'يختفي بهدوء', 'out', function (q) { return { o: E.out(q) }; }, { n: 6 }),
    F('o_shrink', 'يصغر', 'out', function (q) { var e = E.inC(1 - q); return { o: cl(q * 3, 0, 1), s: lerp(1, .2, e) }; }),
    F('o_through', 'زووم لجوه الشاشة', 'out', function (q) { var e = E.inC(1 - q); return { o: q, s: lerp(1, 3.2, e), blur: e * 24 }; }),
    F('o_apple', 'أبل (بلور طالع)', 'out', function (q) { var e = E.out(1 - q); return { o: q, blur: e * 26, dy: -e * .02 }; }),
    F('o_blur', 'بلور', 'out', function (q) { var e = E.out(1 - q); return { o: q, blur: e * 32 }; }),
    F('o_rise', 'يطلع لفوق', 'out', function (q) { var e = E.inC(1 - q); return { o: q, dy: -e * .08 }; }),
    F('o_fall', 'يقع لتحت', 'out', function (q) { var e = E.inC(1 - q); return { o: cl(q * 2, 0, 1), dy: e * .35, r: e * 25 }; }),
    F('o_left', 'خارج شمال', 'out', function (q) { var e = E.inC(1 - q); return { o: cl(q * 2, 0, 1), dx: -e * .7, blur: e * 30 }; }),
    F('o_right', 'خارج يمين', 'out', function (q) { var e = E.inC(1 - q); return { o: cl(q * 2, 0, 1), dx: e * .7, blur: e * 30 }; }),
    F('o_flip', 'قلب وخروج', 'out', function (q) { var e = E.io(1 - q); return { o: cl(q * 3, 0, 1), sw: Math.max(.01, 1 - e) }; }),
    F('o_flicker', 'يرعش ويختفي', 'out', function (q) { var k = Math.floor((1 - q) * 14); return { o: q <= 0 ? 0 : (rnd(k, 4) > .5 ? 1 : .1) }; }, { n: 16, hold: true })
  ];
  var LOOPS = [
    F('l_float', 'عايم', 'loop', function (t) { return { dy: Math.sin(t * 2.2) * .006 }; }),
    F('l_breathe', 'بيتنفس', 'loop', function (t) { return { s: 1 + Math.sin(t * 2.4) * .025 }; }),
    F('l_beat', 'نبض قلب', 'loop', function (t) { var u = (t * 1.2) % 1, b = Math.exp(-u * 18) + Math.exp(-Math.max(0, u - .22) * 18) * (u > .22 ? .7 : 0); return { s: 1 + b * .06 }; }, { rate: 20 }),
    F('l_wiggle', 'هزة خفيفة', 'loop', function (t) { return { r: Math.sin(t * 7) * 2.2 }; }, { rate: 16 }),
    F('l_shake', 'بيتهز', 'loop', function (t) { var k = Math.floor(t * 18); return { dx: (rnd(k, 1) - .5) * .008, dy: (rnd(k, 2) - .5) * .008 }; }, { rate: 18, hold: true }),
    F('l_push', 'زووم بطيء لجوه', 'loop', function (t, d) { return { s: 1 + cl(t / d, 0, 1) * .08 }; }, { rate: 2 }),
    F('l_pull', 'زووم بطيء لبره', 'loop', function (t, d) { return { s: 1.08 - cl(t / d, 0, 1) * .08 }; }, { rate: 2 }),
    F('l_drift', 'زحف جنب', 'loop', function (t, d) { return { dx: (cl(t / d, 0, 1) - .5) * .03 }; }, { rate: 2 }),
    F('l_sway', 'تمايل', 'loop', function (t) { return { r: Math.sin(t * 1.6) * 3, dy: Math.sin(t * 3.2) * .003 }; })
  ];
  var BY = {}; INS.concat(OUTS, LOOPS).forEach(function (p) { BY[p.id] = p; });

  var DEF = { inDur: .55, outDur: .45, pivot: 'keep' };
  var P = (function () { var o = {}, s = st.get('set', {}), k; for (k in DEF) o[k] = DEF[k]; for (k in s) o[k] = s[k]; return o; })();
  function save() { st.set('set', P); }

  /* all props of a stack (in / out / loop) at time t in a clip of length d */
  function propsAt(stack, t, d) {
    var r = { o: 1, dx: 0, dy: 0, s: 1, sw: 1, sh: 1, r: 0, blur: 0 };
    function add(x) { if (!x) return; if (x.o !== undefined) r.o *= x.o; if (x.s !== undefined) r.s *= x.s; if (x.sw !== undefined) r.sw *= x.sw; if (x.sh !== undefined) r.sh *= x.sh; r.dx += x.dx || 0; r.dy += x.dy || 0; r.r += x.r || 0; r.blur += x.blur || 0; }
    var inD = Math.min(P.inDur, d * .45), outD = Math.min(P.outDur, d * .45);
    if (stack.in && BY[stack.in]) add(BY[stack.in].f(cl(t / Math.max(.01, inD), 0, 1)));
    if (stack.out && BY[stack.out]) add(BY[stack.out].f(cl((d - t) / Math.max(.01, outD), 0, 1)));
    if (stack.loop && BY[stack.loop]) add(BY[stack.loop].f(t, d));
    return r;
  }
  function sampleTimes(stack, d, fps) {
    var ts = [0, d], fr = 1 / (fps || 30), inD = Math.min(P.inDur, d * .45), outD = Math.min(P.outDur, d * .45);
    function seg(a, b, n) { for (var i = 0; i <= n; i++) ts.push(a + (b - a) * i / n); }
    if (stack.in && BY[stack.in]) seg(0, inD, BY[stack.in].hold ? Math.max(4, Math.round(inD / fr)) : BY[stack.in].n);
    if (stack.out && BY[stack.out]) seg(d - outD, d, BY[stack.out].hold ? Math.max(4, Math.round(outD / fr)) : BY[stack.out].n);
    if (stack.loop && BY[stack.loop]) { var L = BY[stack.loop], rate = L.rate || 10; seg(0, d, Math.max(2, Math.min(600, Math.round(d * rate)))); }
    ts = ts.map(function (t) { return Math.round(cl(t, 0, d - fr) / fr) * fr; }).sort(function (a, b) { return a - b; });
    return ts.filter(function (t, i) { return i === 0 || t - ts[i - 1] > fr * .5; });
  }
  /* keyframes for one clip; base: { scale, pos:[x,y], anchor:[x,y] }; W/H = frame */
  function keysFor(stack, clip, base, fps, W, H) {
    var d = clip.end - clip.start, ts = sampleTimes(stack, d, fps), out = { opacity: [], pos: [], scale: [], scaleW: [], rot: [], blur: [] };
    var k0 = (base.scale || 100) / 100, A0 = base.anchor || [.5, .5], P0 = base.pos || [.5, .5], A = A0, P1 = P0;
    if (P.pivot !== 'keep') { var q = [.5, { top: .22, mid: .5, low: .78 }[P.pivot] || .5]; A = q; P1 = [P0[0] + (q[0] - A0[0]) * k0, P0[1] + (q[1] - A0[1]) * k0]; }
    var bs = H / 1080, nonUni = false, used = { o: 0, pos: 0, s: 0, r: 0, blur: 0 };
    var rows = ts.map(function (t) { var r = propsAt(stack, t, d); if (Math.abs(r.sw - 1) > 1e-4 || Math.abs(r.sh - 1) > 1e-4) nonUni = true; return [t, r]; });
    rows.forEach(function (row) {
      var r = row[1];
      if (Math.abs(r.o - 1) > 1e-4) used.o = 1; if (Math.abs(r.dx) > 1e-5 || Math.abs(r.dy) > 1e-5) used.pos = 1;
      if (Math.abs(r.s - 1) > 1e-4 || nonUni) used.s = 1; if (Math.abs(r.r) > 1e-3) used.r = 1; if (r.blur > .05) used.blur = 1;
    });
    rows.forEach(function (row) {
      var t = clip.start + row[0], r = row[1];
      if (used.o) out.opacity.push([t, Math.round(cl(r.o, 0, 1) * (base.opacity === undefined ? 100 : base.opacity) * 10) / 10]);
      if (used.pos) out.pos.push([t, [P1[0] + r.dx, P1[1] + r.dy]]);
      if (used.s) { out.scale.push([t, Math.round(base.scale * r.s * (nonUni ? r.sh : 1) * 100) / 100]); if (nonUni) out.scaleW.push([t, Math.round(base.scale * r.s * r.sw * 100) / 100]); }
      if (used.r) out.rot.push([t, Math.round(((base.rot || 0) + r.r) * 100) / 100]);
      if (used.blur) out.blur.push([t, Math.round(r.blur * bs * 10) / 10]);
    });
    var res = { uniform: !nonUni }; for (var k in out) if (out[k].length) res[k] = out[k];
    if (P.pivot !== 'keep') { res.anchor = A; if (!used.pos) res.posStatic = P1; }
    res.count = ts.length;
    return res;
  }

  /* ---------- tab ---------- */
  var ui = {}, tiles = [], raf = 0, last = 0, visible = false, busy = false;
  function stackOf(id) { var all = st.get('stacks', {}); return all[id] || {}; }
  function clipKey(c) { return (c.id || '') + '|' + c.track + '|' + c.start.toFixed(3); }
  function apply(slot, presetId) {
    if (busy) return; busy = true;
    ui.status.show('busy', 'بقرا الكليبات المختارة…'); ui.prog.set(0);
    Sys.call('cr_clips', { fallback: false }).then(function (r) {
      if (!r || !r.ok) throw new Error(r && r.error === 'no_sequence' ? 'افتح سيكوينس الأول.' : 'حصلت مشكلة');
      if (!r.clips.length) throw new Error('اختار الكلام (أو الكليبات) في التايملاين الأول — تقدر تختار كذا واحد مع بعض.');
      var stacks = st.get('stacks', {}), bases = st.get('bases', {}), done = 0, warn = '', keys = 0;
      return r.clips.reduce(function (pr, c) {
        return pr.then(function () {
          var id = clipKey(c), sk = stacks[id] || {};
          if (slot === 'clear') sk = {}; else sk[slot] = presetId;
          if (!bases[id] || !c.keyed) bases[id] = { scale: c.scale || 100, pos: c.pos || [.5, .5], anchor: c.anchor || [.5, .5], opacity: typeof c.opacity === 'number' ? c.opacity : 100, rot: typeof c.rot === 'number' ? c.rot : 0 };
          var b = bases[id], ks = keysFor(sk, c, b, r.fps, r.w, r.h), empty = !sk.in && !sk.out && !sk.loop;
          return Sys.call('cr_fx', { clip: { track: c.track, start: c.start, id: c.id }, p: ks, base: { scale: b.scale, pos: b.pos, anchor: b.anchor, opacity: b.opacity === undefined ? 100 : b.opacity, rot: b.rot || 0 }, clearOnly: empty }).then(function (x) {
            if (!x || !x.ok) throw new Error(x && x.error === 'clip_moved' ? 'الكليب اتحرك — اختاره تاني.' : 'حصلت مشكلة [' + (x && (x.error || x.detail)) + ']');
            if (x.warn === 'no_blur') warn = 'البلور ماتحطش (مالقيتش Gaussian Blur) — باقي الحركة اتحطت.';
            keys += x.n; done++; ui.prog.set(done / r.clips.length);
            if (empty) { delete stacks[id]; delete bases[id]; } else stacks[id] = sk;
          });
        });
      }, Promise.resolve()).then(function () {
        st.set('stacks', stacks); st.set('bases', bases);
        ui.status.show(warn ? 'warn' : 'ok', (slot === 'clear' ? 'رجّعت ' + done + ' كليب زي ما كانوا.' : 'اتحط «' + BY[presetId].name + '» على ' + done + ' كليب (' + keys + ' كيفريم).') + (warn ? ' ' + warn : ''));
      });
    }).catch(function (e) { ui.status.show('err', e.message || String(e)); }).then(function () { busy = false; ui.prog.done(); });
  }

  /* little looping previews */
  function drawTile(T, now) {
    var cv = T.cv, w = cv.width, hh = cv.height, x = cv.getContext('2d'), d = 2.4, cyc = (now / 1000 + T.ph) % (d + .5), t = Math.min(cyc, d);
    var stack = {}; stack[T.p.kind === 'in' ? 'in' : T.p.kind === 'out' ? 'out' : 'loop'] = T.p.id;
    var r = propsAt(stack, T.p.kind === 'out' ? Math.max(0, t) : t, d);
    if (T.p.kind === 'in' && cyc > d) r.o = 0;
    x.setTransform(1, 0, 0, 1, 0, 0); x.clearRect(0, 0, w, hh);
    x.save(); x.globalAlpha = cl(r.o, 0, 1);
    if (r.blur > .3) x.filter = 'blur(' + (r.blur * hh / 1080 * 3).toFixed(1) + 'px)';
    x.translate(w / 2 + r.dx * w * 1.6, hh / 2 + r.dy * hh * 3); x.rotate(r.r * PI / 180); x.scale(r.s * r.sw, r.s * r.sh);
    x.font = '800 ' + Math.round(hh * .34) + 'px "Segoe UI", Tahoma, Arial'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillStyle = '#fff';
    x.shadowColor = 'rgba(228,138,166,.8)'; x.shadowBlur = 10; x.fillText('ENP', 0, 0); x.restore();
  }
  function loop(now) {
    raf = 0; if (!visible) return;
    if (now - last > 33) { last = now; tiles.forEach(function (T) { if (T.cv.offsetParent !== null) drawTile(T, now); }); }
    raf = G.requestAnimationFrame(loop);
  }
  function grid(list, slot) {
    var box = h('div', { class: 'fxgrid' });
    list.forEach(function (p, i) {
      var cv = h('canvas', { width: 150, height: 84 });
      var b = h('button', { type: 'button', class: 'fxtile', title: p.name, onclick: function () { apply(slot, p.id); } }, [cv, h('span', { text: p.name })]);
      tiles.push({ cv: cv, p: p, ph: i * .13 }); box.appendChild(b);
    });
    return box;
  }
  function build(root) {
    ui.status = K.status(); ui.prog = K.progress();
    var sl = function (k, label, min, max, step) { return K.slider({ label: label, min: min, max: max, step: step, value: P[k], fmt: function (v) { return (+v).toFixed(2) + ' ث'; }, onInput: function (v) { P[k] = v; save(); } }); };
    [h('div', { class: 'hint intro', text: 'حدد الكلام (أو أي كليبات) في التايملاين — كذا واحد مع بعض — ودوس على أي تأثير: بيتحط على كل واحد ويتظبط على طوله. تقدر تجمع دخول + خروج + حركة مستمرة على نفس الكليبات.' }),
      h('div', { class: 'out' }, [K.btn('شيل التأثيرات من المختار', { cls: 'ghost', icon: 'undo', onClick: function () { apply('clear'); } }), ui.prog, ui.status]),
      K.section('الدخول (' + INS.length + ')', [grid(INS, 'in')], true, 'fx_in'),
      K.section('الخروج (' + OUTS.length + ')', [grid(OUTS, 'out')], true, 'fx_out'),
      K.section('حركة مستمرة (' + LOOPS.length + ')', [grid(LOOPS, 'loop')], false, 'fx_loop'),
      K.section('الإعدادات', [sl('inDur', 'مدة الدخول', .15, 2, .05), sl('outDur', 'مدة الخروج', .15, 2, .05),
        K.field('الكلام فين في الكادر؟ (للتكبير واللف)', K.seg({ items: [{ v: 'keep', label: 'زي ما هو' }, { v: 'top', label: 'فوق' }, { v: 'mid', label: 'النص' }, { v: 'low', label: 'تحت' }], value: P.pivot, onChange: function (v) { P.pivot = v; save(); } })),
        h('div', { class: 'hint', text: 'التكبير واللف بيحصلوا حوالين النقطة دي. لو الكلام تحت (زي الكابشن) اختار «تحت» عشان مايتحركش لنص الشاشة.' })], false, 'fx_set')
    ].forEach(function (el) { root.appendChild(el); });
  }
  G.FxTab = { build: build, onShow: function () { visible = true; if (!raf) raf = G.requestAnimationFrame(loop); }, onHide: function () { visible = false; },
    _keys: keysFor, _props: propsAt, BY: BY, count: INS.length + OUTS.length + LOOPS.length };
})(window);
