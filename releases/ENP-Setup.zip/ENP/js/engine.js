/* Carousel 3D — scene engine.
   Pure math: settings + time -> list of cards with 4x4 matrices.
   No DOM, no WebGL here, so the same file drives the panel preview,
   the final render and the look thumbnails. */
(function (G) {
  'use strict';
  var PI = Math.PI, TAU = PI * 2, DEG = PI / 180;

  /* ---------- small 4x4 matrix kit (column-major, like WebGL) ---------- */
  function I() { return [1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1]; }
  function mul(a, b) {
    var o = new Array(16);
    for (var c = 0; c < 4; c++) for (var r = 0; r < 4; r++) {
      o[c*4+r] = a[r]*b[c*4] + a[4+r]*b[c*4+1] + a[8+r]*b[c*4+2] + a[12+r]*b[c*4+3];
    }
    return o;
  }
  function chain() { var m = arguments[0]; for (var i = 1; i < arguments.length; i++) m = mul(m, arguments[i]); return m; }
  function T(x, y, z) { var m = I(); m[12] = x; m[13] = y; m[14] = z; return m; }
  function S(x, y, z) { var m = I(); m[0] = x; m[5] = y; m[10] = z; return m; }
  function RX(a) { var c = Math.cos(a), s = Math.sin(a); return [1,0,0,0, 0,c,s,0, 0,-s,c,0, 0,0,0,1]; }
  function RY(a) { var c = Math.cos(a), s = Math.sin(a); return [c,0,-s,0, 0,1,0,0, s,0,c,0, 0,0,0,1]; }
  function RZ(a) { var c = Math.cos(a), s = Math.sin(a); return [c,s,0,0, -s,c,0,0, 0,0,1,0, 0,0,0,1]; }
  function xf(m, v) {
    var w = v.length > 3 ? v[3] : 1;
    return [m[0]*v[0]+m[4]*v[1]+m[8]*v[2]+m[12]*w, m[1]*v[0]+m[5]*v[1]+m[9]*v[2]+m[13]*w,
            m[2]*v[0]+m[6]*v[1]+m[10]*v[2]+m[14]*w, m[3]*v[0]+m[7]*v[1]+m[11]*v[2]+m[15]*w];
  }
  function persp(fovy, asp, n, f) {
    var t = 1 / Math.tan(fovy / 2), nf = 1 / (n - f);
    return [t/asp,0,0,0, 0,t,0,0, 0,0,(f+n)*nf,-1, 0,0,2*f*n*nf,0];
  }

  /* ---------- helpers ---------- */
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function lerp(a, b, k) { return a + (b - a) * k; }
  function wrapC(v, n) { if (n <= 0) return v; v = ((v % n) + n) % n; return v > n / 2 ? v - n : v; } // -> (-n/2, n/2]
  function wrapFrom(v, n, lo) { return n > 0 ? (((v - lo) % n) + n) % n + lo : v; }
  function hex(c) {
    var s = String(c || '#000').replace('#', '');
    if (s.length === 3) s = s[0]+s[0]+s[1]+s[1]+s[2]+s[2];
    var n = parseInt(s.slice(0, 6), 16) || 0;
    return [(n >> 16 & 255) / 255, (n >> 8 & 255) / 255, (n & 255) / 255];
  }

  var EASE = {
    smooth: function (x) { x = clamp(x, 0, 1); return x < .5 ? 4*x*x*x : 1 - Math.pow(-2*x + 2, 3) / 2; },
    snappy: function (x) { x = clamp(x, 0, 1); return x >= 1 ? 1 : 1 - Math.pow(2, -10 * x); },
    spring: function (x) { x = clamp(x, 0, 1); if (x >= 1) return 1; var e = 1 - Math.exp(-6 * x) * Math.cos(10.5 * x); return e + x * (1 - (1 - Math.exp(-6) * Math.cos(10.5))); },
    back: function (x) { x = clamp(x, 0, 1); var c = 1.70158 * 1.525; return x < .5 ? (Math.pow(2*x, 2) * ((c+1)*2*x - c)) / 2 : (Math.pow(2*x-2, 2) * ((c+1)*(x*2-2) + c) + 2) / 2; },
    linear: function (x) { return clamp(x, 0, 1); }
  };
  function ease(name) { return EASE[name] || EASE.smooth; }
  function outCubic(x) { x = clamp(x, 0, 1); return 1 - Math.pow(1 - x, 3); }
  function outBack(x) { x = clamp(x, 0, 1); var c = 1.9; return 1 + (c + 1) * Math.pow(x - 1, 3) + c * Math.pow(x - 1, 2); }
  function outBounce(x) {
    x = clamp(x, 0, 1); var n = 7.5625, d = 2.75;
    if (x < 1/d) return n*x*x; if (x < 2/d) { x -= 1.5/d; return n*x*x + .75; }
    if (x < 2.5/d) { x -= 2.25/d; return n*x*x + .9375; } x -= 2.625/d; return n*x*x + .984375;
  }

  /* ---------- defaults & catalog ---------- */
  var DEF = {
    look: 'ring', layout: 'ring', count: 0, aspect: '9:16',
    size: 1, gap: .1, radius: 1, angle: 0, rows: 2,
    corner: .06, border: 0, borderColor: '#ffffff', shadow: .45, reflect: 0,
    thick: 0, thickColor: '#e8e8ee', backs: 'mirror', backColor: '#1d1d24', fit: 'cover',
    tilt: 8, yaw: 0, roll: 0, dist: 2.4, x: .5, y: .5, scale: 1, camA: null, cam2: null, camEase: 'smooth',
    motion: 'step', dir: 1, secPerCard: 1.4, hold: 1, move: .6, ease: 'smooth', start: 0,
    blur: .35, dim: .35, fade: 0, focus: 1, glow: 0, glowColor: '#e48aa6',
    intro: 'unfold', introDur: .9, outro: 'fade', outroDur: .6,
    bg: 'none', bgColor: '#000000', bgAlpha: .55, dur: 6, split: false
  };

  /* fill = how much of the frame height the front card takes at scale 1 */
  var LAYOUTS = {
    ring:      { min: 6,  fill: .48, reflect: true },
    inside:    { min: 10, fill: .5,  inside: true },
    coverflow: { min: 5,  fill: .52, reflect: true, angle: 55 },
    wheel:     { min: 8,  fill: .17 },
    slot:      { min: 6,  fill: .42 },
    stack:     { min: 4,  fill: .5 },
    fan:       { min: 5,  fill: .42, angle: 13 },
    wall:      { min: 8,  fill: .28 },
    helix:     { min: 8,  fill: .34 },
    orbit:     { min: 6,  fill: .3, billboard: true },
    arc:       { min: 5,  fill: .48, reflect: true },
    tunnel:    { min: 5,  fill: .5 },
    strip:     { min: 5,  fill: .44, reflect: true, angle: 28 },
    sphere:    { min: 14, fill: .2 }
  };

  /* A look = a layout + a starting set of options. */
  var LOOKS = [
    { id: 'ring',       layout: 'ring',      set: { tilt: 12, reflect: .22, shadow: .4, blur: .4, dim: .4, motion: 'step', intro: 'unfold', corner: .06 } },
    { id: 'ring_top',   layout: 'ring',      set: { tilt: 28, dist: 2.8, shadow: .5, blur: .3, dim: .45, motion: 'spin', secPerCard: 1.1, intro: 'spin', radius: 1.1 } },
    { id: 'ring_thick', layout: 'ring',      set: { tilt: 6, thick: .035, corner: .03, blur: .25, dim: .35, shadow: .3, motion: 'step', ease: 'spring', intro: 'grow' } },
    { id: 'inside',     layout: 'inside',    set: { tilt: 0, dist: 2.2, blur: .5, dim: .25, motion: 'spin', secPerCard: 1.6, intro: 'fly', shadow: 0 } },
    { id: 'coverflow',  layout: 'coverflow', set: { tilt: 4, reflect: .32, angle: 58, blur: .2, dim: .35, motion: 'step', intro: 'unfold', shadow: .35, focus: 1.04 } },
    { id: 'strip',      layout: 'strip',     set: { tilt: 10, reflect: .2, gap: .12, blur: .45, dim: .2, motion: 'spin', secPerCard: .9, intro: 'rise' } },
    { id: 'stack',      layout: 'stack',     set: { tilt: 6, shadow: .6, blur: .15, dim: .25, motion: 'step', ease: 'snappy', hold: 1.1, move: .5, intro: 'drop' } },
    { id: 'fan',        layout: 'fan',       set: { tilt: 0, shadow: .55, blur: 0, dim: .3, motion: 'step', ease: 'spring', intro: 'unfold', focus: 1.08 } },
    { id: 'wheel',      layout: 'wheel',     set: { tilt: 12, y: .3, shadow: .4, blur: .15, dim: .15, motion: 'spin', secPerCard: .9, intro: 'grow', corner: .1 } },
    { id: 'slot',       layout: 'slot',      set: { tilt: 0, blur: .45, dim: .5, motion: 'step', ease: 'back', intro: 'rise', shadow: .2 } },
    { id: 'wall',       layout: 'wall',      set: { tilt: 3, rows: 2, gap: .08, blur: .25, dim: .3, motion: 'spin', secPerCard: 1.2, intro: 'pop', shadow: .3 } },
    { id: 'helix',      layout: 'helix',     set: { tilt: 14, blur: .4, dim: .4, motion: 'spin', secPerCard: 1, intro: 'rise', shadow: .3 } },
    { id: 'orbit',      layout: 'orbit',     set: { tilt: 8, y: .45, blur: .45, dim: .35, motion: 'spin', secPerCard: 1.3, intro: 'grow', shadow: .35, corner: .08 } },
    { id: 'arc',        layout: 'arc',       set: { tilt: 5, reflect: .25, blur: .3, dim: .3, motion: 'step', intro: 'unfold', shadow: .3, focus: 1.06 } },
    { id: 'tunnel',     layout: 'tunnel',    set: { tilt: 0, dist: 2.2, blur: .55, dim: .45, motion: 'step', hold: .9, move: .7, intro: 'fly', shadow: .3 } },
    { id: 'sphere',     layout: 'sphere',    set: { tilt: 6, blur: .4, dim: .5, motion: 'spin', secPerCard: .35, intro: 'grow', shadow: 0, corner: .08, aspect: '1:1' } }
  ];
  function look(id) { for (var i = 0; i < LOOKS.length; i++) if (LOOKS[i].id === id) return LOOKS[i]; return LOOKS[0]; }

  /* the settings of a look: defaults, then the look's own values */
  function withLook(base, id) {
    var L = look(id), o = {}, k;
    for (k in DEF) o[k] = DEF[k];
    for (k in (base || {})) if (base[k] !== undefined) o[k] = base[k];
    // look-controlled values reset to defaults first, so looks don't leak into each other
    ['tilt','yaw','roll','dist','reflect','shadow','blur','dim','fade','focus','glow','thick','corner','gap','radius','angle','rows',
     'motion','secPerCard','hold','move','ease','intro','outro','start','cam2','camA'].forEach(function (k2) { o[k2] = DEF[k2]; });
    for (k in L.set) o[k] = L.set[k];
    o.layout = L.layout; o.look = L.id;
    return o;
  }
  function norm(s) {
    var o = {}, k;
    for (k in DEF) o[k] = DEF[k];
    for (k in (s || {})) if (s[k] !== undefined && s[k] !== null) o[k] = s[k];
    if (!LAYOUTS[o.layout]) o.layout = 'ring';
    o.dir = +o.dir < 0 ? -1 : 1;
    return o;
  }
  function aspectOf(a) {
    var m = /^(\d+(?:\.\d+)?)\s*[:x\/]\s*(\d+(?:\.\d+)?)$/.exec(String(a || ''));
    return m && +m[2] > 0 ? +m[1] / +m[2] : 9 / 16;
  }
  function cardCount(s, n) {
    var c = Math.round(+s.count || 0);
    return c > 0 ? clamp(c, 2, 60) : Math.max(LAYOUTS[s.layout].min, n || 0);
  }
  function angleOf(s) { var L = LAYOUTS[s.layout]; return (+s.angle > 0 ? +s.angle : (L.angle || 30)) * DEG; }

  /* ---------- motion: which card is in front at time t (float) ---------- */
  function focusAt(s, N, t, markers) {
    var st = +s.start || 0, dir = s.dir, e = ease(s.ease);
    switch (s.motion) {
      case 'still': return st;
      case 'spin': return st + dir * t / Math.max(.15, +s.secPerCard || 1.4);
      case 'once': {
        var a = (+s.introDur || 0) * .5, b = Math.max(a + .1, (+s.dur || 6) - (+s.outroDur || 0) * .5);
        return st + dir * N * e((t - a) / (b - a));
      }
      case 'markers': {
        var f = st, mv = Math.max(.05, +s.move || .6);
        (markers || []).forEach(function (m) { if (t > m) f += dir * e((t - m) / mv); });
        return f;
      }
      default: { // step
        var h = Math.max(0, +s.hold || 0), m2 = Math.max(.05, +s.move || .6), cyc = h + m2;
        var n = Math.floor(t / cyc), r = t - n * cyc;
        return st + dir * (n + (r < h ? 0 : e((r - h) / m2)));
      }
    }
  }

  /* ---------- layouts ---------- */
  function ringR(s, N, span) { return Math.max(span * .6, span / (2 * Math.sin(PI / Math.max(3, N)))) * (+s.radius || 1); }
  function seam(N, d) { return clamp((N / 2 - Math.abs(d)) / .9, 0, 1); }

  /* returns {x,y,z, rx,ry,rz, sc, op, k(front-ness 0..1), d, bb(billboard)} for card i */
  function place(s, i, f, N, W, H) {
    var p = (+s.gap || 0) * W, c = { x:0,y:0,z:0, rx:0,ry:0,rz:0, sc:1, op:1, bb:false };
    var d = wrapC(i - f, N), ad = Math.abs(d);
    c.k = Math.max(0, 1 - ad); c.d = d;
    switch (s.layout) {
      case 'ring': { var R = ringR(s, N, W + p), a = d * TAU / N; c.x = R * Math.sin(a); c.z = R * Math.cos(a) - R; c.ry = a; c.center = [0,0,-R]; break; }
      case 'inside': { var R2 = 1.15 * ringR(s, N, W + p), a2 = d * TAU / N; c.x = R2 * Math.sin(a2); c.z = R2 - R2 * Math.cos(a2); c.ry = -a2; c.center = [0,0,R2]; break; }
      case 'coverflow': {
        var k = clamp(d, -1, 1), ang = angleOf(s), near = .5 * W + p + .5 * W * Math.cos(ang), far = W * (.3 + (+s.gap || 0));
        c.x = k * near + (d - k) * far; c.z = -Math.abs(k) * W * .55 - Math.max(0, ad - 1) * W * .05; c.ry = -k * ang;
        c.op = seam(N, d); break;
      }
      case 'wheel': { var R3 = ringR(s, N, H + p), a3 = d * TAU / N; c.x = R3 * Math.sin(a3); c.y = R3 * Math.cos(a3) - R3; c.rz = -a3; c.center = [0,-R3,0]; break; }
      case 'slot': { var R4 = ringR(s, N, H + p), a4 = d * TAU / N; c.y = -R4 * Math.sin(a4); c.z = R4 * Math.cos(a4) - R4; c.rx = a4; c.center = [0,0,-R4]; break; }
      case 'stack': {
        var e = wrapFrom(i - f, N, -1);
        if (e >= 0) {
          c.x = e * W * .1; c.y = e * H * .035; c.z = -e * W * .3; c.sc = 1 - .04 * e;
          c.rz = -3 * e * DEG; c.ry = -4 * e * DEG; c.op = clamp(4.5 - e, 0, 1); c.k = Math.max(0, 1 - e);
        } else {
          var L = -e;
          c.x = -L * W * 1.9; c.y = L * H * .08; c.z = L * W * .3; c.rz = -24 * L * DEG; c.ry = -38 * L * DEG;
          c.op = clamp(1 - 1.15 * L, 0, 1); c.k = Math.max(0, 1 - L);
        }
        c.d = e; break;
      }
      case 'fan': {
        var P = 1.6 * H, ph = d * angleOf(s);
        c.x = P * Math.sin(ph); c.y = P * Math.cos(ph) - P + .08 * H * c.k; c.z = -ad * W * .02; c.rz = -ph; c.op = seam(N, d); break;
      }
      case 'wall': {
        var rows = clamp(Math.round(+s.rows || 2), 1, 4), cols = Math.max(1, Math.ceil(N / rows));
        var row = i % rows, dc = wrapC(Math.floor(i / rows) - f, cols);
        var Rr = (W + p) * Math.max(3, cols) / 1.6, ph2 = dc * (W + p) / Rr;
        c.x = Rr * Math.sin(ph2); c.z = Rr * (1 - Math.cos(ph2)); c.ry = -ph2; c.y = ((rows - 1) / 2 - row) * (H + p);
        c.op = clamp((cols / 2 - Math.abs(dc)) / .8, 0, 1); c.k = Math.max(0, 1 - Math.abs(dc)) * (rows === 1 ? 1 : .999); c.d = dc; break;
      }
      case 'helix': {
        var Nh = Math.min(N, 8), R5 = ringR(s, Nh, W + p), a5 = d * TAU / Nh;
        c.x = R5 * Math.sin(a5); c.z = R5 * Math.cos(a5) - R5; c.ry = a5; c.y = -d * H * .32; c.op = seam(N, d); break;
      }
      case 'orbit': {
        var R6 = 1.7 * ringR(s, N, W + p), a6 = d * TAU / N, b = 18 * DEG;
        c.x = R6 * Math.sin(a6); c.y = -R6 * Math.cos(a6) * Math.sin(b) + R6 * Math.sin(b); c.z = R6 * Math.cos(a6) * Math.cos(b) - R6;
        c.bb = true; c.center = [0, R6 * Math.sin(b), -R6 * Math.cos(b)]; break;
      }
      case 'arc': {
        var Ra = 3.2 * (W + p), ph3 = d * (W + p) / Ra;
        c.x = Ra * Math.sin(ph3); c.z = Ra * (1 - Math.cos(ph3)) * .85; c.ry = -ph3; c.op = seam(N, d); break;
      }
      case 'tunnel': {
        var e2 = wrapFrom(i - f, N, -1);
        if (e2 >= 0) { c.z = -e2 * W * 1.6; c.x = e2 * W * .38; c.y = e2 * H * .18; c.ry = -6 * e2 * DEG; c.op = clamp(5.5 - e2, 0, 1); c.k = Math.max(0, 1 - e2); }
        else { c.z = -e2 * W * 3; c.x = e2 * W * .45; c.y = e2 * H * .3; c.op = clamp(1 + 1.4 * e2, 0, 1); c.k = Math.max(0, 1 + e2); }
        c.d = e2; break;
      }
      case 'strip': {
        var ang2 = angleOf(s), q = d * (W + p);
        c.x = q * Math.cos(ang2); c.z = -q * Math.sin(ang2); c.ry = ang2; c.op = seam(N, d); break;
      }
      case 'sphere': {
        var yN = 1 - 2 * (i + .5) / N, r = Math.sqrt(Math.max(0, 1 - yN * yN));
        var ph4 = i * PI * (3 - Math.sqrt(5)) - f * TAU / N, Rs = Math.sqrt(N) * W * .5 * (+s.radius || 1);
        var sx = Math.sin(ph4) * r, sz = Math.cos(ph4) * r;
        c.x = Rs * sx; c.y = Rs * yN; c.z = Rs * sz - Rs; c.ry = Math.atan2(sx, sz); c.rx = -Math.asin(clamp(yN, -1, 1));
        c.k = clamp((sz - .82) / .18, 0, 1); c.d = 1 - sz; c.center = [0,0,-Rs]; break;
      }
    }
    return c;
  }

  /* ---------- intro / outro ---------- */
  function animIn(kind, p, c, H, W) {
    if (kind === 'none' || p >= 1) return;
    var e = outCubic(p);
    switch (kind) {
      case 'fade': c.op *= e; break;
      case 'grow': c.sc *= lerp(.35, 1, outBack(p)); c.op *= clamp(p * 3, 0, 1); break;
      case 'rise': c.y -= (1 - e) * H * 2.2; c.op *= clamp(p * 2.5, 0, 1); break;
      case 'drop': c.y += (1 - outBounce(p)) * H * 2.4; c.op *= clamp(p * 4, 0, 1); break;
      case 'unfold': c.op *= clamp(p * 4, 0, 1); break;              // handled by spreading d
      case 'spin': c.op *= clamp(p * 2.5, 0, 1); break;               // handled by group spin
      case 'fly': c.z -= (1 - e) * W * 14; c.op *= clamp(p * 2, 0, 1); break;
      case 'pop': c.sc *= outBack(p); c.op *= clamp(p * 4, 0, 1); break;
    }
  }
  function animOut(kind, p, c, H, W) { // p: 1 = fully visible, 0 = gone
    if (kind === 'none' || p >= 1) return;
    var e = 1 - outCubic(1 - p); // eases in as it leaves
    switch (kind) {
      case 'fade': c.op *= p; break;
      case 'shrink': c.sc *= lerp(.2, 1, e); c.op *= clamp(p * 2, 0, 1); break;
      case 'fall': c.y -= (1 - e) * (1 - e) * H * 3; c.rz += (1 - p) * .4 * (c.d >= 0 ? 1 : -1); c.op *= clamp(p * 2, 0, 1); break;
      case 'fold': c.op *= clamp(p * 3, 0, 1); break;
      case 'spin': c.op *= clamp(p * 2, 0, 1); break;
      case 'fly': c.z -= (1 - e) * W * 14; c.op *= clamp(p * 1.6, 0, 1); break;
    }
  }

  /* ---------- camera ---------- */
  function camAt(s, t) {
    var a = { tilt: +s.tilt || 0, yaw: +s.yaw || 0, roll: +s.roll || 0, dist: +s.dist || 2.4, x: +s.x, y: +s.y, scale: +s.scale || 1 };
    if (!s.cam2) return a;
    var b = s.cam2, k = ease(s.camEase)(t / Math.max(.1, +s.dur || 6)), o = {};
    for (var key in a) o[key] = lerp(a[key], +b[key], k);
    return o;
  }

  /* ---------- one frame ---------- */
  /* opts: { n: media count, w, h (pixels), t, markers, layer: 'all'|'back'|'front' } */
  function frame(settings, opts) {
    var s = norm(settings), L = LAYOUTS[s.layout];
    var N = cardCount(s, opts.n), t = opts.t || 0, dur = Math.max(.3, +s.dur || 6);
    var ar = aspectOf(s.aspect), W = +s.size || 1, H = W / ar;
    var f = focusAt(s, N, t, opts.markers);
    var cam = camAt(s, t);

    var pIn = s.intro === 'none' ? 1 : clamp(t / Math.max(.05, +s.introDur || .9), 0, 1);
    var pOut = s.outro === 'none' ? 1 : clamp((dur - t) / Math.max(.05, +s.outroDur || .6), 0, 1);
    var spread = 1;
    if (s.intro === 'unfold') spread *= outCubic(pIn);
    if (s.outro === 'fold') spread *= outCubic(pOut);
    var gSpin = 0;
    if (s.intro === 'spin') gSpin += (1 - outCubic(pIn)) * TAU * .75;
    if (s.outro === 'spin') gSpin -= (1 - pOut) * (1 - pOut) * TAU * .75;

    /* camera: framing keeps the front card the same size whatever the perspective */
    var Wpx = opts.w || 1080, Hpx = opts.h || 1920, asp = Wpx / Hpx;
    var baseH = (1 / ar) / (L.fill || .5) / Math.max(.05, cam.scale);   // world height visible at the front card
    var D = Math.max(.3, cam.dist) * baseH;
    var cards = [], i, c;
    var ringCenterZ = 0;
    for (i = 0; i < N; i++) {
      c = place(s, i, f, N, W, H);
      if (c.center && c.center[2] && s.layout === 'inside') ringCenterZ = c.center[2];
      cards.push(c);
    }
    if (L.inside && ringCenterZ > 0) D = Math.min(D, ringCenterZ * .85);
    var fov = 2 * Math.atan((baseH / 2) / D);
    var C = mul(RY(cam.yaw * DEG), RX(-cam.tilt * DEG));             // camera orientation
    var eye = xf(C, [0, 0, D]);
    // view = inverse(T(eye) * C * RZ(roll)) = RZ(-roll) * C^T * T(-eye)
    var Ct = [C[0],C[4],C[8],0, C[1],C[5],C[9],0, C[2],C[6],C[10],0, 0,0,0,1];
    var view = chain(RZ(-cam.roll * DEG), Ct, T(-eye[0], -eye[1], -eye[2]));
    var proj = persp(fov, asp, D * .03, D * 200);
    proj = mul(T((cam.x - .5) * 2, -(cam.y - .5) * 2, 0), proj);    // move the whole picture on screen
    var VP = mul(proj, view);

    /* intro stagger: front cards first */
    var order = cards.map(function (cc, idx) { return { i: idx, a: Math.abs(cc.d) }; }).sort(function (a, b) { return a.a - b.a; });
    var rank = []; order.forEach(function (o, r) { rank[o.i] = N > 1 ? r / (N - 1) : 0; });

    var out = [], focusZ = null;
    for (i = 0; i < N; i++) {
      c = cards[i];
      if (spread < 1) { // unfold / fold: everything starts stacked on the front card
        var c2 = place(s, i, f + (wrapC(i - f, N)) * (1 - spread), N, W, H);
        c2.k = c.k; c2.d = c.d; c = c2;
      }
      var stag = s.intro === 'pop' ? .7 : .25;
      var lpIn = clamp(pIn * (1 + stag) - stag * rank[i], 0, 1);
      var stagO = .2, lpOut = clamp(pOut * (1 + stagO) - stagO * (1 - rank[i]), 0, 1);
      animIn(s.intro, pIn >= 1 ? 1 : lpIn, c, H, W);
      animOut(s.outro, pOut >= 1 ? 1 : lpOut, c, H, W);
      if (c.op <= .003) continue;

      var foc = 1 + ((+s.focus || 1) - 1) * c.k;
      var M;
      if (c.bb) M = chain(T(c.x, c.y, c.z), C, RZ(c.rz), S(c.sc * foc, c.sc * foc, c.sc * foc));
      else M = chain(T(c.x, c.y, c.z), RY(c.ry), RX(c.rx), RZ(c.rz), S(c.sc * foc, c.sc * foc, c.sc * foc));
      if (gSpin) {
        var ctr = c.center || [0, 0, -W];
        M = chain(T(ctr[0], ctr[1], ctr[2]), RY(gSpin), T(-ctr[0], -ctr[1], -ctr[2]), M);
      }
      var vz = xf(view, xf(M, [0, 0, 0]))[2];
      var far = 1 - c.k;
      out.push({
        slot: i, M: M, MVP: mul(VP, M), w: W, h: H, zView: vz, k: c.k, d: c.d,
        op: c.op * (1 - (+s.fade || 0) * far),
        dim: (+s.dim || 0) * far, blur: (+s.blur || 0) * far, glow: (+s.glow || 0) * c.k
      });
      if (c.k > .5 && (focusZ === null || vz > focusZ)) focusZ = vz;
    }
    if (focusZ === null) focusZ = -D;
    out.forEach(function (o) { o.back = o.zView < focusZ - W * .02; });
    if (opts.layer === 'back') out = out.filter(function (o) { return o.back; });
    if (opts.layer === 'front') out = out.filter(function (o) { return !o.back; });
    out.sort(function (a, b) { return a.zView - b.zView; }); // far first

    var nearest = null; cards.forEach(function (cc, idx) { if (nearest === null || cc.k > cards[nearest].k) nearest = idx; });
    return {
      N: N, f: f, cards: out, VP: VP, view: view, proj: proj, D: D, W: W, H: H, ar: ar,
      reflect: L.reflect ? (+s.reflect || 0) : 0, focusSlot: nearest, cam: { s: 1 / baseH },
      w: Wpx, h: Hpx, s: s
    };
  }

  /* which card is under a pixel (for double-click) */
  function hit(fr, px, py) {
    var best = null;
    fr.cards.forEach(function (c) {
      var pts = [[-.5,-.5],[.5,-.5],[.5,.5],[-.5,.5]].map(function (q) {
        var v = xf(c.MVP, [q[0] * c.w, q[1] * c.h, 0, 1]);
        return [(v[0] / v[3] * .5 + .5) * fr.w, (1 - (v[1] / v[3] * .5 + .5)) * fr.h, v[3]];
      });
      if (pts.some(function (p) { return p[2] <= 0; })) return;
      var inside = true, sign = 0;
      for (var j = 0; j < 4; j++) {
        var a = pts[j], b = pts[(j + 1) % 4];
        var cr = (b[0] - a[0]) * (py - a[1]) - (b[1] - a[1]) * (px - a[0]);
        if (cr !== 0) { var sg = cr > 0 ? 1 : -1; if (!sign) sign = sg; else if (sg !== sign) { inside = false; break; } }
      }
      if (inside && (!best || c.zView > best.zView)) best = c;
    });
    return best;
  }

  G.CarEngine = {
    DEF: DEF, LAYOUTS: LAYOUTS, LOOKS: LOOKS, look: look, withLook: withLook, norm: norm,
    aspectOf: aspectOf, cardCount: cardCount, frame: frame, hit: hit, wrapC: wrapC, hex: hex,
    mat: { mul: mul, T: T, S: S, RX: RX, RY: RY, RZ: RZ, xf: xf }
  };
})(typeof window !== 'undefined' ? window : globalThis);
