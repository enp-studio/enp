/* Amar Studio — fonts installed on this computer (and folders the editor adds),
   read straight from the font files so any font works, Arabic included. */
(function (G) {
  'use strict';
  var S = G.Sys, req = S && S.req;
  var fs = req ? req('fs') : null, path = req ? req('path') : null, os = req ? req('os') : null, proc = req ? req('process') : { env: {} };
  var st = G.K ? G.K.store('c3d_fonts_') : { get: function (k, d) { return d; }, set: function () {} };
  var FONT_RE = /\.(ttf|otf|ttc)$/i;
  var list = null;     // [{family, files:[{file, weight, italic, idx}], arabic}]
  var loaded = {};     // family|weight -> Promise

  /* ---------- reading names from the file ---------- */
  function u16(b, o) { return b.readUInt16BE(o); }
  function u32(b, o) { return b.readUInt32BE(o); }
  function readFont(buf, base) {
    var num = u16(buf, base + 4), tables = {};
    for (var i = 0; i < num; i++) {
      var r = base + 12 + i * 16;
      tables[buf.toString('latin1', r, r + 4)] = { off: u32(buf, r + 8), len: u32(buf, r + 12) };
    }
    var out = { family: '', sub: '', typo: '', weight: 400, italic: false, arabic: false };
    var nt = tables.name;
    if (nt) {
      var o = nt.off, count = u16(buf, o + 2), strOff = o + u16(buf, o + 4), best = {};
      for (var j = 0; j < count; j++) {
        var rec = o + 6 + j * 12, pid = u16(buf, rec), eid = u16(buf, rec + 2), lid = u16(buf, rec + 4), nid = u16(buf, rec + 6), len = u16(buf, rec + 8), so = u16(buf, rec + 10);
        if ([1, 2, 16].indexOf(nid) < 0) continue;
        var s = '';
        if (pid === 3 || pid === 0) { for (var k = 0; k < len; k += 2) s += String.fromCharCode(u16(buf, strOff + so + k)); }
        else if (pid === 1 && eid === 0) s = buf.toString('latin1', strOff + so, strOff + so + len);
        else continue;
        var score = (pid === 3 ? 4 : 1) + (lid === 0x409 || (pid === 1 && lid === 0) ? 2 : 0);
        if (!best[nid] || score > best[nid].score) best[nid] = { s: s, score: score };
      }
      out.family = (best[16] || best[1] || { s: '' }).s.trim();
      out.sub = (best[2] || { s: '' }).s.trim();
    }
    var os2 = tables['OS/2'];
    if (os2) {
      out.weight = u16(buf, os2.off + 4) || 400;
      var r1 = u32(buf, os2.off + 42);
      out.arabic = !!(r1 & (1 << 13));
      out.italic = !!(u16(buf, os2.off + 62) & 1);
    }
    if (/italic|oblique/i.test(out.sub)) out.italic = true;
    if (out.weight < 100 || out.weight > 1000) out.weight = 400;
    return out;
  }
  function readFile(file) {
    var buf = fs.readFileSync(file), res = [];
    if (buf.toString('latin1', 0, 4) === 'ttcf') {
      var n = u32(buf, 8);
      for (var i = 0; i < Math.min(n, 8); i++) { try { var f = readFont(buf, u32(buf, 12 + i * 4)); f.idx = i; res.push(f); } catch (e) {} }
    } else res.push(readFont(buf, 0));
    return res;
  }

  /* ---------- scanning ---------- */
  function dirs() {
    var d = [];
    if (S.isWin) {
      d.push((proc.env.WINDIR || 'C:\\Windows') + '\\Fonts');
      if (proc.env.LOCALAPPDATA) d.push(path.join(proc.env.LOCALAPPDATA, 'Microsoft', 'Windows', 'Fonts'));
    } else {
      d.push('/Library/Fonts', '/System/Library/Fonts', path.join(os.homedir(), 'Library', 'Fonts'), '/usr/share/fonts', path.join(os.homedir(), '.fonts'));
    }
    return d.concat(st.get('extra', []));
  }
  function walk(dir, out, depth) {
    var items; try { items = fs.readdirSync(dir, { withFileTypes: true }); } catch (e) { return; }
    items.forEach(function (it) {
      var p = path.join(dir, it.name);
      if (it.isDirectory() && depth < 4) walk(p, out, depth + 1);
      else if (FONT_RE.test(it.name)) out.push(p);
    });
  }
  function scan(force) {
    if (list && !force) return Promise.resolve(list);
    if (!fs) return Promise.resolve(list = []);
    var cacheFile = path.join(S.workDir(), 'fonts-index.json'), cache = {};
    try { cache = JSON.parse(fs.readFileSync(cacheFile, 'utf8')); } catch (e) {}
    return new Promise(function (resolve) {
      setTimeout(function () {
        var files = []; dirs().forEach(function (d) { walk(d, files, 0); });
        var fam = {}, newCache = {};
        files.forEach(function (f) {
          var mt = 0; try { mt = fs.statSync(f).mtimeMs; } catch (e) {}
          var key = f + '|' + mt, info = cache[key];
          if (!info) { try { info = readFile(f); } catch (e) { info = []; } }
          newCache[key] = info;
          info.forEach(function (x) {
            if (!x.family) return;
            var F = fam[x.family] || (fam[x.family] = { family: x.family, files: [], arabic: false });
            F.files.push({ file: f, weight: x.weight, italic: x.italic, idx: x.idx || 0, sub: x.sub });
            if (x.arabic) F.arabic = true;
          });
        });
        try { fs.writeFileSync(cacheFile, JSON.stringify(newCache)); } catch (e) {}
        list = Object.keys(fam).map(function (k) { return fam[k]; }).sort(function (a, b) { return a.family.localeCompare(b.family); });
        resolve(list);
      }, 10);
    });
  }
  function find(family) { return (list || []).filter(function (f) { return f.family === family; })[0] || null; }
  function weights(family) {
    var F = find(family); if (!F) return [400, 700];
    var w = {}; F.files.forEach(function (x) { if (!x.italic) w[x.weight] = 1; });
    var out = Object.keys(w).map(Number).sort(function (a, b) { return a - b; });
    return out.length ? out : [400];
  }
  /* make the font usable by canvas; resolves when it is */
  function ensure(family, weight) {
    var key = family + '|' + weight;
    if (loaded[key]) return loaded[key];
    var F = find(family);
    if (!F || !G.FontFace) return (loaded[key] = Promise.resolve(false));
    var ws = F.files.filter(function (x) { return !x.italic; }); if (!ws.length) ws = F.files;
    var best = ws.slice().sort(function (a, b) { return Math.abs(a.weight - weight) - Math.abs(b.weight - weight); })[0];
    if (/\.ttc$/i.test(best.file)) {
      // collections can't be loaded by file; the browser may still know them as system fonts
      return (loaded[key] = (D().fonts ? D().fonts.load(weight + ' 40px "' + family + '"', 'aب') : Promise.resolve()).then(function () { return true; }, function () { return false; }));
    }
    var ff = new FontFace(family, 'url("' + S.url(best.file) + '")', { weight: String(weight) });
    return (loaded[key] = ff.load().then(function (f) { D().fonts.add(f); return true; }, function () { return false; }));
  }
  function D() { return G.document; }
  function addFolder(p) { var e = st.get('extra', []); if (p && e.indexOf(p) < 0) { e.push(p); st.set('extra', e); } return scan(true); }

  /* a searchable font picker: input + list */
  function picker(opts) {
    var K = G.K, h = K.h, cur = opts.value || 'Arial', onlyAr = st.get('onlyAr', false);
    var btn = h('button', { type: 'button', class: 'fpick' }, [h('span', { class: 'fname' }), h('i', { text: '▾' })]);
    var search = h('input', { type: 'search', class: 'search', placeholder: 'دوّر على خط…' });
    var listEl = h('div', { class: 'flist' });
    var arT = K.toggle('الخطوط العربي بس', onlyAr, function (v) { onlyAr = v; st.set('onlyAr', v); fill(); });
    var pop = h('div', { class: 'fpop hide' }, [search, arT, listEl,
      h('div', { class: 'adds', style: 'margin-top:6px' }, [K.btn('ضيف فولدر خطوط', { cls: 'ghost', icon: 'folder', onClick: function () { var p = S.pickFolder('فولدر الخطوط'); if (p) addFolder(p).then(fill); } }),
        K.btn('حدّث', { cls: 'ghost', icon: 'refresh', onClick: function () { scan(true).then(fill); } })])]);
    var box = h('div', { class: 'fbox' }, [btn, pop]);
    var io = G.IntersectionObserver ? new IntersectionObserver(function (ents) {
      ents.forEach(function (e) {
        if (!e.isIntersecting) return; io.unobserve(e.target);
        var row = e.target; ensure(row.__fam, 400).then(function (ok) { if (ok) row.querySelector('.fs').style.fontFamily = '"' + row.__fam + '"'; });
      });
    }, { root: listEl }) : null;
    function label() { btn.querySelector('.fname').textContent = cur; btn.querySelector('.fname').style.fontFamily = '"' + cur + '"'; }
    function fill() {
      listEl.innerHTML = '';
      var q = search.value.trim().toLowerCase(), n = 0;
      (list || []).forEach(function (F) {
        if (onlyAr && !F.arabic) return;
        if (q && F.family.toLowerCase().indexOf(q) < 0) return;
        if (n++ > 400) return;
        var row = h('div', { class: 'frow2' + (F.family === cur ? ' on' : ''), title: F.family }, [h('span', { class: 'fn', text: F.family }), h('span', { class: 'fs', text: F.arabic ? 'أبجد Aa' : 'Aa' })]);
        row.addEventListener('click', function () { cur = F.family; label(); pop.classList.add('hide'); if (opts.onChange) opts.onChange(cur); });
        listEl.appendChild(row);
        // preview in its own face once the row is on screen
        row.__fam = F.family;
        if (io) io.observe(row);
      });
      if (!n) listEl.appendChild(h('div', { class: 'hint', style: 'padding:8px', text: list ? 'مفيش خطوط بالاسم ده' : 'بقرا الخطوط…' }));
    }
    btn.addEventListener('click', function () { pop.classList.toggle('hide'); if (!pop.classList.contains('hide')) { search.focus(); scan().then(fill); } });
    search.addEventListener('input', fill);
    G.document.addEventListener('pointerdown', function (e) { if (!box.contains(e.target)) pop.classList.add('hide'); });
    box.setValue = function (v) { cur = v; label(); };
    label();
    return box;
  }

  G.Fonts = { scan: scan, ensure: ensure, weights: weights, find: find, picker: picker, addFolder: addFolder, readFile: readFile };
})(window);
