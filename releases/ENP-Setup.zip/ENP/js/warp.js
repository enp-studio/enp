/* ENP — perspective helpers: homographies (fit / RANSAC / apply) and a WebGL
   renderer that lays a picture (text / image) onto any 4-corner shape. */
(function (G) {
  'use strict';
  /* ---------- 3x3 matrices as arrays of 9 (row major) ---------- */
  function apply(H, x, y) { var w = H[6] * x + H[7] * y + H[8]; return [(H[0] * x + H[1] * y + H[2]) / w, (H[3] * x + H[4] * y + H[5]) / w]; }
  function inv(m) {
    var a = m[0], b = m[1], c = m[2], d = m[3], e = m[4], f = m[5], g = m[6], h = m[7], i = m[8];
    var A = e * i - f * h, B = -(d * i - f * g), C = d * h - e * g, det = a * A + b * B + c * C;
    if (Math.abs(det) < 1e-12) return null;
    return [A / det, -(b * i - c * h) / det, (b * f - c * e) / det, B / det, (a * i - c * g) / det, -(a * f - c * d) / det, C / det, -(a * h - b * g) / det, (a * e - b * d) / det];
  }
  /* solve n x n (in place gaussian elimination with pivoting) */
  function solve(M, v) {
    var n = v.length, i, j, k;
    for (i = 0; i < n; i++) {
      var p = i; for (j = i + 1; j < n; j++) if (Math.abs(M[j][i]) > Math.abs(M[p][i])) p = j;
      if (Math.abs(M[p][i]) < 1e-12) return null;
      var t = M[i]; M[i] = M[p]; M[p] = t; var tv = v[i]; v[i] = v[p]; v[p] = tv;
      for (j = i + 1; j < n; j++) { var f = M[j][i] / M[i][i]; if (!f) continue; for (k = i; k < n; k++) M[j][k] -= f * M[i][k]; v[j] -= f * v[i]; }
    }
    var x = new Array(n);
    for (i = n - 1; i >= 0; i--) { var s = v[i]; for (k = i + 1; k < n; k++) s -= M[i][k] * x[k]; x[i] = s / M[i][i]; }
    return x;
  }
  /* homography mapping src[i] -> dst[i] (least squares, >= 4 pairs; points normalised for stability) */
  function fit(src, dst) {
    var n = src.length; if (n < 4) return null;
    function norm(P) {
      var mx = 0, my = 0; P.forEach(function (p) { mx += p[0]; my += p[1]; }); mx /= n; my /= n;
      var d = 0; P.forEach(function (p) { d += Math.hypot(p[0] - mx, p[1] - my); }); d = d / n || 1; var s = Math.SQRT2 / d;
      return { T: [s, 0, -s * mx, 0, s, -s * my, 0, 0, 1], P: P.map(function (p) { return [(p[0] - mx) * s, (p[1] - my) * s]; }) };
    }
    var A = norm(src), B = norm(dst), M = [], v = [], i, j;
    for (i = 0; i < 8; i++) { M.push([0, 0, 0, 0, 0, 0, 0, 0]); v.push(0); }
    for (i = 0; i < n; i++) {
      var x = A.P[i][0], y = A.P[i][1], u = B.P[i][0], w = B.P[i][1];
      var r1 = [x, y, 1, 0, 0, 0, -u * x, -u * y], r2 = [0, 0, 0, x, y, 1, -w * x, -w * y];
      for (j = 0; j < 8; j++) { for (var k = 0; k < 8; k++) M[j][k] += r1[j] * r1[k] + r2[j] * r2[k]; v[j] += r1[j] * u + r2[j] * w; }
    }
    var hh = solve(M, v); if (!hh) return null;
    var Hn = [hh[0], hh[1], hh[2], hh[3], hh[4], hh[5], hh[6], hh[7], 1];
    var Tb = inv(B.T); if (!Tb) return null;
    return mul(Tb, mul(Hn, A.T));
  }
  function mul(a, b) { var r = []; for (var i = 0; i < 3; i++) for (var j = 0; j < 3; j++) r.push(a[i * 3] * b[j] + a[i * 3 + 1] * b[3 + j] + a[i * 3 + 2] * b[6 + j]); return r; }
  /* robust fit: RANSAC on 4-point samples, then least squares on the inliers */
  function ransac(src, dst, thr, iters) {
    var n = src.length; if (n < 4) return null;
    if (n === 4) { var H4 = fit(src, dst); return H4 ? { H: H4, inliers: [0, 1, 2, 3] } : null; }
    var seed = 12345; function rnd() { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff; }
    var best = null, bestIn = [], t2 = thr * thr;
    for (var it = 0; it < (iters || 80); it++) {
      var idx = []; while (idx.length < 4) { var k = Math.floor(rnd() * n); if (idx.indexOf(k) < 0) idx.push(k); }
      var H = fit(idx.map(function (i) { return src[i]; }), idx.map(function (i) { return dst[i]; })); if (!H) continue;
      var ins = [];
      for (var i = 0; i < n; i++) { var p = apply(H, src[i][0], src[i][1]), dx = p[0] - dst[i][0], dy = p[1] - dst[i][1]; if (dx * dx + dy * dy < t2) ins.push(i); }
      if (ins.length > bestIn.length) { bestIn = ins; best = H; if (ins.length === n) break; }
    }
    if (!best || bestIn.length < 4) return null;
    var Hf = fit(bestIn.map(function (i) { return src[i]; }), bestIn.map(function (i) { return dst[i]; })) || best;
    return { H: Hf, inliers: bestIn };
  }
  /* affine least squares (6 dof) as a 3x3 */
  function fitAffine(src, dst) {
    var n = src.length; if (n < 3) return null;
    var M = [[0, 0, 0], [0, 0, 0], [0, 0, 0]], bx = [0, 0, 0], by = [0, 0, 0];
    for (var i = 0; i < n; i++) { var r = [src[i][0], src[i][1], 1]; for (var a = 0; a < 3; a++) { for (var b = 0; b < 3; b++) M[a][b] += r[a] * r[b]; bx[a] += r[a] * dst[i][0]; by[a] += r[a] * dst[i][1]; } }
    var X = solve(M.map(function (r) { return r.slice(); }), bx), Y = solve(M.map(function (r) { return r.slice(); }), by);
    return X && Y ? [X[0], X[1], X[2], Y[0], Y[1], Y[2], 0, 0, 1] : null;
  }
  function rms(H, src, dst, idx) { var s = 0; idx.forEach(function (i) { var p = apply(H, src[i][0], src[i][1]); s += (p[0] - dst[i][0]) * (p[0] - dst[i][0]) + (p[1] - dst[i][1]) * (p[1] - dst[i][1]); }); return Math.sqrt(s / Math.max(1, idx.length)); }
  /* unit square (0,0)(1,0)(1,1)(0,1) -> quad [[x,y]*4] (same order) */
  function squareTo(q) { return fit([[0, 0], [1, 0], [1, 1], [0, 1]], q); }

  /* ---------- WebGL: draw a texture through a homography ---------- */
  var VS = 'attribute vec2 aP; void main(){ gl_Position = vec4(aP, 0.0, 1.0); }';
  var FS = [
    'precision highp float;',
    'uniform sampler2D uT; uniform mat3 uHi; uniform vec2 uRes; uniform float uA;',
    'void main(){',
    '  vec2 p = vec2(gl_FragCoord.x, uRes.y - gl_FragCoord.y);',
    '  vec3 q = uHi * vec3(p, 1.0); if (q.z <= 0.0) discard;',
    '  vec2 uv = q.xy / q.z;',
    '  if (uv.x < 0.0 || uv.y < 0.0 || uv.x > 1.0 || uv.y > 1.0) discard;',
    '  vec4 c = texture2D(uT, uv);',
    '  if (c.a < 0.002) discard;',
    '  gl_FragColor = vec4(c.rgb / c.a, c.a * uA);',   // texture is premultiplied; output straight alpha
    '}'].join('\n');
  function pot(n) { var p = 1; while (p < n) p *= 2; return Math.min(4096, p); }
  function Renderer() {
    var cv = G.document.createElement('canvas');
    var gl = cv.getContext('webgl', { alpha: true, premultipliedAlpha: false, preserveDrawingBuffer: true, antialias: true });
    if (!gl) throw new Error('no_webgl');
    function sh(t, s) { var o = gl.createShader(t); gl.shaderSource(o, s); gl.compileShader(o); if (!gl.getShaderParameter(o, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(o)); return o; }
    var pr = gl.createProgram(); gl.attachShader(pr, sh(gl.VERTEX_SHADER, VS)); gl.attachShader(pr, sh(gl.FRAGMENT_SHADER, FS)); gl.linkProgram(pr); gl.useProgram(pr);
    var U = { T: gl.getUniformLocation(pr, 'uT'), Hi: gl.getUniformLocation(pr, 'uHi'), Res: gl.getUniformLocation(pr, 'uRes'), A: gl.getUniformLocation(pr, 'uA') };
    var b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
    var a = gl.getAttribLocation(pr, 'aP'); gl.enableVertexAttribArray(a); gl.vertexAttribPointer(a, 2, gl.FLOAT, false, 0, 0);
    var tex = gl.createTexture(), scratch = G.document.createElement('canvas'), buf = null;
    return {
      canvas: cv,
      /* src: canvas / image. A transparent border keeps the edges soft. */
      setTexture: function (src) {
        var w = pot(src.width + 8), hh = pot(src.height + 8);
        scratch.width = w; scratch.height = hh; var x = scratch.getContext('2d'); x.clearRect(0, 0, w, hh);
        var pad = 4 * w / (src.width + 8), padY = 4 * hh / (src.height + 8);
        x.drawImage(src, pad, padY, w - pad * 2, hh - padY * 2);
        this.pad = [pad / w, padY / hh];
        gl.bindTexture(gl.TEXTURE_2D, tex);
        gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, true);
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, scratch);
        gl.generateMipmap(gl.TEXTURE_2D);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      },
      /* quad: 4 corners [x,y] in output pixels (tl, tr, br, bl) where the picture's own corners go */
      draw: function (W, H, quad, alpha) {
        if (cv.width !== W || cv.height !== H) { cv.width = W; cv.height = H; }
        gl.viewport(0, 0, W, H); gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT);
        if (!quad || alpha <= 0) return;
        /* the texture has a transparent border: stretch the quad a little so the picture itself lands on `quad` */
        var px = this.pad || [0, 0], Hs = squareTo(quad); if (!Hs) return;
        var e = [[-px[0] / (1 - 2 * px[0]), -px[1] / (1 - 2 * px[1])], [1 + px[0] / (1 - 2 * px[0]), -px[1] / (1 - 2 * px[1])], [1 + px[0] / (1 - 2 * px[0]), 1 + px[1] / (1 - 2 * px[1])], [-px[0] / (1 - 2 * px[0]), 1 + px[1] / (1 - 2 * px[1])]];
        var Q = e.map(function (p) { return apply(Hs, p[0], p[1]); }), Hq = squareTo(Q), Hi = Hq && inv(Hq); if (!Hi) return;
        gl.uniform1i(U.T, 0); gl.uniform2f(U.Res, W, H); gl.uniform1f(U.A, alpha);
        gl.uniformMatrix3fv(U.Hi, false, new Float32Array([Hi[0], Hi[3], Hi[6], Hi[1], Hi[4], Hi[7], Hi[2], Hi[5], Hi[8]]));
        gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
      },
      /* RGBA top-down, straight alpha */
      read: function (W, H) {
        if (!buf || buf.length !== W * H * 4) buf = new Uint8Array(W * H * 4);
        gl.readPixels(0, 0, W, H, gl.RGBA, gl.UNSIGNED_BYTE, buf);
        return buf;
      }
    };
  }

  /* text or picture -> canvas (the thing that gets laid onto the surface) */
  function element(o) {
    var c = G.document.createElement('canvas'), x = c.getContext('2d');
    if (o.img) {
      var s = Math.min(1, 2048 / Math.max(o.img.width, o.img.height));
      c.width = Math.max(2, Math.round(o.img.width * s)); c.height = Math.max(2, Math.round(o.img.height * s));
      x.drawImage(o.img, 0, 0, c.width, c.height); return c;
    }
    var px = 220, lines = String(o.text || ' ').split('\n'), font = (o.weight || 800) + ' ' + px + 'px "' + (o.font || 'Arial') + '", "Segoe UI", Tahoma, Arial, sans-serif';
    x.font = font; var w = 1; lines.forEach(function (l) { w = Math.max(w, x.measureText(l).width); });
    var pad = px * (.25 + (o.glow || 0) * .5), lh = px * 1.15;
    c.width = Math.min(4096, Math.ceil(w + pad * 2)); c.height = Math.min(4096, Math.ceil(lines.length * lh + pad * 2));
    x = c.getContext('2d'); x.font = font; x.textAlign = 'center'; x.textBaseline = 'middle';
    lines.forEach(function (l, i) {
      var y = pad + lh * (i + .5), cx = c.width / 2;
      x.direction = /[֐-ࣿ]/.test(l) ? 'rtl' : 'ltr';
      if (o.glow > 0) { x.save(); x.shadowColor = o.glowColor || o.color || '#fff'; x.shadowBlur = px * o.glow * .6; x.fillStyle = o.glowColor || o.color || '#fff'; x.fillText(l, cx, y); x.restore(); }
      if (o.stroke > 0) { x.lineJoin = 'round'; x.lineWidth = px * o.stroke * .1; x.strokeStyle = o.strokeColor || '#000'; x.strokeText(l, cx, y); }
      x.fillStyle = o.color || '#fff'; x.fillText(l, cx, y);
    });
    return c;
  }

  G.Warp = { fitAffine: fitAffine, rms: rms, apply: apply, inv: inv, fit: fit, ransac: ransac, squareTo: squareTo, Renderer: Renderer, element: element };
})(typeof window !== 'undefined' ? window : globalThis);
