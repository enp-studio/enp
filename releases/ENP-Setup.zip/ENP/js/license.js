/* ENP — who may use the panel.
   The owner publishes a signed policy.json (free until a date / subscription only,
   revoked keys, blocked devices). Subscribers get a signed key bound to their
   device. Signatures are checked with the public key shipped in license.pub, so
   neither file can be faked. */
(function (G) {
  'use strict';
  var S = G.Sys, K = G.K, req = S.req, st = K.store('enp_lic_');
  var fs = req ? req('fs') : null, path = req ? req('path') : null, os = req ? req('os') : null, crypto = req ? req('crypto') : null;
  var ext = S.extDir();
  function readJSON(f, d) { try { return JSON.parse(fs.readFileSync(path.join(ext, f), 'utf8')); } catch (e) { return d; } }
  function readText(f) { try { return fs.readFileSync(path.join(ext, f), 'utf8'); } catch (e) { return ''; } }
  var CFG = readJSON('enp.json', { product: 'ENP', version: '0.0.0', github: '' });
  var PUB = readText('license.pub');
  function base() { return CFG.github ? 'https://raw.githubusercontent.com/' + CFG.github + '/enp/main/' : ''; }

  /* ---------- helpers ---------- */
  function b64u(buf) { return Buffer.from(buf).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); }
  function unb64u(s) { s = String(s).replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '='; return Buffer.from(s, 'base64'); }
  function verify(data, sigB64) {
    if (!crypto || !PUB) return false;
    try { var v = crypto.createVerify('SHA256'); v.update(data); return v.verify(PUB, sigB64, 'base64'); } catch (e) { return false; }
  }
  var Buffer = req ? req('buffer').Buffer : null;
  function deviceId() {
    if (!os || !crypto) return 'NO-DEVICE';
    var cpu = ''; try { cpu = (os.cpus()[0] || {}).model || ''; } catch (e) {}
    var user = ''; try { user = os.userInfo().username; } catch (e) {}
    var raw = [os.hostname(), user, os.platform(), cpu, Math.round(os.totalmem() / 1073741824)].join('|');
    var hx = crypto.createHash('sha256').update(raw).digest('hex').toUpperCase().slice(0, 16);
    return hx.match(/.{4}/g).join('-');
  }
  /* time can't be wound back: the latest time ever seen (clock or server) wins */
  function now(serverMs) {
    var t = Math.max(Date.now(), st.get('seen', 0), serverMs || 0);
    st.set('seen', t); return t;
  }
  function dayEnd(d) { var t = Date.parse(d + 'T23:59:59'); return isNaN(t) ? 0 : t; }

  /* ---------- policy ---------- */
  function parseSigned(obj) {
    if (!obj || typeof obj.data !== 'string' || !obj.sig) return null;
    if (!verify(obj.data, obj.sig)) return null;
    try { return JSON.parse(obj.data); } catch (e) { return null; }
  }
  var policy = null, policySrc = 'none';
  function loadPolicy() {
    var cached = st.get('policy', null), cp = cached && parseSigned(cached.raw);
    var emb = parseSigned(readJSON('policy.default.json', null));
    // newest valid one wins (by its own issue date)
    var cands = [];
    if (cp) cands.push({ p: cp, src: 'cache' });
    if (emb) cands.push({ p: emb, src: 'built-in' });
    cands.sort(function (a, b) { return (b.p.issued || 0) - (a.p.issued || 0); });
    if (cands.length) { policy = cands[0].p; policySrc = cands[0].src; }
    else { policy = null; policySrc = 'none'; }
  }
  function fetchPolicy() {
    if (!base() || !S.httpGet) return Promise.resolve(false);
    return S.httpGet(base() + 'policy.json?t=' + Date.now()).then(function (r) {
      now(r.date);
      var raw = JSON.parse(r.body), p = parseSigned(raw);
      if (!p) return false;
      st.set('online', now());                                              // the owner's server answered with a real policy
      if (policy && (policy.issued || 0) > (p.issued || 0)) return false;   // never go back to an older policy
      st.set('policy', { raw: raw, at: Date.now() }); policy = p; policySrc = 'online';
      return true;
    }).catch(function () { return false; });
  }

  /* ---------- license keys: ENP1.<payload>.<sig> ---------- */
  function parseKey(key) {
    var m = /^ENP1\.([A-Za-z0-9_-]+)\.([A-Za-z0-9_-]+)$/.exec(String(key || '').replace(/\s+/g, ''));
    if (!m) return null;
    var data = unb64u(m[1]).toString('utf8'), sig = unb64u(m[2]).toString('base64');
    if (!verify(data, sig)) return null;
    try { return JSON.parse(data); } catch (e) { return null; }
  }

  /* ---------- decision ---------- */
  function cmpV(a, b) { a = String(a).split('.').map(Number); b = String(b).split('.').map(Number); for (var i = 0; i < 3; i++) if ((a[i] || 0) !== (b[i] || 0)) return (a[i] || 0) - (b[i] || 0); return 0; }
  function evaluate() {
    if (!req) return { ok: true, kind: 'free', device: 'PREVIEW', src: 'preview' };   // outside Premiere (design preview)
    // no valid signed policy at all (files removed or edited): only a valid key opens it
    var dev = deviceId(), t = now(), p = policy || { mode: 'paid' };
    var res = { device: dev, mode: p.mode || 'free', contact: p.contact || '', message: p.message || '', src: policySrc };
    if ((p.blocked || []).indexOf(dev) >= 0) { res.ok = false; res.reason = 'blocked'; return res; }
    if (p.minVersion && cmpV(CFG.version, p.minVersion) < 0) { res.ok = false; res.reason = 'update'; return res; }
    var key = st.get('key', ''), L = key ? parseKey(key) : null;
    if (L) {
      var revoked = (p.revoked || []).indexOf(L.id) >= 0, expired = L.exp && t > dayEnd(L.exp);
      var devOk = !L.devices || L.devices === '*' || (L.devices.indexOf && L.devices.indexOf(dev) >= 0);
      res.license = { id: L.id, name: L.name, email: L.email, exp: L.exp, plan: L.plan, revoked: revoked, expired: expired, devOk: devOk };
      if (!revoked && !expired && devOk) { res.ok = true; res.kind = 'pro'; return res; }
    }
    if ((p.mode || 'free') === 'free' && (!p.freeUntil || t <= dayEnd(p.freeUntil))) {
      // free use needs the owner's policy seen online in the last 10 days (3 days' grace after install)
      var first = st.get('first', 0); if (!first) { first = t; st.set('first', t); }
      var seen = st.get('online', 0), DAY = 86400000;
      if (base() && t - seen > 10 * DAY && t - first > 3 * DAY) { res.ok = false; res.reason = 'offline'; return res; }
      res.ok = true; res.kind = 'free'; res.until = p.freeUntil || ''; return res;
    }
    res.ok = false; res.reason = res.license ? (res.license.revoked ? 'revoked' : res.license.expired ? 'expired' : 'device') : 'subscribe';
    return res;
  }

  /* ---------- UI: header chip + gate ---------- */
  var gate = null, chip = null, last = null;
  function fmtDate(d) { if (!d) return ''; var x = new Date(d + 'T12:00:00'); return isNaN(x) ? d : x.getDate() + '/' + (x.getMonth() + 1) + '/' + x.getFullYear(); }
  function render() {
    last = evaluate();
    if (chip) {
      chip.className = 'chip-st' + (last.kind === 'pro' ? ' pro' : '');
      chip.textContent = !last.ok ? 'متوقف' : last.kind === 'pro' ? 'PRO' + (last.license.exp ? ' · لحد ' + fmtDate(last.license.exp) : '') : 'مجاني' + (last.until ? ' لحد ' + fmtDate(last.until) : '');
    }
    var app = [G.document.getElementById('tabs')].concat([].slice.call(G.document.querySelectorAll('.tab')));
    if (last.ok) { if (gate) { gate.remove(); gate = null; } app.forEach(function (e) { if (e) e.style.visibility = ''; }); return last; }
    app.forEach(function (e) { if (e) e.style.visibility = 'hidden'; });
    showGate(last);
    return last;
  }
  var TITLES = {
    subscribe: ['الفترة المجانية خلصت', 'ENP بقى بالاشتراك. ابعتلنا كود الجهاز ده عشان نفعّلك.'],
    expired: ['الاشتراك خلص', 'جدّد اشتراكك عشان ترجع تستخدم ENP.'],
    revoked: ['المفتاح ده اتوقف', 'كلمنا عشان نراجع اشتراكك.'],
    device: ['المفتاح ده لجهاز تاني', 'كل مفتاح بيشتغل على الأجهزة اللي اتعمله ليها بس. ابعتلنا كود الجهاز ده.'],
    blocked: ['الجهاز ده موقوف', 'كلمنا لو فيه حاجة غلط.'],
    update: ['لازم تحدّث ENP', 'النسخة دي قديمة. دوس «دوّر على تحديث» تحت أو نزّل آخر نسخة.'],
    offline: ['محتاج نت لحظة', 'النسخة المجانية بتتأكد من النت كل كام يوم. اتصل بالنت وافتح البانل تاني — أو فعّل اشتراك ويشتغل من غير نت.']
  };
  function showGate(r) {
    if (gate) gate.remove();
    var tt = TITLES[r.reason] || TITLES.subscribe;
    var keyIn = K.h('textarea', { class: 'txin', rows: '3', dir: 'ltr', placeholder: 'ENP1.xxxxx.xxxxx' });
    var msg = K.status();
    var devBox = K.h('div', { class: 'devid', text: r.device });
    var copy = K.btn('انسخ كود الجهاز', { icon: 'target', onClick: function () { try { G.navigator.clipboard.writeText(r.device); } catch (e) {} copyTxt(r.device); msg.show('ok', 'اتنسخ ✓'); } });
    var act = K.btn('فعّل', { cls: 'pri', icon: 'spark', onClick: function () {
      var L = parseKey(keyIn.value);
      if (!L) return msg.show('err', 'المفتاح ده مش صحيح.');
      st.set('key', keyIn.value.replace(/\s+/g, ''));
      var x = render();
      if (!x.ok) msg.show('err', TITLES[x.reason] ? TITLES[x.reason][0] : 'مش شغال');
    } });
    var kids = [K.h('div', { class: 'hdr' }, [logo(), K.h('div', { class: 'name', html: 'ENP<small>' + CFG.version + '</small>' })]),
      K.h('h2', { text: tt[0] }), K.h('p', { text: r.message || tt[1] }),
      K.h('div', { class: 'hint', text: 'كود الجهاز' }), devBox, K.h('div', { class: 'row2' }, [copy]),
      K.h('div', { class: 'hint', style: 'margin-top:12px', text: 'عندك مفتاح؟ الصقه هنا' }), keyIn, K.h('div', { class: 'row2' }, [act])];
    if (r.contact) kids.push(K.h('div', { class: 'row2' }, [K.btn('كلمنا للاشتراك', { cls: 'ghost', onClick: function () { openUrl(r.contact); } })]));
    if (r.reason === 'update' && G.Updater) kids.push(K.h('div', { class: 'row2' }, [K.btn('دوّر على تحديث', { cls: 'ghost', icon: 'refresh', onClick: function () { G.Updater.check(true); } })]));
    kids.push(msg);
    gate = K.h('div', { class: 'gate' }, [K.h('div', { class: 'card' }, kids)]);
    G.document.body.appendChild(gate);
  }
  function copyTxt(s) { var t = G.document.createElement('textarea'); t.value = s; G.document.body.appendChild(t); t.select(); try { G.document.execCommand('copy'); } catch (e) {} t.remove(); }
  function openUrl(u) {
    if (!/^https?:\/\//.test(u)) u = 'https://' + u;
    try { if (G.cep && G.cep.util && G.cep.util.openURLInDefaultBrowser) return G.cep.util.openURLInDefaultBrowser(u); } catch (e) {}
    try { req('child_process').spawn(S.isWin ? 'explorer' : 'open', [u], { windowsHide: true }); } catch (e) {}
  }
  function logo() {
    return K.h('div', { class: 'logo', html: '<img src="icons/logo-mark.png" alt="ENP">' });
  }
  function header() {
    var hd = G.document.getElementById('hdr'); if (!hd) return;
    chip = K.h('span', { class: 'chip-st', text: '…' });
    hd.appendChild(logo()); hd.appendChild(K.h('div', { class: 'name', html: 'ENP<small>Editing Power Tools · ' + CFG.version + '</small>' })); hd.appendChild(chip);
  }

  header();
  loadPolicy();
  render();
  fetchPolicy().then(function () { render(); });
  setInterval(function () { fetchPolicy().then(render); }, 3 * 3600 * 1000);
  G.addEventListener('focus', function () { render(); });

  G.License = {
    deviceId: deviceId, evaluate: evaluate, render: render, parseKey: parseKey, base: base, cfg: CFG, b64u: b64u,
    reloadPolicy: function () { loadPolicy(); return fetchPolicy().then(render); }, setKey: function (k) { st.set('key', k); return render(); },
    openUrl: openUrl, copy: copyTxt, logo: logo
  };
})(window);
