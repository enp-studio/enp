/* ENP — the sequence's sound as one track (in sequence time), and where the talking is.
   Used by captions, the first cut and the auto zoom, so they all hear the same thing. */
(function (G) {
  'use strict';
  var S = G.Sys, req = S && S.req;
  var fs = req ? req('fs') : null, cp = req ? req('child_process') : null, Buf = req ? req('buffer').Buffer : null;

  /* which part of the sequence: selection > in/out > all; tracks: list of audio track indexes ([] = all unmuted) */
  function collect(o) {
    o = o || {};
    return S.call('cr_audioClips').then(function (r) {
      if (!r || !r.ok) throw new Error(r && r.error === 'no_sequence' ? 'no_seq' : 'host');
      var range = o.range === 'all' ? null : (r.sel || r.inout);
      var t0 = range ? range[0] : 0, t1 = range ? range[1] : r.end;
      var want = o.tracks && o.tracks.length ? o.tracks : r.tracks.filter(function (t) { return !t.muted; }).map(function (t) { return t.i; });
      var clips = r.clips.filter(function (c) { return want.indexOf(c.track) >= 0 && c.end > t0 + .01 && c.start < t1 - .01; });
      return { info: r, t0: t0, t1: t1, clips: clips, range: range ? (r.sel ? 'sel' : 'inout') : 'all' };
    });
  }

  /* decode part of a file to mono s16 at sr */
  function decode(p, from, dur, sr, speed) {
    return new Promise(function (resolve, reject) {
      var af = speed && Math.abs(speed - 1) > .01 ? ['-af', 'atempo=' + Math.max(.5, Math.min(2, speed))] : [];
      var args = ['-hide_banner', '-loglevel', 'error', '-ss', String(Math.max(0, from)), '-t', String(dur * (speed || 1)), '-i', p, '-vn', '-ac', '1', '-ar', String(sr)].concat(af).concat(['-f', 's16le', '-']);
      var pr = cp.spawn(S.ffPath(), args, { windowsHide: true }), ch = [], err = '';
      pr.stdout.on('data', function (d) { ch.push(d); });
      pr.stderr.on('data', function (d) { err += d; });
      pr.on('error', reject);
      pr.on('close', function () { var b = Buf.concat(ch); resolve(new Int16Array(b.buffer, b.byteOffset, Math.floor(b.length / 2))); });
    });
  }
  /* all the clips mixed into one Int16Array covering [t0, t1] */
  function mix(col, sr, onProg, isStopped) {
    sr = sr || 16000;
    var t0 = col.t0, n = Math.max(1, Math.ceil((col.t1 - t0) * sr)), acc = new Float32Array(n), i = 0;
    function next() {
      if (isStopped && isStopped()) return Promise.reject(new Error('cancelled'));
      if (i >= col.clips.length) return Promise.resolve();
      var c = col.clips[i++], a = Math.max(c.start, t0), b = Math.min(c.end, col.t1);
      if (onProg) onProg(i / col.clips.length);
      return decode(c.path, c.inPoint + (a - c.start) * (c.speed || 1), b - a, sr, c.speed).then(function (pcm) {
        var o = Math.round((a - t0) * sr), m = Math.min(pcm.length, n - o);
        for (var k = 0; k < m; k++) acc[o + k] += pcm[k];
      }, function () {}).then(next);
    }
    return next().then(function () {
      var out = new Int16Array(n);
      for (var k = 0; k < n; k++) { var v = acc[k]; out[k] = v > 32767 ? 32767 : v < -32768 ? -32768 : v; }
      return { pcm: out, sr: sr, t0: t0, t1: col.t1 };
    });
  }
  function writeWav(file, pcm, sr) {
    var b = Buf.alloc(44 + pcm.length * 2);
    b.write('RIFF', 0); b.writeUInt32LE(36 + pcm.length * 2, 4); b.write('WAVE', 8); b.write('fmt ', 12);
    b.writeUInt32LE(16, 16); b.writeUInt16LE(1, 20); b.writeUInt16LE(1, 22); b.writeUInt32LE(sr, 24); b.writeUInt32LE(sr * 2, 28); b.writeUInt16LE(2, 32); b.writeUInt16LE(16, 34);
    b.write('data', 36); b.writeUInt32LE(pcm.length * 2, 40);
    Buf.from(pcm.buffer, pcm.byteOffset, pcm.length * 2).copy(b, 44);
    fs.writeFileSync(file, b); return file;
  }

  /* loudness every 10 ms (dB) */
  function levels(m) {
    var hop = Math.round(m.sr / 100), n = Math.floor(m.pcm.length / hop), db = new Float32Array(n);
    for (var i = 0; i < n; i++) {
      var s = 0; for (var k = i * hop, e = k + hop; k < e; k++) { var v = m.pcm[k] / 32768; s += v * v; }
      db[i] = 10 * Math.log(s / hop + 1e-10) / Math.LN10;
    }
    return db;
  }
  function pct(arr, q) { var a = Array.prototype.slice.call(arr).sort(function (x, y) { return x - y; }); return a[Math.min(a.length - 1, Math.max(0, Math.floor(q * a.length)))]; }
  /* where the talking is. o: { threshold: 'auto' | dB, sens: 0..1 (auto only), minSil, minSpeech }
     returns { speech: [{a,b}] (sequence s), floor, level, thr, peaks: [0..1] } */
  function vad(m, o) {
    o = o || {};
    var db = levels(m), n = db.length;
    if (!n) return { speech: [], floor: -90, level: -90, thr: -40, peaks: [] };
    var live = []; for (var i = 0; i < n; i++) if (db[i] > -85) live.push(db[i]);
    var floor = live.length ? pct(live, .1) : -90, level = live.length ? pct(live, .95) : -90;
    var sens = o.sens === undefined ? .5 : o.sens;
    var thr = typeof o.threshold === 'number' ? o.threshold : Math.min(level - 6, floor + Math.max(6, (level - floor) * (.2 + .35 * sens)));
    /* frames above the line, with a little hangover so word endings stay */
    var on = new Uint8Array(n), hang = 0;
    for (var j = 0; j < n; j++) { if (db[j] > thr) { on[j] = 1; hang = 8; } else if (hang > 0) { on[j] = 1; hang--; } }
    var runs = [], st = -1;
    for (var k = 0; k <= n; k++) { if (k < n && on[k]) { if (st < 0) st = k; } else if (st >= 0) { runs.push([st, k]); st = -1; } }
    var minSil = Math.round((o.minSil || .25) * 100), minSp = Math.round((o.minSpeech || .08) * 100), merged = [];
    runs.forEach(function (r) { var last = merged[merged.length - 1]; if (last && r[0] - last[1] < minSil) last[1] = r[1]; else merged.push(r.slice()); });
    var speech = merged.filter(function (r) { return r[1] - r[0] >= minSp; }).map(function (r) { return { a: m.t0 + r[0] / 100, b: m.t0 + r[1] / 100 }; });
    /* peaks for drawing (about 8 per second, max 1500) */
    var cnt = Math.max(100, Math.min(1500, Math.round(n / 12))), per = n / cnt, pk = [];
    for (var c = 0; c < cnt; c++) { var mx = -120; for (var x = Math.floor(c * per); x < Math.floor((c + 1) * per); x++) if (db[x] > mx) mx = db[x]; pk.push(Math.max(0, Math.min(1, (mx - floor) / Math.max(6, level - floor + 3)))); }
    return { speech: speech, floor: floor, level: level, thr: thr, peaks: pk };
  }
  function errText(e) {
    var m = e && e.message || String(e);
    return { no_seq: 'افتح سيكوينس الأول.', host: 'بريمير مارجعش رد — جرّب تاني.', no_audio: 'مفيش صوت في الجزء ده من السيكوينس.', cancelled: 'اتوقف.' }[m] || m;
  }
  G.SeqAudio = { collect: collect, mix: mix, decode: decode, writeWav: writeWav, vad: vad, levels: levels, errText: errText };
})(window);
