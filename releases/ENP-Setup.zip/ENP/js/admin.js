/* ENP — owner's control room. Shows only on the computer that holds the owner key
   (…/CEP/extensions/ENP-Admin/owner.pem). From here: the free period / subscription
   switch, subscriber keys, and building a release to upload. */
(function (G) {
  'use strict';
  var S = G.Sys, K = G.K, h = K.h, req = S.req;
  if (!req) { G.AdminTab = null; return; }
  var fs = req('fs'), path = req('path'), os = req('os'), crypto = req('crypto'), cp = req('child_process'), Buf = req('buffer').Buffer;
  var ext = S.extDir(), adminDir = path.join(ext, '..', 'ENP-Admin'), keyFile = path.join(adminDir, 'owner.pem'), cfgFile = path.join(adminDir, 'admin.json');
  if (!fs.existsSync(keyFile)) { G.AdminTab = null; return; }

  function rj(f, d) { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) { return d; } }
  function wj(f, o) { fs.writeFileSync(f, JSON.stringify(o, null, 2)); }
  var A = rj(cfgFile, {});
  A.policy = A.policy || { mode: 'free', freeUntil: '', message: '', contact: '', minVersion: '', revoked: [], blocked: [] };
  A.licenses = A.licenses || [];
  function saveA() { wj(cfgFile, A); }
  var enp = rj(path.join(ext, 'enp.json'), { product: 'ENP', version: '2.0.0', github: '' });
  if (A.github === undefined) A.github = enp.github || '';

  function priv() { return fs.readFileSync(keyFile, 'utf8'); }
  function sign(data) { var s = crypto.createSign('SHA256'); s.update(data); return s.sign(priv(), 'base64'); }
  function b64u(b) { return Buf.from(b).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); }
  function signedPolicy() {
    var p = A.policy, data = JSON.stringify({
      v: 1, issued: Date.now(), mode: p.mode, freeUntil: p.freeUntil || '', message: p.message || '', contact: p.contact || '',
      minVersion: p.minVersion || '', revoked: p.revoked || [], blocked: p.blocked || []
    });
    return { data: data, sig: sign(data) };
  }
  function makeKey(o) {
    var data = JSON.stringify(o);
    return 'ENP1.' + b64u(data) + '.' + b64u(Buf.from(sign(data), 'base64'));
  }
  function desktop() {
    var c = [path.join(os.homedir(), 'Desktop'), path.join(os.homedir(), 'OneDrive', 'Desktop'), path.join(os.homedir(), 'Documents')];
    for (var i = 0; i < c.length; i++) if (fs.existsSync(c[i])) return c[i];
    return os.homedir();
  }
  function base() { return A.github ? 'https://raw.githubusercontent.com/' + A.github + '/enp/main/' : ''; }
  function openFolder(p) { try { cp.spawn(S.isWin ? 'explorer' : 'open', [p], { windowsHide: false }); } catch (e) {} }

  /* ---------- release ---------- */
  var SKIP = { _backup: 1, _update: 1 };
  function copyDir(src, dst, top) {
    fs.mkdirSync(dst, { recursive: true });
    fs.readdirSync(src, { withFileTypes: true }).forEach(function (it) {
      if (top && SKIP[it.name]) return;
      var a = path.join(src, it.name), b = path.join(dst, it.name);
      if (it.isDirectory()) copyDir(a, b, false);
      else if (!/^ffmpeg(\.exe)?$/i.test(it.name)) fs.copyFileSync(a, b);
    });
  }
  function rmrf(p) { try { fs.rmSync(p, { recursive: true, force: true }); } catch (e) {} }
  function zip(srcPaths, out) {
    return new Promise(function (res, rej) {
      try { fs.unlinkSync(out); } catch (e) {}
      var p;
      if (S.isWin) {
        var list = srcPaths.map(function (s) { return "'" + s.replace(/'/g, "''") + "'"; }).join(',');
        p = cp.spawn('powershell', ['-NoProfile', '-Command', 'Compress-Archive -Path ' + list + " -DestinationPath '" + out.replace(/'/g, "''") + "' -Force"], { windowsHide: true });
      } else p = cp.spawn('zip', ['-qr', out].concat(srcPaths.map(function (s) { return path.basename(s); })), { cwd: path.dirname(srcPaths[0]) });
      var err = ''; p.stderr.on('data', function (d) { err += d; });
      p.on('close', function (c) { c === 0 && fs.existsSync(out) ? res(out) : rej(new Error('zip: ' + err.slice(0, 200))); }); p.on('error', rej);
    });
  }
  function publish(ver, notes, say) {
    if (!/^\d+\.\d+\.\d+$/.test(ver)) return Promise.reject(new Error('رقم النسخة لازم يبقى زي 2.0.1'));
    if (!A.github) return Promise.reject(new Error('اكتب اسم حسابك على GitHub الأول'));
    var out = path.join(desktop(), 'ENP Release', ver), rel = path.join(out, 'releases'), tmp = path.join(os.tmpdir(), 'ENP-build');
    rmrf(tmp); fs.mkdirSync(rel, { recursive: true }); fs.mkdirSync(tmp, { recursive: true });
    say('بجهّز النسخة ' + ver + '…');
    enp.version = ver; enp.github = A.github; wj(path.join(ext, 'enp.json'), enp);
    var mf = path.join(ext, 'CSXS', 'manifest.xml'), m = fs.readFileSync(mf, 'utf8');
    m = m.replace(/ExtensionBundleVersion="[^"]*"/, 'ExtensionBundleVersion="' + ver + '"').replace(/(<Extension Id="[^"]+" Version=")[^"]*"/, '$1' + ver + '"');
    fs.writeFileSync(mf, m);
    var pol = signedPolicy();
    wj(path.join(ext, 'policy.default.json'), pol); wj(path.join(out, 'policy.json'), pol);
    var stage = path.join(tmp, 'ENP'); copyDir(ext, stage, true);
    return zip([stage], path.join(rel, 'ENP-' + ver + '.zip')).then(function (z) {
      var sha = crypto.createHash('sha256').update(fs.readFileSync(z)).digest('hex');
      wj(path.join(out, 'latest.json'), { version: ver, url: base() + 'releases/ENP-' + ver + '.zip', sha256: sha, notes: notes || '' });
      say('بعمل ملف التثبيت…');
      var setup = path.join(tmp, 'setup'); fs.mkdirSync(setup, { recursive: true });
      var inst = path.join(ext, 'installer');
      fs.readdirSync(inst).forEach(function (f) { fs.copyFileSync(path.join(inst, f), path.join(setup, f)); });
      copyDir(stage, path.join(setup, 'ENP'), false);
      var items = fs.readdirSync(setup).map(function (f) { return path.join(setup, f); });
      return zip(items, path.join(out, 'ENP-Setup-' + ver + '.zip'));
    }).then(function (sz) {
      fs.copyFileSync(sz, path.join(rel, 'ENP-Setup.zip'));     // a fixed link for the latest installer
      rmrf(tmp);
      return out;
    });
  }

  /* ---------- UI ---------- */
  function inp(val, ph, ltr) { var i = h('input', { type: 'text', class: 'inp', placeholder: ph || '', dir: ltr ? 'ltr' : 'auto' }); i.value = val || ''; return i; }
  function dateIn(val) { var i = h('input', { type: 'date', class: 'inp', dir: 'ltr' }); i.value = val || ''; return i; }
  function build(root) {
    root.classList.add('adm');
    var status = K.status();
    var me = G.License ? G.License.deviceId() : '';

    /* account */
    var gh = inp(A.github, 'اسم حسابك على GitHub', true);
    gh.addEventListener('change', function () { A.github = gh.value.trim().replace(/^@/, ''); saveA(); links.textContent = base() ? base() + 'policy.json' : ''; });
    var links = h('div', { class: 'hint', style: 'direction:ltr;text-align:left;word-break:break-all;margin-top:4px', text: base() ? base() + 'policy.json' : '' });

    /* policy */
    var P = A.policy;
    var modeSeg = K.seg({ items: [{ v: 'free', label: 'مجاني للكل' }, { v: 'paid', label: 'بالاشتراك بس' }], value: P.mode, onChange: function (v) { P.mode = v; } });
    var until = dateIn(P.freeUntil), contact = inp(P.contact, 'رابط واتساب / إنستجرام', true), msgIn = inp(P.message, 'رسالة تظهر للي اشتراكه خلص (اختياري)');
    var minV = inp(P.minVersion, 'أقل نسخة مسموح بيها (اختياري)', true);
    var revoked = h('textarea', { class: 'lic', rows: '2', placeholder: 'IDs المفاتيح الموقوفة — واحد في كل سطر' }); revoked.value = (P.revoked || []).join('\n');
    var blocked = h('textarea', { class: 'lic', rows: '2', placeholder: 'أكواد أجهزة موقوفة — واحد في كل سطر' }); blocked.value = (P.blocked || []).join('\n');
    function lines(t) { return t.value.split(/\s*\n\s*/).map(function (x) { return x.trim(); }).filter(Boolean); }
    function savePolicy() {
      P.freeUntil = until.value; P.contact = contact.value.trim(); P.message = msgIn.value.trim(); P.minVersion = minV.value.trim();
      P.revoked = lines(revoked); P.blocked = lines(blocked); saveA();
      var pol = signedPolicy(), out = path.join(desktop(), 'ENP Release'); fs.mkdirSync(out, { recursive: true });
      wj(path.join(out, 'policy.json'), pol); wj(path.join(ext, 'policy.default.json'), pol);
      if (G.License) G.License.reloadPolicy();
      status.show('ok', 'اتحفظ ✓ ارفع «policy.json» من فولدر «ENP Release» على سطح المكتب لـ GitHub (مكان القديم) — والناس هتاخده خلال ساعات.');
      openFolder(out);
    }

    /* keys */
    var kName = inp('', 'اسم المشترك'), kMail = inp('', 'الإيميل أو رقم التليفون', true), kDev = h('textarea', { class: 'lic', rows: '2', placeholder: 'كود الجهاز (ممكن أكتر من جهاز — واحد في كل سطر). سيبه فاضي = أي جهاز' });
    var kExp = dateIn(''), kOut = h('textarea', { class: 'lic', rows: '3', readonly: 'readonly' });
    var table = h('table');
    function refreshTable() {
      table.innerHTML = '';
      A.licenses.slice().reverse().forEach(function (L) {
        var off = (P.revoked || []).indexOf(L.id) >= 0;
        var tr = h('tr', {}, [h('td', { text: L.name || L.email }), h('td', { style: 'direction:ltr', text: L.exp || '∞' }), h('td', { text: off ? 'موقوف' : 'شغال' }),
          h('td', {}, [K.btn(off ? 'رجّعه' : 'وقّفه', { cls: 'ghost', onClick: function () {
            var r = lines(revoked), i = r.indexOf(L.id); if (i >= 0) r.splice(i, 1); else r.push(L.id); revoked.value = r.join('\n'); P.revoked = r; saveA(); refreshTable();
            status.show('warn', 'متنساش «احفظ السياسة» عشان التغيير يوصل للناس.');
          } }), K.btn('انسخ', { cls: 'ghost', onClick: function () { G.License.copy(L.key); status.show('ok', 'المفتاح اتنسخ'); } })])]);
        table.appendChild(tr);
      });
    }
    function genKey(forMe) {
      var devs = forMe ? [me] : lines(kDev);
      var o = { id: crypto.randomBytes(5).toString('hex'), name: forMe ? 'Owner' : kName.value.trim(), email: forMe ? '' : kMail.value.trim(),
        devices: devs.length ? devs : '*', exp: forMe ? null : (kExp.value || null), plan: 'pro', iat: Date.now() };
      var key = makeKey(o);
      A.licenses.push({ id: o.id, name: o.name, email: o.email, exp: o.exp, devices: o.devices, key: key, at: Date.now() }); saveA(); refreshTable();
      if (forMe) { G.License.setKey(key); status.show('ok', 'جهازك متفعّل للأبد ✓'); return; }
      kOut.value = key; G.License.copy(key); status.show('ok', 'المفتاح اتعمل واتنسخ — ابعته للمشترك.');
    }

    /* publish */
    var cur = enp.version || '2.0.0', parts = cur.split('.').map(Number); parts[2] = (parts[2] || 0) + 1;
    var verIn = inp(parts.join('.'), '2.0.1', true), notesIn = inp('', 'إيه الجديد؟ (سطر واحد)');
    var pubBtn = K.btn('اعمل نسخة للنشر', { cls: 'pri', icon: 'spark', onClick: function () {
      pubBtn.disabled = true;
      publish(verIn.value.trim(), notesIn.value.trim(), function (m) { status.show('busy', m); }).then(function (out) {
        status.show('ok', 'جاهزة ✓ ارفع محتوى الفولدر ده على GitHub (repo اسمه enp): policy.json و latest.json وفولدر releases. ملف التثبيت للناس: ENP-Setup-' + verIn.value.trim() + '.zip');
        openFolder(out);
      }).catch(function (e) { status.show('err', e.message || String(e)); }).then(function () { pubBtn.disabled = false; });
    } });

    [h('div', { class: 'hint intro', text: 'لوحة التحكم دي بتظهر على جهازك بس (لأن مفتاح المالك عليه). محدش غيرك يقدر يعمل مفاتيح أو يغيّر السياسة.' }),
      K.section('حسابك', [K.field('GitHub', gh), links, K.field('كود جهازك', h('div', { class: 'devid', style: 'direction:ltr', text: me })),
        h('div', { class: 'adds' }, [K.btn('فعّل جهازي للأبد', { onClick: function () { genKey(true); } })])], true, 'adm_acc'),
      K.section('مجاني ولا اشتراك', [K.field('', modeSeg), K.field('مجاني لحد (اختياري — بعده يبقى اشتراك تلقائي)', until), K.field('التواصل للاشتراك', contact),
        K.field('رسالة', msgIn), K.field('أقل نسخة', minV), K.field('مفاتيح موقوفة', revoked), K.field('أجهزة موقوفة', blocked),
        h('div', { style: 'margin-top:10px' }, [K.btn('احفظ السياسة (policy.json)', { cls: 'pri', onClick: savePolicy })])], true, 'adm_pol'),
      K.section('مفتاح لمشترك', [K.field('الاسم', kName), K.field('التواصل', kMail), K.field('الأجهزة', kDev), K.field('ينتهي في (فاضي = مفتوح)', kExp),
        h('div', { style: 'margin-top:10px' }, [K.btn('اعمل مفتاح', { cls: 'pri', icon: 'spark', onClick: function () { genKey(false); } })]), kOut,
        h('div', { style: 'margin-top:10px;font-weight:600', text: 'المشتركين' }), table], true, 'adm_keys'),
      K.section('نشر نسخة جديدة', [K.field('رقم النسخة', verIn), K.field('الجديد', notesIn), h('div', { style: 'margin-top:10px' }, [pubBtn]),
        h('div', { class: 'hint', style: 'margin-top:6px', text: 'بيطلّع على سطح المكتب فولدر «ENP Release» فيه كل اللي ترفعه، وملف التثبيت اللي تبعته للناس.' })], true, 'adm_pub'),
      h('div', { class: 'out' }, [status])
    ].forEach(function (el) { root.appendChild(el); });
    refreshTable();
  }
  G.AdminTab = { build: build, _publish: publish, _key: makeKey, _A: A };
})(window);
