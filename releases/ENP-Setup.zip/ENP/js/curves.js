/* Amar Studio — keyframe curves: give the keyframes you already have any easing
   (bezier you draw, or bounce / elastic / spring), baked as in-between keys. */
(function (G) {
  'use strict';
  var K = G.K, h = K.h, st = K.store('c3d_cv_');

  /* ---------- curves ---------- */
  function bez(x1, y1, x2, y2) {
    function cx(t) { return 3 * x1 * t * (1 - t) * (1 - t) + 3 * x2 * t * t * (1 - t) + t * t * t; }
    function cy(t) { return 3 * y1 * t * (1 - t) * (1 - t) + 3 * y2 * t * t * (1 - t) + t * t * t; }
    function dx(t) { return 3 * x1 * (1 - t) * (1 - t) + 6 * (x2 - x1) * t * (1 - t) + 3 * (1 - x2) * t * t; }
    return function (x) {
      if (x <= 0) return 0; if (x >= 1) return 1;
      var t = x;
      for (var i = 0; i < 8; i++) { var d = dx(t); if (Math.abs(d) < 1e-6) break; t -= (cx(t) - x) / d; t = Math.max(0, Math.min(1, t)); }
      var lo = 0, hi = 1;
      if (Math.abs(cx(t) - x) > 1e-4) { for (var j = 0; j < 30; j++) { t = (lo + hi) / 2; if (cx(t) < x) lo = t; else hi = t; } }
      return cy(t);
    };
  }
  var FN = {
    elastic: function (x) { if (x <= 0 || x >= 1) return x <= 0 ? 0 : 1; return Math.pow(2, -10 * x) * Math.sin((x * 10 - .75) * (2 * Math.PI / 3)) + 1; },
    bounce: function (x) { var n = 7.5625, d = 2.75; if (x < 1 / d) return n * x * x; if (x < 2 / d) { x -= 1.5 / d; return n * x * x + .75; } if (x < 2.5 / d) { x -= 2.25 / d; return n * x * x + .9375; } x -= 2.625 / d; return n * x * x + .984375; },
    spring: function (x) { if (x >= 1) return 1; return 1 - Math.exp(-6 * x) * Math.cos(12 * x) * (1 - x * .0); },
    wobble: function (x) { if (x >= 1) return 1; return x + Math.sin(x * Math.PI * 3) * (1 - x) * .18; },
    steps: function (x) { return Math.min(1, Math.floor(x * 5) / 4); }
  };
  var PRESETS = [
    { id: 'linear', name: 'لينير', b: [0, 0, 1, 1] },
    { id: 'ease', name: 'ناعم', b: [.25, .1, .25, 1] },
    { id: 'easeInOut', name: 'دخول وخروج', b: [.42, 0, .58, 1] },
    { id: 'in', name: 'يبدأ بطيء', b: [.42, 0, 1, 1] },
    { id: 'out', name: 'يخلص بطيء', b: [0, 0, .58, 1] },
    { id: 'cubicIO', name: 'Cubic', b: [.65, 0, .35, 1] },
    { id: 'quintIO', name: 'Quint', b: [.83, 0, .17, 1] },
    { id: 'expoIO', name: 'Expo', b: [.87, 0, .13, 1] },
    { id: 'expoOut', name: 'Expo Out', b: [.16, 1, .3, 1] },
    { id: 'expoIn', name: 'Expo In', b: [.7, 0, .84, 0] },
    { id: 'circIO', name: 'Circ', b: [.85, 0, .15, 1] },
    { id: 'quartOut', name: 'Quart Out', b: [.25, 1, .5, 1] },
    { id: 'motion', name: 'موشن ديزاينر', b: [.7, 0, .2, 1] },
    { id: 'snappy', name: 'سريع وحاد', b: [.2, .9, .1, 1] },
    { id: 'smooth', name: 'ناعم جدًا', b: [.45, .05, .2, 1] },
    { id: 'backOut', name: 'بيعدّي ويرجع', b: [.34, 1.56, .64, 1] },
    { id: 'backIn', name: 'بيرجع ويطلع', b: [.36, 0, .66, -.56] },
    { id: 'backIO', name: 'Back In-Out', b: [.68, -.6, .32, 1.6] },
    { id: 'anticip', name: 'تحضير', b: [.6, -.28, .73, .05] },
    { id: 'elastic', name: 'مطاطي', fn: 'elastic' },
    { id: 'bounce', name: 'بينط', fn: 'bounce' },
    { id: 'spring', name: 'سوستة', fn: 'spring' },
    { id: 'wobble', name: 'بيتهز', fn: 'wobble' },
    { id: 'steps', name: 'خطوات', fn: 'steps' }
  ];
  var C = st.get('curve', { b: [.7, 0, .2, 1], fn: null, id: 'motion' });
  function curveFn(c) { return c.fn ? FN[c.fn] : bez(c.b[0], c.b[1], c.b[2], c.b[3]); }

  /* ---------- graph editor ---------- */
  var ui = {}, P = st.get('set', { every: 2, scope: 'all', linear: true });
  var found = null, last = st.get('last', null), clock = 0, raf = 0;
  function save() { st.set('curve', C); st.set('set', P); }
  var PAD = 22, YMIN = -.6, YMAX = 1.6;
  function gx(x, w) { return PAD + x * (w - PAD * 2); }
  function gy(y, hh) { return hh - PAD - (y - YMIN) / (YMAX - YMIN) * (hh - PAD * 2); }
  function drawGraph() {
    var cv = ui.graph, w = cv.clientWidth || 260, hh = cv.clientHeight || 220, dpr = Math.min(2, G.devicePixelRatio || 1);
    cv.width = Math.round(w * dpr); cv.height = Math.round(hh * dpr);
    var x = cv.getContext('2d'); x.setTransform(dpr, 0, 0, dpr, 0, 0); x.clearRect(0, 0, w, hh);
    x.strokeStyle = 'rgba(255,255,255,.08)'; x.lineWidth = 1;
    for (var i = 0; i <= 4; i++) { var xx = gx(i / 4, w); x.beginPath(); x.moveTo(xx, gy(YMIN, hh)); x.lineTo(xx, gy(YMAX, hh)); x.stroke(); }
    [0, 1].forEach(function (v) { x.strokeStyle = 'rgba(255,255,255,.2)'; x.beginPath(); x.moveTo(gx(0, w), gy(v, hh)); x.lineTo(gx(1, w), gy(v, hh)); x.stroke(); });
    var f = curveFn(C);
    x.strokeStyle = '#e48aa6'; x.lineWidth = 2.5; x.beginPath();
    for (var s = 0; s <= 120; s++) { var u = s / 120, px = gx(u, w), py = gy(f(u), hh); s ? x.lineTo(px, py) : x.moveTo(px, py); }
    x.stroke();
    if (!C.fn) {
      var b = C.b, hs = [[0, 0, b[0], b[1]], [1, 1, b[2], b[3]]];
      hs.forEach(function (q) {
        x.strokeStyle = 'rgba(255,211,77,.7)'; x.lineWidth = 1.5; x.beginPath(); x.moveTo(gx(q[0], w), gy(q[1], hh)); x.lineTo(gx(q[2], w), gy(q[3], hh)); x.stroke();
        x.fillStyle = '#ffd34d'; x.beginPath(); x.arc(gx(q[2], w), gy(q[3], hh), 6, 0, 7); x.fill();
      });
      ui.bezTxt.textContent = 'cubic-bezier(' + b.map(function (v) { return (+v).toFixed(2); }).join(', ') + ')';
    } else ui.bezTxt.textContent = 'منحنى خاص — مش بيتعدّل بالإيد';
    var p = (clock % 1.6) / 1.2; if (p > 1) p = 1;
    x.fillStyle = '#ff6b6b'; x.beginPath(); x.arc(gx(p, w), gy(f(p), hh), 4, 0, 7); x.fill();
  }
  function drawDemo() {
    var cv = ui.demo, w = cv.clientWidth || 260, hh = 46, dpr = Math.min(2, G.devicePixelRatio || 1);
    cv.width = Math.round(w * dpr); cv.height = Math.round(hh * dpr);
    var x = cv.getContext('2d'); x.setTransform(dpr, 0, 0, dpr, 0, 0); x.clearRect(0, 0, w, hh);
    var f = curveFn(C), p = (clock % 1.6) / 1.2; if (p > 1) p = 1;
    var v = f(p), bx = 20 + v * (w - 60);
    x.fillStyle = 'rgba(255,255,255,.06)'; x.fillRect(10, hh / 2 - 2, w - 20, 4);
    x.fillStyle = '#a3284f'; K && roundRect(x, bx, hh / 2 - 14, 28, 28, 7); x.fill();
  }
  function roundRect(c, x, y, w, hh, r) { c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + hh, r); c.arcTo(x + w, y + hh, x, y + hh, r); c.arcTo(x, y + hh, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); }
  function loop() { raf = 0; clock += 1 / 60; drawGraph(); drawDemo(); if (ui.on) raf = (G.requestAnimationFrame || setTimeout)(loop); }
  function bindGraph() {
    var drag = -1, cv = ui.graph;
    function at(e) { var r = cv.getBoundingClientRect(), w = r.width, hh = r.height; return { x: Math.max(0, Math.min(1, (e.clientX - r.left - PAD) / (w - PAD * 2))), y: YMIN + (hh - PAD - (e.clientY - r.top)) / (hh - PAD * 2) * (YMAX - YMIN) }; }
    cv.addEventListener('pointerdown', function (e) {
      if (C.fn) { C = { b: [.42, 0, .58, 1], fn: null, id: 'custom' }; markPreset(); }
      var p = at(e), b = C.b, d1 = Math.hypot(p.x - b[0], (p.y - b[1]) * .6), d2 = Math.hypot(p.x - b[2], (p.y - b[3]) * .6);
      drag = d1 < d2 ? 0 : 1; try { cv.setPointerCapture(e.pointerId); } catch (x) {}
      move(e);
    });
    function move(e) {
      if (drag < 0) return; var p = at(e);
      p.y = Math.max(YMIN, Math.min(YMAX, p.y));
      C.b[drag * 2] = Math.round(p.x * 100) / 100; C.b[drag * 2 + 1] = Math.round(p.y * 100) / 100; C.id = 'custom'; markPreset();
    }
    cv.addEventListener('pointermove', move);
    cv.addEventListener('pointerup', function () { if (drag >= 0) { drag = -1; save(); } });
  }
  function presetThumb(p) {
    var c = h('canvas', { width: 64, height: 40 }), x = c.getContext('2d'), f = p.fn ? FN[p.fn] : bez(p.b[0], p.b[1], p.b[2], p.b[3]);
    x.strokeStyle = '#e48aa6'; x.lineWidth = 2; x.beginPath();
    for (var s = 0; s <= 40; s++) { var u = s / 40, px = 6 + u * 52, py = 40 - 8 - (f(u) + .3) / 1.6 * 26; s ? x.lineTo(px, py) : x.moveTo(px, py); }
    x.stroke(); return c;
  }
  function markPreset() { [].forEach.call(ui.presets.children, function (b) { b.classList.toggle('on', b.getAttribute('data-id') === C.id); }); }

  /* ---------- Premiere ---------- */
  function lerpV(a, b, k) { if (typeof a === 'number') return a + (b - a) * k; return a.map(function (v, i) { return v + (b[i] - v) * k; }); }
  function readKeys() {
    ui.status.show('busy', 'بقرا الكيفريمز…');
    Sys.call('cr_kfList').then(function (r) {
      if (!r || !r.ok) throw new Error(r && r.error === 'no_sequence' ? 'افتح سيكوينس الأول.' : 'حصلت مشكلة [' + (r && (r.error || r.detail)) + ']');
      if (!r.selected) throw new Error('اختار الكليبات اللي عليها الكيفريمز في التايملاين الأول.');
      found = r; ui.list.innerHTML = '';
      if (!r.params.length) { ui.status.show('warn', 'مفيش كيفريمز (اتنين أو أكتر) على الكليبات المختارة.'); ui.apply.disabled = true; return; }
      r.params.forEach(function (p, i) {
        p.on = true;
        var cb = h('input', { type: 'checkbox' }); cb.checked = true; cb.addEventListener('change', function () { p.on = cb.checked; });
        ui.list.appendChild(h('label', { class: 'kfrow' }, [cb, h('span', { text: p.clip.name + ' › ' + p.cname + ' › ' + p.pname }), h('span', { class: 'hint', text: p.keys.length + ' كيفريم' })]));
        void i;
      });
      ui.apply.disabled = false;
      ui.status.show('ok', 'لقيت ' + r.params.length + ' خاصية عليها كيفريمز. اختار المنحنى ودوس «طبّق».');
    }).catch(function (e) { ui.status.show('err', e.message || String(e)); });
  }
  function apply() {
    if (!found) return;
    ui.apply.disabled = true;
    var f = curveFn(C), fps = found.fps || 30, step = Math.max(1, +P.every) / fps, jobs = [], total = 0;
    found.params.forEach(function (p) {
      if (!p.on) return;
      var adds = [], mediaT = found.t - p.clip.start + p.clip.inPoint;
      for (var i = 0; i < p.keys.length - 1; i++) {
        var a = p.keys[i], b = p.keys[i + 1];
        if (P.scope === 'here' && !(mediaT >= a[0] - 1e-4 && mediaT <= b[0] + 1e-4)) continue;
        var span = b[0] - a[0]; if (span < step * 1.5) continue;
        for (var t = a[0] + step; t < b[0] - step * .5; t += step) adds.push([Math.round(t * 100000) / 100000, lerpV(a[1], b[1], f((t - a[0]) / span))]);
      }
      if (adds.length) { jobs.push({ p: p, adds: adds }); total += adds.length; }
    });
    if (!jobs.length) { ui.status.show('warn', P.scope === 'here' ? 'المؤشر مش بين كيفريمين على الخصائص دي.' : 'الكيفريمز قريبين من بعض أوي — قلّل «كيفريم كل».'); ui.apply.disabled = false; return; }
    var done = 0, undo = [];
    ui.prog.set(0);
    jobs.reduce(function (pr, j) {
      return pr.then(function () {
        return K.chunks(j.adds, 50, function (part) {
          return Sys.call('cr_kfAdd', { clip: j.p.clip, comp: j.p.comp, prop: j.p.prop, keys: part, linear: P.linear }).then(function (r) {
            if (!r || !r.ok) throw new Error(r && r.error === 'clip_moved' ? 'الكليب اتحرك — اقرا الكيفريمز تاني.' : 'حصلت مشكلة [' + (r && (r.error || r.detail)) + ']');
            done += part.length; ui.prog.set(done / total); ui.status.show('busy', 'بطبّق المنحنى… ' + Math.round(done / total * 100) + '%');
          });
        }).then(function () { undo.push({ clip: j.p.clip, comp: j.p.comp, prop: j.p.prop, times: j.adds.map(function (k) { return k[0]; }) }); });
      });
    }, Promise.resolve()).then(function () {
      last = undo; st.set('last', last); K.show(ui.undo, true);
      ui.status.show('ok', 'تمام — المنحنى اتطبّق على ' + jobs.length + ' خاصية (' + total + ' كيفريم في النص).');
      found = null; ui.list.innerHTML = ''; ui.list.appendChild(h('div', { class: 'hint', text: 'لو عايز تطبّق تاني اقرا الكيفريمز من جديد.' }));
    }).catch(function (e) { ui.status.show('err', e.message || String(e)); }).then(function () { ui.prog.done(); });
  }
  function undoLast() {
    if (!last) return;
    last.reduce(function (pr, u) { return pr.then(function () { return K.chunks(u.times, 200, function (part) { return Sys.call('cr_kfRemove', { clip: u.clip, comp: u.comp, prop: u.prop, times: part }); }); }); }, Promise.resolve())
      .then(function () { ui.status.show('ok', 'رجعت الكيفريمز زي ما كانت.'); last = null; st.set('last', null); K.show(ui.undo, false); });
  }

  function build(root) {
    ui.graph = h('canvas', { class: 'cgraph' }); ui.demo = h('canvas', { class: 'cdemo' }); ui.bezTxt = h('div', { class: 'hint', style: 'direction:ltr;text-align:center;margin-top:4px' });
    bindGraph();
    ui.presets = h('div', { class: 'cpre' });
    PRESETS.forEach(function (p) {
      var b = h('button', { type: 'button', class: 'cbtn', 'data-id': p.id, title: p.name }, [presetThumb(p), h('span', { text: p.name })]);
      b.addEventListener('click', function () { C = { b: p.b ? p.b.slice() : [0, 0, 1, 1], fn: p.fn || null, id: p.id }; save(); markPreset(); clock = 0; });
      ui.presets.appendChild(b);
    });
    ui.list = h('div', { class: 'kflist' }, [h('div', { class: 'hint', text: 'اختار الكليبات في التايملاين ودوس «اقرا الكيفريمز».' })]);
    ui.status = K.status(); ui.prog = K.progress();
    ui.apply = K.btn('طبّق المنحنى', { cls: 'pri', icon: 'spark', onClick: apply }); ui.apply.disabled = true;
    ui.undo = K.btn('تراجع عن آخر تطبيق', { cls: 'ghost', icon: 'undo', onClick: undoLast }); K.show(ui.undo, !!last);
    [h('div', { class: 'hint intro', text: 'إدّي الكيفريمز اللي عندك أي إحساس حركة: ارسم المنحنى بالإيد أو اختار جاهز (Bounce و Elastic و Spring كمان). بيتطبّق على أي خاصية عليها كيفريمز — Position، Scale، Rotation، Opacity، الصوت، وأي إفكت.' }),
      h('div', { class: 'pv' }, [ui.graph, ui.bezTxt, ui.demo]),
      K.section('منحنيات جاهزة', [ui.presets], true, 'cv_pre'),
      K.section('طبّق على الكيفريمز', [
        h('div', { class: 'adds' }, [K.btn('اقرا الكيفريمز من المختار', { icon: 'target', onClick: readKeys })]), ui.list,
        K.field('على', K.seg({ items: [{ v: 'all', label: 'كل الكيفريمز' }, { v: 'here', label: 'اللي حوالين المؤشر بس' }], value: P.scope, onChange: function (v) { P.scope = v; save(); } })),
        K.field('كيفريم كل', K.seg({ items: [{ v: 1, label: 'فريم' }, { v: 2, label: '2 فريم' }, { v: 3, label: '3 فريم' }, { v: 4, label: '4 فريم' }], value: P.every, onChange: function (v) { P.every = v; save(); } })),
        K.toggle('خلّي الكيفريمز الجديدة Linear (أدق)', P.linear, function (v) { P.linear = v; save(); }),
        h('div', { style: 'margin-top:10px' }, [ui.apply]), h('div', { class: 'tk' }, [ui.undo]), ui.prog, ui.status
      ], true, 'cv_apply')
    ].forEach(function (el) { root.appendChild(el); });
    markPreset();
  }
  G.CurvesTab = {
    build: build,
    onShow: function () { ui.on = true; if (!raf) loop(); },
    onHide: function () { ui.on = false; },
    _fn: function (c) { return curveFn(c); }
  };
})(window);
