/* ENP — update safety net. If a freshly installed update fails to start three
   times, the previous version (kept in _backup) is put back automatically. */
(function (G) {
  'use strict';
  var req = (G.cep_node && G.cep_node.require) || G.require;
  if (!req) { G.ENPBootOK = function () {}; return; }
  var fs = req('fs'), path = req('path');
  var ext = (function () {
    try { var p = G.__adobe_cep__.getSystemPath('extension'); if (p) return decodeURIComponent(String(p).replace(/^file:\/{2,3}/, /^win/i.test(G.navigator.platform) ? '' : '/')); } catch (e) {}
    var u = decodeURIComponent(G.location.pathname).replace(/\/[^\/]*$/, '');
    return /^win/i.test(G.navigator.platform) ? u.replace(/^\//, '').replace(/\//g, '\\') : u;
  })();
  var stateFile = path.join(ext, '_update', 'state.json');
  function read() { try { return JSON.parse(fs.readFileSync(stateFile, 'utf8')); } catch (e) { return null; } }
  function write(s) { try { fs.mkdirSync(path.dirname(stateFile), { recursive: true }); fs.writeFileSync(stateFile, JSON.stringify(s)); } catch (e) {} }
  var SKIP = { _backup: 1, _update: 1, runtime: 1 };
  function copyDir(src, dst, top) {
    fs.readdirSync(src, { withFileTypes: true }).forEach(function (it) {
      if (top && SKIP[it.name]) return;
      var a = path.join(src, it.name), b = path.join(dst, it.name);
      if (it.isDirectory()) { try { fs.mkdirSync(b, { recursive: true }); } catch (e) {} copyDir(a, b, false); } else fs.copyFileSync(a, b);
    });
  }
  function rollback(reason) {
    var bk = path.join(ext, '_backup');
    if (!fs.existsSync(path.join(bk, 'index.html'))) return false;
    copyDir(bk, ext, true);
    write({ pending: false, rolledBack: true, reason: reason || '', at: Date.now() });
    return true;
  }
  var s = read();
  if (s && s.pending) {
    s.attempts = (s.attempts || 0) + 1; write(s);
    if (s.attempts >= 3) { if (rollback('start_failed')) { G.location.reload(); return; } }
    // an error while starting counts as a failed start
    var t0 = Date.now();
    G.addEventListener('error', function () { if (Date.now() - t0 < 8000 && read() && read().pending) setTimeout(function () { G.location.reload(); }, 800); });
  }
  G.ENPBootOK = function () { var x = read(); if (x && x.pending) { x.pending = false; x.okAt = Date.now(); write(x); } };
  G.ENPRollback = rollback;
  G.ENPBootState = read;
})(window);
