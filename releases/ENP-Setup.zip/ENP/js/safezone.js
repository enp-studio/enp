/* ENP — safe zones: how the frame will look once it's on TikTok / Reels / Shorts / Facebook,
   with each app's buttons and captions drawn over it, and a guide you can lay on the timeline. */
(function (G) {
  'use strict';
  var K = G.K, h = K.h, st = K.store('enp_safe_');
  /* reference frame 1080 x 1920. top / bottom / left / right = what the app covers (approximate) */
  var P = {
    tiktok: { name: 'TikTok', top: 160, bottom: 480, left: 60, right: 150 },
    reels: { name: 'Instagram Reels', top: 220, bottom: 420, left: 60, right: 150 },
    shorts: { name: 'YouTube Shorts', top: 200, bottom: 440, left: 50, right: 190 },
    facebook: { name: 'Facebook Reels', top: 250, bottom: 400, left: 60, right: 150 }
  };
  var S = (function () { var o = { plat: 'tiktok', ui: true, red: true, op: .8 }, s = st.get('set', {}); for (var k in s) o[k] = s[k]; return o; })();
  function save() { st.set('set', S); }

  /* ---------- drawing ---------- */
  function icon(x, kind, cx, cy, r) {
    x.save(); x.translate(cx, cy); x.fillStyle = '#fff'; x.strokeStyle = '#fff'; x.lineWidth = r * .16; x.lineCap = 'round'; x.lineJoin = 'round';
    x.shadowColor = 'rgba(0,0,0,.45)'; x.shadowBlur = r * .4;
    switch (kind) {
      case 'heart': x.beginPath(); x.moveTo(0, r * .75); x.bezierCurveTo(-r * 1.2, -r * .1, -r * .6, -r * 1, 0, -r * .35); x.bezierCurveTo(r * .6, -r * 1, r * 1.2, -r * .1, 0, r * .75); x.fill(); break;
      case 'comment': x.beginPath(); x.ellipse(0, -r * .05, r * .85, r * .7, 0, 0, 7); x.fill(); x.beginPath(); x.moveTo(-r * .35, r * .5); x.lineTo(-r * .6, r * .95); x.lineTo(r * .05, r * .6); x.fill(); break;
      case 'share': x.beginPath(); x.moveTo(r * .9, -r * .1); x.lineTo(r * .05, -r * .8); x.lineTo(r * .05, -r * .4); x.quadraticCurveTo(-r * .9, -r * .3, -r * .9, r * .75); x.quadraticCurveTo(-r * .4, r * .1, r * .05, r * .2); x.lineTo(r * .05, r * .6); x.closePath(); x.fill(); break;
      case 'save': x.beginPath(); x.moveTo(-r * .6, -r * .85); x.lineTo(r * .6, -r * .85); x.lineTo(r * .6, r * .85); x.lineTo(0, r * .35); x.lineTo(-r * .6, r * .85); x.closePath(); x.fill(); break;
      case 'dislike': x.rotate(Math.PI); /* falls through */
      case 'like': x.beginPath(); x.rect(-r * .85, -r * .1, r * .35, r * .9); x.fill(); x.beginPath(); x.moveTo(-r * .4, -r * .1); x.lineTo(0, -r * .9); x.quadraticCurveTo(r * .3, -r * .9, r * .2, -r * .35); x.lineTo(r * .85, -r * .35); x.lineTo(r * .65, r * .8); x.lineTo(-r * .4, r * .8); x.closePath(); x.fill(); break;
      case 'more': for (var i = -1; i <= 1; i++) { x.beginPath(); x.arc(i * r * .55, 0, r * .16, 0, 7); x.fill(); } break;
      case 'avatar': x.fillStyle = '#c9a26b'; x.beginPath(); x.arc(0, 0, r, 0, 7); x.fill(); x.lineWidth = r * .12; x.stroke(); x.fillStyle = '#ff3b5c'; x.beginPath(); x.arc(0, r, r * .32, 0, 7); x.fill(); break;
      case 'disc': x.fillStyle = '#222'; x.beginPath(); x.arc(0, 0, r, 0, 7); x.fill(); x.fillStyle = '#c9a26b'; x.beginPath(); x.arc(0, 0, r * .45, 0, 7); x.fill(); break;
      case 'remix': x.beginPath(); x.arc(0, 0, r * .7, .3, 5.9); x.stroke(); break;
      case 'cam': x.beginPath(); x.rect(-r * .8, -r * .5, r * 1.6, r * 1.1); x.stroke(); x.beginPath(); x.arc(0, r * .05, r * .3, 0, 7); x.stroke(); break;
      case 'search': x.beginPath(); x.arc(-r * .15, -r * .15, r * .55, 0, 7); x.stroke(); x.beginPath(); x.moveTo(r * .25, r * .25); x.lineTo(r * .8, r * .8); x.stroke(); break;
    }
    x.restore();
  }
  function text(x, s, X, Y, px, o) { o = o || {}; x.save(); x.font = (o.w || 600) + ' ' + px + 'px "Segoe UI", Tahoma, Arial, sans-serif'; x.fillStyle = o.c || '#fff'; x.textAlign = o.al || 'left'; x.textBaseline = 'middle'; x.direction = 'ltr'; x.shadowColor = 'rgba(0,0,0,.5)'; x.shadowBlur = px * .3; x.globalAlpha *= o.a || 1; x.fillText(s, X, Y); x.restore(); }
  function bar(x, Y, w, hh, a) { x.save(); x.globalAlpha *= a || .85; x.fillStyle = '#fff'; x.beginPath(); x.roundRect ? x.roundRect(0, Y - hh / 2, w, hh, hh / 2) : x.rect(0, Y - hh / 2, w, hh); x.fill(); x.restore(); }
  /* the app's screen over a W x H frame (9:16) */
  function drawUI(x, plat, W, H) {
    var k = W / 1080; x.save(); x.scale(k, H / 1920);
    var R = 1080 - 75;
    if (plat === 'tiktok') {
      text(x, 'Following', 430, 110, 38, { al: 'right', a: .7 }); text(x, 'For You', 470, 110, 40, { w: 800 }); x.fillStyle = '#fff'; x.fillRect(500, 140, 80, 6); icon(x, 'search', 1010, 110, 30);
      icon(x, 'avatar', R, 930, 50); icon(x, 'heart', R, 1100, 46); text(x, '12.4K', R, 1160, 28, { al: 'center' }); icon(x, 'comment', R, 1260, 44); text(x, '842', R, 1320, 28, { al: 'center' });
      icon(x, 'save', R, 1420, 40); text(x, '1.1K', R, 1480, 28, { al: 'center' }); icon(x, 'share', R, 1580, 44); text(x, 'Share', R, 1640, 26, { al: 'center' }); icon(x, 'disc', R, 1730, 42);
      text(x, '@username', 40, 1580, 38, { w: 800 }); x.save(); x.translate(40, 0); bar(x, 1640, 640, 26, .75); bar(x, 1685, 480, 26, .6); x.restore(); text(x, '♫  original sound - username', 40, 1740, 30, { a: .9 });
      x.fillStyle = 'rgba(0,0,0,.92)'; x.fillRect(0, 1800, 1080, 120); ['Home', 'Friends', '', 'Inbox', 'Profile'].forEach(function (s, i) { var cx = 108 + i * 216; if (i === 2) { x.fillStyle = '#fff'; x.beginPath(); x.roundRect ? x.roundRect(cx - 55, 1830, 110, 64, 16) : x.rect(cx - 55, 1830, 110, 64); x.fill(); text(x, '+', cx, 1862, 50, { c: '#000', al: 'center', w: 800 }); } else text(x, s, cx, 1870, 26, { al: 'center', a: .85 }); });
    } else if (plat === 'reels' || plat === 'facebook') {
      text(x, plat === 'reels' ? 'Reels' : 'Reels', 50, 120, 54, { w: 800 }); icon(x, 'cam', 1010, 120, 34);
      icon(x, 'heart', R, 1150, 44); text(x, '9,823', R, 1210, 28, { al: 'center' }); icon(x, 'comment', R, 1310, 42); text(x, '312', R, 1370, 28, { al: 'center' });
      icon(x, 'share', R, 1470, 42); text(x, plat === 'facebook' ? 'Share' : '', R, 1530, 26, { al: 'center' }); icon(x, 'more', R, 1610, 40);
      x.save(); x.fillStyle = '#c9a26b'; x.beginPath(); x.roundRect ? x.roundRect(R - 34, 1680, 68, 68, 12) : x.rect(R - 34, 1680, 68, 68); x.fill(); x.restore();
      x.save(); x.fillStyle = '#c9a26b'; x.beginPath(); x.arc(78, 1590, 34, 0, 7); x.fill(); x.restore(); text(x, 'username', 130, 1590, 34, { w: 800 });
      x.save(); x.strokeStyle = '#fff'; x.lineWidth = 3; x.beginPath(); x.roundRect ? x.roundRect(330, 1565, 140, 52, 12) : x.rect(330, 1565, 140, 52); x.stroke(); x.restore(); text(x, 'Follow', 400, 1591, 28, { al: 'center', w: 700 });
      x.save(); x.translate(44, 0); bar(x, 1660, 620, 26, .75); x.restore(); text(x, '♫  username · Original audio', 44, 1720, 28, { a: .9 });
      x.fillStyle = plat === 'reels' ? 'rgba(0,0,0,.92)' : 'rgba(24,25,26,.95)'; x.fillRect(0, 1810, 1080, 110); for (var i = 0; i < 5; i++) { x.save(); x.strokeStyle = '#fff'; x.lineWidth = 5; x.beginPath(); x.arc(108 + i * 216, 1865, 22, 0, 7); x.stroke(); x.restore(); }
    } else if (plat === 'shorts') {
      icon(x, 'search', 900, 110, 30); icon(x, 'more', 1010, 110, 34);
      var ys = [1080, 1240, 1400, 1560, 1700], ic = ['like', 'dislike', 'comment', 'share', 'remix'], lab = ['24K', 'Dislike', '1.2K', 'Share', 'Remix'];
      ys.forEach(function (y, i) { x.save(); x.fillStyle = 'rgba(255,255,255,.18)'; x.beginPath(); x.arc(990, y, 58, 0, 7); x.fill(); x.restore(); icon(x, ic[i], 990, y, 34); text(x, lab[i], 990, y + 88, 26, { al: 'center' }); });
      x.save(); x.fillStyle = '#c9a26b'; x.beginPath(); x.arc(78, 1640, 34, 0, 7); x.fill(); x.restore(); text(x, '@channel', 130, 1640, 32, { w: 700 });
      x.save(); x.fillStyle = '#fff'; x.beginPath(); x.roundRect ? x.roundRect(330, 1612, 170, 56, 28) : x.rect(330, 1612, 170, 56); x.fill(); x.restore(); text(x, 'Subscribe', 415, 1641, 26, { al: 'center', c: '#000', w: 700 });
      x.save(); x.translate(44, 0); bar(x, 1720, 700, 28, .8); x.restore(); text(x, '♫  Sound name', 44, 1780, 26, { a: .8 });
      x.fillStyle = 'rgba(15,15,15,.95)'; x.fillRect(0, 1830, 1080, 90); ['Home', 'Shorts', '+', 'Subscriptions', 'You'].forEach(function (s, i) { text(x, s, 108 + i * 216, 1875, s === '+' ? 54 : 24, { al: 'center', a: .85 }); });
    }
    x.restore();
  }
  /* red = covered by the app, green dashed = keep your text and faces in here */
  function drawZones(x, plat, W, H, red) {
    var p = P[plat], kx = W / 1080, ky = H / 1920, t = p.top * ky, b = p.bottom * ky, l = p.left * kx, r = p.right * kx;
    if (red) {
      x.save(); x.fillStyle = 'rgba(255,45,85,.28)';
      x.fillRect(0, 0, W, t); x.fillRect(0, H - b, W, b); x.fillRect(0, t, l, H - t - b); x.fillRect(W - r, t, r, H - t - b); x.restore();
    }
    x.save(); x.setLineDash([12 * kx, 8 * kx]); x.lineWidth = Math.max(2, 4 * kx); x.strokeStyle = '#4fd18b'; x.strokeRect(l, t, W - l - r, H - t - b); x.restore();
  }
  /* other shapes (16:9 and so on): title-safe 90% and action-safe 95% */
  function drawGeneric(x, W, H) {
    x.save(); x.lineWidth = Math.max(2, W / 600); x.setLineDash([10, 7]);
    x.strokeStyle = 'rgba(79,209,139,.95)'; x.strokeRect(W * .05, H * .05, W * .9, H * .9);
    x.strokeStyle = 'rgba(240,184,96,.9)'; x.strokeRect(W * .025, H * .025, W * .95, H * .95);
    x.restore();
  }
  function overlay(x, W, H) {
    x.save(); x.globalAlpha = S.op;
    if (Math.abs(W / H - 9 / 16) < .02) {
      var list = S.plat === 'all' ? ['tiktok', 'reels', 'shorts', 'facebook'] : [S.plat];
      if (S.plat === 'all') {   // where everything is safe on every app
        var u = { top: 0, bottom: 0, left: 0, right: 0 }; list.forEach(function (k) { ['top', 'bottom', 'left', 'right'].forEach(function (s) { u[s] = Math.max(u[s], P[k][s]); }); });
        P.all = u; drawZones(x, 'all', W, H, S.red);
      } else { if (S.ui) drawUI(x, S.plat, W, H); drawZones(x, S.plat, W, H, S.red); }
    } else drawGeneric(x, W, H);
    x.restore();
  }

  /* ---------- tab ---------- */
  var ui = {}, seq = { w: 1080, h: 1920 }, under = null, busy = false, last = st.get('last', null);
  function fit() {
    if (!ui.wrap) return;
    var w = Math.max(160, ui.wrap.clientWidth || 300), ar = seq.w / seq.h, hh = Math.min(480, w / ar), ww = hh * ar;
    ui.stage.style.width = Math.round(ww) + 'px'; ui.stage.style.height = Math.round(hh) + 'px';
    var dpr = Math.min(2, G.devicePixelRatio || 1); ui.cv.width = Math.round(ww * dpr); ui.cv.height = Math.round(hh * dpr); paint();
  }
  function paint() {
    if (!ui.cv) return;
    var W = ui.cv.width, H = ui.cv.height, x = ui.cv.getContext('2d'); x.setTransform(1, 0, 0, 1, 0, 0); x.clearRect(0, 0, W, H);
    if (under) { var ir = under.width / under.height, vr = W / H, dw = ir > vr ? H * ir : W, dh = ir > vr ? H : W / ir; x.drawImage(under, (W - dw) / 2, (H - dh) / 2, dw, dh); }
    else { var g = x.createLinearGradient(0, 0, W, H); g.addColorStop(0, '#2b3442'); g.addColorStop(1, '#5a4a55'); x.fillStyle = g; x.fillRect(0, 0, W, H); }
    overlay(x, W, H);
    var p = S.plat === 'all' ? null : P[S.plat];
    ui.info.textContent = Math.abs(seq.w / seq.h - 9 / 16) < .02 ? (p ? 'خلي الكلام والوشوش جوه الخط الأخضر. الأحمر بيتغطى بأزرار وكلام ' + p.name + '.' : 'الأخضر = آمن على كل التطبيقات مع بعض.') : 'السيكوينس مش رأسي (9:16) — ظاهر خط الأمان العادي: الأخضر للكلام (90%) والأصفر للحركة (95%).';
  }
  function grab() {
    ui.status.show('busy', 'بجيب الفريم…');
    Sys.call('cr_under2').then(function (r) {
      if (!r || !r.ok) throw new Error('افتح سيكوينس الأول.');
      if (r.w) seq = { w: r.w, h: r.h };
      if (r.none || !r.clip) { under = null; ui.status.show('warn', 'مفيش فيديو تحت المؤشر.'); fit(); return; }
      return Sys.grabFrame(r.clip.path, r.clip.src, Math.round(seq.w / 2), Math.round(seq.h / 2)).then(function (p) {
        return new Promise(function (res) { var im = new Image(); im.onload = function () { res(im); }; im.onerror = function () { res(null); }; im.src = Sys.url(p); });
      }).then(function (im) { under = im; ui.status.show('', ''); fit(); });
    }).catch(function (e) { ui.status.show('err', e.message || String(e)); });
  }
  /* the guide as a clip on top of everything (turn it off before export) */
  function place() {
    if (busy) return; busy = true; ui.place.disabled = true;
    var info = null, png = '', mov = '';
    Sys.call('cr_audioClips').then(function (r) {
      if (!r || !r.ok) throw new Error('افتح سيكوينس الأول.');
      info = r; seq = { w: r.w, h: r.h };
      var c = G.document.createElement('canvas'); c.width = r.w; c.height = r.h; overlay(c.getContext('2d'), r.w, r.h);
      var dir = Sys.join(Sys.workDir(), 'safezone'); Sys.mkdirp(dir);
      png = Sys.join(dir, 'sz' + Date.now() + '.png'); mov = Sys.join(dir, 'ENP_SafeZone_' + (S.plat) + '_' + Date.now() + '.mov');
      Sys.req('fs').writeFileSync(png, Sys.req('buffer').Buffer.from(c.toDataURL('image/png').split(',')[1], 'base64'));
      var dur = Math.max(5, Math.ceil(r.end || 60) + 1);
      ui.status.show('busy', 'بجهّز الدليل…');
      return Sys.run(['-y', '-hide_banner', '-loglevel', 'error', '-loop', '1', '-i', png, '-t', String(dur), '-r', String(Math.round(r.fps || 30)), '-c:v', 'qtrle', '-pix_fmt', 'argb', mov], { timeout: 600000 })
        .then(function () { if (!Sys.exists(mov)) throw new Error('render'); return Sys.call('cr_place', { front: mov, back: '', at: 0, duration: dur, replace: last ? last.names : [], bin: 'ENP Safe Zone' }); });
    }).then(function (r) {
      if (!r || !r.ok) throw new Error(r && (r.error || r.detail) || 'place');
      last = { names: r.names }; st.set('last', last); K.show(ui.remove, true);
      ui.status.show('ok', 'الدليل اتحط على ' + r.track + ' فوق كل حاجة ✓ — اقفله أو امسحه قبل الإكسبورت.');
    }).catch(function (e) { ui.status.show('err', 'حصلت مشكلة [' + (e.message || e) + ']'); })
      .then(function () { busy = false; ui.place.disabled = false; try { if (png) Sys.remove(png); } catch (e) {} });
  }
  function removeIt() {
    if (!last) return;
    Sys.call('cr_remove', { names: last.names }).then(function (r) { if (r && r.ok) { ui.status.show('ok', 'الدليل اتشال من التايملاين.'); last = null; st.set('last', null); K.show(ui.remove, false); } });
  }
  function build(root) {
    ui.cv = h('canvas', { class: 'glcv' }); ui.stage = h('div', { class: 'stage' }, [ui.cv]); ui.wrap = h('div', { class: 'pvwrap' }, [ui.stage]);
    ui.status = K.status(); ui.info = h('div', { class: 'hint', style: 'margin-top:6px' });
    ui.place = K.btn('حط الدليل على التايملاين', { cls: 'pri', icon: 'spark', onClick: place });
    ui.remove = K.btn('شيل الدليل', { cls: 'ghost', icon: 'undo', onClick: removeIt }); K.show(ui.remove, !!last);
    function tg(k, label) { return K.toggle(label, S[k], function (v) { S[k] = v; save(); paint(); }); }
    [h('div', { class: 'hint intro', text: 'شوف الفريم هيبان إزاي بعد ما ينزل على التيك توك أو الريلز أو الشورتس أو فيسبوك: الأزرار والكلام بتاع التطبيق فوق الفيديو، والمنطقة اللي لازم الكلام والوشوش يفضلوا جواها.' }),
      h('div', { class: 'pv' }, [ui.wrap, ui.info, h('div', { class: 'adds', style: 'margin-top:8px' }, [K.btn('هات الفريم اللي تحت المؤشر', { icon: 'target', onClick: grab })])]),
      K.section('المنصة', [K.seg({ items: [{ v: 'tiktok', label: 'TikTok' }, { v: 'reels', label: 'Reels' }, { v: 'shorts', label: 'Shorts' }, { v: 'facebook', label: 'Facebook' }, { v: 'all', label: 'كلهم' }], value: S.plat, onChange: function (v) { S.plat = v; save(); paint(); } }),
        tg('ui', 'اظهر أزرار وكلام التطبيق'), tg('red', 'لوّن المناطق اللي بتتغطى'),
        K.slider({ label: 'الوضوح', min: .2, max: 1, step: .01, value: S.op, fmt: function (v) { return Math.round(v * 100) + '%'; }, onInput: function (v) { S.op = v; save(); paint(); } }),
        h('div', { class: 'hint', text: 'المقاسات تقريبية — كل تطبيق بيغيّر شكله شوية حسب الموبايل.' })], true, 'sz_plat'),
      h('div', { class: 'out' }, [h('div', { class: 'hint', text: 'تقدر تحط الدليل على التايملاين فوق كل حاجة وانت بتمنتج — بس اقفله أو امسحه قبل الإكسبورت.' }), h('div', { style: 'margin-top:10px' }, [ui.place]), h('div', { class: 'tk' }, [ui.remove]), ui.status])
    ].forEach(function (el) { root.appendChild(el); });
    G.addEventListener('resize', fit);
    Sys.call('cr_info').then(function (r) { if (r && r.ok && r.hasSequence && r.w) { seq = { w: r.w, h: r.h }; fit(); } });
    fit();
  }
  G.SafeTab = { build: build, onShow: function () { Sys.call('cr_info').then(function (r) { if (r && r.ok && r.hasSequence && r.w && (r.w !== seq.w || r.h !== seq.h)) { seq = { w: r.w, h: r.h }; under = null; fit(); } }); }, _overlay: overlay, _S: S };
})(window);
