/* ENP — text on a path. Draw a line / curve with a pen tool (anchors + bezier handles),
   the text follows it: start anywhere on it, grow or shrink along it, many entrances.
   Arabic stays joined: the line is shaped once, then laid along the curve in thin slices. */
(function (G) {
  'use strict';
  var K = G.K, h = K.h, st = K.store('enp_path_');
  function cl(v, a, b) { return v < a ? a : v > b ? b : v; }
  function lerp(a, b, k) { return a + (b - a) * k; }
  var E = {
    out: function (x) { x = cl(x, 0, 1); return 1 - Math.pow(1 - x, 3); },
    out5: function (x) { x = cl(x, 0, 1); return 1 - Math.pow(1 - x, 5); },
    io: function (x) { x = cl(x, 0, 1); return x < .5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2; },
    back: function (x) { x = cl(x, 0, 1); var c = 2.2; return 1 + (c + 1) * Math.pow(x - 1, 3) + c * Math.pow(x - 1, 2); },
    elastic: function (x) { x = cl(x, 0, 1); if (x === 0 || x === 1) return x; return Math.pow(2, -10 * x) * Math.sin((x * 10 - .75) * (2 * Math.PI / 3)) + 1; }
  };
  function rnd(i, k) { var x = Math.sin((i + 1) * 12.9898 + (k || 0) * 78.233) * 43758.5453; return x - Math.floor(x); }
  var AR = /[֐-ࣿיִ-﷿ﹰ-﻿]/;

  /* ---------- shapes to start from (x,y of the frame; handles relative) ---------- */
  function N(x, y, ix, iy, ox, oy) { return { x: x, y: y, hin: [ix || 0, iy || 0], hout: [ox || 0, oy || 0] }; }
  var SHAPES = {
    arc: { name: 'قوس فوق', closed: false, nodes: [N(.18, .22, 0, 0, .1, -.1), N(.82, .22, -.1, -.1, 0, 0)] },
    smile: { name: 'قوس تحت', closed: false, nodes: [N(.15, .66, 0, 0, .12, .1), N(.85, .66, -.12, .1, 0, 0)] },
    wave: { name: 'موجة', closed: false, nodes: [N(.08, .5, 0, 0, .1, -.08), N(.5, .5, -.1, .08, .1, -.08), N(.92, .5, -.1, .08, 0, 0)] },
    s: { name: 'S', closed: false, nodes: [N(.15, .35, 0, 0, .3, -.06), N(.85, .62, -.3, -.06, 0, 0)] },
    line: { name: 'خط مستقيم', closed: false, nodes: [N(.12, .5), N(.88, .5)] },
    diag: { name: 'مايل', closed: false, nodes: [N(.12, .62), N(.88, .38)] },
    circle: { name: 'دايرة', closed: true, nodes: (function () { var r = .3, k = .5523 * r, cx = .5, cy = .45, ry = r * 9 / 16; return [N(cx - r, cy, 0, k * 9 / 16, 0, -k * 9 / 16), N(cx, cy - ry, -k, 0, k, 0), N(cx + r, cy, 0, -k * 9 / 16, 0, k * 9 / 16), N(cx, cy + ry, k, 0, -k, 0)]; })() },
    spiral: { name: 'لولب', closed: false, nodes: [N(.5, .45, 0, 0, .08, -.02), N(.62, .4, 0, -.04, 0, .05), N(.5, .55, .1, 0, -.12, 0), N(.3, .4, 0, .08, 0, -.1), N(.55, .25, -.15, 0, .15, 0), N(.85, .45, 0, -.1, 0, .1)] }
  };
  var ANIMS = {
    reveal: 'بيظهر على طول الخط', grow: 'حرف ورا حرف بيكبر', travel: 'بيمشي على الخط لمكانه', drawline: 'الخط بيترسم والكلام وراه',
    scatter: 'متبعتر وبيتجمع', flip: 'بيتقلب لفوق', blur: 'بلور ناعم (أبل)', drop: 'نازل على الخط', elastic: 'مطاطي', fade: 'ظهور هادي', none: 'من غير'
  };
  var OUTS = { fade: 'يختفي بهدوء', reverse: 'يتمسح بالعكس', travel: 'يكمل على الخط ويخرج', blur: 'بلور', scatter: 'يتبعتر', none: 'من غير' };
  var LOOPS = { none: 'مفيش', wave: 'موجة', float: 'عايم', shine: 'لمعة', pulse: 'نبض' };

  var DEF = {
    shape: 'arc', nodes: SHAPES.arc.nodes, closed: false,
    text: 'أستايل جامد', font: 'Arial', weight: 800, color: '#ffffff', color2: '#e48aa6', grad: false,
    glow: .5, glowColor: '#ffffff', stroke: 0, strokeColor: '#000000', shadow: .2,
    size: .055, sStart: 1, sEnd: 1, align: 'center', offset: 0, lift: 0, flip: false,
    anim: 'reveal', inDur: 1, outMode: 'fade', outDur: .5, dur: 4, loop: 'none',
    showPath: false, pathColor: '#ffffff', pathW: 3, pathGlow: .5
  };
  var S = (function () { var o = JSON.parse(JSON.stringify(DEF)), s = st.get('set', {}), k; for (k in s) o[k] = s[k]; return o; })();
  function save() { st.set('set', S); }

  /* ---------- path geometry ---------- */
  function segs(s, W, H) {
    var n = s.nodes, out = [], m = s.closed ? n.length : n.length - 1;
    for (var i = 0; i < m; i++) {
      var a = n[i], b = n[(i + 1) % n.length];
      out.push([[a.x * W, a.y * H], [(a.x + a.hout[0]) * W, (a.y + a.hout[1]) * H], [(b.x + b.hin[0]) * W, (b.y + b.hin[1]) * H], [b.x * W, b.y * H]]);
    }
    return out;
  }
  function bz(p, t) { var u = 1 - t; return [u * u * u * p[0][0] + 3 * u * u * t * p[1][0] + 3 * u * t * t * p[2][0] + t * t * t * p[3][0], u * u * u * p[0][1] + 3 * u * u * t * p[1][1] + 3 * u * t * t * p[2][1] + t * t * t * p[3][1]]; }
  /* polyline with arc lengths; at(d) -> {x, y, a (tangent angle)} */
  function poly(s, W, H) {
    var P = [], L = [0];
    segs(s, W, H).forEach(function (sg, k) { for (var i = (k ? 1 : 0); i <= 80; i++) P.push(bz(sg, i / 80)); });
    if (s.flip) P.reverse();
    for (var i = 1; i < P.length; i++) L.push(L[i - 1] + Math.hypot(P[i][0] - P[i - 1][0], P[i][1] - P[i - 1][1]));
    var tot = L[L.length - 1] || 1, j = 0;
    function at(d) {
      if (P.length < 2) return { x: 0, y: 0, a: 0 };
      if (d <= 0) { var a0 = Math.atan2(P[1][1] - P[0][1], P[1][0] - P[0][0]); return { x: P[0][0] + Math.cos(a0) * d, y: P[0][1] + Math.sin(a0) * d, a: a0 }; }
      if (d >= tot) { var n = P.length - 1, a1 = Math.atan2(P[n][1] - P[n - 1][1], P[n][0] - P[n - 1][0]); return { x: P[n][0] + Math.cos(a1) * (d - tot), y: P[n][1] + Math.sin(a1) * (d - tot), a: a1 }; }
      if (L[j] > d) j = 0;
      while (j < L.length - 2 && L[j + 1] < d) j++;
      var k = (d - L[j]) / Math.max(1e-6, L[j + 1] - L[j]), x = lerp(P[j][0], P[j + 1][0], k), y = lerp(P[j][1], P[j + 1][1], k);
      /* tangent averaged over a short stretch: no kinks between samples */
      var b = Math.max(0, j - 2), e = Math.min(P.length - 1, j + 3);
      return { x: x, y: y, a: Math.atan2(P[e][1] - P[b][1], P[e][0] - P[b][0]) };
    }
    return { pts: P, len: tot, at: at };
  }

  /* ---------- the text as one shaped strip ---------- */
  var stripCache = { key: '', c: null, rtl: false, base: 0, pxs: 1 };
  function strip(s, px) {
    var key = [s.text, s.font, s.weight, s.color, s.color2, s.grad, s.glow, s.glowColor, s.stroke, s.strokeColor, s.shadow, Math.round(px)].join('|');
    if (stripCache.key === key) return stripCache;
    var c = stripCache.c || G.document.createElement('canvas'), x = c.getContext('2d'), txt = String(s.text || ' ').replace(/\n/g, ' ');
    var font = s.weight + ' ' + px + 'px "' + s.font + '", "Segoe UI", Tahoma, Arial, sans-serif';
    x.font = font; var w = Math.ceil(x.measureText(txt).width), pad = Math.ceil(px * (.25 + s.glow * .6));
    c.width = Math.max(4, Math.min(8000, w + pad * 2)); c.height = Math.ceil(px * 1.6 + pad * 2);
    x = c.getContext('2d'); x.font = font; x.textBaseline = 'alphabetic'; var rtl = AR.test(txt); x.direction = rtl ? 'rtl' : 'ltr'; x.textAlign = 'center';
    var base = pad + px * 1.05, cx = c.width / 2;
    if (s.glow > 0) { x.save(); x.shadowColor = s.glowColor; x.shadowBlur = px * s.glow * .7; x.fillStyle = s.glowColor; x.globalAlpha = .85; x.fillText(txt, cx, base); x.fillText(txt, cx, base); x.restore(); }
    if (s.shadow > 0) { x.shadowColor = 'rgba(0,0,0,' + s.shadow + ')'; x.shadowBlur = px * .15; x.shadowOffsetY = px * .05; }
    if (s.stroke > 0) { x.lineJoin = 'round'; x.lineWidth = px * s.stroke * .12; x.strokeStyle = s.strokeColor; x.strokeText(txt, cx, base); x.shadowColor = 'transparent'; }
    if (s.grad) { var g = x.createLinearGradient(pad, 0, c.width - pad, 0); g.addColorStop(0, s.color); g.addColorStop(1, s.color2); x.fillStyle = g; } else x.fillStyle = s.color;
    x.fillText(txt, cx, base);
    stripCache = { key: key, c: c, rtl: rtl, base: base, px: px, pad: pad, w: w };
    return stripCache;
  }

  /* ---------- draw everything at time t ---------- */
  function draw(ctx, s, W, H, t, opt) {
    opt = opt || {};
    var path = poly(s, W, H), px = Math.max(6, s.size * H), big = Math.max(s.sStart, s.sEnd, .1);
    var sp = strip(s, px * big * (opt.quality || 1.25)), k0 = 1 / (big * (opt.quality || 1.25));   // strip px -> output px at scale 1
    var c = sp.c, sw = c.width, sh = c.height, dur = Math.max(.4, s.dur), inD = Math.max(.05, s.inDur), outD = Math.max(.05, s.outDur);
    var pIn = s.anim === 'none' ? 1 : cl(t / inD, 0, 1), pOut = s.outMode === 'none' ? 1 : cl((dur - t) / outD, 0, 1);
    /* slice widths along the path: each slice is scaled by where it sits in the reading order */
    var SL = Math.max(2, Math.round(sw / 400)), n = Math.ceil(sw / SL), scale = new Float32Array(n), tot = 0, i;
    for (i = 0; i < n; i++) { var ux = (i + .5) / n, ur = sp.rtl ? 1 - ux : ux; scale[i] = lerp(s.sStart, s.sEnd, ur) / big; tot += SL * scale[i] * k0 * big; }
    var start = s.align === 'start' ? 0 : s.align === 'end' ? path.len - tot : (path.len - tot) / 2;
    start += s.offset * path.len;
    var travel = 0;
    if (s.anim === 'travel' && pIn < 1) travel = -(1 - E.out5(pIn)) * (start + tot + 20);
    if (s.outMode === 'travel' && pOut < 1) travel += Math.pow(1 - pOut, 2) * (path.len - start + 20);
    /* the path line itself */
    if (s.showPath || s.anim === 'drawline') {
      var pl = s.anim === 'drawline' ? E.io(cl(t / (inD * .7), 0, 1)) : (s.anim === 'none' ? 1 : E.out(pIn));
      var shownTo = path.len * pl * pOut;
      if (s.showPath || s.anim === 'drawline') {
        ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.strokeStyle = s.pathColor; ctx.lineWidth = s.pathW * H / 1080;
        if (s.pathGlow > 0) { ctx.shadowColor = s.pathColor; ctx.shadowBlur = 20 * s.pathGlow * H / 1080; }
        ctx.globalAlpha = s.showPath ? 1 : (1 - cl((t - inD) / .5, 0, 1)) * .9;
        ctx.beginPath(); var dd = 0; ctx.moveTo(path.pts[0][0], path.pts[0][1]);
        for (i = 1; i < path.pts.length; i++) { dd += Math.hypot(path.pts[i][0] - path.pts[i - 1][0], path.pts[i][1] - path.pts[i - 1][1]); if (dd > shownTo) break; ctx.lineTo(path.pts[i][0], path.pts[i][1]); }
        ctx.stroke(); ctx.restore();
        if (s.anim === 'drawline' && pl > 0 && pl < 1) { var hd = path.at(shownTo); ctx.save(); var gr = ctx.createRadialGradient(hd.x, hd.y, 0, hd.x, hd.y, px * .9); gr.addColorStop(0, 'rgba(255,255,255,.95)'); gr.addColorStop(.3, 'rgba(255,255,255,.35)'); gr.addColorStop(1, 'rgba(255,255,255,0)'); ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(hd.x, hd.y, px * .9, 0, 7); ctx.fill(); ctx.restore(); }
      }
    }
    /* the text, slice by slice */
    var lift = s.lift * px, pos = start + travel, blurAll = 0, alphaAll = 1;
    if (s.anim === 'blur') { blurAll = (1 - E.out(pIn)) * px * .35; alphaAll *= E.out(pIn); }
    if (s.anim === 'fade') alphaAll *= E.out(pIn);
    if (s.outMode === 'fade') alphaAll *= E.out(pOut);
    if (s.outMode === 'blur') { blurAll += (1 - E.out(pOut)) * px * .35; alphaAll *= pOut; }
    if (alphaAll <= .003) return;
    ctx.save(); ctx.globalAlpha = alphaAll;
    if (blurAll > .4) ctx.filter = 'blur(' + blurAll.toFixed(1) + 'px)';
    var shineAt = s.loop === 'shine' ? ((t * .45) % 1.6) / 1.6 * 1.4 - .2 : -9;
    for (i = 0; i < n; i++) {
      var sc = scale[i] * big * k0, wOut = SL * sc, ux2 = (i + .5) / n, ord = sp.rtl ? 1 - ux2 : ux2;   // ord: 0 = first letter read
      var mid = pos + wOut / 2; pos += wOut;
      /* per-slice animation */
      var a = 1, dy = 0, ss = 1, dx = 0, rot = 0;
      var lp = cl((pIn * 1.35 - ord * .35 * 1) / 1, 0, 1);  // a wave going through the letters in reading order
      var local = cl((pIn - ord * .6) / .4, 0, 1);
      switch (s.anim) {
        case 'reveal': a = cl((pIn * 1.15 - ord) / .15, 0, 1); ss = lerp(.85, 1, a); break;
        case 'grow': ss = E.back(local); a = cl(local * 3, 0, 1); break;
        case 'drawline': a = cl((cl(t / (inD * .7), 0, 1) * 1.1 - (sp.rtl ? 1 - ux2 : ux2)) / .1, 0, 1); break;
        case 'scatter': { var e = E.out5(local); dx = (rnd(i >> 3, 1) - .5) * px * 6 * (1 - e); dy = (rnd(i >> 3, 2) - .5) * px * 6 * (1 - e); rot = (rnd(i >> 3, 3) - .5) * 2 * (1 - e); a = cl(local * 2, 0, 1); break; }
        case 'flip': ss = 1; a = cl(local * 2, 0, 1); dy = 0; break;
        case 'drop': { var e2 = E.out5(local); dy = -(1 - e2) * px * 1.6; a = cl(local * 2.5, 0, 1); break; }
        case 'elastic': ss = Math.max(0, E.elastic(local)); a = cl(local * 4, 0, 1); break;
      }
      if (s.outMode === 'reverse' && pOut < 1) a *= cl((pOut * 1.15 - (1 - ord)) / .15, 0, 1);
      if (s.outMode === 'scatter' && pOut < 1) { var e3 = 1 - E.out(pOut); dx += (rnd(i >> 3, 5) - .5) * px * 6 * e3; dy += (rnd(i >> 3, 6) - .5) * px * 6 * e3; a *= pOut; }
      if (s.loop === 'wave') dy += Math.sin(t * 4 - ord * 9) * px * .14;
      if (s.loop === 'float') dy += Math.sin(t * 2.2) * px * .1;
      if (s.loop === 'pulse') ss *= 1 + Math.max(0, Math.sin(t * 5)) * .05;
      if (a <= .003 || ss <= .001) continue;
      var P = path.at(mid);
      ctx.save(); ctx.globalAlpha = alphaAll * a;
      ctx.translate(P.x + dx, P.y + dy); ctx.rotate(P.a + rot);
      ctx.translate(0, -lift);
      var sy = s.anim === 'flip' ? Math.max(.01, Math.sin(E.out(local) * Math.PI / 2)) : 1;
      ctx.scale(sc * ss, sc * ss * sy);
      /* slices overlap by half a pixel so there are no seams on curves */
      ctx.drawImage(c, i * SL, 0, Math.min(SL + 1, sw - i * SL), sh, -SL / 2 - .3, -sp.base, Math.min(SL + 1, sw - i * SL) + .6, sh);
      if (Math.abs(ord - shineAt) < .12) { ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = alphaAll * a * (1 - Math.abs(ord - shineAt) / .12) * .6; ctx.drawImage(c, i * SL, 0, Math.min(SL + 1, sw - i * SL), sh, -SL / 2 - .3, -sp.base, Math.min(SL + 1, sw - i * SL) + .6, sh); }
      ctx.restore();
    }
    ctx.restore();
  }

  /* ---------- editor ---------- */
  var ui = {}, ctl = {}, seq = { w: 1080, h: 1920 }, under = null, clock = { on: false, t: 1.5, last: 0 }, raf = 0, busy = false, stopReq = false;
  var pen = false, sel = -1, drag = null, last = st.get('last', null);
  function view() { return { W: ui.cv.width, H: ui.cv.height }; }
  function fit() {
    if (!ui.wrap) return;
    var w = Math.max(160, ui.wrap.clientWidth || 300), ar = seq.w / seq.h, hh = Math.min(460, w / ar), ww = hh * ar;
    ui.stage.style.width = Math.round(ww) + 'px'; ui.stage.style.height = Math.round(hh) + 'px';
    var dpr = Math.min(2, G.devicePixelRatio || 1); ui.cv.width = Math.round(ww * dpr); ui.cv.height = Math.round(hh * dpr); paint();
  }
  function req() { if (!raf) raf = (G.requestAnimationFrame || setTimeout)(paint); }
  function paint() {
    raf = 0; if (!ui.cv) return;
    var now = Date.now();
    if (clock.on) { clock.t += Math.min(.1, (now - (clock.last || now)) / 1000); clock.last = now; if (clock.t > S.dur + .4) clock.t = 0; }
    var V = view(), x = ui.cv.getContext('2d'); x.setTransform(1, 0, 0, 1, 0, 0); x.clearRect(0, 0, V.W, V.H);
    if (under && under.img) { var ir = under.img.width / under.img.height, vr = V.W / V.H, dw = ir > vr ? V.H * ir : V.W, dh = ir > vr ? V.H : V.W / ir; x.drawImage(under.img, (V.W - dw) / 2, (V.H - dh) / 2, dw, dh); }
    else { var g = x.createLinearGradient(0, 0, V.W, V.H); g.addColorStop(0, '#2b3442'); g.addColorStop(1, '#5a4a55'); x.fillStyle = g; x.fillRect(0, 0, V.W, V.H); }
    draw(x, S, V.W, V.H, Math.min(clock.t, S.dur), { quality: 1 });
    if (!clock.on || ui.edit) drawEditor(x, V);
    ui.scrub.max = String(S.dur); ui.scrub.value = String(Math.min(clock.t, S.dur));
    ui.time.textContent = Math.min(clock.t, S.dur).toFixed(1) + ' / ' + (+S.dur).toFixed(1) + 's';
    if (clock.on) req();
  }
  function drawEditor(x, V) {
    var W = V.W, H = V.H, d = Math.min(2, G.devicePixelRatio || 1);
    x.save(); x.lineWidth = 1.5 * d; x.strokeStyle = 'rgba(255,211,77,.9)'; x.setLineDash([6 * d, 4 * d]);
    x.beginPath(); segs(S, W, H).forEach(function (sg, k) { if (!k) x.moveTo(sg[0][0], sg[0][1]); x.bezierCurveTo(sg[1][0], sg[1][1], sg[2][0], sg[2][1], sg[3][0], sg[3][1]); });
    x.stroke(); x.setLineDash([]);
    S.nodes.forEach(function (n, i) {
      var px = n.x * W, py = n.y * H;
      if (i === sel) {
        [['hin', n.hin], ['hout', n.hout]].forEach(function (hd) { if (!hd[1][0] && !hd[1][1]) return; var hx = (n.x + hd[1][0]) * W, hy = (n.y + hd[1][1]) * H; x.strokeStyle = 'rgba(77,210,255,.9)'; x.beginPath(); x.moveTo(px, py); x.lineTo(hx, hy); x.stroke(); x.fillStyle = '#4dd2ff'; x.beginPath(); x.arc(hx, hy, 4.5 * d, 0, 7); x.fill(); });
      }
      x.fillStyle = i === sel ? '#ffd34d' : '#fff'; x.strokeStyle = '#2a0712'; x.lineWidth = 1.5 * d;
      x.beginPath(); x.rect(px - 5 * d, py - 5 * d, 10 * d, 10 * d); x.fill(); x.stroke();
      if (i === 0) { x.fillStyle = '#4fd18b'; x.beginPath(); x.arc(px, py, 2.5 * d, 0, 7); x.fill(); }
    });
    x.restore();
  }
  function ptr(e) { var r = ui.cv.getBoundingClientRect(); return { x: (e.clientX - r.left) / r.width, y: (e.clientY - r.top) / r.height, r: r }; }
  function hit(p) {
    var r = p.r, best = null, bd = 12;
    if (sel >= 0 && S.nodes[sel]) ['hin', 'hout'].forEach(function (k) { var n = S.nodes[sel], hx = n.x + n[k][0], hy = n.y + n[k][1]; if (!n[k][0] && !n[k][1]) return; var dd = Math.hypot((hx - p.x) * r.width, (hy - p.y) * r.height); if (dd < bd) { bd = dd; best = { node: sel, h: k }; } });
    S.nodes.forEach(function (n, i) { var dd = Math.hypot((n.x - p.x) * r.width, (n.y - p.y) * r.height); if (dd < bd) { bd = dd; best = { node: i }; } });
    return best;
  }
  function nearestOnPath(p) {   // segment + t closest to the pointer (for inserting a node)
    var best = { d: 1e9 }, W = p.r.width, H = p.r.height;
    segs(S, 1, 1).forEach(function (sg, k) { for (var i = 0; i <= 60; i++) { var q = bz(sg, i / 60), dd = Math.hypot((q[0] - p.x) * W, (q[1] - p.y) * H); if (dd < best.d) best = { d: dd, k: k, t: i / 60 }; } });
    return best;
  }
  function split(k, t) {   // de Casteljau: put a node on segment k at t, curve unchanged
    var a = S.nodes[k], b = S.nodes[(k + 1) % S.nodes.length];
    var p0 = [a.x, a.y], p1 = [a.x + a.hout[0], a.y + a.hout[1]], p2 = [b.x + b.hin[0], b.y + b.hin[1]], p3 = [b.x, b.y];
    function L(u, v) { return [lerp(u[0], v[0], t), lerp(u[1], v[1], t)]; }
    var q0 = L(p0, p1), q1 = L(p1, p2), q2 = L(p2, p3), r0 = L(q0, q1), r1 = L(q1, q2), m = L(r0, r1);
    a.hout = [q0[0] - a.x, q0[1] - a.y]; b.hin = [q2[0] - b.x, q2[1] - b.y];
    S.nodes.splice(k + 1, 0, { x: m[0], y: m[1], hin: [r0[0] - m[0], r0[1] - m[1]], hout: [r1[0] - m[0], r1[1] - m[1]] });
    return k + 1;
  }
  function bindEditor() {
    var cv = ui.cv;
    cv.setAttribute('tabindex', '0');
    cv.addEventListener('pointerdown', function (e) {
      if (busy) return; try { cv.setPointerCapture(e.pointerId); } catch (x) {} cv.focus();
      if (clock.on) play(false);
      var p = ptr(e), hh = hit(p);
      if (hh) { sel = hh.node; drag = { h: hh.h, node: hh.node, alt: e.altKey, start: p }; req(); return; }
      if (pen) {
        if (S.closed) { S.closed = false; }
        if (S.nodes.length > 2 && Math.hypot((S.nodes[0].x - p.x) * p.r.width, (S.nodes[0].y - p.y) * p.r.height) < 12) { S.closed = true; sel = 0; save(); req(); return; }
        S.nodes.push({ x: p.x, y: p.y, hin: [0, 0], hout: [0, 0] }); sel = S.nodes.length - 1; drag = { pull: true, node: sel, start: p }; S.shape = 'custom'; save(); req(); return;
      }
      var np = nearestOnPath(p);
      if (np.d < 10) { sel = split(np.k, np.t); drag = { node: sel, start: p }; S.shape = 'custom'; save(); req(); return; }
      sel = -1; req();
    });
    cv.addEventListener('pointermove', function (e) {
      if (!drag) return; var p = ptr(e), n = S.nodes[drag.node]; if (!n) return;
      if (drag.pull) { n.hout = [p.x - n.x, p.y - n.y]; n.hin = [-(p.x - n.x), -(p.y - n.y)]; }
      else if (drag.h) {
        var o = drag.h === 'hin' ? 'hout' : 'hin'; n[drag.h] = [p.x - n.x, p.y - n.y];
        if (!drag.alt && !e.altKey && n.smooth !== false) { var lo = Math.hypot(n[o][0], n[o][1]), lh = Math.hypot(n[drag.h][0], n[drag.h][1]) || 1; if (lo > 0) n[o] = [-n[drag.h][0] / lh * lo, -n[drag.h][1] / lh * lo]; }
        else n.smooth = false;
      } else { n.x = p.x; n.y = p.y; }
      S.shape = 'custom'; req();
    });
    function end() { if (drag) { drag = null; save(); } }
    cv.addEventListener('pointerup', end); cv.addEventListener('pointercancel', end);
    cv.addEventListener('dblclick', function (e) {
      var hh = hit(ptr(e)); if (!hh || hh.h) return;
      var n = S.nodes[hh.node], i = hh.node;
      if (n.hin[0] || n.hin[1] || n.hout[0] || n.hout[1]) { n.hin = [0, 0]; n.hout = [0, 0]; n.smooth = false; }
      else {
        var pv = S.nodes[i - 1] || (S.closed ? S.nodes[S.nodes.length - 1] : null), nx = S.nodes[i + 1] || (S.closed ? S.nodes[0] : null);
        var a = pv || n, b = nx || n, dx = (b.x - a.x) / 6, dy = (b.y - a.y) / 6; n.hin = [-dx, -dy]; n.hout = [dx, dy]; n.smooth = true;
      }
      save(); req();
    });
    cv.addEventListener('keydown', function (e) {
      if ((e.key === 'Delete' || e.key === 'Backspace') && sel >= 0 && S.nodes.length > 2) { S.nodes.splice(sel, 1); sel = -1; if (S.nodes.length < 3) S.closed = false; save(); req(); e.preventDefault(); }
    });
  }
  function play(on) { clock.on = on; clock.last = Date.now(); ui.play.innerHTML = K.ICON[on ? 'stop' : 'play']; req(); }
  function setShape(k) { var sh = SHAPES[k]; S.shape = k; S.nodes = JSON.parse(JSON.stringify(sh.nodes)); S.closed = sh.closed; sel = -1; save(); clock.t = 0; play(true); }
  function grab() {
    ui.status.show('busy', 'بجيب الفريم…');
    Sys.call('cr_under2').then(function (r) {
      if (!r || !r.ok) throw new Error('افتح سيكوينس الأول.');
      if (r.w) seq = { w: r.w, h: r.h };
      if (r.none || !r.clip) { under = null; ui.status.show('warn', 'مفيش فيديو تحت المؤشر.'); fit(); return; }
      return Sys.grabFrame(r.clip.path, r.clip.src, Math.round(seq.w / 2), Math.round(seq.h / 2)).then(function (p) {
        return new Promise(function (res) { var im = new Image(); im.onload = function () { res(im); }; im.onerror = function () { res(null); }; im.src = Sys.url(p); });
      }).then(function (im) { under = im ? { img: im } : null; ui.status.show('', ''); fit(); });
    }).catch(function (e) { ui.status.show('err', e.message || String(e)); });
  }
  function place() {
    if (busy) return;
    busy = true; stopReq = false; ui.place.disabled = true; K.show(ui.stop, true); play(false);
    var SS = JSON.parse(JSON.stringify(S)), cv = G.document.createElement('canvas'), x;
    Out.renderAndPlace({
      prefix: 'ENP_PathText', bin: 'ENP Path Text', dur: SS.dur, replace: st.get('replace', false) && last ? last.names : [],
      prepare: function (o) { cv.width = o.w; cv.height = o.h; x = cv.getContext('2d'); stripCache.key = ''; return Fonts.ensure(SS.font, +SS.weight); },
      frame: function (t, i, o) { x.setTransform(1, 0, 0, 1, 0, 0); x.clearRect(0, 0, o.w, o.h); draw(x, SS, o.w, o.h, t, { quality: 1.25 }); return x.getImageData(0, 0, o.w, o.h).data; },
      onProgress: function (p) { ui.prog.set(p); ui.status.show('busy', 'برسم النص… ' + Math.round(p * 100) + '%'); },
      cancelled: function () { return stopReq; }
    }).then(function (r) { last = { names: r.names }; st.set('last', last); ui.status.show('ok', 'اتحط على ' + r.track + ' ✓'); })
      .catch(function (e) { ui.status.show(e && e.message === 'cancelled' ? 'warn' : 'err', Out.errText(e)); })
      .then(function () { busy = false; ui.place.disabled = false; K.show(ui.stop, false); ui.prog.done(); stripCache.key = ''; req(); });
  }

  function set(p) { for (var k in p) S[k] = p[k]; save(); req(); }
  function sl(k, label, min, max, step, fmt) { var c = K.slider({ label: label, min: min, max: max, step: step, value: S[k], fmt: fmt, onInput: function (v) { var p = {}; p[k] = v; set(p); } }); ctl[k] = c; return c; }
  function col(k, label) { var inp = h('input', { type: 'color', value: S[k] }); inp.addEventListener('input', function () { var p = {}; p[k] = inp.value; set(p); }); return h('label', { class: 'cfield' }, [inp, h('span', { text: label })]); }
  function sel2(k, map) { var s = h('select', { class: 'sel' }, Object.keys(map).map(function (v) { return h('option', { value: v, text: map[v] }); })); s.value = S[k]; s.addEventListener('change', function () { var p = {}; p[k] = s.value; set(p); if (k === 'anim') { clock.t = 0; play(true); } }); return s; }
  function pct(v) { return Math.round(v * 100) + '%'; }
  function sec(v) { return (+v).toFixed(1) + ' ث'; }
  function build(root) {
    ui.cv = h('canvas', { class: 'glcv' }); ui.stage = h('div', { class: 'stage' }, [ui.cv]); ui.wrap = h('div', { class: 'pvwrap' }, [ui.stage]);
    ui.play = h('button', { type: 'button', class: 'ibtn', html: K.ICON.play, onclick: function () { if (!clock.on && clock.t >= S.dur) clock.t = 0; play(!clock.on); } });
    ui.scrub = h('input', { type: 'range', class: 'scrub', min: 0, max: S.dur, step: .01, value: clock.t });
    ui.scrub.addEventListener('input', function () { clock.t = parseFloat(ui.scrub.value) || 0; if (clock.on) play(false); req(); });
    ui.time = h('span', { class: 'time' }); ui.status = K.status(); ui.prog = K.progress();
    bindEditor();
    var penBtn = K.btn('قلم: ارسم نقط جديدة', { icon: 'plus', onClick: function () { pen = !pen; penBtn.classList.toggle('pri', pen); ui.status.show(pen ? 'ok' : '', pen ? 'دوس عشان تحط نقطة، واسحب وانت دايس عشان تعمل منحنى. دوس على أول نقطة يقفل الشكل. دوس على الزرار تاني عشان تخلص.' : ''); } });
    var clearBtn = K.btn('ارسم من الأول', { cls: 'ghost', icon: 'undo', onClick: function () { S.nodes = []; S.closed = false; sel = -1; pen = true; penBtn.classList.add('pri'); save(); req(); ui.status.show('ok', 'ارسم الخط: دوس لكل نقطة واسحب للمنحنى.'); } });
    var shapes = h('div', { class: 'chips' });
    Object.keys(SHAPES).forEach(function (k) { shapes.appendChild(h('button', { type: 'button', class: 'chip', text: SHAPES[k].name, onclick: function () { setShape(k); } })); });
    var txt = h('textarea', { class: 'txin', dir: 'auto', rows: '2' }); txt.value = S.text; txt.addEventListener('input', function () { set({ text: txt.value }); });
    ui.place = K.btn('حطه على التايملاين', { cls: 'pri', icon: 'spark', onClick: place });
    ui.stop = K.btn('وقّف', { icon: 'stop', onClick: function () { stopReq = true; } }); K.show(ui.stop, false);
    [K.beta(), h('div', { class: 'hint intro', text: 'ارسم خط أو منحنى والكلام يمشي عليه. اسحب المربعات تحركها، والنقط الزرقا بتعوّج المنحنى (Alt عشان تكسرها لوحدها)، دبل كليك على نقطة يقلبها حادة/ناعمة، Delete يمسحها، وكليك على الخط يضيف نقطة.' }),
      h('div', { class: 'pv' }, [ui.wrap, h('div', { class: 'bar' }, [ui.play, ui.scrub, ui.time]),
        h('div', { class: 'adds', style: 'margin-top:8px' }, [K.btn('هات الفريم اللي تحت المؤشر', { icon: 'target', onClick: grab }), penBtn, clearBtn])]),
      K.section('أشكال جاهزة للخط', [shapes, K.toggle('اقلب اتجاه الكلام على الخط', S.flip, function (v) { set({ flip: v }); })], true, 'pt_shapes'),
      K.section('الكلام', [txt, K.field('الخط', Fonts.picker({ value: S.font, onChange: function (f) { S.font = f; save(); Fonts.ensure(f, +S.weight).then(function () { stripCache.key = ''; req(); }); } })),
        sl('size', 'الحجم', .02, .15, .001, pct), sl('sStart', 'حجم البداية', .2, 2.5, .01, pct), sl('sEnd', 'حجم النهاية', .2, 2.5, .01, pct),
        K.field('مكانه على الخط', K.seg({ items: [{ v: 'start', label: 'من البداية' }, { v: 'center', label: 'في النص' }, { v: 'end', label: 'في الآخر' }], value: S.align, onChange: function (v) { set({ align: v }); } })),
        sl('offset', 'حرّكه على الخط', -1, 1, .005, pct), sl('lift', 'بعيد عن الخط', -1.5, 1.5, .01, function (v) { return v.toFixed(2); })], true, 'pt_text'),
      K.section('الشكل', [h('div', { class: 'crow' }, [col('color', 'اللون'), col('color2', 'لون التدرج'), col('glowColor', 'لون التوهج')]),
        K.toggle('تدرج لوني', S.grad, function (v) { set({ grad: v }); }), sl('glow', 'توهج', 0, 1.5, .01, pct), sl('stroke', 'إطار', 0, 1.5, .01, pct), sl('shadow', 'ظل', 0, 1, .01, pct),
        K.toggle('اظهر الخط نفسه', S.showPath, function (v) { set({ showPath: v }); }), h('div', { class: 'crow' }, [col('pathColor', 'لون الخط')]), sl('pathW', 'سُمك الخط', 1, 12, .5, String), sl('pathGlow', 'توهج الخط', 0, 1.5, .01, pct)], false, 'pt_look'),
      K.section('الحركة', [K.field('الدخول', sel2('anim', ANIMS)), sl('inDur', 'مدة الدخول', .2, 3, .05, sec), K.field('الخروج', sel2('outMode', OUTS)), sl('outDur', 'مدة الخروج', .2, 2.5, .05, sec),
        K.field('حركة مستمرة', sel2('loop', LOOPS)), sl('dur', 'المدة', 1, 20, .1, sec)], true, 'pt_anim'),
      h('div', { class: 'out' }, [K.toggle('بدّل آخر واحد حطيته', st.get('replace', false), function (v) { st.set('replace', v); }), h('div', { style: 'margin-top:10px' }, [ui.place]), h('div', { class: 'tk' }, [ui.stop]), ui.prog, ui.status])
    ].forEach(function (el) { root.appendChild(el); });
    G.addEventListener('resize', fit);
    Sys.call('cr_info').then(function (r) { if (r && r.ok && r.hasSequence && r.w) { seq = { w: r.w, h: r.h }; fit(); } });
    fit(); Fonts.ensure(S.font, +S.weight).then(function () { stripCache.key = ''; req(); });
  }
  G.PathTab = { build: build, onHide: function () { if (clock.on) play(false); }, _draw: draw, _S: function () { return S; }, SHAPES: SHAPES };
})(window);
