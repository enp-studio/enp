/* Carousel 3D — talking to Premiere (ExtendScript) and to the disk / ffmpeg (Node). */
(function (G) {
  'use strict';
  var req = (G.cep_node && G.cep_node.require) || G.require || null;
  var Buf = req ? req('buffer').Buffer : null, fs = req ? req('fs') : null, path = req ? req('path') : null, os = req ? req('os') : null, cp = req ? req('child_process') : null;
  var isWin = /^win/i.test((G.navigator && G.navigator.platform) || '') || (typeof process !== 'undefined' && process.platform === 'win32');

  /* ---------- ExtendScript ---------- */
  function call(fn, args) {
    return new Promise(function (resolve) {
      var cs = G.__adobe_cep__;
      if (!cs) return resolve({ ok: false, error: 'no_host' });
      var code = fn + '(' + (args === undefined ? '' : JSON.stringify(JSON.stringify(args))) + ')';
      cs.evalScript(code, function (res) {
        if (res === 'EvalScript error.' || res === undefined) return resolve({ ok: false, error: 'eval', detail: res });
        try { resolve(JSON.parse(res)); } catch (e) { resolve({ ok: false, error: 'parse', detail: String(res).slice(0, 300) }); }
      });
    });
  }

  /* ---------- paths ---------- */
  function extDir() {
    try {
      var p = G.__adobe_cep__ && G.__adobe_cep__.getSystemPath && G.__adobe_cep__.getSystemPath('extension');
      if (p) return decodeURIComponent(String(p).replace(/^file:\/{2,3}/, isWin ? '' : '/'));
    } catch (e) {}
    var u = decodeURIComponent(G.location.pathname).replace(/\/[^\/]*$/, '');
    return isWin ? u.replace(/^\//, '').replace(/\//g, '\\') : u;
  }
  function ascii(s) { return /^[\x20-\x7E]*$/.test(String(s)); }
  var _work = null;
  function workDir() {
    if (_work) return _work;
    var d = path.join(os.tmpdir(), 'Carousel3D');
    if (isWin && !ascii(d)) d = 'C:\\Users\\Public\\Carousel3D';   // ffmpeg + non-latin user names
    mkdirp(d); _work = d; return d;
  }
  function mkdirp(d) { try { fs.mkdirSync(d, { recursive: true }); } catch (e) {} }
  function exists(p) { try { return fs.existsSync(p); } catch (e) { return false; } }
  function url(p) { return 'file:///' + encodeURI(String(p).replace(/\\/g, '/').replace(/^\//, '')).replace(/#/g, '%23').replace(/\?/g, '%3F'); }
  function hash(s) { var h = 0; s = String(s); for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0; return (h >>> 0).toString(36); }
  function mtime(p) { try { return fs.statSync(p).mtimeMs || 0; } catch (e) { return 0; } }

  /* ---------- ffmpeg ---------- */
  var _ff = null;
  function ffPath() {
    if (_ff) return _ff;
    var local = path.join(extDir(), 'runtime', isWin ? 'ffmpeg.exe' : 'ffmpeg');
    if (exists(local)) return (_ff = local);
    /* no copy of our own: use an ffmpeg another panel on this computer already has */
    var exe = isWin ? 'ffmpeg.exe' : 'ffmpeg', parent = path.join(extDir(), '..');
    try {
      var dirs = fs.readdirSync(parent);
      for (var i = 0; i < dirs.length; i++) {
        var cands = [path.join(parent, dirs[i], 'runtime', exe), path.join(parent, dirs[i], 'bin', exe), path.join(parent, dirs[i], exe)];
        for (var j = 0; j < cands.length; j++) if (exists(cands[j])) return (_ff = cands[j]);
      }
    } catch (e) {}
    return (_ff = 'ffmpeg');
  }
  function run(args, opt) {
    opt = opt || {};
    return new Promise(function (resolve, reject) {
      var p, out = '', err = '', timer = null;
      try { p = cp.spawn(ffPath(), args, { windowsHide: true }); } catch (e) { return reject(e); }
      p.stdout.on('data', function (d) { out += d; });
      p.stderr.on('data', function (d) { err += d; if (err.length > 200000) err = err.slice(-100000); });
      p.on('error', function (e) { clearTimeout(timer); reject(e); });
      p.on('close', function (code) { clearTimeout(timer); resolve({ code: code, out: out, err: err }); });
      if (opt.timeout) timer = setTimeout(function () { try { p.kill(); } catch (e) {} }, opt.timeout);
    });
  }
  var _ffOk = null;
  function ffAvailable() {
    if (_ffOk !== null) return Promise.resolve(_ffOk);
    if (!cp) return Promise.resolve(_ffOk = false);
    return run(['-hide_banner', '-version'], { timeout: 15000 }).then(function (r) { return (_ffOk = /ffmpeg version/i.test(r.out + r.err)); }, function () { return (_ffOk = false); });
  }

  /* raw RGBA frames in -> ProRes 4444 with alpha out */
  function fpsArg(f) {
    f = +f || 30;
    if (Math.abs(f - 29.97) < .01) return '30000/1001';
    if (Math.abs(f - 23.976) < .01) return '24000/1001';
    if (Math.abs(f - 59.94) < .01) return '60000/1001';
    return String(Math.round(f * 1000) / 1000);
  }
  function encoder(out, w, h, fps, opt) {
    opt = opt || {};
    var args = ['-y', '-hide_banner', '-loglevel', 'error', '-f', 'rawvideo', '-pix_fmt', 'rgba', '-s', w + 'x' + h, '-r', fpsArg(fps), '-i', '-',
      '-vf', opt.flip === false ? 'null' : 'vflip'].concat(opt.codec === 'qtrle'
        ? ['-c:v', 'qtrle', '-pix_fmt', 'argb']          // QuickTime Animation: tiny files when most of the frame is empty
        : ['-c:v', 'prores_ks', '-profile:v', '4444', '-qscale:v', '9', '-pix_fmt', 'yuva444p10le', '-vendor', 'apl0']).concat(['-an', out]);
    var p = cp.spawn(ffPath(), args, { windowsHide: true }), err = '', code = null;
    p.stderr.on('data', function (d) { err += d; });
    var done = new Promise(function (res, rej) {
      p.on('close', function (c) { code = c; c === 0 ? res() : rej(new Error('encode: ' + (err.trim().split(/\r?\n/).pop() || 'exit ' + c))); });
      p.on('error', rej);
    });
    p.stdin.on('error', function () {});
    return {
      write: function (px) {
        if (code !== null) return Promise.reject(new Error('encode: ' + (err.trim().split(/\r?\n/).pop() || 'closed')));
        var b = Buf.from(px.buffer, px.byteOffset, px.byteLength);
        return new Promise(function (r) { p.stdin.write(b, function () { r(); }); });
      },
      end: function () { try { p.stdin.end(); } catch (e) {} return done; },
      kill: function () { try { p.kill(); } catch (e) {} }
    };
  }

  /* ---------- media: probe, thumbnail, preview copy ---------- */
  var IMG_NATIVE = /\.(jpe?g|png|webp|gif|bmp|jfif|avif)$/i;
  var IMG_ANY = /\.(jpe?g|png|webp|gif|bmp|jfif|avif|tiff?|heic|heif|psd|tga|exr|dpx)$/i;
  var VID = /\.(mp4|mov|m4v|mkv|webm|avi|mxf|mts|m2ts|wmv|mpg|mpeg|3gp|flv|ts)$/i;
  function probe(p) {
    return run(['-hide_banner', '-i', p], { timeout: 30000 }).then(function (r) {
      var t = r.err + r.out, v = /Stream #\d+:\d+[^\n]*?: Video: ([^\n]*)/.exec(t);
      if (!v) throw new Error('not_media');
      var wh = /\b(\d{2,5})x(\d{2,5})\b/.exec(v[1]), w = wh ? +wh[1] : 0, h = wh ? +wh[2] : 0;
      var rot = /rotation of (-?[\d.]+) degrees/.exec(t) || /\brotate\s*:\s*(-?\d+)/.exec(t);
      if (rot && Math.abs(Math.round(+rot[1] / 90)) % 2 === 1) { var x = w; w = h; h = x; }
      var d = /Duration: (\d+):(\d+):(\d+(?:\.\d+)?)/.exec(t), dur = d ? (+d[1]) * 3600 + (+d[2]) * 60 + parseFloat(d[3]) : 0;
      var image = IMG_ANY.test(p) || (!VID.test(p) && !(dur > .2));
      return { kind: image ? 'image' : 'video', w: w, h: h, dur: image ? 0 : dur };
    });
  }
  /* returns { kind, w, h, dur, key, thumb, view } — view is something the panel can show */
  function media(p, from) {
    var dir = path.join(workDir(), 'media'); mkdirp(dir);
    var key = hash(p + '|' + mtime(p) + '|' + (from || 0));
    return probe(p).then(function (info) {
      var o = { kind: info.kind, w: info.w, h: info.h, dur: info.dur, key: key };
      var thumb = path.join(dir, key + '-th.jpg'), jobs = [];
      if (!exists(thumb)) jobs.push(run(['-y', '-hide_banner', '-loglevel', 'error'].concat(info.kind === 'video' ? ['-ss', String((from || 0) + Math.min(1, info.dur / 3))] : [])
        .concat(['-i', p, '-frames:v', '1', '-vf', 'scale=200:-2', '-q:v', '4', thumb]), { timeout: 60000 }));
      if (info.kind === 'image') {
        if (IMG_NATIVE.test(p)) o.view = p;
        else {
          o.view = path.join(dir, key + '-img.png');
          if (!exists(o.view)) jobs.push(run(['-y', '-hide_banner', '-loglevel', 'error', '-i', p, '-frames:v', '1', '-vf', "scale='min(2048,iw)':-2", o.view], { timeout: 60000 }));
        }
      } else {
        /* a small, short WebM copy the panel can play (the panel's browser has no H.264) */
        o.view = path.join(dir, key + '-pv.webm');
        if (!exists(o.view)) jobs.push(run(['-y', '-hide_banner', '-loglevel', 'error', '-ss', String(from || 0), '-i', p, '-t', '20', '-an',
          '-vf', 'scale=-2:480', '-c:v', 'libvpx', '-deadline', 'realtime', '-cpu-used', '8', '-b:v', '1200k', o.view], { timeout: 180000 }));
      }
      o.thumb = thumb;
      return Promise.all(jobs).then(function () {
        if (info.kind === 'video' && !exists(o.view)) o.view = thumb;   // could not make a preview: show a still
        if (!exists(o.view)) throw new Error('prepare_failed');
        return o;
      });
    });
  }
  /* every frame of a clip for the final render, as JPEGs at the render's frame rate */
  function clipFrames(p, from, dur, fps, maxSide) {
    var dir = path.join(workDir(), 'frames', hash(p + '|' + mtime(p) + '|' + from + '|' + dur + '|' + fps + '|' + maxSide));
    var first = path.join(dir, '00001.jpg');
    if (exists(first) && exists(path.join(dir, 'done'))) return Promise.resolve(dir);
    mkdirp(dir);
    return run(['-y', '-hide_banner', '-loglevel', 'error', '-stream_loop', '-1', '-ss', String(from || 0), '-i', p, '-t', String(dur + .5), '-an',
      '-vf', 'fps=' + fpsArg(fps) + ",scale='if(gt(iw,ih),min(" + maxSide + ",iw),-2)':'if(gt(iw,ih),-2,min(" + maxSide + ",ih))'", '-q:v', '3', path.join(dir, '%05d.jpg')], { timeout: 600000 })
      .then(function (r) {
        if (!exists(first)) throw new Error('frames: ' + (r.err.trim().split(/\r?\n/).pop() || 'failed'));
        fs.writeFileSync(path.join(dir, 'done'), '1');
        return dir;
      });
  }
  function grabFrame(p, t, w, h) {
    var out = path.join(workDir(), 'under-' + (Date.now() % 100000) + '.jpg');
    return run(['-y', '-hide_banner', '-loglevel', 'error', '-ss', String(Math.max(0, t).toFixed(3)), '-i', p, '-frames:v', '1',
      '-vf', 'scale=' + w + ':' + h + ':force_original_aspect_ratio=increase,crop=' + w + ':' + h, '-q:v', '4', out], { timeout: 30000 })
      .then(function () { if (!exists(out)) throw new Error('grab'); return out; });
  }

  /* ---------- file picker ---------- */
  function pickFiles(title, exts) {
    try {
      var r = G.cep && G.cep.fs && G.cep.fs.showOpenDialogEx ? G.cep.fs.showOpenDialogEx(true, false, title, '', exts)
        : G.cep.fs.showOpenDialog(true, false, title, '', exts);
      return (r && r.data) || [];
    } catch (e) { return []; }
  }

  G.Sys = {
    hasNode: !!req, isWin: isWin, call: call, extDir: extDir, workDir: workDir, mkdirp: mkdirp, exists: exists, url: url,
    join: function () { return path.join.apply(path, arguments); }, ffAvailable: ffAvailable, ffPath: ffPath,
    encoder: encoder, media: media, probe: probe, run: run, req: req, isAscii: ascii, clipFrames: clipFrames, grabFrame: grabFrame, pickFiles: pickFiles, hash: hash,
    remove: function (p) { try { fs.unlinkSync(p); } catch (e) {} }
  };
})(window);
