/* ENP — first cut: hears where the talking is, then builds a NEW sequence with the
   silences taken out and everything after them pulled together (like a first assembly).
   The original sequence is never touched. Option: markers only. */
(function (G) {
  'use strict';
  var K = G.K, h = K.h, st = K.store('enp_cut2_');
  var DEF = { auto: true, sens: .5, noise: -38, minSil: .4, padA: .1, padB: .12, edges: true, mode: 'seq', range: 'auto', track: 'all', effects: true };
  var P = (function () { var o = {}, s = st.get('set', {}), k; for (k in DEF) o[k] = DEF[k]; for (k in s) o[k] = s[k]; return o; })();
  var A = null, cuts = [], ui = {}, busy = false;
  function save() { st.set('set', P); }

  /* ---------- plan: speech -> cuts (sequence seconds, on frames) ---------- */
  function plan() {
    cuts = [];
    if (!A) return;
    var fr = 1 / (A.fps || 30), snap = function (t) { return Math.round(t / fr) * fr; }, sil = [], last = A.t0;
    A.speech.forEach(function (s) { if (s.a > last + .005) sil.push([last, s.a]); last = Math.max(last, s.b); });
    if (last < A.t1 - .005) sil.push([last, A.t1]);
    sil.forEach(function (s) {
      var atStart = Math.abs(s[0] - A.t0) < .01, atEnd = Math.abs(s[1] - A.t1) < .01;
      if ((atStart || atEnd) && !P.edges) return;
      if (s[1] - s[0] < P.minSil && !atStart && !atEnd) return;
      var a = atStart ? s[0] : s[0] + P.padA, b = atEnd ? s[1] : s[1] - P.padB;
      a = snap(a); b = snap(b);
      if (b - a >= fr * 2) cuts.push([a, b]);
    });
  }
  function drawMap() {
    var cv = ui.map, w = cv.clientWidth || 300, hh = 110, dpr = Math.min(2, G.devicePixelRatio || 1);
    cv.width = Math.round(w * dpr); cv.height = Math.round(hh * dpr);
    var x = cv.getContext('2d'); x.setTransform(dpr, 0, 0, dpr, 0, 0); x.clearRect(0, 0, w, hh);
    if (!A) return;
    var t0 = A.t0, t1 = A.t1, X = function (t) { return (t - t0) / Math.max(.01, t1 - t0) * w; }, mid = hh / 2, pk = A.peaks, n = pk.length;
    x.fillStyle = 'rgba(244,235,239,.55)';
    for (var i = 0; i < n; i++) { var ph = Math.max(1, pk[i] * (hh - 16) / 2); x.fillRect(i / n * w, mid - ph, Math.max(1, w / n - .3), ph * 2); }
    x.fillStyle = 'rgba(178,54,94,.6)';
    cuts.forEach(function (c) { x.fillRect(X(c[0]), 0, Math.max(1, X(c[1]) - X(c[0])), hh); });
    if (ui.playT !== undefined) { x.fillStyle = '#f0b860'; x.fillRect(X(ui.playT) - 1, 0, 2, hh); }
    var rem = cuts.reduce(function (s, c) { return s + c[1] - c[0]; }, 0), tot = t1 - t0;
    ui.stats.innerHTML = '';
    [[cuts.length, 'قطع'], [rem.toFixed(1) + 'ث', 'هيتشال'], [K.mmss(tot), 'قبل'], [K.mmss(tot - rem), 'بعد']].forEach(function (s) {
      ui.stats.appendChild(h('div', { class: 'kpi' }, [h('b', { text: String(s[0]) }), h('span', { text: s[1] })]));
    });
    ui.mapWrap.classList.remove('hide');
    ui.apply.disabled = !cuts.length;
  }
  function replan() { save(); plan(); drawMap(); }
  function revad() { if (!A || !A.mix) { save(); return; } var v = SeqAudio.vad(A.mix, vadOpts()); A.speech = v.speech; A.thr = v.thr; replan(); thrNote(); }
  function vadOpts() { return { threshold: P.auto ? 'auto' : P.noise, sens: P.sens, minSil: .2, minSpeech: .1 }; }
  function thrNote() { if (A && ui.thr) ui.thr.textContent = 'حد السكوت المستخدم: ' + Math.round(A.thr) + ' dB'; }

  function fillTracks(tracks) {
    var cur = P.track; ui.trackSel.innerHTML = '';
    ui.trackSel.appendChild(h('option', { value: 'all', text: 'كل تراكات الصوت (غير المكتومة)' }));
    (tracks || []).forEach(function (t) { ui.trackSel.appendChild(h('option', { value: String(t.i), text: 'A' + (t.i + 1) + (t.name && t.name !== 'A' + (t.i + 1) ? ' · ' + t.name : '') + (t.n ? '' : ' (فاضي)') + (t.muted ? ' (مكتوم)' : '') })); });
    ui.trackSel.value = [].some.call(ui.trackSel.options, function (o) { return o.value === String(cur); }) ? String(cur) : 'all';
  }

  function analyze() {
    if (busy) return; busy = true;
    ui.status.show('busy', 'بسمع…'); ui.apply.disabled = true; ui.prog.set(0);
    SeqAudio.collect({ range: P.range, tracks: P.track === 'all' ? [] : [+P.track] }).then(function (c) {
      fillTracks(c.info.tracks);
      if (!c.clips.length) throw new Error('مفيش صوت في الجزء ده — شوف «صوت الكلام».');
      ui.status.show('busy', 'بسمع ' + (c.range === 'sel' ? 'الكليبات المختارة' : c.range === 'inout' ? 'ما بين الـ In والـ Out' : 'السيكوينس كله') + '…');
      return SeqAudio.mix(c, 8000, function (p) { ui.prog.set(p); }).then(function (m) {
        var v = SeqAudio.vad(m, vadOpts());
        A = { mix: m, t0: c.t0, t1: c.t1, fps: c.info.fps, speech: v.speech, peaks: v.peaks, thr: v.thr, seqId: c.info.id, seqName: c.info.name, range: c.range };
        ui.playT = c.info.t; plan(); drawMap(); thrNote();
        ui.status.show(cuts.length ? 'ok' : 'warn', cuts.length ? 'لقيت ' + cuts.length + ' سكتة. بص على الخريطة وبعدين «اعمل الفيرست كت».' : 'مفيش سكتات بالإعدادات دي — جرّب «حساسية» أعلى أو «أقصر سكتة» أقل.');
      });
    }).catch(function (e) { ui.status.show('err', SeqAudio.errText(e)); }).then(function () { busy = false; ui.prog.done(); });
  }

  /* ---------- the new sequence as FCP XML ---------- */
  function esc(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
  function pathUrl(p) {
    var s = String(p).replace(/\\/g, '/'), parts = s.split('/');
    var enc = parts.map(function (seg, i) { if (i === 0 && /^[A-Za-z]:$/.test(seg)) return seg[0] + '%3a'; return encodeURIComponent(seg).replace(/%2F/gi, '/'); });
    var j = enc.join('/'); if (j[0] !== '/') j = '/' + j;
    return 'file://localhost' + j;
  }
  function rate(fps) { var tb = Math.round(fps), ntsc = Math.abs(fps - tb) > .01; return { tb: tb, ntsc: ntsc, xml: '<rate><timebase>' + tb + '</timebase><ntsc>' + (ntsc ? 'TRUE' : 'FALSE') + '</ntsc></rate>' }; }
  function probeAll(paths) {
    var out = {}, i = 0;
    function next() {
      if (i >= paths.length) return Promise.resolve(out);
      var p = paths[i++];
      return Sys.run(['-hide_banner', '-i', p], { timeout: 30000 }).then(function (r) {
        var t = r.err + r.out, v = /Stream #\d+:\d+[^\n]*?: Video: ([^\n]*)/.exec(t), wh = v ? /\b(\d{2,5})x(\d{2,5})\b/.exec(v[1]) : null;
        var d = /Duration: (\d+):(\d+):(\d+(?:\.\d+)?)/.exec(t), dur = d ? (+d[1]) * 3600 + (+d[2]) * 60 + parseFloat(d[3]) : 0;
        var auds = t.match(/Stream #\d+:\d+[^\n]*?: Audio: [^\n]*/g) || [], ch = 0;
        auds.forEach(function (a) { ch += /stereo/.test(a) ? 2 : /mono/.test(a) ? 1 : (/(\d+) channels/.exec(a) ? +/(\d+) channels/.exec(a)[1] : /5\.1/.test(a) ? 6 : 2); });
        var still = /\.(png|jpe?g|webp|gif|bmp|tiff?|psd|tga)$/i.test(p) || (v && !(dur > .2));
        out[p] = { video: !!v, w: wh ? +wh[1] : 0, h: wh ? +wh[2] : 0, dur: dur, ch: ch, still: still };
      }, function () { out[p] = { video: false, w: 0, h: 0, dur: 0, ch: 2 }; }).then(next);
    }
    return next();
  }
  /* keep = [0,end] minus cuts; map(t) = t minus all cut time before t */
  function keepRanges(end) {
    var k = [], last = 0;
    cuts.forEach(function (c) { if (c[0] > last) k.push([last, c[0]]); last = Math.max(last, c[1]); });
    if (end > last) k.push([last, end]);
    return k;
  }
  function mapT(t) { var sh = 0; cuts.forEach(function (c) { if (c[1] <= t + 1e-6) sh += c[1] - c[0]; else if (c[0] < t) sh += t - c[0]; }); return t - sh; }
  function buildXml(D, media, name) {
    var R = rate(D.fps), fps = D.fps, F = function (t) { return Math.round(t * fps); };
    var end = 0; D.v.concat(D.a).forEach(function (tr) { tr.clips.forEach(function (c) { if (c.end > end) end = c.end; }); });
    var keep = keepRanges(end), items = [], id = 0, fileIds = {}, fid = 0, speedWarn = 0;
    /* pieces of every clip */
    function cut(type, tr) {
      var list = [];
      tr.clips.forEach(function (c) {
        if (Math.abs(c.speed - 1) > .01) speedWarn++;
        var pcs = [];
        keep.forEach(function (k) {
          var a = Math.max(k[0], c.start), b = Math.min(k[1], c.end);
          if (b - a < .5 / fps) return;
          var s0 = F(mapT(a)), s1 = F(mapT(b)); if (s1 <= s0) return;
          var inF = F(c.inPoint + (a - c.start));
          pcs.push({ type: type, track: tr.i, src: c, start: s0, end: s1, inF: inF, outF: inF + (s1 - s0), id: 'clipitem-' + (++id) });
        });
        list = list.concat(pcs);
      });
      return list;
    }
    var vt = D.v.map(function (tr) { return { tr: tr, items: cut('v', tr) }; }), at = D.a.map(function (tr) { return { tr: tr, items: cut('a', tr) }; });
    /* links: same source clip time + same new start = one linked group */
    var groups = {};
    vt.concat(at).forEach(function (T) { T.items.forEach(function (it, k) { it.clipIndex = k + 1; var key = it.src.path + '|' + F(it.src.start - it.src.inPoint) + '|' + it.start; (groups[key] = groups[key] || []).push(it); it.key = key; }); });
    Object.keys(groups).forEach(function (k) { var g = groups[k], ai = 0; g.sort(function (x, y) { return (x.type === 'v' ? 0 : 1) - (y.type === 'v' ? 0 : 1) || x.track - y.track; }); g.forEach(function (it) { if (it.type === 'a') it.srcTrack = ++ai; }); });
    function fileXml(p) {
      if (fileIds[p]) return '<file id="' + fileIds[p] + '"/>';
      var m = media[p] || { video: true, ch: 2, dur: 0 }, fidS = 'file-' + (++fid); fileIds[p] = fidS;
      var durF = m.still ? 108000 : Math.max(1, F(m.dur || 0));
      var md = '';
      if (m.video) md += '<video><samplecharacteristics>' + R.xml + '<width>' + (m.w || D.w) + '</width><height>' + (m.h || D.h) + '</height><anamorphic>FALSE</anamorphic><pixelaspectratio>square</pixelaspectratio><fielddominance>none</fielddominance></samplecharacteristics></video>';
      if (m.ch > 0) md += '<audio><samplecharacteristics><depth>16</depth><samplerate>' + (D.sr || 48000) + '</samplerate></samplecharacteristics><channelcount>' + m.ch + '</channelcount></audio>';
      return '<file id="' + fidS + '"><name>' + esc(p.split(/[\\\/]/).pop()) + '</name><pathurl>' + esc(pathUrl(p)) + '</pathurl>' + R.xml + '<duration>' + durF + '</duration>' +
        '<timecode>' + R.xml + '<string>00:00:00:00</string><frame>0</frame><displayformat>NDF</displayformat></timecode><media>' + md + '</media></file>';
    }
    function clipXml(it) {
      var m = media[it.src.path] || {}, durF = m.still ? 108000 : Math.max(it.outF, F(m.dur || 0));
      var x = '<clipitem id="' + it.id + '"><name>' + esc(it.src.name || '') + '</name><enabled>' + (it.src.on === false ? 'FALSE' : 'TRUE') + '</enabled><duration>' + durF + '</duration>' + R.xml +
        '<start>' + it.start + '</start><end>' + it.end + '</end><in>' + it.inF + '</in><out>' + it.outF + '</out>' + fileXml(it.src.path);
      if (it.type === 'a') x += '<sourcetrack><mediatype>audio</mediatype><trackindex>' + (it.srcTrack || 1) + '</trackindex></sourcetrack>';
      var g = groups[it.key];
      if (g && g.length > 1) g.forEach(function (o) {
        x += '<link><linkclipref>' + o.id + '</linkclipref><mediatype>' + (o.type === 'v' ? 'video' : 'audio') + '</mediatype><trackindex>' + (o.track + 1) + '</trackindex><clipindex>' + o.clipIndex + '</clipindex>' + (o.type === 'a' ? '<groupindex>1</groupindex>' : '') + '</link>';
      });
      return x + '</clipitem>';
    }
    var total = 0; vt.concat(at).forEach(function (T) { T.items.forEach(function (it) { if (it.end > total) total = it.end; }); });
    var xml = '<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE xmeml>\n<xmeml version="4"><sequence id="sequence-1"><name>' + esc(name) + '</name><duration>' + total + '</duration>' + R.xml +
      '<timecode>' + R.xml + '<string>00:00:00:00</string><frame>0</frame><displayformat>NDF</displayformat></timecode><media>' +
      '<video><format><samplecharacteristics>' + R.xml + '<width>' + D.w + '</width><height>' + D.h + '</height><anamorphic>FALSE</anamorphic><pixelaspectratio>square</pixelaspectratio><fielddominance>none</fielddominance></samplecharacteristics></format>' +
      vt.map(function (T) { return '<track>' + T.items.map(clipXml).join('') + '<enabled>TRUE</enabled><locked>FALSE</locked></track>'; }).join('') + '</video>' +
      '<audio><numOutputChannels>2</numOutputChannels><format><samplecharacteristics><depth>16</depth><samplerate>' + (D.sr || 48000) + '</samplerate></samplecharacteristics></format>' +
      at.map(function (T, k) { return '<track>' + T.items.map(clipXml).join('') + '<enabled>TRUE</enabled><locked>FALSE</locked><outputchannelindex>' + (k % 2 + 1) + '</outputchannelindex></track>'; }).join('') + '</audio>' +
      '</media></sequence></xmeml>\n';
    /* which new pieces came from which old clip (to copy Motion, Opacity, Volume, effects) */
    var map = {};
    vt.concat(at).forEach(function (T) { T.items.forEach(function (it) { var k = it.type + it.track + '|' + it.src.id + '|' + it.src.start; if (!map[k]) map[k] = { type: it.type, track: it.track, id: it.src.id, srcStart: it.src.start, pieces: [] }; map[k].pieces.push(it.start / fps); }); });
    return { xml: xml, map: Object.keys(map).map(function (k) { return map[k]; }), speedWarn: speedWarn, pieces: id, newDur: total / fps };
  }

  function apply() {
    if (!cuts.length || busy) return;
    busy = true; ui.apply.disabled = true; ui.prog.set(0);
    var list = cuts.slice();
    if (P.mode === 'markers') {
      Sys.call('cr_cutMarkers', { cuts: list }).then(function (r) { if (!r || !r.ok) throw new Error('حصلت مشكلة'); ui.status.show('ok', 'اتحط ' + r.done + ' ماركر على السكتات.'); })
        .catch(function (e) { ui.status.show('err', e.message || String(e)); }).then(function () { busy = false; ui.apply.disabled = false; ui.prog.done(); });
      return;
    }
    var D = null, built = null;
    ui.status.show('busy', 'بقرا السيكوينس…');
    Sys.call('cr_seqDump').then(function (r) {
      if (!r || !r.ok) throw new Error('افتح السيكوينس اللي سمعته.');
      if (A.seqId && r.id !== A.seqId) throw new Error('السيكوينس المفتوح مش اللي سمعته — افتحه أو اسمع تاني.');
      D = r;
      var paths = {}; D.v.concat(D.a).forEach(function (tr) { tr.clips.forEach(function (c) { paths[c.path] = 1; }); });
      ui.status.show('busy', 'بجهّز الميديا…'); ui.prog.set(.15);
      return probeAll(Object.keys(paths));
    }).then(function (media) {
      var name = D.name + ' - ENP First Cut';
      built = buildXml(D, media, name);
      var dir = Sys.join(Sys.workDir(), 'firstcut'); Sys.mkdirp(dir);
      var f = Sys.join(dir, 'ENP_FirstCut_' + Date.now() + '.xml');
      Sys.req('fs').writeFileSync(f, built.xml, 'utf8');
      ui.status.show('busy', 'ببني السيكوينس الجديد…'); ui.prog.set(.4);
      return Sys.call('cr_importXml', { path: f, name: name });
    }).then(function (r) {
      if (!r || !r.ok) throw new Error('بريمير مقدرش يفتح السيكوينس الجديد [' + (r && (r.error || r.detail)) + ']');
      ui.prog.set(.7); ui.status.show('busy', 'بنقل الحجم والمكان والصوت لكل جزء…');
      return K.chunks(built.map, 8, function (part) { return Sys.call('cr_copyParams', { src: D.id, dst: r.id, map: part, effects: P.effects }); }, function (p) { ui.prog.set(.7 + p * .3); })
        .then(function () { return r; });
    }).then(function (r) {
      var rem = list.reduce(function (s, c) { return s + c[1] - c[0]; }, 0);
      var notes = [];
      if (D.skipped) notes.push(D.skipped + ' عنصر من غير ميديا (عناوين/جرافيك/نِست) ماتنقلش');
      if (built.speedWarn) notes.push(built.speedWarn + ' كليب عليه سرعة متغيرة اتحط بسرعته العادية');
      ui.status.show(notes.length ? 'warn' : 'ok', 'تمام ✓ اتعمل سيكوينس جديد «' + r.name + '» واتشال ' + list.length + ' سكتة (' + rem.toFixed(1) + ' ثانية). الأصلي زي ما هو.' + (notes.length ? ' · ' + notes.join(' · ') : ''));
    }).catch(function (e) { ui.status.show('err', e.message || String(e)); })
      .then(function () { busy = false; ui.apply.disabled = false; ui.prog.done(); });
  }

  function sl(k, label, min, max, step, fmt, onCh) { return K.slider({ label: label, min: min, max: max, step: step, value: P[k], fmt: fmt, onInput: function (v) { P[k] = v; (onCh || save)(); } }); }
  function sec(v) { return (+v).toFixed(2) + ' ث'; }
  function build(root) {
    ui.status = K.status(); ui.prog = K.progress();
    ui.map = h('canvas', { class: 'cmap' });
    ui.map.addEventListener('click', function (e) {
      if (!A) return; var r = ui.map.getBoundingClientRect(); ui.playT = A.t0 + (e.clientX - r.left) / r.width * (A.t1 - A.t0); drawMap(); Sys.call('cr_seek', { t: ui.playT });
    });
    ui.stats = h('div', { class: 'kpis' }); ui.thr = h('div', { class: 'hint' });
    ui.mapWrap = h('div', { class: 'sec hide' }, [h('div', { class: 'sb', style: 'padding-top:10px' }, [h('div', { style: 'font-weight:600', text: 'خريطة السكتات' }),
      h('div', { class: 'hint', text: 'الأبيض صوت، والبيرجاندي اللي هيتشال. دوس في أي مكان عشان المؤشر يروحله.' }), ui.map, ui.stats, ui.thr])]);
    ui.apply = K.btn('اعمل الفيرست كت', { cls: 'pri', icon: 'spark', onClick: apply }); ui.apply.disabled = true;
    ui.trackSel = h('select', { class: 'sel' }); ui.trackSel.addEventListener('change', function () { P.track = ui.trackSel.value; save(); }); fillTracks([]);
    var manual = sl('noise', 'السكوت أقل من', -60, -20, 1, function (v) { return v + ' dB'; }, revad);
    var sens = sl('sens', 'الحساسية (أعلى = بيقص أكتر)', 0, 1, .05, function (v) { return Math.round(v * 100) + '%'; }, revad);
    function showThr() { K.show(manual, !P.auto); K.show(sens, P.auto); }
    [h('div', { class: 'hint intro', text: 'زي الـ First Cut: بيسمع الكلام، ويعمل سيكوينس جديد من غير السكتات والفراغات، وكل التراكات (فيديو وصوت) ملزوقة في بعض ومتزامنة. السيكوينس الأصلي مابيتلمسش.' }),
      h('div', { class: 'out' }, [
        K.field('الجزء', K.seg({ items: [{ v: 'auto', label: 'المختار أو In/Out' }, { v: 'all', label: 'السيكوينس كله' }], value: P.range, onChange: function (v) { P.range = v; save(); } })),
        K.field('صوت الكلام', ui.trackSel),
        h('div', { style: 'margin-top:8px' }, [K.btn('اسمع وطلّع السكتات', { cls: 'pri', icon: 'target', onClick: analyze })])]),
      ui.mapWrap,
      K.section('الإعدادات', [
        K.toggle('حد السكوت تلقائي (بيتظبط على صوتك)', P.auto, function (v) { P.auto = v; showThr(); revad(); }), sens, manual,
        sl('minSil', 'أقصر سكتة تتشال', .15, 2, .05, sec, replan),
        sl('padA', 'سيب بعد الكلام', 0, .5, .01, sec, replan),
        sl('padB', 'سيب قبل الكلام', 0, .5, .01, sec, replan),
        K.toggle('شيل السكوت في الأول والآخر', P.edges, function (v) { P.edges = v; replan(); }),
        h('div', { class: 'hint', style: 'margin-top:6px', text: 'كل الإعدادات بتتحدّث على الخريطة على طول، من غير ما تسمع تاني.' })
      ], true, 'cut_set'),
      h('div', { class: 'out' }, [
        K.field('الناتج', K.seg({ items: [{ v: 'seq', label: 'سيكوينس جديد مقصوص' }, { v: 'markers', label: 'ماركرز بس' }], value: P.mode, onChange: function (v) { P.mode = v; save(); } })),
        K.toggle('انقل الإيفيكتات اللي على الكليبات كمان', P.effects, function (v) { P.effects = v; save(); }),
        h('div', { style: 'margin-top:10px' }, [ui.apply]), ui.prog, ui.status])
    ].forEach(function (el) { root.appendChild(el); });
    showThr();
    Sys.call('cr_audioClips').then(function (r) { if (r && r.ok) fillTracks(r.tracks); });
    G.addEventListener('resize', function () { if (A) drawMap(); });
  }
  G.CutTab = { build: build, onShow: function () { if (ui.trackSel) Sys.call('cr_audioClips').then(function (r) { if (r && r.ok) fillTracks(r.tracks); }); },
    _plan: function (a, p) { A = a; for (var k in (p || {})) P[k] = p[k]; plan(); return cuts; }, _xml: function (D, media, name, c) { cuts = c; return buildXml(D, media, name); } };
})(window);
