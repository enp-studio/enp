/* ENP — smart cut: finds the silences in the talking and removes them. */
(function (G) {
  'use strict';
  var K = G.K, h = K.h, st = K.store('enp_cut_');
  var DEF = { noise: -38, minSil: .45, padA: .08, padB: .12, edges: true, clone: true, mode: 'cut' };
  var P = (function () { var o = {}, s = st.get('set', {}), k; for (k in DEF) o[k] = DEF[k]; for (k in s) o[k] = s[k]; return o; })();
  var A = null, cuts = [], ui = {};
  function save() { st.set('set', P); }

  /* silences -> cuts (sequence seconds, on frames) */
  function plan() {
    cuts = [];
    if (!A) return;
    var fr = 1 / (A.fps || 30), snap = function (t) { return Math.round(t / fr) * fr; };
    A.clips.forEach(function (cl) {
      var c = cl.info, sil = [], last = c.start;
      cl.speech.forEach(function (s) { if (s.a > last + .005) sil.push([last, s.a]); last = Math.max(last, s.b); });
      if (last < c.end - .005) sil.push([last, c.end]);
      sil.forEach(function (s) {
        var atStart = Math.abs(s[0] - c.start) < .01, atEnd = Math.abs(s[1] - c.end) < .01;
        if ((atStart || atEnd) && !P.edges) return;
        var a = atStart ? s[0] : s[0] + P.padA, b = atEnd ? s[1] : s[1] - P.padB;
        a = snap(a); b = snap(b);
        if (b - a >= Math.max(P.minSil - P.padA - P.padB, fr * 2) && (s[1] - s[0]) >= P.minSil) cuts.push([a, b]);
      });
    });
    cuts.sort(function (x, y) { return x[0] - y[0]; });
  }
  function drawMap() {
    var cv = ui.map, w = cv.clientWidth || 300, hh = 110, dpr = Math.min(2, G.devicePixelRatio || 1);
    cv.width = Math.round(w * dpr); cv.height = Math.round(hh * dpr);
    var x = cv.getContext('2d'); x.setTransform(dpr, 0, 0, dpr, 0, 0); x.clearRect(0, 0, w, hh);
    if (!A) return;
    var t0 = A.t0, t1 = A.t1, X = function (t) { return (t - t0) / Math.max(.01, t1 - t0) * w; }, mid = hh / 2;
    A.clips.forEach(function (cl) {
      var pk = cl.peaks || [], a = X(cl.info.start), b = X(cl.info.end), n = pk.length;
      x.fillStyle = 'rgba(244,235,239,.55)';
      for (var i = 0; i < n; i++) { var px = a + (b - a) * i / n, ph = Math.max(1, pk[i] * (hh - 16) / 2); x.fillRect(px, mid - ph, Math.max(1, (b - a) / n - .3), ph * 2); }
    });
    x.fillStyle = 'rgba(178,54,94,.55)';
    cuts.forEach(function (c) { x.fillRect(X(c[0]), 0, Math.max(1, X(c[1]) - X(c[0])), hh); });
    if (ui.playT !== undefined) { x.fillStyle = '#f0b860'; x.fillRect(X(ui.playT) - 1, 0, 2, hh); }
    var rem = cuts.reduce(function (s, c) { return s + c[1] - c[0]; }, 0), tot = A.clips.reduce(function (s, c) { return s + c.info.end - c.info.start; }, 0);
    ui.stats.innerHTML = '';
    [[cuts.length, 'قطع'], [rem.toFixed(1) + 'ث', 'هيتشال'], [K.mmss(tot), 'قبل'], [K.mmss(tot - rem), 'بعد']].forEach(function (s) {
      ui.stats.appendChild(h('div', { class: 'kpi' }, [h('b', { text: String(s[0]) }), h('span', { text: s[1] })]));
    });
    ui.mapWrap.classList.remove('hide');
    ui.apply.disabled = !cuts.length;
  }
  function replan() { save(); plan(); drawMap(); }

  function analyze() {
    ui.status.show('busy', 'بسمع…'); ui.apply.disabled = true;
    Sys.call('cr_clips').then(function (r) {
      if (!r || !r.ok) throw new Error(r && r.error === 'no_sequence' ? 'افتح سيكوينس الأول.' : 'حصلت مشكلة');
      if (!r.clips.length) throw new Error('اختار الكليب اللي فيه الكلام (أو سيب المؤشر عليه).');
      var res = { clips: [], fps: r.fps };
      return r.clips.reduce(function (pr, c) {
        return pr.then(function () {
          ui.status.show('busy', 'بسمع «' + c.name + '»…');
          var dur = c.end - c.start;
          return Sys.silences(c.path, c.inPoint, dur, P.noise, Math.max(.1, Math.min(P.minSil, .3))).then(function (sp) {
            return Sys.peaksRange(c.path, c.inPoint, dur, Math.min(1500, Math.max(200, Math.round(dur * 8)))).catch(function () { return []; }).then(function (pk) {
              res.clips.push({ info: c, peaks: pk, speech: sp.map(function (s) { return { a: c.start + s.a, b: c.start + s.b }; }) });
            });
          }, function (e) { if (e.message === 'no_audio') throw new Error('«' + c.name + '» مالوش صوت — اختار الكليب اللي فيه الكلام.'); throw e; });
        });
      }, Promise.resolve()).then(function () {
        res.t0 = Math.min.apply(null, res.clips.map(function (c) { return c.info.start; }));
        res.t1 = Math.max.apply(null, res.clips.map(function (c) { return c.info.end; }));
        A = res; ui.playT = r.t; plan(); drawMap();
        ui.status.show(cuts.length ? 'ok' : 'warn', cuts.length ? 'لقيت ' + cuts.length + ' سكتة. بص على الخريطة وبعدين «اقطع».' : 'مفيش سكتات بالإعدادات دي — جرّب ترفع «السكوت أقل من».');
      });
    }).catch(function (e) { ui.status.show('err', e.message || String(e)); });
  }
  function apply() {
    if (!cuts.length) return;
    ui.apply.disabled = true; ui.prog.set(0);
    var list = cuts.slice();
    var step0 = P.mode === 'markers' ? Promise.resolve() : (P.clone ? Sys.call('cr_clone').then(function (r) { if (!r || !r.ok) throw new Error('مقدرتش أعمل نسخة احتياطي من السيكوينس — اقفل «نسخة احتياطي» لو عايز تكمل.'); ui.backup = r.name; }) : Promise.resolve());
    step0.then(function () {
      if (P.mode === 'markers') return Sys.call('cr_cutMarkers', { cuts: list }).then(function (r) { if (!r || !r.ok) throw new Error('حصلت مشكلة'); ui.status.show('ok', 'اتحط ' + r.done + ' ماركر على السكتات.'); });
      var done = 0;
      return K.chunks(list, 6, function (part) {
        return Sys.call('cr_cutRazor', { cuts: part }).then(function (r) {
          if (!r || !r.ok) throw new Error('القص وقف [' + (r && (r.error || r.detail)) + ']');
          done += part.length; ui.prog.set(done / list.length * .6); ui.status.show('busy', 'بقص… ' + done + '/' + list.length);
        });
      }).then(function () {
        ui.status.show('busy', 'بلم الفراغات…'); ui.prog.set(.7);
        return Sys.call('cr_cutCompact', { cuts: list });
      }).then(function (r) {
        var rem = list.reduce(function (s, c) { return s + c[1] - c[0]; }, 0);
        if (!r || !r.ok) {
          ui.status.show('warn', 'السكتات اتشالت بس فضلت مكانها فراغات (بريمير ماسمحش بالتحريك). اعمل عليها Ripple Delete أو Close Gap.' + (ui.backup ? ' النسخة الأصلية: «' + ui.backup + '».' : ''));
          return;
        }
        ui.status.show('ok', 'تمام — اتشال ' + list.length + ' سكتة (' + rem.toFixed(1) + ' ثانية).' + (ui.backup ? ' النسخة الأصلية محفوظة باسم «' + ui.backup + '».' : ''));
      });
    }).catch(function (e) { ui.status.show('err', e.message || String(e)); })
      .then(function () { ui.prog.done(); A = null; cuts = []; ui.mapWrap.classList.add('hide'); });
  }

  function sl(k, label, min, max, step, fmt, live) { return K.slider({ label: label, min: min, max: max, step: step, value: P[k], fmt: fmt, onInput: function (v) { P[k] = v; if (live) replan(); else save(); } }); }
  function sec(v) { return (+v).toFixed(2) + ' ث'; }
  function build(root) {
    ui.status = K.status(); ui.prog = K.progress();
    ui.map = h('canvas', { class: 'cmap' });
    ui.map.addEventListener('click', function (e) {
      if (!A) return; var r = ui.map.getBoundingClientRect(); ui.playT = A.t0 + (e.clientX - r.left) / r.width * (A.t1 - A.t0); drawMap(); Sys.call('cr_seek', { t: ui.playT });
    });
    ui.stats = h('div', { class: 'kpis' });
    ui.mapWrap = h('div', { class: 'sec hide' }, [h('div', { class: 'sb', style: 'padding-top:10px' }, [h('div', { style: 'font-weight:600', text: 'خريطة السكتات' }),
      h('div', { class: 'hint', text: 'الأبيض صوت، والبيرجاندي اللي هيتقص. دوس في أي مكان عشان المؤشر يروحله.' }), ui.map, ui.stats])]);
    ui.apply = K.btn('اقطع السكتات', { cls: 'pri', icon: 'spark', onClick: apply }); ui.apply.disabled = true;
    [h('div', { class: 'hint intro', text: 'بيسمع الكلام ويشيل السكتات والفراغات لوحده، وبيحرّك كل التراكات مع بعض عشان مفيش حاجة تخرج عن المزامنة.' }),
      h('div', { class: 'out' }, [h('div', { class: 'hint', text: 'اختار الكليب اللي فيه الكلام في التايملاين (أو سيب المؤشر عليه) ودوس «اسمع».' }),
        h('div', { style: 'margin-top:8px' }, [K.btn('اسمع وطلّع السكتات', { cls: 'pri', icon: 'target', onClick: analyze })])]),
      ui.mapWrap,
      K.section('الإعدادات', [
        sl('noise', 'السكوت أقل من', -60, -20, 1, function (v) { return v + ' dB'; }),
        sl('minSil', 'أقصر سكتة تتقص', .2, 2, .05, sec, true),
        sl('padA', 'سيب بعد الكلام', 0, .5, .01, sec, true),
        sl('padB', 'سيب قبل الكلام', 0, .5, .01, sec, true),
        K.toggle('شيل السكوت في أول وآخر الكليب', P.edges, function (v) { P.edges = v; replan(); }),
        h('div', { class: 'hint', style: 'margin-top:6px', text: 'لو غيّرت «السكوت أقل من» اسمع تاني. الباقي بيتحدّث على الخريطة على طول.' })
      ], true, 'cut_set'),
      h('div', { class: 'out' }, [
        K.field('الناتج', K.seg({ items: [{ v: 'cut', label: 'اقطع فعلًا' }, { v: 'markers', label: 'ماركرز بس' }], value: P.mode, onChange: function (v) { P.mode = v; save(); } })),
        K.toggle('اعمل نسخة احتياطي من السيكوينس الأول', P.clone, function (v) { P.clone = v; save(); }),
        h('div', { style: 'margin-top:10px' }, [ui.apply]), ui.prog, ui.status])
    ].forEach(function (el) { root.appendChild(el); });
    G.addEventListener('resize', function () { if (A) drawMap(); });
  }
  G.CutTab = { build: build, _plan: function (a, p) { A = a; for (var k in (p || {})) P[k] = p[k]; plan(); return cuts; } };
})(window);
