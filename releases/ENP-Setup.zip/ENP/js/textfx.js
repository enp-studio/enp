/* Amar Studio — animated text engine (canvas 2D).
   Arabic keeps its letters joined: a piece (letter / word) is always drawn
   from the whole shaped line, clipped to that piece's slice. */
(function (G) {
  'use strict';
  var PI = Math.PI;
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function lerp(a, b, k) { return a + (b - a) * k; }
  var E = {
    lin: function (x) { return clamp(x, 0, 1); },
    out: function (x) { x = clamp(x, 0, 1); return 1 - Math.pow(1 - x, 3); },
    out5: function (x) { x = clamp(x, 0, 1); return 1 - Math.pow(1 - x, 5); },
    inOut: function (x) { x = clamp(x, 0, 1); return x < .5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2; },
    expo: function (x) { x = clamp(x, 0, 1); return x >= 1 ? 1 : 1 - Math.pow(2, -10 * x); },
    back: function (x) { x = clamp(x, 0, 1); var c = 1.9; return 1 + (c + 1) * Math.pow(x - 1, 3) + c * Math.pow(x - 1, 2); },
    elastic: function (x) { x = clamp(x, 0, 1); if (x === 0 || x === 1) return x; return Math.pow(2, -10 * x) * Math.sin((x * 10 - .75) * (2 * PI / 3)) + 1; },
    bounce: function (x) {
      x = clamp(x, 0, 1); var n = 7.5625, d = 2.75;
      if (x < 1 / d) return n * x * x; if (x < 2 / d) { x -= 1.5 / d; return n * x * x + .75; }
      if (x < 2.5 / d) { x -= 2.25 / d; return n * x * x + .9375; } x -= 2.625 / d; return n * x * x + .984375;
    }
  };
  function rnd(i, k) { var x = Math.sin((i + 1) * 12.9898 + (k || 0) * 78.233) * 43758.5453; return x - Math.floor(x); }
  var AR = /[֐-ࣿיִ-﷿ﹰ-﻿]/;
  var MARK = /[ً-ٰٟۖ-ۭؐ-ؚ‌‍]/;

  /* ---------- presets ----------
     unit: line | word | char;  f(p, i, n) -> props for in-progress p (0..1)
     props: o (opacity), dx, dy (em), s, sx, sy, r (deg), blur (em), skx (deg), mask (clip stays put), reveal (0..1 wipe)
     loop(t, i, n): continuous extras while on screen; special: draw hooks */
  function P(id, name, unit, f, extra) { var o = { id: id, name: name, unit: unit, f: f }; for (var k in (extra || {})) o[k] = extra[k]; return o; }
  var PRESETS = [
    P('fade', 'ظهور هادي', 'line', function (p) { return { o: E.out(p) }; }),
    P('fade_w', 'كلمة كلمة', 'word', function (p) { return { o: E.out(p) }; }),
    P('fade_c', 'حرف حرف', 'char', function (p) { return { o: E.out(p) }; }),
    P('rise', 'طالع من تحت', 'line', function (p) { var e = E.out5(p); return { o: e, dy: (1 - e) * .6 }; }),
    P('rise_w', 'كلمات طالعة', 'word', function (p) { var e = E.out5(p); return { o: e, dy: (1 - e) * .7 }; }),
    P('rise_c', 'حروف طالعة', 'char', function (p) { var e = E.out5(p); return { o: e, dy: (1 - e) * .8 }; }),
    P('drop_w', 'نازل من فوق', 'word', function (p) { var e = E.bounce(p); return { o: clamp(p * 3, 0, 1), dy: -(1 - e) * 1.4 }; }),
    P('slide_r', 'داخل من اليمين', 'line', function (p) { var e = E.expo(p); return { o: clamp(p * 2, 0, 1), dx: (1 - e) * 3 }; }),
    P('slide_l', 'داخل من الشمال', 'line', function (p) { var e = E.expo(p); return { o: clamp(p * 2, 0, 1), dx: -(1 - e) * 3 }; }),
    P('slide_w', 'كلمات منزلقة', 'word', function (p) { var e = E.out5(p); return { o: e, dx: (1 - e) * 1.2 }; }),
    P('pop_w', 'كلمات بتنط', 'word', function (p) { return { o: clamp(p * 4, 0, 1), s: E.back(p) }; }),
    P('pop_c', 'حروف بتنط', 'char', function (p) { return { o: clamp(p * 4, 0, 1), s: E.back(p) }; }),
    P('zoom_in', 'زووم من قريب', 'line', function (p) { var e = E.out5(p); return { o: e, s: lerp(2.2, 1, e), blur: (1 - e) * .25 }; }),
    P('zoom_out', 'زووم من بعيد', 'line', function (p) { var e = E.back(p); return { o: clamp(p * 3, 0, 1), s: lerp(.2, 1, e) }; }),
    P('blur_w', 'بلور كلمات', 'word', function (p) { var e = E.out(p); return { o: e, blur: (1 - e) * .35, s: lerp(1.15, 1, e) }; }),
    P('blur_c', 'بلور حروف', 'char', function (p) { var e = E.out(p); return { o: e, blur: (1 - e) * .3, dy: (1 - e) * .15 }; }),
    P('apple', 'ستايل أبل', 'word', function (p) { var e = E.out5(p); return { o: e, blur: (1 - e) * .22, dy: (1 - e) * .35, s: lerp(.96, 1, e) }; }),
    P('type', 'آلة كاتبة', 'char', function (p) { return { o: p > 0 ? 1 : 0 }; }, { cursor: true, pd: .02 }),
    P('wipe', 'مسح', 'line', function (p) { return { reveal: E.inOut(p) }; }),
    P('mask_w', 'طالع من خط', 'word', function (p) { var e = E.out5(p); return { mask: true, dy: (1 - e) * 1.1 }; }),
    P('mask_c', 'حروف من خط', 'char', function (p) { var e = E.out5(p); return { mask: true, dy: (1 - e) * 1.1 }; }),
    P('mask_down', 'نازل من خط', 'word', function (p) { var e = E.out5(p); return { mask: true, dy: -(1 - e) * 1.1 }; }),
    P('flip_x', 'قلب لفوق', 'word', function (p) { var e = E.back(p); return { o: clamp(p * 3, 0, 1), sy: Math.max(.001, e), dy: (1 - e) * .2 }; }),
    P('flip_y', 'قلب جنب', 'char', function (p) { var e = E.out(p); return { o: clamp(p * 3, 0, 1), sx: Math.cos((1 - e) * PI / 2) }; }),
    P('spin_w', 'كلمات بتلف', 'word', function (p) { var e = E.back(p); return { o: clamp(p * 3, 0, 1), r: (1 - e) * -90, s: lerp(.5, 1, e) }; }),
    P('elastic_w', 'مطاطي', 'word', function (p) { var e = E.elastic(p); return { o: clamp(p * 4, 0, 1), s: Math.max(0, e) }; }),
    P('stretch', 'مطّ', 'line', function (p) { var e = E.out5(p); return { o: e, sx: lerp(2.4, 1, e), blur: (1 - e) * .15 }; }),
    P('squash_c', 'حروف بتترج', 'char', function (p) { var e = E.elastic(p); return { o: clamp(p * 4, 0, 1), sy: Math.max(.05, e), dy: (1 - Math.min(1, e)) * .3 }; }),
    P('swing_w', 'مرجيحة', 'word', function (p) { var e = E.elastic(p); return { o: clamp(p * 3, 0, 1), r: (1 - e) * 40, pivot: 'top' }; }),
    P('tilt', 'مايل وداخل', 'line', function (p) { var e = E.out5(p); return { o: e, skx: (1 - e) * -35, dx: (1 - e) * 1.2 }; }),
    P('cascade_c', 'شلال حروف', 'char', function (p) { var e = E.out5(p); return { o: e, dy: -(1 - e) * 1.2, dx: (1 - e) * .5, r: (1 - e) * 25 }; }),
    P('random_c', 'حروف عشوائي', 'char', function (p) { return { o: E.out(p), s: lerp(1.6, 1, E.out(p)) }; }, { order: 'random' }),
    P('center_w', 'من النص للأطراف', 'word', function (p) { var e = E.out5(p); return { o: e, s: lerp(.6, 1, E.back(p)) }; }, { order: 'center' }),
    P('track_in', 'حروف بتتلم', 'char', function (p, i, n) { var e = E.out5(p); return { o: e, dx: (i - (n - 1) / 2) * (1 - e) * -.45 }; }, { order: 'all' }),
    P('roll3d', 'رول ثلاثي الأبعاد', 'word', function (p) { var e = E.out(p); return { o: e, sy: Math.max(.02, Math.sin(e * PI / 2)), dy: (1 - e) * .5, skx: 0 }; }),
    P('split', 'نصين بيتقابلوا', 'line', function (p) { var e = E.expo(p); return { o: e, split: 1 - e }; }),
    P('shutter', 'شيش', 'line', function (p) { return { shutter: E.inOut(p) }; }),
    P('glitch', 'جليتش', 'line', function (p) { var e = E.out(p); return { o: clamp(p * 5, 0, 1), rgb: (1 - e) * .12, jit: (1 - e) * .25 }; }, { loopFx: 'glitch' }),
    P('neon', 'نيون بيرعش', 'line', function (p) { var fl = p < 1 ? (rnd(Math.floor(p * 14)) > .45 ? 1 : .15) : 1; return { o: fl }; }, { glowAuto: true }),
    P('scramble', 'فك شفرة', 'line', function (p) { return { o: 1, scramble: p }; }),
    P('highlight', 'هايلايت ورا الكلمة', 'word', function (p) { var e = E.inOut(p); return { o: clamp(p * 3, 0, 1), hl: e }; }),
    P('underline', 'خط تحت', 'line', function (p) { var e = E.inOut(p); return { o: clamp(p * 2, 0, 1), ul: e }; }),
    P('karaoke', 'كاريوكي', 'word', function (p) { return { o: E.out(p) }; }, { loopFx: 'karaoke' }),
    P('wave', 'موجة', 'char', function (p) { var e = E.out(p); return { o: e, dy: (1 - e) * .4 }; }, { loopFx: 'wave' }),
    P('float', 'عايم', 'word', function (p) { var e = E.out(p); return { o: e, dy: (1 - e) * .3 }; }, { loopFx: 'float' }),
    P('pulse', 'نبض', 'line', function (p) { var e = E.back(p); return { o: clamp(p * 3, 0, 1), s: lerp(.6, 1, e) }; }, { loopFx: 'pulse' }),
    P('shine', 'لمعة', 'line', function (p) { var e = E.out(p); return { o: e }; }, { loopFx: 'shine' }),
    P('shake', 'بيتهز', 'word', function (p) { var e = E.out(p); return { o: e }; }, { loopFx: 'shake' }),
    P('one_word', 'كلمة لوحدها', 'word', function (p) { return { o: 1, s: lerp(1.35, 1, E.back(p)) }; }, { solo: true }),
    P('push', 'كاميرا داخلة', 'line', function (p) { var e = E.out(p); return { o: e, blur: (1 - e) * .12 }; }, { loopFx: 'push' }),
    P('bounce_c', 'حروف بتنطط', 'char', function (p) { var e = E.bounce(p); return { o: clamp(p * 4, 0, 1), dy: -(1 - e) * 1.2 }; }),
    P('stamp', 'ختم', 'line', function (p) { var e = E.out5(p); return { o: clamp(p * 4, 0, 1), s: lerp(3, 1, e), r: (1 - e) * -12 }; }, { shakeOnLand: true })
  ];
  var BY = {}; PRESETS.forEach(function (p) { BY[p.id] = p; });

  var OUTS = {
    mirror: 'عكس الدخول', fade: 'يختفي بهدوء', blur: 'بلور', drop: 'يقع لتحت', rise: 'يطلع لفوق', zoom: 'يصغر', wipe: 'مسح', none: 'من غير'
  };
  function outProps(mode, q) { // q: 1 visible -> 0 gone
    var e = E.out(1 - q);
    switch (mode) {
      case 'fade': return { o: q };
      case 'blur': return { o: q, blur: e * .3, s: lerp(1, 1.1, e) };
      case 'drop': return { o: q, dy: e * e * 1.4 };
      case 'rise': return { o: q, dy: -e * 1 };
      case 'zoom': return { o: q, s: lerp(1, .4, e) };
      case 'wipe': return { reveal: q, revDir: -1 };
      default: return {};
    }
  }

  /* ---------- defaults ---------- */
  var DEF = {
    text: 'اكتب النص هنا', font: 'Arial', weight: 700, size: .065, color: '#ffffff', color2: '#e48aa6', grad: false,
    align: 'center', lineH: 1.25, maxW: .86, x: .5, y: .5,
    stroke: 0, strokeColor: '#000000', shadow: .35, glow: 0, glowColor: '#e48aa6',
    box: false, boxColor: '#000000', boxAlpha: .55, boxPad: .35, boxRadius: .3,
    preset: 'apple', dur: 3, inDur: .9, outDur: .5, outMode: 'mirror', speed: 1, upper: false
  };
  function norm(t) { var o = {}, k; for (k in DEF) o[k] = DEF[k]; for (k in (t || {})) if (t[k] !== undefined && t[k] !== null) o[k] = t[k]; if (!BY[o.preset]) o.preset = 'fade'; return o; }

  /* ---------- layout ---------- */
  function fontStr(T, px) { return T.weight + ' ' + px + 'px "' + T.font + '", "Segoe UI", Tahoma, Arial, sans-serif'; }
  function graphemes(s) {
    var out = [], i = 0;
    var cps = Array.from(s);
    var pos = 0;
    cps.forEach(function (c) {
      if (out.length && MARK.test(c)) { out[out.length - 1].b += c.length; }
      else out.push({ a: pos, b: pos + c.length });
      pos += c.length;
    });
    void i; return out;
  }
  function layout(ctx, T, W, H) {
    var px = Math.max(4, T.size * H), lh = px * T.lineH, maxW = T.maxW * W;
    ctx.font = fontStr(T, px);
    var raw = String(T.text || '').replace(/\r/g, '');
    if (T.upper) raw = raw.toUpperCase();
    var lines = [];
    raw.split('\n').forEach(function (para) {
      var words = para.split(/ +/).filter(function (w) { return w.length; }), cur = '';
      if (!words.length) { lines.push(''); return; }
      words.forEach(function (w) {
        var tryS = cur ? cur + ' ' + w : w;
        if (cur && ctx.measureText(tryS).width > maxW) { lines.push(cur); cur = w; } else cur = tryS;
      });
      lines.push(cur);
    });
    var blockH = lines.length * lh, top = T.y * H - blockH / 2;
    var out = { px: px, lh: lh, lines: [], W: W, H: H, top: top, blockH: blockH, minX: Infinity, maxX: -Infinity };
    lines.forEach(function (s, li) {
      var rtl = AR.test(s), w = ctx.measureText(s).width, cx = T.x * W;
      var left = T.align === 'center' ? cx - w / 2 : (T.align === 'right' ? cx + maxW / 2 - w : cx - maxW / 2);
      var L = { s: s, rtl: rtl, w: w, left: left, right: left + w, y: top + li * lh + lh / 2, words: [], chars: [] };
      function span(a, b) {
        var wa = ctx.measureText(s.slice(0, a)).width, wb = ctx.measureText(s.slice(0, b)).width;
        return rtl ? [L.right - wb, L.right - wa] : [L.left + wa, L.left + wb];
      }
      var re = /\S+/g, m;
      while ((m = re.exec(s))) { var sp = span(m.index, m.index + m[0].length); L.words.push({ a: m.index, b: m.index + m[0].length, x0: sp[0], x1: sp[1], text: m[0] }); }
      graphemes(s).forEach(function (g) { if (/\s/.test(s.slice(g.a, g.b))) return; var sp2 = span(g.a, g.b); L.chars.push({ a: g.a, b: g.b, x0: sp2[0], x1: sp2[1] }); });
      out.minX = Math.min(out.minX, L.left); out.maxX = Math.max(out.maxX, L.right);
      out.lines.push(L);
    });
    return out;
  }

  /* ---------- timing ---------- */
  function pieces(Lo, unit) {
    var list = [];
    Lo.lines.forEach(function (L, li) {
      if (unit === 'line') list.push({ L: L, li: li, x0: L.left, x1: L.right, whole: true });
      else {
        var own = (unit === 'word' ? L.words : L.chars).map(function (p) { return { L: L, li: li, x0: p.x0, x1: p.x1, cx0: p.x0, cx1: p.x1, a: p.a, b: p.b, text: p.text }; });
        // clip edges meet halfway across the gaps, so glow and shadow stay continuous
        var vis = own.slice().sort(function (a, b) { return a.x0 - b.x0; });
        for (var k = 0; k < vis.length - 1; k++) { var m = (vis[k].x1 + vis[k + 1].x0) / 2; vis[k].cx1 = m; vis[k + 1].cx0 = m; }
        if (vis.length) { vis[0].cx0 = vis[0].x0 - 1e4; vis[vis.length - 1].cx1 = vis[vis.length - 1].x1 + 1e4; vis[0].edge = vis[vis.length - 1].edge = true; }
        own.forEach(function (p) { list.push(p); });
      }
    });
    return list;
  }
  function orderOf(pr, n, i) {
    if (pr.order === 'random') { var arr = []; for (var k = 0; k < n; k++) arr.push([rnd(k, 3), k]); arr.sort(function (a, b) { return a[0] - b[0]; }); for (var j = 0; j < n; j++) if (arr[j][1] === i) return j; }
    if (pr.order === 'center') { var c = (n - 1) / 2; return Math.abs(i - c) * 2; }
    if (pr.order === 'all') return 0;
    return i;
  }
  function phase(T, pr, i, n, t) {
    var unitF = pr.unit === 'line' ? .75 : pr.unit === 'word' ? .5 : .32;
    var inDur = Math.max(.05, +T.inDur) / Math.max(.2, +T.speed || 1), outDur = Math.max(.05, +T.outDur);
    var pd = pr.pd !== undefined ? Math.max(.001, pr.pd * inDur) : inDur * unitF;
    var maxOrd = pr.order === 'center' ? (n - 1) : pr.order === 'all' ? 1 : Math.max(1, n - 1);
    var stag = n > 1 ? (inDur - pd) / maxOrd : 0;
    var start = orderOf(pr, n, i) * stag;
    var pIn = clamp((t - start) / pd, 0, 1);
    var dur = Math.max(.3, +T.dur), oStart = dur - outDur;
    var pdO = outDur * unitF, stO = n > 1 ? (outDur - pdO) / Math.max(1, n - 1) : 0;
    var q = 1 - clamp((t - oStart - (T.outMode === 'mirror' ? (n - 1 - i) : i) * stO) / Math.max(.001, pdO), 0, 1);
    if (T.outMode === 'none') q = 1;
    return { pIn: pIn, q: q, start: start, pd: pd };
  }

  /* ---------- drawing ---------- */
  function paintLine(ctx, T, Lo, L, color, lyr) {
    ctx.direction = L.rtl ? 'rtl' : 'ltr';
    ctx.textAlign = L.rtl ? 'right' : 'left';
    ctx.textBaseline = 'middle';
    var x = L.rtl ? L.right : L.left, y = L.y;
    var px = Lo.px;
    if (T.glow > 0 || lyr.glow) {
      ctx.save(); ctx.shadowColor = T.glowColor; ctx.shadowBlur = px * (.25 + .6 * Math.max(T.glow, lyr.glow || 0)); ctx.fillStyle = T.glowColor;
      ctx.globalAlpha *= .9; ctx.fillText(L.s, x, y); ctx.restore();
    }
    if (T.shadow > 0) { ctx.shadowColor = 'rgba(0,0,0,' + clamp(T.shadow, 0, 1) + ')'; ctx.shadowBlur = px * .18; ctx.shadowOffsetY = px * .05; }
    if (T.stroke > 0) {
      ctx.lineJoin = 'round'; ctx.miterLimit = 2; ctx.lineWidth = T.stroke * px * .12; ctx.strokeStyle = T.strokeColor; ctx.strokeText(L.s, x, y);
      ctx.shadowColor = 'transparent';
    }
    if (T.grad) {
      var g = ctx.createLinearGradient(0, y - px / 2, 0, y + px / 2); g.addColorStop(0, color); g.addColorStop(1, T.color2); ctx.fillStyle = g;
    } else ctx.fillStyle = color;
    ctx.fillText(L.s, x, y);
    ctx.shadowColor = 'transparent';
  }
  function scrambled(s, p, seed) {
    var cps = Array.from(s), n = cps.length, ar = AR.test(s);
    var pool = ar ? 'ابتثجحخدذرزسشصضطظعغفقكلمنهوي' : 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789#$%&*';
    return cps.map(function (c, i) {
      if (/\s/.test(c)) return c;
      return (i / n) < p ? c : pool[Math.floor(rnd(i, seed) * pool.length)];
    }).join('');
  }

  var layerCv = null;
  function getLayer(w, h) {
    if (!layerCv) layerCv = G.document.createElement('canvas');
    if (layerCv.width !== w || layerCv.height !== h) { layerCv.width = w; layerCv.height = h; }
    var c = layerCv.getContext('2d'); c.setTransform(1, 0, 0, 1, 0, 0); c.clearRect(0, 0, w, h); return c;
  }

  /* draw the text at time t onto ctx (W x H pixels) */
  function draw(ctx, Tin, W, H, t) {
    var T = norm(Tin), pr = BY[T.preset], dur = Math.max(.3, +T.dur);
    var Lo = layout(ctx, T, W, H), px = Lo.px;
    var list = pieces(Lo, pr.unit), n = list.length;
    var lc = getLayer(W, H);    // everything goes on a layer first (for shine / clean alpha)
    lc.font = fontStr(T, px);
    var shakeAll = 0;

    /* background box behind the whole block */
    if (T.box && Lo.lines.length) {
      var ph0 = phase(T, { unit: 'line' }, 0, 1, t), bo = E.out(clamp(t / Math.max(.05, T.inDur * .6), 0, 1)) * ph0.q;
      var pad = T.boxPad * px, bx = Lo.minX - pad, by = Lo.top - pad * .6, bw = (Lo.maxX - Lo.minX) + pad * 2, bh = Lo.blockH + pad * 1.2;
      var sc = lerp(.85, 1, E.back(clamp(t / Math.max(.05, T.inDur * .6), 0, 1)));
      lc.save(); lc.globalAlpha = bo * T.boxAlpha; lc.fillStyle = T.boxColor;
      lc.translate(bx + bw / 2, by + bh / 2); lc.scale(sc, sc);
      roundRect(lc, -bw / 2, -bh / 2, bw, bh, Math.min(bh / 2, T.boxRadius * px * 2)); lc.fill(); lc.restore();
    }

    var lastVisible = null;
    list.forEach(function (pc, i) {
      var ph = phase(T, pr, i, n, t);
      if (pr.solo) { // one word at a time
        var seg = dur / n, k0 = i * seg;
        if (t < k0 || t >= k0 + seg) return;
        ph.pIn = clamp((t - k0) / Math.min(.25, seg * .5), 0, 1); ph.q = 1;
      }
      var a = pr.f(ph.pIn, i, n) || {};
      var b = T.outMode === 'mirror' ? (ph.q < 1 ? pr.f(ph.q, i, n) : {}) : outProps(T.outMode, ph.q);
      var o = (a.o === undefined ? 1 : a.o) * (b.o === undefined ? 1 : b.o);
      if (ph.pIn <= 0 && !pr.solo) return;
      if (o <= .003 && !a.mask && a.reveal === undefined) return;
      lastVisible = pc;
      var dx = ((a.dx || 0) + (b.dx || 0)) * px, dy = ((a.dy || 0) + (b.dy || 0)) * px;
      var s = (a.s === undefined ? 1 : a.s) * (b.s === undefined ? 1 : b.s);
      var sx = s * (a.sx === undefined ? 1 : a.sx) * (b.sx === undefined ? 1 : b.sx), sy = s * (a.sy === undefined ? 1 : a.sy) * (b.sy === undefined ? 1 : b.sy);
      var r = ((a.r || 0) + (b.r || 0)) * PI / 180, skx = (a.skx || 0) + (b.skx || 0), blur = ((a.blur || 0) + (b.blur || 0)) * px;
      var mask = a.mask || b.mask, reveal = a.reveal !== undefined ? a.reveal : (b.reveal !== undefined ? b.reveal : 1);
      /* continuous extras */
      var lt = t - (ph.start + ph.pd);
      if (pr.loopFx === 'wave') dy += Math.sin(t * 5 - i * .55) * px * .12;
      if (pr.loopFx === 'float') { dy += Math.sin(t * 2.2 + i * 1.3) * px * .08; r += Math.sin(t * 1.7 + i) * .03; }
      if (pr.loopFx === 'pulse' && lt > 0) { var pu = 1 + Math.max(0, Math.sin(lt * 6)) * .05; sx *= pu; sy *= pu; }
      if (pr.loopFx === 'shake' && lt > 0) { dx += (rnd(Math.floor(t * 24), i) - .5) * px * .08; dy += (rnd(Math.floor(t * 24), i + 9) - .5) * px * .08; }
      if (pr.loopFx === 'push') { var pp = 1 + clamp(t / dur, 0, 1) * .08; sx *= pp; sy *= pp; }
      if (pr.loopFx === 'glitch' && rnd(Math.floor(t * 10), 7) > .86) { a.rgb = (a.rgb || 0) + .08; a.jit = (a.jit || 0) + .15; }
      if (pr.shakeOnLand && ph.pIn >= 1 && lt < .25) shakeAll = Math.max(shakeAll, (1 - lt / .25) * px * .08);

      var L = pc.L, cx = (pc.x0 + pc.x1) / 2, cy = L.y;
      if (pr.solo) { dx += T.x * W - cx; dy += T.y * H - cy; }
      var pivotY = a.pivot === 'top' ? cy - px * .55 : cy;
      var clipX0 = pc.whole ? pc.x0 - px * 3 : Math.max(pc.cx0, pc.x0 - px * 3), clipX1 = pc.whole ? pc.x1 + px * 3 : Math.min(pc.cx1, pc.x1 + px * 3);
      clipX0 = Math.round(clipX0); clipX1 = Math.round(clipX1);   // whole pixels: neighbours meet without a seam
      var clipY0 = cy - Lo.lh * 1.4, clipY1 = cy + Lo.lh * 1.4;
      if (mask) { clipY0 = cy - Lo.lh * .55; clipY1 = cy + Lo.lh * .58; }

      lc.save();
      lc.globalAlpha = clamp(o, 0, 1);
      if (blur > .3) lc.filter = 'blur(' + blur.toFixed(1) + 'px)';
      if (mask) { lc.beginPath(); lc.rect(clipX0, clipY0, clipX1 - clipX0, clipY1 - clipY0); lc.clip(); }
      if (reveal < 1) {
        var dirR = (b.revDir || 1) * (L.rtl ? -1 : 1), wv = (clipX1 - clipX0) * clamp(reveal, 0, 1);
        lc.beginPath();
        if (dirR > 0) lc.rect(clipX0, clipY0 - px, wv, clipY1 - clipY0 + 2 * px); else lc.rect(clipX1 - wv, clipY0 - px, wv, clipY1 - clipY0 + 2 * px);
        lc.clip();
      }
      lc.translate(cx + dx, pivotY + dy);
      if (r) lc.rotate(r);
      if (skx) lc.transform(1, 0, Math.tan(skx * PI / 180), 1, 0, 0);
      lc.scale(sx, sy);
      lc.translate(-cx, -pivotY);
      if (!mask && !pc.whole) { lc.beginPath(); lc.rect(clipX0, clipY0, clipX1 - clipX0, clipY1 - clipY0); lc.clip(); }

      /* special drawings */
      if (a.hl !== undefined) {
        var hw = (pc.x1 - pc.x0 + px * .3) * a.hl, hx = L.rtl ? pc.x1 + px * .15 - hw : pc.x0 - px * .15;
        lc.save(); lc.globalAlpha *= .95; lc.fillStyle = T.color2; roundRect(lc, hx, cy - px * .55, hw, px * 1.1, px * .18); lc.fill(); lc.restore();
      }
      var Ls = L;
      if (a.scramble !== undefined && a.scramble < 1) Ls = { s: scrambled(L.s, a.scramble, Math.floor(t * 18)), rtl: L.rtl, left: L.left, right: L.right, y: L.y };
      if (a.split !== undefined && a.split > 0) {
        var off = a.split * px * 1.4;
        lc.save(); lc.beginPath(); lc.rect(clipX0, cy - px, clipX1 - clipX0, px); lc.clip(); lc.translate(-off, 0); paintLine(lc, T, Lo, Ls, T.color, {}); lc.restore();
        lc.save(); lc.beginPath(); lc.rect(clipX0, cy, clipX1 - clipX0, px); lc.clip(); lc.translate(off, 0); paintLine(lc, T, Lo, Ls, T.color, {}); lc.restore();
      } else if (a.shutter !== undefined && a.shutter < 1) {
        var slices = 6, sh = Lo.lh / slices;
        for (var k = 0; k < slices; k++) {
          var y0 = cy - Lo.lh / 2 + k * sh;
          lc.save(); lc.beginPath(); lc.rect(clipX0, y0 + sh * (1 - a.shutter) / 2, clipX1 - clipX0, sh * a.shutter); lc.clip(); paintLine(lc, T, Lo, Ls, T.color, {}); lc.restore();
        }
      } else if (a.rgb) {
        var e = a.rgb * px, j = (a.jit || 0) * px * (rnd(Math.floor(t * 30), i) - .5);
        lc.save(); lc.globalCompositeOperation = 'lighter'; lc.globalAlpha *= .8;
        lc.translate(-e + j, 0); paintLine(lc, { glow: 0, shadow: 0, stroke: 0, color: '#ff0040', grad: false }, Lo, Ls, '#ff2050', {});
        lc.translate(2 * e, 0); paintLine(lc, { glow: 0, shadow: 0, stroke: 0, grad: false }, Lo, Ls, '#00e5ff', {}); lc.restore();
        paintLine(lc, T, Lo, Ls, T.color, {});
      } else {
        var col = T.color;
        if (pr.loopFx === 'karaoke') {
          var span0 = Math.max(.1, dur - T.inDur - T.outDur), kp = (t - T.inDur) / span0 * n - i;
          paintLine(lc, T, Lo, Ls, col, { glow: pr.glowAuto ? .6 : 0 });
          if (kp > 0) { lc.save(); var kw = (pc.x1 - pc.x0) * clamp(kp, 0, 1); lc.beginPath(); if (L.rtl) lc.rect(pc.x1 - kw, clipY0, kw, clipY1 - clipY0); else lc.rect(pc.x0, clipY0, kw, clipY1 - clipY0); lc.clip(); paintLine(lc, T, Lo, Ls, T.color2, {}); lc.restore(); }
        } else paintLine(lc, T, Lo, Ls, col, { glow: pr.glowAuto ? .7 : 0 });
      }
      if (a.ul !== undefined) {
        var uw = (L.right - L.left) * a.ul, ux = L.rtl ? L.right - uw : L.left;
        lc.fillStyle = T.color2; lc.fillRect(ux, cy + px * .58, uw, Math.max(2, px * .08));
      }
      lc.restore();
    });

    /* typewriter cursor */
    if (pr.cursor && lastVisible && t < dur - T.outDur) {
      var Lc = lastVisible.L, cxp = Lc.rtl ? lastVisible.x0 - px * .08 : lastVisible.x1 + px * .08;
      if (Math.floor(t * 2.2) % 2 === 0 || t < T.inDur) { lc.fillStyle = T.color; lc.fillRect(cxp - px * .04, Lc.y - px * .5, px * .08, px); }
    }
    /* shine: a light band crossing the letters */
    if (pr.loopFx === 'shine') {
      var span1 = (Lo.maxX - Lo.minX) + px * 4, sp = ((t * .55) % 1.6) / 1.6, bxs = Lo.minX - px * 2 + span1 * sp;
      lc.save(); lc.globalCompositeOperation = 'source-atop';
      var gr = lc.createLinearGradient(bxs - px, 0, bxs + px, 0);
      gr.addColorStop(0, 'rgba(255,255,255,0)'); gr.addColorStop(.5, 'rgba(255,255,255,.85)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
      lc.fillStyle = gr; lc.fillRect(0, 0, W, H); lc.restore();
    }
    var sx2 = shakeAll ? (rnd(Math.floor(t * 40), 1) - .5) * shakeAll * 2 : 0, sy2 = shakeAll ? (rnd(Math.floor(t * 40), 2) - .5) * shakeAll * 2 : 0;
    ctx.drawImage(layerCv, sx2, sy2);
    return Lo;
  }
  function roundRect(c, x, y, w, h, r) {
    r = Math.max(0, Math.min(r, w / 2, h / 2));
    c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath();
  }

  G.TextFX = { PRESETS: PRESETS, BY: BY, OUTS: OUTS, DEF: DEF, norm: norm, draw: draw, layout: layout, fontStr: fontStr, roundRect: roundRect };
})(window);
