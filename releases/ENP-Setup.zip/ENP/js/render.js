/* Carousel 3D — final render: every frame drawn with the same renderer as the
   preview, at the sequence's size, piped into ffmpeg as ProRes 4444 + alpha. */
(function (G) {
  'use strict';

  function loadImg(p) {
    return new Promise(function (res, rej) {
      var im = new Image();
      im.onload = function () { res(im); };
      im.onerror = function () { rej(new Error('image_load: ' + p)); };
      im.src = Sys.url(p);
    });
  }
  function pad(n) { return ('0000' + n).slice(-5); }

  /* premultiplied -> straight alpha, in place */
  function unpremultiply(px) {
    for (var i = 0, n = px.length; i < n; i += 4) {
      var a = px[i + 3];
      if (a && a < 255) {
        var k = 255 / a;
        px[i] = Math.min(255, px[i] * k + .5); px[i + 1] = Math.min(255, px[i + 1] * k + .5); px[i + 2] = Math.min(255, px[i + 2] * k + .5);
      }
    }
    return px;
  }

  /* job: { R (renderer), settings, items (ready media), frame:{w,h}, fps, dur, markers, outDir, look,
            mediaKeys: fn(items) -> keys, onProgress(p), cancelled() } */
  function render(job) {
    var t0 = Date.now(), R = job.R, s = job.settings, fps = job.fps, dur = job.dur;
    var W = job.frame.w, H = job.frame.h, split = !!s.split;
    var nF = Math.max(2, Math.round(dur * fps));
    var stamp = new Date(), tag = String(stamp.getFullYear()).slice(2) + ('0' + (stamp.getMonth() + 1)).slice(-2) + ('0' + stamp.getDate()).slice(-2) + '_' +
      ('0' + stamp.getHours()).slice(-2) + ('0' + stamp.getMinutes()).slice(-2) + ('0' + stamp.getSeconds()).slice(-2);
    var dir = job.outDir || Sys.join(Sys.workDir(), 'renders'); Sys.mkdirp(dir);
    var base = 'ENP_Carousel_' + (job.look || 'ring') + '_' + tag;
    var front = Sys.join(dir, base + (split ? '_front' : '') + '.mov'), back = split ? Sys.join(dir, base + '_back.mov') : '';
    var encF = null, encB = null, buf = null;
    var vids = job.items.filter(function (it) { return it.kind === 'video'; });
    var frameDirs = {};

    // 1) every clip -> frames at the render rate (looping if it's shorter than the carousel)
    var prep = vids.reduce(function (pr, it, k) {
      return pr.then(function () {
        if (job.cancelled()) throw new Error('cancelled');
        job.onProgress(.12 * k / Math.max(1, vids.length), 'prep');
        return Sys.clipFrames(it.path, it.from || 0, dur, fps, 1024).then(function (d) { frameDirs[it.key] = d; });
      });
    }, Promise.resolve());

    return prep.then(function () {
      R.resize(W, H);
      encF = Sys.encoder(front, W, H, fps);
      if (split) encB = Sys.encoder(back, W, H, fps);
      var keys = job.items.map(function (it) { return 'k_' + it.key; });
      var n = 0;
      function step() {
        if (job.cancelled()) throw new Error('cancelled');
        if (n >= nF) return Promise.resolve();
        var t = n / fps, idx = n + 1;
        var loads = vids.map(function (it) {
          return loadImg(Sys.join(frameDirs[it.key], pad(idx) + '.jpg')).catch(function () { return null; })
            .then(function (im) { if (im) R.setImage('k_' + it.key, im); });
        });
        return Promise.all(loads).then(function () {
          var opts = { n: job.items.length, w: W, h: H, t: t, markers: job.markers };
          var media = { media: keys, placeholder: job.placeholder };
          var writes = [];
          if (split) {
            opts.layer = 'back';
            R.draw(CarEngine.frame(s, opts), media);
            buf = unpremultiply(R.readRGBA(buf));
            writes.push(encB.write(buf));
            return Promise.all(writes).then(function () {
              opts.layer = 'front';
              R.draw(CarEngine.frame(s, opts), { media: keys, placeholder: job.placeholder, layerBg: false });
              buf = unpremultiply(R.readRGBA(buf));
              return encF.write(buf);
            });
          }
          R.draw(CarEngine.frame(s, opts), media);
          buf = unpremultiply(R.readRGBA(buf));
          return encF.write(buf);
        }).then(function () {
          n++;
          job.onProgress(.12 + .86 * n / nF, 'draw');
          return (n % 8 === 0) ? new Promise(function (r) { setTimeout(r, 0); }).then(step) : step();
        });
      }
      return step();
    }).then(function () {
      return Promise.all([encF.end(), encB ? encB.end() : null]);
    }).then(function () {
      return { path: front, back: back, duration: nF / fps, ms: Date.now() - t0 };
    }).catch(function (e) {
      if (encF) encF.kill(); if (encB) encB.kill();
      Sys.remove(front); if (back) Sys.remove(back);
      throw e;
    });
  }

  G.CarRender = { render: render };
})(window);
