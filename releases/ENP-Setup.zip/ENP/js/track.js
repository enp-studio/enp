/* Carousel 3D — tracking inside Premiere.
   Mark something on the frame under the playhead, follow it frame by frame
   (ffmpeg grey frames + CarTracker), then: make other clips follow it,
   hold it still (stabilize), or reframe the clip to follow it (face follow). */
(function (G) {
  'use strict';
  var K = G.K, h = K.h, st = K.store('c3d_tk_');
  var L = {
    intro: 'علّم على أي حاجة بتتحرك في الفيديو وهو يمشي وراها فريم بفريم. بعدها: كليب يمشي معاها، أو تثبّتها في الكادر، أو الكادر نفسه يمشي ورا الوش.',
    s1: '١. علّم على الحاجة', s1_hint: 'وقّف المؤشر على فريم الحاجة باينة فيه، دوس «هات الفريم»، وارسم مربع عليها هي بالظبط.',
    grab: 'هات الفريم ده', shot: 'بيتابع في: {n}', both: 'ومن أول الكليب كمان (مش من المؤشر بس)', size: 'تابع حجمها كمان (لو بتقرّب أو تبعد)',
    go: 'ابدأ التراكينج', stop: 'وقّف', decode: 'بيجهّز الفريمات…', tracking: 'بيعمل تراكينج… {p}%',
    tracked: 'تمام — مشي وراها من {a} لحد {b} ✓ اختار تحت هتعمل بيها إيه.', lost: 'ضاعت منه عند {b} (حد عدّى قدامها أو اتغيّرت أوي). تقدر تستخدم اللي اتعمل لحد هنا.',
    s2: '٢. هتعمل بيها إيه؟', s2_wait: 'اعمل التراكينج الأول.',
    m_attach: 'كليب يمشي معاها', m_steady: 'ثبّتها', m_follow: 'الكادر يمشي وراها',
    attach_hint: 'اختار في التايملاين الكليب (أو الكليبات) اللي عايزه يمشي معاها — نص، ستيكر، لوجو… — وحطه في المكان اللي عايزه عند المؤشر، وبعدين دوس «طبّق».',
    scale: 'يكبر ويصغر معاها', smooth: 'نعومة الحركة',
    steady_hint: 'الفيديو كله هيتحرك عشان الحاجة دي تفضل ثابتة.', where: 'تفضل فين؟', w_here: 'في مكانها', w_center: 'في نص الكادر', fill: 'كبّر شوية عشان الأطراف السودا ماتبانش',
    follow_hint: 'مثالي لفيديو عرضي في سيكوينس رأسي: الكليب بيتكبّر يملا الكادر، والكادر بيمشي ورا الوش اللي علّمت عليه بنعومة.',
    zoom: 'زووم زيادة', axis: 'يتابع', ax_x: 'يمين وشمال بس', ax_xy: 'كل الاتجاهات',
    apply: 'طبّق', applying: 'بحط الحركة في بريمير… {p}%', undo: 'تراجع عن آخر تطبيق',
    done_attach: 'تمام — {n} كليب بقى ماشي معاها ({k} كيفريم) ✓', done_steady: 'تمام — ثابتة والفيديو هو اللي بيتحرك ({k} كيفريم){z} ✓', zoomed: ' واتكبّر {p}%',
    done_follow: 'تمام — الكادر ماشي وراها ({k} كيفريم) ✓', undone: 'رجع زي ما كان.',
    e_seq: 'افتح سيكوينس الأول.', e_shot: 'مفيش كليب فيديو تحت المؤشر.', e_box: 'ارسم المربع الأول.', e_nosel: 'اختار الكليب اللي عايزه يمشي معاها في التايملاين الأول.',
    e_self: 'ده نفس الكليب اللي اتعمله تراكينج — اختار كليب تاني.', e_outside: 'الكليب المختار مش موجود في وقت التراكينج.', e_short: 'مفيش وقت كفاية في الكليب بعد المؤشر.',
    e_moved: 'الكليب اتحرّك من مكانه — اعمل التراكينج تاني.', w_keyed: 'الكليب ده عليه زووم/حركة — التراكينج بيتحسب على الصورة نفسها فممكن يبعد شوية.', failed: 'حصلت مشكلة'
  };
  function t(k, v) { var s = L[k] || k; if (v) for (var x in v) s = s.replace('{' + x + '}', v[x]); return s; }
  var P = (function () { var d = { both: false, size: false, mode: 'attach', scale: false, smA: 1, smS: 2, smF: 6, where: 'here', fill: true, zoom: 1.15, axis: 'x' }, s = st.get('set', {}); for (var k in s) d[k] = s[k]; return d; })();
  function save() { st.set('set', P); }

  var shot = null;   // { clip, t, w, h, fps, srcW, srcH, img, tw, th }
  var box = null;    // normalized {x,y,w,h}
  var track = null;  // { pts:[{t,u,v,s}], mark }
  var busy = false, stopReq = false, last = st.get('last', null);
  var ui = {};

  /* ---------- canvas ---------- */
  function drawShot() {
    var cv = ui.cv;
    if (!shot || !shot.img) { ui.cvWrap.classList.add('hide'); return; }
    ui.cvWrap.classList.remove('hide');
    var w = Math.max(160, ui.cvWrap.clientWidth || 300), ar = shot.srcW / shot.srcH, hh = Math.min(420, w / ar), ww = hh * ar;
    var dpr = Math.min(2, G.devicePixelRatio || 1);
    cv.style.width = Math.round(ww) + 'px'; cv.style.height = Math.round(hh) + 'px';
    cv.width = Math.round(ww * dpr); cv.height = Math.round(hh * dpr);
    var x = cv.getContext('2d'); x.setTransform(dpr, 0, 0, dpr, 0, 0);
    x.drawImage(shot.img, 0, 0, ww, hh);
    if (track && track.pts.length > 1) {
      x.strokeStyle = 'rgba(228,138,166,.9)'; x.lineWidth = 2; x.beginPath();
      track.pts.forEach(function (p, i) { var px = p.u * ww, py = p.v * hh; i ? x.lineTo(px, py) : x.moveTo(px, py); });
      x.stroke();
    }
    if (box) {
      x.strokeStyle = '#ffd34d'; x.lineWidth = 2; x.setLineDash([5, 3]);
      x.strokeRect(box.x * ww, box.y * hh, box.w * ww, box.h * hh); x.setLineDash([]);
      x.fillStyle = '#ffd34d'; x.beginPath(); x.arc((box.x + box.w / 2) * ww, (box.y + box.h / 2) * hh, 3, 0, 7); x.fill();
    }
  }
  function bindCanvas() {
    var cv = ui.cv, d = null;
    function pt(e) { var r = cv.getBoundingClientRect(); return { x: Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)), y: Math.max(0, Math.min(1, (e.clientY - r.top) / r.height)) }; }
    cv.addEventListener('pointerdown', function (e) { if (busy || !shot) return; try { cv.setPointerCapture(e.pointerId); } catch (x) {} d = pt(e); box = null; track = null; refresh(); });
    cv.addEventListener('pointermove', function (e) {
      if (!d) return; var p = pt(e);
      box = { x: Math.min(d.x, p.x), y: Math.min(d.y, p.y), w: Math.abs(p.x - d.x), h: Math.abs(p.y - d.y) }; drawShot();
    });
    function end() { if (!d) return; d = null; if (box && (box.w < .01 || box.h < .01)) box = null; refresh(); }
    cv.addEventListener('pointerup', end); cv.addEventListener('pointercancel', end);
  }
  function refresh() { drawShot(); ui.goBtn.disabled = !box || busy; K.show(ui.step2, !!track); K.show(ui.wait, !track); }

  /* ---------- 1. grab the frame ---------- */
  function grab() {
    ui.status.show('busy', '…');
    Sys.call('cr_under2').then(function (r) {
      if (!r || !r.ok) throw new Error(r && r.error === 'no_sequence' ? t('e_seq') : t('failed'));
      if (r.none || !r.clip) throw new Error(t('e_shot'));
      var c = r.clip;
      return Sys.probe(c.path).then(function (info) {
        var srcW = info.w || 1920, srcH = info.h || 1080, big = Math.max(srcW, srcH), k = 640 / big;
        var tw = Math.max(64, Math.round(srcW * k / 2) * 2), th = Math.max(64, Math.round(srcH * k / 2) * 2);
        var dw = Math.round(srcW * (720 / big) / 2) * 2, dh = Math.round(srcH * (720 / big) / 2) * 2;
        return Sys.grabFrame(c.path, c.src, dw, dh).then(function (file) {
          return new Promise(function (res, rej) { var im = new Image(); im.onload = function () { res(im); }; im.onerror = function () { rej(new Error('frame')); }; im.src = Sys.url(file); });
        }).then(function (img) {
          shot = { clip: c, t: r.t, w: r.w, h: r.h, fps: r.fps, srcW: srcW, srcH: srcH, img: img, tw: tw, th: th };
          box = null; track = null;
          ui.shotName.textContent = t('shot', { n: c.name });
          ui.status.show(c.keyed ? 'warn' : '', c.keyed ? t('w_keyed') : '');
          refresh();
        });
      });
    }).catch(function (e) { ui.status.show('err', e.message || String(e)); });
  }

  /* ---------- 2. track ---------- */
  function run() {
    if (!shot || !box || busy) return;
    busy = true; stopReq = false; refresh(); K.show(ui.stopBtn, true);
    var c = shot.clip, fps = shot.fps || 30, fr = 1 / fps;
    var fwdDur = Math.min(120, c.end - shot.t), backDur = P.both ? Math.min(30, shot.t - c.start) : 0;
    if (fwdDur < fr * 2 && backDur < fr * 2) { busy = false; K.show(ui.stopBtn, false); refresh(); return ui.status.show('err', t('e_short')); }
    var tb = { x: box.x * shot.tw, y: box.y * shot.th, w: Math.max(6, box.w * shot.tw), h: Math.max(6, box.h * shot.th) };
    var pts = [], lostAt = null, total = Math.round((fwdDur + backDur) * fps), done = 0;
    function prog() { done++; if (done % 5 === 0) { ui.prog.set(done / Math.max(1, total)); ui.status.show('busy', t('tracking', { p: Math.round(done / Math.max(1, total) * 100) })); } }
    function push(tt, r) { pts.push({ t: tt, u: r.cx / shot.tw, v: r.cy / shot.th, s: r.s }); }
    ui.status.show('busy', t('decode')); ui.prog.set(0);
    var fwd = fwdDur < fr * 2 ? Promise.resolve() : (function () {
      var tr = null, stop = false;
      return Sys.grayFrames(c.path, c.src, fwdDur, fps, shot.tw, shot.th, function (buf, i) {
        if (i === 0) { tr = new CarTracker.Tracker(shot.tw, shot.th, tb, { scale: P.size }); push(shot.t, tr.init(buf)); prog(); return; }
        var r = tr.step(buf); prog();
        if (r.lost || r.cx < 0 || r.cy < 0 || r.cx > shot.tw || r.cy > shot.th) { lostAt = shot.t + (i - 4) * fr; pts.splice(Math.max(1, pts.length - 3)); stop = true; return false; }
        push(shot.t + i * fr, r);
      }, function () { return stopReq; }).then(function () { if (stopReq && !stop) lostAt = pts.length ? pts[pts.length - 1].t : shot.t; });
    })();
    fwd.then(function () {
      if (backDur < fr * 2 || stopReq) return;
      var frames = [];
      return Sys.grayFrames(c.path, c.src - backDur, backDur + fr * .5, fps, shot.tw, shot.th, function (buf) { frames.push(buf); }, function () { return stopReq; }).then(function () {
        var tr = new CarTracker.Tracker(shot.tw, shot.th, tb, { scale: P.size }), back = [];
        tr.init(frames[frames.length - 1] || frames[0]);
        for (var i = frames.length - 2; i >= 0; i--) {
          var r = tr.step(frames[i]); prog();
          if (r.lost) break;
          back.push({ t: shot.t - (frames.length - 1 - i) * fr, u: r.cx / shot.tw, v: r.cy / shot.th, s: r.s });
        }
        pts = back.reverse().concat(pts);
      });
    }).then(function () {
      pts.sort(function (a, b) { return a.t - b.t; });
      if (pts.length < 2) throw new Error(t('e_short'));
      track = { pts: pts, mark: shot.t, clip: shot.clip, w: shot.w, h: shot.h, fps: fps, srcW: shot.srcW, srcH: shot.srcH };
      var a = K.tc(pts[0].t, fps), b = K.tc(pts[pts.length - 1].t, fps);
      ui.status.show(lostAt !== null ? 'warn' : 'ok', lostAt !== null ? t('lost', { b: K.tc(lostAt, fps) }) : t('tracked', { a: a, b: b }));
    }).catch(function (e) { ui.status.show('err', e.message || String(e)); })
      .then(function () { busy = false; ui.prog.done(); K.show(ui.stopBtn, false); refresh(); });
  }

  /* ---------- 3. apply ---------- */
  function sm(arr, amount) { return CarTracker.smooth(arr, amount * (track.fps || 30) * .06); }
  function seqPt(clip, u, v, k) { // a point of the tracked picture, in sequence pixels
    var W = track.w, H = track.h, A = clip.anchor || [.5, .5], Pp = clip.pos || [.5, .5];
    return [Pp[0] * W + (u - A[0]) * track.srcW * k, Pp[1] * H + (v - A[1]) * track.srcH * k];
  }
  function thin(list) { if (list.length <= 600) return list; var out = []; for (var i = 0; i < list.length; i += 2) out.push(list[i]); if (out[out.length - 1] !== list[list.length - 1]) out.push(list[list.length - 1]); return out; }
  function markIndex() { var best = 0; track.pts.forEach(function (p, i) { if (Math.abs(p.t - track.mark) < Math.abs(track.pts[best].t - track.mark)) best = i; }); return best; }
  function sendKeys(jobs) {
    var total = jobs.reduce(function (a, j) { return a + (j.keys ? j.keys.length : 0); }, 0), done = 0;
    ui.prog.set(0);
    return jobs.reduce(function (pr, j) {
      return pr.then(function () {
        if (!j.keys || !j.keys.length) return Sys.call('cr_keys', { clip: j.ref, prop: j.prop, keys: [], reset: true, value: j.value }).then(chk);
        var first = true;
        return K.chunks(j.keys, 60, function (part) {
          var r0 = first; first = false;
          return Sys.call('cr_keys', { clip: j.ref, prop: j.prop, keys: part, reset: r0 }).then(chk).then(function () {
            done += part.length; ui.prog.set(done / Math.max(1, total)); ui.status.show('busy', t('applying', { p: Math.round(done / Math.max(1, total) * 100) }));
          });
        });
      });
    }, Promise.resolve()).then(function () { return total; });
    function chk(r) { if (!r || !r.ok) throw new Error(r && r.error === 'clip_moved' ? t('e_moved') : t('failed') + ' [' + (r && (r.error || r.detail)) + ']'); }
  }
  function refOf(c) { return { track: c.track, start: c.start, id: c.id }; }
  function remember(list) { last = list; st.set('last', last); K.show(ui.undoBtn, true); }

  function applyAttach() {
    var c0 = track.clip, k0 = (c0.scale || 100) / 100, mi = markIndex();
    var us = sm(track.pts.map(function (p) { return p.u; }), P.smA), vs = sm(track.pts.map(function (p) { return p.v; }), P.smA), ss = sm(track.pts.map(function (p) { return p.s; }), P.smA);
    var ref = seqPt(c0, us[mi], vs[mi], k0);
    return Sys.call('cr_clips', { fallback: false }).then(function (r) {
      if (!r || !r.ok) throw new Error(t('e_seq'));
      var targets = r.clips.filter(function (c) { return !(c.track === c0.track && Math.abs(c.start - c0.start) < .002); });
      if (!r.clips.length) throw new Error(t('e_nosel'));
      if (!targets.length) throw new Error(t('e_self'));
      var jobs = [], undo = [];
      targets.forEach(function (c) {
        var idx = [];
        track.pts.forEach(function (p, i) { if (p.t >= c.start - 1e-4 && p.t < c.end) idx.push(i); });
        if (idx.length < 2) return;
        idx = thin(idx);
        var base = c.pos || [.5, .5], bs = c.scale || 100;
        jobs.push({ ref: refOf(c), prop: 'pos', keys: idx.map(function (i) {
          var q = seqPt(c0, us[i], vs[i], k0);
          return [track.pts[i].t, [base[0] + (q[0] - ref[0]) / track.w, base[1] + (q[1] - ref[1]) / track.h]];
        }) });
        if (P.scale) jobs.push({ ref: refOf(c), prop: 'scale', keys: idx.map(function (i) { return [track.pts[i].t, Math.round(bs * ss[i] / ss[mi] * 100) / 100]; }) });
        undo.push({ ref: refOf(c), props: P.scale ? ['pos', 'scale'] : ['pos'], base: { pos: c.pos, scale: c.scale } });
      });
      if (!jobs.length) throw new Error(t('e_outside'));
      return sendKeys(jobs).then(function (k) { remember(undo); ui.status.show('ok', t('done_attach', { n: undo.length, k: k })); });
    });
  }
  function applySelf(mode) {
    var c = track.clip, W = track.w, H = track.h, sw = track.srcW, sh = track.srcH, A = c.anchor || [.5, .5], k0 = (c.scale || 100) / 100;
    var amt = mode === 'follow' ? P.smF : P.smS;
    var us = sm(track.pts.map(function (p) { return p.u; }), amt), vs = sm(track.pts.map(function (p) { return p.v; }), amt);
    var n = us.length, pos = [], k, z = 1, i;
    if (mode === 'steady') {
      var mi = markIndex(), target = P.where === 'center' ? [W / 2, H / 2] : seqPt(c, us[mi], vs[mi], k0);
      var calc = function (kk) {
        var out = [];
        for (var j = 0; j < n; j++) out.push([target[0] - (us[j] - A[0]) * sw * kk, target[1] - (vs[j] - A[1]) * sh * kk]);
        return out;
      };
      var covers = function (list, kk) {
        return list.every(function (p) { return p[0] - A[0] * sw * kk <= .5 && p[0] + (1 - A[0]) * sw * kk >= W - .5 && p[1] - A[1] * sh * kk <= .5 && p[1] + (1 - A[1]) * sh * kk >= H - .5; });
      };
      k = k0; pos = calc(k);
      if (P.fill) { for (z = 1; z <= 2.5; z += .01) { k = k0 * z; pos = calc(k); if (covers(pos, k)) break; } if (z > 2.5) { z = 1; k = k0; pos = calc(k); } }
    } else {
      var cover = Math.max(W / sw, H / sh); k = cover * Math.max(1, P.zoom); z = k / k0;
      for (i = 0; i < n; i++) {
        var px = W / 2 - (us[i] - A[0]) * sw * k;
        px = Math.min(A[0] * sw * k, Math.max(W - (1 - A[0]) * sw * k, px));
        var py;
        if (P.axis === 'xy') { py = H / 2 - (vs[i] - A[1]) * sh * k; py = Math.min(A[1] * sh * k, Math.max(H - (1 - A[1]) * sh * k, py)); }
        else py = H / 2 + (A[1] - .5) * sh * k;
        pos.push([px, py]);
      }
    }
    var idx = thin(track.pts.map(function (p, j) { return j; }));
    var jobs = [
      { ref: refOf(c), prop: 'scale', keys: [], value: Math.round(k * 10000) / 100 },
      { ref: refOf(c), prop: 'pos', keys: idx.map(function (j) { return [track.pts[j].t, [pos[j][0] / W, pos[j][1] / H]]; }) }
    ];
    return sendKeys(jobs).then(function (kk) {
      remember([{ ref: refOf(c), props: ['pos', 'scale'], base: { pos: c.pos, scale: c.scale } }]);
      ui.status.show('ok', mode === 'follow' ? t('done_follow', { k: kk }) : t('done_steady', { k: kk, z: z > 1.001 ? t('zoomed', { p: Math.round((z - 1) * 100) }) : '' }));
    });
  }
  function apply() {
    if (!track || busy) return;
    busy = true; ui.applyBtn.disabled = true;
    (P.mode === 'attach' ? applyAttach() : applySelf(P.mode))
      .catch(function (e) { ui.status.show('err', e.message || String(e)); })
      .then(function () { busy = false; ui.applyBtn.disabled = false; ui.prog.done(); });
  }
  function undo() {
    if (!last || !last.length) return;
    last.reduce(function (pr, u) { return pr.then(function () { return Sys.call('cr_unkey', { clip: u.ref, props: u.props, base: u.base }); }); }, Promise.resolve())
      .then(function () { ui.status.show('ok', t('undone')); last = null; st.set('last', null); K.show(ui.undoBtn, false); });
  }

  /* ---------- build ---------- */
  function build(root) {
    ui.status = K.status(); ui.prog = K.progress();
    ui.cv = h('canvas', { class: 'tkcv' }); ui.cvWrap = h('div', { class: 'tkwrap hide' }, [ui.cv]); bindCanvas();
    ui.shotName = h('div', { class: 'hint', style: 'margin-top:6px' });
    ui.goBtn = K.btn(t('go'), { cls: 'pri', icon: 'target', onClick: run }); ui.goBtn.disabled = true;
    ui.stopBtn = K.btn(t('stop'), { icon: 'stop', onClick: function () { stopReq = true; } }); K.show(ui.stopBtn, false);
    var smA = K.slider({ label: t('smooth'), min: 0, max: 10, step: .5, value: P.smA, onInput: function (v) { P.smA = v; save(); } });
    var smS = K.slider({ label: t('smooth'), min: 0, max: 10, step: .5, value: P.smS, onInput: function (v) { P.smS = v; save(); } });
    var smF = K.slider({ label: t('smooth'), min: 0, max: 12, step: .5, value: P.smF, onInput: function (v) { P.smF = v; save(); } });
    ui.pAttach = h('div', {}, [h('div', { class: 'hint', text: t('attach_hint') }), K.toggle(t('scale'), P.scale, function (v) { P.scale = v; save(); }), smA]);
    ui.pSteady = h('div', {}, [h('div', { class: 'hint', text: t('steady_hint') }),
      K.field(t('where'), K.seg({ items: [{ v: 'here', label: t('w_here') }, { v: 'center', label: t('w_center') }], value: P.where, onChange: function (v) { P.where = v; save(); } })),
      K.toggle(t('fill'), P.fill, function (v) { P.fill = v; save(); }), smS]);
    ui.pFollow = h('div', {}, [h('div', { class: 'hint', text: t('follow_hint') }),
      K.slider({ label: t('zoom'), min: 1, max: 2.5, step: .01, value: P.zoom, fmt: function (v) { return Math.round(v * 100) + '%'; }, onInput: function (v) { P.zoom = v; save(); } }),
      K.field(t('axis'), K.seg({ items: [{ v: 'x', label: t('ax_x') }, { v: 'xy', label: t('ax_xy') }], value: P.axis, onChange: function (v) { P.axis = v; save(); } })), smF]);
    function modeShow() { K.show(ui.pAttach, P.mode === 'attach'); K.show(ui.pSteady, P.mode === 'steady'); K.show(ui.pFollow, P.mode === 'follow'); }
    ui.applyBtn = K.btn(t('apply'), { cls: 'pri', icon: 'spark', onClick: apply });
    ui.undoBtn = K.btn(t('undo'), { cls: 'ghost', icon: 'undo', onClick: undo }); K.show(ui.undoBtn, !!last);
    ui.wait = h('div', { class: 'hint', text: t('s2_wait') });
    ui.step2 = h('div', {}, [
      K.seg({ items: [{ v: 'attach', label: t('m_attach') }, { v: 'steady', label: t('m_steady') }, { v: 'follow', label: t('m_follow') }], value: P.mode, onChange: function (v) { P.mode = v; save(); modeShow(); } }),
      h('div', { style: 'margin-top:8px' }, [ui.pAttach, ui.pSteady, ui.pFollow]),
      h('div', { style: 'margin-top:12px' }, [ui.applyBtn])
    ]);
    modeShow();
    [h('div', { class: 'hint intro', text: t('intro') }),
      K.section(t('s1'), [h('div', { class: 'hint', text: t('s1_hint') }), h('div', { class: 'adds', style: 'margin-top:8px' }, [K.btn(t('grab'), { icon: 'target', onClick: grab })]),
        ui.cvWrap, ui.shotName,
        K.toggle(t('both'), P.both, function (v) { P.both = v; save(); }), K.toggle(t('size'), P.size, function (v) { P.size = v; save(); }),
        h('div', { style: 'margin-top:10px' }, [ui.goBtn]), h('div', { class: 'tk' }, [ui.stopBtn])], true, 'tk1'),
      K.section(t('s2'), [ui.wait, ui.step2], true, 'tk2'),
      h('div', { class: 'out' }, [ui.prog, ui.status, h('div', { class: 'tk' }, [ui.undoBtn])])
    ].forEach(function (el) { root.appendChild(el); });
    refresh();
    G.addEventListener('resize', drawShot);
  }

  G.TrackTab = { build: build };
})(window);
