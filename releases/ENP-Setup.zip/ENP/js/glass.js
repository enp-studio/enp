/* Amar Studio — Liquid Glass (Apple-style) panels over your video.
   The glass bends and frosts the actual picture under it: the clip under the
   playhead is read frame by frame and refracted in a WebGL shader. */
(function (G) {
  'use strict';
  var K = G.K, h = K.h, st = K.store('c3d_gl_');

  /* ---------------- renderer ---------------- */
  var VS = 'attribute vec2 aP; void main(){ gl_Position = vec4(aP, 0.0, 1.0); }';
  var FS = [
    'precision highp float;',
    'uniform sampler2D uBg; uniform vec2 uRes; uniform vec2 uC; uniform vec2 uHalf; uniform float uR;',
    'uniform float uBlur; uniform float uRefr; uniform float uEdge; uniform float uChroma; uniform vec3 uTint; uniform float uTintA;',
    'uniform float uSpec; uniform float uShadow; uniform float uAlpha; uniform float uSat; uniform float uBright; uniform float uHasBg; uniform float uMag;',
    'float sd(vec2 p){ vec2 q = abs(p) - uHalf + uR; return length(max(q,0.0)) + min(max(q.x,q.y),0.0) - uR; }',
    'vec3 bg(vec2 p, float bias){ vec2 uv = clamp(p / uRes, 0.0, 1.0); return texture2D(uBg, uv, bias).rgb; }',
    'vec3 frost(vec2 p){',
    '  float rad = uBlur * min(uHalf.x, uHalf.y) * 0.5; float bias = uBlur * 5.0;',
    '  vec3 s = bg(p, bias) * 0.2;',
    '  for (int i = 0; i < 8; i++) { float a = float(i) * 0.785398 + 0.3; vec2 o = vec2(cos(a), sin(a)) * rad * (0.55 + 0.45 * mod(float(i), 2.0)); s += bg(p + o, bias) * 0.1; }',
    '  return s;',
    '}',
    'void main(){',
    '  vec2 p = vec2(gl_FragCoord.x, uRes.y - gl_FragCoord.y);',
    '  vec2 lp = p - uC; float d = sd(lp);',
    '  float aa = 1.0;',
    '  if (d > aa) {',  // outside: soft drop shadow only
    '    float ds = sd(lp - vec2(0.0, uHalf.y * 0.12 + 6.0));',
    '    float sh = uShadow * 0.55 * exp(-max(ds, 0.0) / (8.0 + min(uHalf.x, uHalf.y) * 0.35));',
    '    gl_FragColor = vec4(0.0, 0.0, 0.0, sh * uAlpha); return;',
    '  }',
    '  vec2 e2 = vec2(1.0, 0.0);',
    '  vec2 n = normalize(vec2(sd(lp + e2.xy) - sd(lp - e2.xy), sd(lp + e2.yx) - sd(lp - e2.yx)) + 1e-5);',
    '  float depth = clamp(-d / uEdge, 0.0, 1.0);',
    '  float bend = pow(1.0 - depth, 2.2) * uRefr;',
    '  vec2 q = uC + lp * (1.0 - uMag) - n * bend;',
    '  vec3 col;',
    '  if (uChroma > 0.0) {',
    '    vec2 ch = n * bend * uChroma;',
    '    col = vec3(frost(q - ch).r, frost(q).g, frost(q + ch).b);',
    '  } else col = frost(q);',
    '  col = mix(vec3(0.5), col, uHasBg);',
    '  float l = dot(col, vec3(0.299, 0.587, 0.114));',
    '  col = mix(vec3(l), col, uSat) * uBright;',
    '  col = mix(col, uTint, uTintA);',
    '  vec2 L = normalize(vec2(-0.55, -0.85));',
    '  float rim = pow(1.0 - depth, 3.0);',
    '  float lit = max(dot(n, L), 0.0), dark = max(dot(n, -L), 0.0);',
    '  col += vec3(1.0) * rim * lit * uSpec * 1.1;',
    '  col += vec3(1.0) * pow(1.0 - clamp(-d / 1.6, 0.0, 1.0), 2.0) * 0.35 * uSpec;',
    '  col -= vec3(0.25) * rim * dark * uSpec;',
    '  float sheen = smoothstep(0.0, 1.0, 1.0 - (lp.y + uHalf.y) / (uHalf.y * 2.0)) * 0.06 * uSpec;',
    '  col += sheen;',
    '  float cover = clamp(0.5 - d, 0.0, 1.0);',
    '  float a = cover * uAlpha * mix(0.82, 1.0, uHasBg);',
    '  gl_FragColor = vec4(clamp(col, 0.0, 1.0), a);',
    '}'].join('\n');

  function pot(n) { var p = 1; while (p < n) p *= 2; return p; }
  function Renderer() {
    var cv = G.document.createElement('canvas');
    var gl = cv.getContext('webgl', { alpha: true, premultipliedAlpha: true, preserveDrawingBuffer: true, antialias: false });
    if (!gl) throw new Error('no_webgl');
    function sh(t, s) { var o = gl.createShader(t); gl.shaderSource(o, s); gl.compileShader(o); if (!gl.getShaderParameter(o, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(o)); return o; }
    var pr = gl.createProgram(); gl.attachShader(pr, sh(gl.VERTEX_SHADER, VS)); gl.attachShader(pr, sh(gl.FRAGMENT_SHADER, FS)); gl.linkProgram(pr); gl.useProgram(pr);
    var U = {}; ['uBg','uRes','uC','uHalf','uR','uBlur','uRefr','uEdge','uChroma','uTint','uTintA','uSpec','uShadow','uAlpha','uSat','uBright','uHasBg','uMag'].forEach(function (n) { U[n] = gl.getUniformLocation(pr, n); });
    var b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1,-1, 1,-1, -1,1, 1,1]), gl.STATIC_DRAW);
    var a = gl.getAttribLocation(pr, 'aP'); gl.enableVertexAttribArray(a); gl.vertexAttribPointer(a, 2, gl.FLOAT, false, 0, 0);
    var tex = gl.createTexture(), scratch = G.document.createElement('canvas'), hasBg = 0;
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array([128, 128, 128, 255]));
    return {
      canvas: cv,
      setBg: function (src) {
        if (!src) { hasBg = 0; return; }
        var w = src.width, hh = src.height, tw = Math.min(2048, pot(w)), th = Math.min(2048, pot(hh));
        scratch.width = tw; scratch.height = th; scratch.getContext('2d').drawImage(src, 0, 0, tw, th);
        gl.bindTexture(gl.TEXTURE_2D, tex);
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, scratch);
        gl.generateMipmap(gl.TEXTURE_2D);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
        hasBg = 1;
      },
      /* g: geometry in pixels {cx,cy,hw,hh,r}, s: settings, alpha */
      draw: function (W, H, g, s, alpha) {
        if (cv.width !== W || cv.height !== H) { cv.width = W; cv.height = H; }
        gl.viewport(0, 0, W, H); gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT);
        gl.enable(gl.BLEND); gl.blendFuncSeparate(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA, gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
        var tc = hex(s.tint), m = Math.min(g.hw, g.hh);
        gl.uniform1i(U.uBg, 0); gl.uniform2f(U.uRes, W, H); gl.uniform2f(U.uC, g.cx, g.cy); gl.uniform2f(U.uHalf, g.hw, g.hh); gl.uniform1f(U.uR, Math.min(g.r, m));
        gl.uniform1f(U.uBlur, s.blur); gl.uniform1f(U.uRefr, s.refr * m * .9); gl.uniform1f(U.uEdge, Math.max(2, s.edge * m)); gl.uniform1f(U.uChroma, s.chroma);
        gl.uniform3f(U.uTint, tc[0], tc[1], tc[2]); gl.uniform1f(U.uTintA, s.tintA); gl.uniform1f(U.uSpec, s.spec); gl.uniform1f(U.uShadow, s.shadow);
        gl.uniform1f(U.uAlpha, alpha); gl.uniform1f(U.uSat, s.sat); gl.uniform1f(U.uBright, s.bright); gl.uniform1f(U.uHasBg, hasBg); gl.uniform1f(U.uMag, s.mag * .12);
        gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
      }
    };
  }
  function hex(c) { var n = parseInt(String(c || '#ffffff').slice(1, 7), 16) || 0; return [(n >> 16 & 255) / 255, (n >> 8 & 255) / 255, (n & 255) / 255]; }

  /* ---------------- settings & presets ---------------- */
  var DEF = {
    shape: 'pill', w: .7, h: .12, radius: .3, x: .5, y: .5,
    blur: .35, refr: .5, edge: .55, chroma: .25, tint: '#ffffff', tintA: .08, spec: .8, shadow: .35, sat: 1.2, bright: 1.05, mag: .3,
    text: '', font: 'Arial', weight: 700, tsize: .38, tcolor: '#ffffff',
    dur: 4, anim: 'jelly', inDur: .7, outDur: .45, outAnim: 'shrink'
  };
  var PRESETS = [
    { id: 'island', name: 'دايناميك آيلاند', set: { shape: 'pill', w: .42, h: .085, x: .5, y: .06, blur: .25, tintA: .15, tint: '#0a0a0a', text: 'تسجيل…', tsize: .42, anim: 'island' } },
    { id: 'notify', name: 'إشعار', set: { shape: 'rect', w: .9, h: .2, radius: .22, x: .5, y: .13, blur: .55, tintA: .1, text: 'رسالة جديدة', tsize: .26, anim: 'drop' } },
    { id: 'button', name: 'زرار', set: { shape: 'pill', w: .5, h: .13, x: .5, y: .82, blur: .3, text: 'تابعني', tsize: .4, anim: 'jelly' } },
    { id: 'lower', name: 'لوور ثيرد', set: { shape: 'rect', w: .88, h: .19, radius: .25, x: .5, y: .78, blur: .45, text: 'الاسم هنا', tsize: .3, anim: 'rise' } },
    { id: 'circle', name: 'دايرة عدسة', set: { shape: 'circle', w: .38, h: .38, x: .5, y: .45, blur: .02, refr: .9, mag: .9, edge: .8, chroma: .35, text: '', anim: 'jelly' } },
    { id: 'card', name: 'كارت', set: { shape: 'rect', w: .84, h: .55, radius: .1, x: .5, y: .5, blur: .6, tintA: .12, text: '', anim: 'rise' } },
    { id: 'tabbar', name: 'تاب بار', set: { shape: 'pill', w: .82, h: .15, x: .5, y: .93, blur: .5, text: '', anim: 'rise' } },
    { id: 'name2', name: 'اسم + وظيفة', set: { shape: 'rect', w: .82, h: .17, radius: .3, x: .5, y: .8, blur: .5, tintA: .12, text: 'الاسم هنا\nالمسمى الوظيفي', tsize: .3, anim: 'rise', outAnim: 'drop' } },
    { id: 'subscribe', name: 'اشترك', set: { shape: 'pill', w: .46, h: .1, x: .5, y: .84, blur: .3, tint: '#ff2d55', tintA: .45, text: 'اشترك', tsize: .45, anim: 'jelly' } },
    { id: 'handle', name: 'يوزرنيم', set: { shape: 'pill', w: .5, h: .075, x: .5, y: .12, blur: .35, tintA: .1, text: '@username', tsize: .42, anim: 'island', outAnim: 'island' } },
    { id: 'cta', name: 'اللينك في البايو', set: { shape: 'pill', w: .72, h: .09, x: .5, y: .9, blur: .4, tint: '#c9a26b', tintA: .3, text: 'اللينك في البايو ↓', tsize: .4, anim: 'rise' } },
    { id: 'chapter', name: 'عنوان فصل', set: { shape: 'rect', w: .8, h: .2, radius: .45, x: .5, y: .5, blur: .65, tintA: .15, text: 'الجزء الأول\nالبداية', tsize: .34, anim: 'pop', outAnim: 'shrink' } },
    { id: 'quote', name: 'اقتباس', set: { shape: 'rect', w: .86, h: .3, radius: .16, x: .5, y: .62, blur: .6, tintA: .12, text: '«الجملة المهمة هنا»\nاسم القائل', tsize: .17, anim: 'rise' } },
    { id: 'price', name: 'سعر / رقم', set: { shape: 'circle', w: .3, x: .78, y: .3, blur: .4, tint: '#c9a26b', tintA: .35, refr: .7, text: '99$', tsize: .3, anim: 'jelly' } },
    { id: 'place', name: 'مكان', set: { shape: 'pill', w: .5, h: .07, x: .5, y: .2, blur: .35, tintA: .1, text: '📍 القاهرة', tsize: .45, anim: 'drop', outAnim: 'rise' } },
    { id: 'lens', name: 'عدسة واضحة', set: { shape: 'rect', w: .6, h: .3, radius: .3, x: .5, y: .5, blur: 0, refr: .75, mag: .5, chroma: .5, text: '', anim: 'fade' } }
  ];
  var ANIMS = { jelly: 'جيلي', island: 'يتمد زي الآيلاند', drop: 'نازل من فوق', rise: 'طالع من تحت', pop: 'بوب', fade: 'يظهر بهدوء', none: 'من غير' };
  var OUTA = { shrink: 'يصغر', island: 'يتلم', fade: 'يختفي', rise: 'يطلع لفوق', drop: 'ينزل لتحت', none: 'من غير' };
  var S = (function () { var o = {}, k, v = st.get('set', {}); for (k in DEF) o[k] = DEF[k]; for (k in v) o[k] = v[k]; return o; })();
  function save() { st.set('set', S); }

  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function outCubic(x) { x = clamp(x, 0, 1); return 1 - Math.pow(1 - x, 3); }
  function outBack(x) { x = clamp(x, 0, 1); var c = 1.7; return 1 + (c + 1) * Math.pow(x - 1, 3) + c * Math.pow(x - 1, 2); }

  /* geometry at time t: center, half sizes, radius, alpha */
  function geo(s, W, H, t) {
    var bw = s.w * W, bh = (s.shape === 'circle' ? s.w : s.h) * W, r = s.shape === 'pill' || s.shape === 'circle' ? Math.min(bw, bh) / 2 : s.radius * Math.min(bw, bh);
    var cx = s.x * W, cy = s.y * H, sx = 1, sy = 1, a = 1, dur = Math.max(.3, s.dur);
    var pi = s.anim === 'none' ? 1 : clamp(t / Math.max(.05, s.inDur), 0, 1), po = s.outAnim === 'none' ? 1 : clamp((dur - t) / Math.max(.05, s.outDur), 0, 1);
    function jelly(p) { var k = Math.exp(-5 * p) * Math.sin(p * 18); return [1 + k * .12, 1 - k * .12]; }
    switch (s.anim) {
      case 'jelly': { var e = outBack(pi), j = jelly(pi); sx = e * j[0]; sy = e * j[1]; a = clamp(pi * 4, 0, 1); break; }
      case 'island': { var e2 = outBack(pi); sx = (bh / bw) + (1 - bh / bw) * e2; var j2 = jelly(pi); sy = j2[1]; a = clamp(pi * 5, 0, 1); break; }
      case 'drop': { cy -= (1 - outBack(pi)) * (cy + bh); a = clamp(pi * 3, 0, 1); break; }
      case 'rise': { cy += (1 - outCubic(pi)) * bh * 1.4; a = outCubic(pi); var j3 = jelly(pi); sx *= j3[0]; sy *= j3[1]; break; }
      case 'pop': { var e3 = outBack(pi); sx = sy = e3; a = clamp(pi * 4, 0, 1); break; }
      case 'fade': { a = outCubic(pi); break; }
    }
    switch (s.outAnim) {
      case 'shrink': { var q = outCubic(po); sx *= .5 + .5 * q; sy *= .5 + .5 * q; a *= po; break; }
      case 'island': { var q2 = outCubic(po); sx *= (bh / bw) + (1 - bh / bw) * q2; a *= clamp(po * 3, 0, 1); break; }
      case 'fade': a *= po; break;
      case 'rise': cy -= (1 - outCubic(po)) * bh * 1.5; a *= po; break;
      case 'drop': cy += (1 - outCubic(po)) * bh * 1.5; a *= po; break;
    }
    var hw = Math.max(1, bw * sx / 2), hh = Math.max(1, bh * sy / 2);
    return { cx: cx, cy: cy, hw: hw, hh: hh, r: Math.min(r * Math.min(sx, sy) + 0 * hh, hw, hh), a: a, textA: clamp((pi - .45) / .4, 0, 1) * po };
  }

  /* everything on one 2D canvas: glass + text */
  function compose(ctx, R, s, W, H, t) {
    var g = geo(s, W, H, t);
    ctx.clearRect(0, 0, W, H);
    if (g.a <= .002) return;
    R.draw(W, H, g, s, g.a);
    ctx.drawImage(R.canvas, 0, 0);
    if (s.text && g.textA > .01) {
      var px = Math.max(6, g.hh * 2 * s.tsize);
      ctx.save(); ctx.globalAlpha = g.textA;
      ctx.font = s.weight + ' ' + px + 'px "' + s.font + '", "Segoe UI", Tahoma, Arial, sans-serif';
      ctx.fillStyle = s.tcolor; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.direction = /[֐-ࣿ]/.test(s.text) ? 'rtl' : 'ltr';
      ctx.shadowColor = 'rgba(0,0,0,.25)'; ctx.shadowBlur = px * .15;
      ctx.beginPath(); ctx.rect(g.cx - g.hw, g.cy - g.hh, g.hw * 2, g.hh * 2); ctx.clip();
      /* first line is the title, the rest are a smaller subtitle */
      var lines = String(s.text).split('\n'), sub = .68, hs = lines.map(function (l, i) { return (i ? px * sub : px) * 1.18; }), tot = hs.reduce(function (a, b) { return a + b; }, 0), y = g.cy - tot / 2;
      lines.forEach(function (ln, i) {
        if (i === 1) { ctx.font = Math.max(400, s.weight - 200) + ' ' + px * sub + 'px "' + s.font + '", "Segoe UI", Tahoma, Arial, sans-serif'; ctx.globalAlpha = g.textA * .82; }
        ctx.fillText(ln, g.cx, y + hs[i] / 2); y += hs[i];
      });
      ctx.restore();
    }
  }

  /* the clip under the playhead drawn the way it sits in the sequence */
  function drawClip(ctx, img, clip, W, H, srcW, srcH) {
    var k = (clip.scale || 100) / 100, P = clip.pos || [.5, .5], A = clip.anchor || [.5, .5];
    var dw = srcW * k, dh = srcH * k;
    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, H);
    ctx.drawImage(img, P[0] * W - A[0] * dw, P[1] * H - A[1] * dh, dw, dh);
  }

  /* m = the glass clip's Motion in Premiere ({k, P, A}); the glass is drawn in its own (unmoved) frame,
     so the picture behind it is pulled through the inverse of that move */
  var scrCv = null;
  function bgLocal(bgx, img, info, W, H, srcW, srcH, m) {
    if (!m || (Math.abs(m.k - 1) < 1e-4 && Math.abs(m.P[0] - m.A[0]) < 1e-4 && Math.abs(m.P[1] - m.A[1]) < 1e-4)) { drawClip(bgx, img, info, W, H, srcW, srcH); return; }
    if (!scrCv) scrCv = G.document.createElement('canvas');
    if (scrCv.width !== W || scrCv.height !== H) { scrCv.width = W; scrCv.height = H; }
    drawClip(scrCv.getContext('2d'), img, info, W, H, srcW, srcH);
    bgx.setTransform(1, 0, 0, 1, 0, 0); bgx.fillStyle = '#000'; bgx.fillRect(0, 0, W, H);
    bgx.setTransform(1 / m.k, 0, 0, 1 / m.k, m.A[0] * W - m.P[0] * W / m.k, m.A[1] * H - m.P[1] * H / m.k);
    bgx.drawImage(scrCv, 0, 0); bgx.setTransform(1, 0, 0, 1, 0, 0);
  }

  /* ---------------- tab ---------------- */
  var ui = {}, ctl = {}, R = null, seq = { w: 1080, h: 1920 }, under = null, clock = { on: false, t: 1.2, last: 0 }, raf = 0, busy = false, stopReq = false, lastPlaced = st.get('last', null);
  var bgCv = null;
  function fit() {
    var w = Math.max(160, ui.wrap.clientWidth || 300), ar = seq.w / seq.h, hh = Math.min(440, w / ar), ww = hh * ar;
    ui.stage.style.width = Math.round(ww) + 'px'; ui.stage.style.height = Math.round(hh) + 'px';
    var dpr = Math.min(2, G.devicePixelRatio || 1);
    ui.cv.width = Math.round(ww * dpr); ui.cv.height = Math.round(hh * dpr);
    refreshBg(); draw();
  }
  function refreshBg() {
    if (!R) return;
    var W = ui.cv.width, H = ui.cv.height;
    if (!bgCv) bgCv = G.document.createElement('canvas');
    bgCv.width = W; bgCv.height = H;
    var x = bgCv.getContext('2d');
    if (under && under.img) { drawClip(x, under.img, under.clip, W, H, under.srcW * W / seq.w, under.srcH * W / seq.w); R.setBg(bgCv); }
    else {
      // no picture yet: a soft colourful stand-in so the glass can be judged
      var gr = x.createLinearGradient(0, 0, W, H); gr.addColorStop(0, '#3a6ea5'); gr.addColorStop(.5, '#c76b98'); gr.addColorStop(1, '#f3b562');
      x.fillStyle = gr; x.fillRect(0, 0, W, H);
      x.fillStyle = 'rgba(255,255,255,.85)'; x.font = 'bold ' + Math.round(H * .05) + 'px Arial'; x.textAlign = 'center';
      for (var i = 0; i < 9; i++) x.fillText('LIQUID GLASS  زجاج سايل', W / 2, H * (.1 + i * .1));
      R.setBg(bgCv);
    }
    ui.bgImg.src = bgCv.toDataURL('image/jpeg', .8);
  }
  function draw() { if (!raf) raf = (G.requestAnimationFrame || setTimeout)(paint); }
  function paint() {
    raf = 0; if (!R) return;
    var now = Date.now();
    if (clock.on) { clock.t += Math.min(.1, (now - (clock.last || now)) / 1000); clock.last = now; if (clock.t > S.dur + .3) clock.t = 0; }
    var x = ui.cv.getContext('2d');
    // preview sizes are relative to the preview width, like the real frame
    compose(x, R, S, ui.cv.width, ui.cv.height, Math.min(clock.t, S.dur));
    ui.scrub.max = String(S.dur); ui.scrub.value = String(Math.min(clock.t, S.dur));
    ui.time.textContent = Math.min(clock.t, S.dur).toFixed(1) + ' / ' + (+S.dur).toFixed(1) + 's';
    if (clock.on) draw();
  }
  function play(on) { clock.on = on; clock.last = Date.now(); ui.play.innerHTML = K.ICON[on ? 'stop' : 'play']; draw(); }
  function grabUnder() {
    ui.status.show('busy', 'بجيب الفريم…');
    return Sys.call('cr_under2').then(function (r) {
      if (!r || !r.ok) throw new Error('افتح سيكوينس الأول.');
      if (r.w) seq = { w: r.w, h: r.h };
      if (r.none || !r.clip) { under = null; ui.status.show('warn', 'مفيش فيديو تحت المؤشر — الجلاس هيبقى من غير انكسار للصورة.'); fit(); return; }
      var c = r.clip;
      return Sys.probe(c.path).then(function (info) {
        var big = Math.max(info.w, info.h), dw = Math.round(info.w * 960 / big / 2) * 2, dh = Math.round(info.h * 960 / big / 2) * 2;
        return Sys.grabFrame(c.path, c.src, dw, dh).then(function (p) {
          return new Promise(function (res) { var im = new Image(); im.onload = function () { res(im); }; im.onerror = function () { res(null); }; im.src = Sys.url(p); });
        }).then(function (im) { under = { img: im, clip: c, srcW: info.w, srcH: info.h }; ui.status.show(c.keyed ? 'warn' : '', c.keyed ? 'الكليب ده عليه حركة/زووم — الانكسار هيتحسب على أول وضع ليه.' : ''); fit(); });
      });
    }).catch(function (e) { ui.status.show('err', e.message || String(e)); });
  }
  function bindDrag() {
    var d = null;
    ui.cv.addEventListener('pointerdown', function (e) { try { ui.cv.setPointerCapture(e.pointerId); } catch (x) {} var r = ui.cv.getBoundingClientRect(); d = { x: e.clientX, y: e.clientY, sx: S.x, sy: S.y, w: r.width, h: r.height }; });
    ui.cv.addEventListener('pointermove', function (e) {
      if (!d) return; var nx = d.sx + (e.clientX - d.x) / d.w, ny = d.sy + (e.clientY - d.y) / d.h;
      if (Math.abs(nx - .5) < .012) nx = .5; S.x = clamp(nx, -.2, 1.2); S.y = clamp(ny, -.2, 1.2); draw();
    });
    function end() { if (d) { d = null; save(); liveKick(); } }
    ui.cv.addEventListener('pointerup', end); ui.cv.addEventListener('pointercancel', end);
    ui.cv.addEventListener('wheel', function (e) { e.preventDefault(); var f = Math.pow(1.0012, -e.deltaY); S.w = clamp(S.w * f, .05, 1.2); S.h = clamp(S.h * f, .03, 1.5); save(); syncAll(); }, { passive: false });
  }
  function set(p) { for (var k in p) S[k] = p[k]; save(); draw(); liveKick(); }
  function sl(k, label, min, max, step, fmt) { var c = K.slider({ label: label, min: min, max: max, step: step, value: S[k], fmt: fmt, onInput: function (v) { var p = {}; p[k] = v; set(p); } }); ctl[k] = c; return c; }
  function col(k, label) { var inp = h('input', { type: 'color', value: S[k] }); inp.addEventListener('input', function () { var p = {}; p[k] = inp.value; set(p); }); var l = h('label', { class: 'cfield' }, [inp, h('span', { text: label })]); l.setValue = function (v) { inp.value = v; }; ctl[k] = l; return l; }
  function sel(k, map) { var s = h('select', { class: 'sel' }, Object.keys(map).map(function (v) { return h('option', { value: v, text: map[v] }); })); s.value = S[k]; s.addEventListener('change', function () { var p = {}; p[k] = s.value; set(p); }); s.setValue = function (v) { s.value = v; }; ctl[k] = s; return s; }
  function pct(v) { return Math.round(v * 100) + '%'; }
  function sec(v) { return (+v).toFixed(1) + ' ث'; }
  function syncAll() { Object.keys(ctl).forEach(function (k) { if (ctl[k].setValue && S[k] !== undefined) ctl[k].setValue(S[k]); }); ui.text.value = S.text; Fonts.ensure(S.font, +S.weight).then(draw); draw(); }

  /* render a glass with settings SS; opts: { at (sequence s), replace: [names] } */
  function glassJob(SS, opts) {
    var out = G.document.createElement('canvas'), ox, RR = null, frameDir = null, info = null, srcW = 0, srcH = 0, bg = G.document.createElement('canvas');
    return {
      prefix: 'ENP_Glass', bin: 'ENP Glass', dur: SS.dur, at: opts.at, replace: opts.replace || [], w: opts.w, h: opts.h, fps: opts.fps, dir: opts.dir,
      prepare: function (o) {
        if (o.t === undefined) o.t = opts.at;
        out.width = o.w; out.height = o.h; ox = out.getContext('2d'); bg.width = o.w; bg.height = o.h; RR = Renderer();
        // the picture under the glass at the time it starts (not wherever the playhead is)
        return Fonts.ensure(SS.font, +SS.weight).then(function () { return Sys.call('cr_under2', { t: o.t }); }).then(function (r) {
          if (!r || !r.ok || r.none || !r.clip) return;
          info = r.clip;
          return Sys.probe(info.path).then(function (pi) {
            srcW = pi.w; srcH = pi.h;
            ui.status.show('busy', 'بجهّز فريمات الفيديو…');
            return Sys.clipFrames(info.path, info.src, SS.dur, o.fps, 1920).then(function (d) { frameDir = d; });
          });
        });
      },
      frame: function (t, i, o) {
        var go = function () { compose(ox, RR, SS, o.w, o.h, t); return ox.getImageData(0, 0, o.w, o.h).data; };
        if (!frameDir) { RR.setBg(null); return go(); }
        return new Promise(function (res) {
          var im = new Image();
          im.onload = function () { bgLocal(bg.getContext('2d'), im, info, o.w, o.h, srcW, srcH, opts.motion); RR.setBg(bg); res(go()); };
          im.onerror = function () { res(go()); };
          im.src = Sys.url(Sys.join(frameDir, ('0000' + (i + 1)).slice(-5) + '.jpg'));
        });
      },
      onProgress: opts.onProgress || function (p) { ui.prog.set(p); ui.status.show('busy', 'برسم الجلاس… ' + Math.round(p * 100) + '%'); },
      cancelled: opts.cancelled || function () { return stopReq; }
    };
  }
  function renderGlass(SS, opts) {
    busy = true; stopReq = false; ui.place.disabled = true; ui.relocate.disabled = true; K.show(ui.stop, true); play(false);
    return Out.renderAndPlace(glassJob(SS, opts)).then(function (r) {
      lastPlaced = { names: r.names }; st.set('last', lastPlaced); K.show(ui.remove, true);
      link = { name: r.names[0], sig: '' }; st.set('link', link); liveBadge();
      var made = st.get('renders', {}); r.names.forEach(function (n) { made[n] = JSON.parse(JSON.stringify(SS)); });
      var keys = Object.keys(made); if (keys.length > 60) keys.slice(0, keys.length - 60).forEach(function (k) { delete made[k]; });
      st.set('renders', made);
      return r;
    }).then(function (r) { ui.status.show('ok', 'اتحط على ' + r.track + ' عند ' + K.tc(r.at, r.fps) + ' · خد ' + (r.ms / 1000).toFixed(1) + ' ث'); }, function (e) { ui.status.show(e && e.message === 'cancelled' ? 'warn' : 'err', Out.errText(e)); })
      .then(function () { busy = false; ui.place.disabled = false; ui.relocate.disabled = false; K.show(ui.stop, false); ui.prog.done(); });
  }
  function placeIt() {
    if (busy) return;
    renderGlass(S, { replace: st.get('replace', false) && lastPlaced ? lastPlaced.names : [] });
  }
  /* the glass was moved / resized in Premiere: draw it again where it is now,
     so it bends what's really under its new place */
  function relocate() {
    if (busy) return;
    ui.status.show('busy', 'بدوّر على الجلاس…');
    Sys.call('cr_clips', { fallback: false }).then(function (r) {
      var pick = r && r.ok ? r.clips.filter(function (c) { return /^ENP_Glass_/.test(c.name); })[0] : null;
      if (pick) return pick;
      if (!lastPlaced) return null;
      return Sys.call('cr_findNamed', { names: lastPlaced.names }).then(function (x) { return x && x.ok ? x.clip : null; });
    }).then(function (c) {
      if (!c) throw new Error('اختار الجلاس في التايملاين الأول.');
      return Sys.call('cr_info').then(function (inf) {
        var W = inf.w || seq.w, H = inf.h || seq.h, made = st.get('renders', {}), base = made[c.name] || S;
        var SS = JSON.parse(JSON.stringify(base));
        var k = (c.scale || 100) / 100, P = c.pos || [.5, .5], A = c.anchor || [.5, .5];
        // where the glass centre ended up on screen after Premiere's Position / Scale
        var cx = P[0] * W + (SS.x * W - A[0] * W) * k, cy = P[1] * H + (SS.y * H - A[1] * H) * k;
        SS.x = cx / W; SS.y = cy / H; SS.w = SS.w * k; SS.h = SS.h * k;
        SS.dur = Math.max(.3, Math.min(SS.dur || 4, c.end - c.start + .001));
        var moved = Math.abs(SS.x - base.x) > .002 || Math.abs(SS.y - base.y) > .002 || Math.abs(k - 1) > .002;
        if (!moved) { ui.status.show('warn', 'الجلاس ده لسه في مكانه — حرّكه في بريمير (Position / Scale) الأول.'); return; }
        if (c.keyed) ui.status.show('warn', 'الجلاس عليه كيفريمز حركة — هرسمه في مكانه عند أول فريم.');
        S.x = SS.x; S.y = SS.y; S.w = SS.w; S.h = SS.h; save(); syncAll();   // the panel follows too
        return renderGlass(SS, { at: c.start, replace: [c.name] });
      });
    }).catch(function (e) { ui.status.show('err', e.message || String(e)); });
  }
  function removeLast() {
    if (!lastPlaced) return;
    Sys.call('cr_remove', { names: lastPlaced.names }).then(function (r) { if (r && r.ok) { ui.status.show('ok', 'اتشال ' + r.removed + ' من التايملاين'); lastPlaced = null; st.set('last', null); K.show(ui.remove, false); } });
  }

  /* ---------------- live: the placed glass follows the panel and its own moves ---------------- */
  var link = st.get('link', null), live = st.get('live', true), lv = { timer: 0, running: false, again: false, poll: 0, last: '' };
  function liveBadge() { if (ui.liveTag) { ui.liveTag.textContent = link ? (lv.running ? 'بيتحدّث…' : 'لايف ✓') : ''; K.show(ui.liveTag, !!(live && link)); } }
  function liveKick(delay) {
    if (!live || !link) return;
    clearTimeout(lv.timer); lv.timer = setTimeout(liveUpdate, delay || 700);
  }
  function liveUpdate() {
    if (!live || !link) return;
    if (lv.running || busy) { lv.again = true; return; }
    lv.running = true; liveBadge();
    var c = null;
    Sys.call('cr_findNamed', { names: [link.name] }).then(function (x) {
      c = x && x.ok ? x.clip : null;
      if (!c) { link = null; st.set('link', null); throw new Error('gone'); }
      return Sys.call('cr_info');
    }).then(function (inf) {
      var SS = JSON.parse(JSON.stringify(S)); SS.dur = Math.max(.3, c.end - c.start);
      var m = { k: (c.scale || 100) / 100, P: c.pos || [.5, .5], A: c.anchor || [.5, .5] };
      lv.last = sig(c);
      var dir = inf && inf.dir ? Sys.join(inf.dir, 'ENP Renders') : Sys.join(Sys.workDir(), 'renders');
      return Out.renderFile(glassJob(SS, { at: c.start, w: inf.w, h: inf.h, fps: inf.fps, dir: dir, motion: m, onProgress: function () {}, cancelled: function () { return false; } }))
        .then(function (f) { return Sys.call('cr_swapMedia', { name: link.name, path: f.path }).then(function (r) { if (!r || !r.ok) throw new Error('swap ' + (r && (r.error || r.detail))); if (link.file && link.file !== f.path) Sys.remove(link.file); link.file = f.path; st.set('link', link); }); });
    }).then(function () { if (c && c.keyed) ui.status.show('warn', 'الجلاس عليه كيفريمز حركة — الانكسار بيتحسب على أول وضع ليه.'); })
      .catch(function (e) { if (e && e.message !== 'gone') ui.status.show('warn', 'التحديث اللايف ماكملش [' + (e.message || e) + ']'); })
      .then(function () { lv.running = false; liveBadge(); if (lv.again) { lv.again = false; liveKick(200); } });
  }
  function sig(c) { return [c.start, c.end, c.scale, (c.pos || []).join(','), (c.anchor || []).join(',')].map(function (v) { return typeof v === 'number' ? v.toFixed(4) : String(v); }).join('|'); }
  /* watch the placed glass: moved / scaled / trimmed in Premiere -> draw it again */
  function livePoll() {
    if (!live || !link || lv.running || busy) return;
    Sys.call('cr_findNamed', { names: [link.name] }).then(function (x) {
      var c = x && x.ok ? x.clip : null; if (!c) return;
      var s2 = sig(c); if (!lv.last) { lv.last = s2; return; }
      if (s2 !== lv.last) { lv.last = s2; liveKick(400); }
    });
  }
  function build(root) {
    try { R = Renderer(); } catch (e) { root.appendChild(h('div', { class: 'notice', text: 'كارت الشاشة مش متاح للبانل.' })); return; }
    ui.cv = h('canvas', { class: 'glcv' }); ui.bgImg = h('img', { class: 'under', alt: '', style: 'opacity:1' });
    ui.stage = h('div', { class: 'stage' }, [ui.bgImg, ui.cv]); ui.wrap = h('div', { class: 'pvwrap' }, [ui.stage]);
    ui.play = h('button', { type: 'button', class: 'ibtn', html: K.ICON.play, onclick: function () { if (!clock.on && clock.t >= S.dur) clock.t = 0; play(!clock.on); } });
    ui.scrub = h('input', { type: 'range', class: 'scrub', min: 0, max: S.dur, step: .01, value: clock.t });
    ui.scrub.addEventListener('input', function () { clock.t = parseFloat(ui.scrub.value) || 0; if (clock.on) play(false); draw(); });
    ui.time = h('span', { class: 'time' });
    bindDrag();
    ui.status = K.status(); ui.prog = K.progress();
    var presets = h('div', { class: 'chips' });
    PRESETS.forEach(function (p) {
      presets.appendChild(h('button', { type: 'button', class: 'chip', text: p.name, onclick: function () {
        var keep = { tint: S.tint, font: S.font, weight: S.weight, tcolor: S.tcolor, dur: S.dur };
        S = {}; var k; for (k in DEF) S[k] = DEF[k]; for (k in keep) S[k] = keep[k]; for (k in p.set) S[k] = p.set[k];
        save(); syncAll(); clock.t = 0; play(true);
      } }));
    });
    ui.text = h('textarea', { class: 'txin', dir: 'auto', rows: '2', placeholder: 'نص جوه الجلاس (اختياري)' }); ui.text.value = S.text;
    ui.text.addEventListener('input', function () { S.text = ui.text.value; save(); draw(); liveKick(); });
    var picker = Fonts.picker({ value: S.font, onChange: function (f) { S.font = f; save(); Fonts.ensure(f, +S.weight).then(draw); } });
    ui.place = K.btn('حطه على التايملاين', { cls: 'pri', icon: 'spark', onClick: placeIt });
    ui.stop = K.btn('وقّف', { icon: 'stop', onClick: function () { stopReq = true; } }); K.show(ui.stop, false);
    ui.remove = K.btn('شيل آخر جلاس', { cls: 'ghost', icon: 'undo', onClick: removeLast }); K.show(ui.remove, !!lastPlaced);
    ui.relocate = K.btn('ارسمه في مكانه الجديد', { icon: 'refresh', onClick: relocate });
    ui.liveTag = h('span', { class: 'livebadge' });
    var shapeSeg = K.seg({ items: [{ v: 'pill', label: 'كبسولة' }, { v: 'rect', label: 'مستطيل' }, { v: 'circle', label: 'دايرة' }], value: S.shape, onChange: function (v) { set({ shape: v }); } }); ctl.shape = shapeSeg;

    [h('div', { class: 'hint intro', text: 'زجاج سايل زي أبل: بيكسر ويغبّش الفيديو اللي تحته بجد. دوس «هات الفريم» عشان تشوفه على الفيديو بتاعك، واسحبه في المعاينة، والعجلة بتكبّره.' }),
      h('div', { class: 'pv' }, [ui.wrap, h('div', { class: 'bar' }, [ui.play, ui.scrub, ui.time]),
        h('div', { class: 'adds', style: 'margin-top:8px' }, [K.btn('هات الفريم اللي تحت المؤشر', { icon: 'target', onClick: grabUnder })])]),
      K.section('أشكال جاهزة', [presets], true, 'gl_pre'),
      K.section('الشكل', [K.field('', shapeSeg), sl('w', 'العرض', .05, 1.2, .005, pct), sl('h', 'الارتفاع', .03, 1.5, .005, pct), sl('radius', 'دوران الزوايا (للمستطيل)', 0, .5, .01, pct),
        sl('x', 'يمين وشمال', 0, 1, .005, pct), sl('y', 'فوق وتحت', 0, 1, .005, pct)], true, 'gl_shape'),
      K.section('الزجاج', [sl('blur', 'تغبيش (فروستد)', 0, 1, .01, pct), sl('refr', 'انكسار الحواف', 0, 1.5, .01, pct), sl('edge', 'عرض الحافة', .05, 1, .01, pct),
        sl('mag', 'تكبير العدسة', 0, 1, .01, pct), sl('chroma', 'ألوان قوس قزح على الحافة', 0, 1, .01, pct), sl('spec', 'لمعة', 0, 1.5, .01, pct),
        sl('sat', 'تشبّع الألوان', 0, 2, .01, function (v) { return v.toFixed(2); }), sl('bright', 'إضاءة', .5, 1.6, .01, function (v) { return v.toFixed(2); }),
        h('div', { class: 'crow' }, [col('tint', 'لون الزجاج')]), sl('tintA', 'قوة اللون', 0, 1, .01, pct), sl('shadow', 'ظل', 0, 1, .01, pct)], false, 'gl_glass'),
      K.section('نص جوه الجلاس', [ui.text, K.field('الخط', picker), sl('tsize', 'حجم النص', .1, .9, .01, pct), h('div', { class: 'crow' }, [col('tcolor', 'لون النص')])], false, 'gl_text'),
      K.section('الحركة', [sl('dur', 'المدة', 1, 20, .1, sec), K.field('الدخول', sel('anim', ANIMS)), sl('inDur', 'مدة الدخول', .1, 2.5, .05, sec),
        K.field('الخروج', sel('outAnim', OUTA)), sl('outDur', 'مدة الخروج', .1, 2.5, .05, sec)], false, 'gl_anim'),
      h('div', { class: 'out' }, [h('div', { class: 'hint', text: 'الجلاس بيترندر فوق الكليب اللي تحت المؤشر — لو غيّرت الكليب أو حرّكته اعمله تاني.' }),
        K.toggle('بدّل آخر جلاس حطيته', st.get('replace', false), function (v) { st.set('replace', v); }),
        K.toggle('لايف: أي تعديل هنا أو تحريك في بريمير يتطبق على الجلاس اللي على التايملاين', live, function (v) { live = v; st.set('live', v); liveBadge(); if (v) liveKick(100); }),
        h('div', { style: 'margin-top:10px' }, [ui.place, ui.liveTag]),
        h('div', { class: 'cam' }, [h('div', { text: 'حرّكته أو كبّرته في بريمير؟' }),
          h('div', { class: 'hint', text: 'الجلاس بيترسم على الصورة اللي تحته وقت الرسم. لو نقلته بـ Position أو Scale في بريمير، اختاره في التايملاين ودوس الزرار ده — هيترسم من جديد على اللي تحته في المكان الجديد ويتحط مكان القديم.' }),
          h('div', { class: 'adds', style: 'margin-top:6px' }, [ui.relocate])]),
        h('div', { class: 'tk' }, [ui.stop, ui.remove]), ui.prog, ui.status])
    ].forEach(function (el) { root.appendChild(el); });
    G.addEventListener('resize', fit);
    Sys.call('cr_info').then(function (r) { if (r && r.ok && r.hasSequence && r.w) { seq = { w: r.w, h: r.h }; fit(); } });
    fit(); Fonts.ensure(S.font, +S.weight).then(draw); liveBadge();
    if (!lv.poll) lv.poll = setInterval(livePoll, 1500);
  }

  G.GlassTab = { build: build, onHide: function () { if (clock.on) play(false); }, _Renderer: Renderer, _compose: compose, _S: function () { return S; } };
})(window);
