/* Carousel 3D — more disk/ffmpeg helpers for the zoom, tracking and sound tabs. */
(function (G) {
  'use strict';
  var S = G.Sys, req = S.req;
  var Buf = req ? req('buffer').Buffer : null, fs = req ? req('fs') : null, path = req ? req('path') : null, cp = req ? req('child_process') : null;

  /* speech = what isn't silence. Returns [{a,b}] in seconds from `from`. */
  function silences(p, from, dur, noiseDb, minSil) {
    return new Promise(function (res, rej) {
      var pr = cp.spawn(S.ffPath(), ['-hide_banner', '-nostats', '-ss', String(from), '-t', String(dur), '-i', p, '-vn', '-ac', '1',
        '-af', 'silencedetect=noise=' + noiseDb + 'dB:d=' + minSil, '-f', 'null', '-'], { windowsHide: true }), err = '';
      pr.stderr.on('data', function (d) { err += d; });
      pr.on('error', rej);
      pr.on('close', function () { res({ err: err }); });
    }).then(function (r) {
      var t = r.err;
      if (/does not contain any stream|Output file #0 does not contain|matches no streams/i.test(t) || !/Audio:/.test(t)) throw new Error('no_audio');
      var sil = [], m, re = /silence_(start|end): (-?[\d.]+)/g, cur = null;
      while ((m = re.exec(t))) {
        var v = Math.max(0, parseFloat(m[2]));
        if (m[1] === 'start') cur = v; else { sil.push({ a: cur === null ? 0 : cur, b: v }); cur = null; }
      }
      if (cur !== null) sil.push({ a: cur, b: dur });
      var speech = [], last = 0;
      sil.forEach(function (x) { if (x.a > last + .01) speech.push({ a: last, b: Math.min(dur, x.a) }); last = Math.max(last, x.b); });
      if (last < dur - .01) speech.push({ a: last, b: dur });
      return speech;
    });
  }

  /* grey frames for the tracker, streamed: onFrame(buf, index) for each; returns {w,h,n} */
  function grayFrames(p, from, dur, fps, w, h, onFrame, isStopped) {
    return new Promise(function (resolve, reject) {
      var args = ['-hide_banner', '-loglevel', 'error', '-ss', String(Math.max(0, from)), '-i', p, '-t', String(dur), '-an',
        '-vf', 'fps=' + fps + ',scale=' + w + ':' + h + ',format=gray', '-f', 'rawvideo', '-pix_fmt', 'gray', '-'];
      var pr = cp.spawn(S.ffPath(), args, { windowsHide: true }), size = w * h, buf = new Uint8Array(size), fill = 0, n = 0, err = '', stopped = false;
      pr.stdout.on('data', function (d) {
        if (stopped) return;
        var off = 0;
        while (off < d.length) {
          var k = Math.min(size - fill, d.length - off);
          buf.set(d.subarray(off, off + k), fill); fill += k; off += k;
          if (fill === size) {
            var keep = onFrame(buf, n++);
            buf = new Uint8Array(size); fill = 0;
            if (keep === false || (isStopped && isStopped())) { stopped = true; try { pr.kill(); } catch (e) {} return; }
          }
        }
      });
      pr.stderr.on('data', function (d) { err += d; });
      pr.on('error', reject);
      pr.on('close', function (code) {
        if (code !== 0 && !stopped && !n) return reject(new Error('frames: ' + (err.trim().split(/\r?\n/).pop() || code)));
        resolve({ w: w, h: h, n: n, stopped: stopped });
      });
    });
  }

  /* waveform peaks (0..1) and duration of a sound */
  var peakCache = {};
  function peaks(p, count) {
    count = count || 90;
    if (peakCache[p]) return Promise.resolve(peakCache[p]);
    var dir = path.join(S.workDir(), 'peaks'); S.mkdirp(dir);
    var file = path.join(dir, S.hash(p + '|' + count) + '.json');
    try { var c = JSON.parse(fs.readFileSync(file, 'utf8')); peakCache[p] = c; return Promise.resolve(c); } catch (e) {}
    return new Promise(function (resolve, reject) {
      var pr = cp.spawn(S.ffPath(), ['-hide_banner', '-i', p, '-t', '60', '-vn', '-ac', '1', '-ar', '3000', '-f', 's16le', '-'], { windowsHide: true });
      var chunks = [], err = '';
      pr.stdout.on('data', function (d) { chunks.push(d); });
      pr.stderr.on('data', function (d) { err += d; });
      pr.on('error', reject);
      pr.on('close', function () {
        var b = Buf.concat(chunks), n = Math.floor(b.length / 2);
        var dm = /Duration: (\d+):(\d+):(\d+(?:\.\d+)?)/.exec(err);
        var dur = dm ? (+dm[1]) * 3600 + (+dm[2]) * 60 + parseFloat(dm[3]) : n / 3000;
        var out = [], per = Math.max(1, Math.floor(n / count)), mx = 1;
        for (var i = 0; i < count; i++) {
          var pk = 0;
          for (var j = i * per; j < Math.min(n, (i + 1) * per); j++) { var v = Math.abs(b.readInt16LE(j * 2)); if (v > pk) pk = v; }
          out.push(pk); if (pk > mx) mx = pk;
        }
        var res = { dur: dur, p: out.map(function (v) { return Math.round(v / mx * 100) / 100; }) };
        peakCache[p] = res;
        try { fs.writeFileSync(file, JSON.stringify(res)); } catch (e) {}
        resolve(res);
      });
    });
  }

  /* every sound file under a folder (subfolder = category) */
  var AUD = /\.(wav|mp3|aif|aiff|ogg|flac|m4a|aac|wma|caf)$/i;
  function scan(root, limit) {
    limit = limit || 20000;
    var out = [], stack = [root];
    while (stack.length && out.length < limit) {
      var d = stack.pop(), list;
      try { list = fs.readdirSync(d, { withFileTypes: true }); } catch (e) { continue; }
      for (var i = 0; i < list.length; i++) {
        var e2 = list[i], full = path.join(d, e2.name);
        if (e2.name[0] === '.') continue;
        if (e2.isDirectory()) stack.push(full);
        else if (AUD.test(e2.name)) {
          var rel = path.relative(root, full).split(/[\\\/]/);
          out.push({ path: full, name: e2.name.replace(/\.[^.]+$/, ''), cat: rel.length > 1 ? rel[0] : path.basename(root), sub: rel.length > 2 ? rel.slice(1, -1).join(' / ') : '' });
        }
      }
    }
    return out;
  }
  function pickFolder(title) {
    try {
      var r = G.cep.fs.showOpenDialogEx ? G.cep.fs.showOpenDialogEx(false, true, title, '', []) : G.cep.fs.showOpenDialog(false, true, title, '', []);
      return (r && r.data && r.data[0]) || '';
    } catch (e) { return ''; }
  }

  /* waveform of part of a file (for maps): count peaks over [from, from+dur] */
  function peaksRange(p, from, dur, count) {
    return new Promise(function (resolve, reject) {
      var pr = cp.spawn(S.ffPath(), ['-hide_banner', '-loglevel', 'error', '-ss', String(from), '-t', String(dur), '-i', p, '-vn', '-ac', '1', '-ar', '2000', '-f', 's16le', '-'], { windowsHide: true });
      var chunks = [];
      pr.stdout.on('data', function (d) { chunks.push(d); });
      pr.on('error', reject);
      pr.on('close', function () {
        var b = Buf.concat(chunks), n = Math.floor(b.length / 2), out = [], per = Math.max(1, Math.floor(n / count)), mx = 1;
        for (var i = 0; i < count; i++) { var pk = 0; for (var j = i * per; j < Math.min(n, (i + 1) * per); j++) { var v = Math.abs(b.readInt16LE(j * 2)); if (v > pk) pk = v; } out.push(pk); if (pk > mx) mx = pk; }
        resolve(out.map(function (v) { return v / mx; }));
      });
    });
  }
  /* GET a URL (follows redirects); toFile -> saves; returns { body, date } */
  function httpGet(url, toFile, hops) {
    hops = hops || 0;
    return new Promise(function (resolve, reject) {
      if (hops > 6) return reject(new Error('redirects'));
      var mod = req(/^https:/.test(url) ? 'https' : 'http');
      var r = mod.get(url, { headers: { 'User-Agent': 'ENP', 'Cache-Control': 'no-cache' } }, function (res) {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) { res.resume(); return resolve(httpGet(new URL(res.headers.location, url).toString(), toFile, hops + 1)); }
        if (res.statusCode !== 200) { res.resume(); return reject(new Error('HTTP ' + res.statusCode)); }
        var date = Date.parse(res.headers.date || '') || 0;
        if (toFile) { var ws = fs.createWriteStream(toFile); res.pipe(ws); ws.on('finish', function () { ws.close(function () { resolve({ body: toFile, date: date }); }); }); ws.on('error', reject); }
        else { var ch = []; res.on('data', function (d) { ch.push(d); }); res.on('end', function () { resolve({ body: Buf.concat(ch).toString('utf8'), date: date }); }); }
      });
      r.on('error', reject); r.setTimeout(30000, function () { r.destroy(new Error('timeout')); });
    });
  }
  S.peaksRange = peaksRange; S.httpGet = httpGet;
  S.silences = silences; S.grayFrames = grayFrames; S.peaks = peaks; S.scan = scan; S.pickFolder = pickFolder;
  S.basename = function (p) { return path ? path.basename(p) : String(p).split(/[\\\/]/).pop(); };
})(window);
