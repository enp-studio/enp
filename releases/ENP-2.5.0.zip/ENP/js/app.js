/* Carousel 3D — the panel. */
(function (G) {
  'use strict';
  var E = G.CarEngine, D = G.document;

  /* ---------------- words ---------------- */
  var L = {
    intro: 'اعمل كاروسيل 3D من صورك وفيديوهاتك: اختار شكل، اسحب في المعاينة عشان تلفّه، ظبّط اللي انت عايزه، وهينزل على التايملاين بخلفية شفافة فوق الفيديو.',
    hint: 'اسحب يمين وشمال عشان تلف · فوق وتحت للزاوية · Shift+سحب عشان تحركه · العجلة للحجم · Ctrl+العجلة للمنظور · دبل كليك على كارت يجيبه قدام',
    play: 'شغّل', pause: 'وقّف', eye: 'المعاينة فوق الفيديو', undo: 'رجوع', redo: 'إعادة',
    looks: 'الشكل',
    l_ring: 'حلقة', l_ring_top: 'حلقة من فوق', l_ring_thick: 'كروت تخينة', l_inside: 'جوه الحلقة', l_coverflow: 'كوفر فلو',
    l_strip: 'شريط مايل', l_stack: 'رصّة كروت', l_fan: 'مروحة', l_wheel: 'عجلة', l_slot: 'بكرة لفوق', l_wall: 'حيطة',
    l_helix: 'حلزوني', l_orbit: 'مدار', l_arc: 'قوس', l_tunnel: 'نفق', l_sphere: 'كرة',
    media: 'الصور والفيديوهات', add_pc: 'من جهازك', add_tl: 'المختار في التايملاين', add_pr: 'المختار في البروجكت',
    pick_title: 'اختار صور أو فيديوهات للكاروسيل', media_hint: 'من غير صور هيستخدم كروت ملونة مترقمة عشان تشوف الشكل. اسحب الصور عشان ترتبها، ودوس على صورة عشان تجيبها قدام.',
    none_tl: 'اختار كليبات على التايملاين الأول', none_pr: 'اختار ملفات في الـ Project الأول', preparing: 'بجهّز {n}…', media_fail: 'مقدرتش أفتح «{n}»',
    clear: 'شيل الكل', count: 'عدد الكروت', count_auto: 'زي عدد الصور',
    motion: 'الحركة', mo_step: 'خطوة خطوة', mo_spin: 'لف مستمر', mo_once: 'لفة واحدة', mo_markers: 'على الماركرز', mo_still: 'ثابت',
    dur: 'المدة', speed: 'السرعة (ثانية لكل كارت)', hold: 'الوقفة على كل كارت', move: 'وقت اللفة', dir: 'الاتجاه', ease: 'إحساس الحركة',
    e_smooth: 'ناعمة', e_snappy: 'سريعة', e_spring: 'بتهتز', e_back: 'بترجع', e_linear: 'ثابتة',
    markers_hint: 'حط ماركرز على التايملاين (زرار M) في الأماكن اللي عايزه يلف فيها.', markers_n: '{n} ماركر جوه مدة الكاروسيل',
    in: 'الدخول', out: 'الخروج',
    i_none: 'من غير', i_fade: 'يظهر بهدوء', i_grow: 'يكبر', i_rise: 'يطلع من تحت', i_drop: 'ينزل ويرتد', i_unfold: 'يتفرد', i_spin: 'يلف وهو داخل', i_fly: 'ييجي من بعيد', i_pop: 'واحد ورا التاني',
    o_none: 'من غير', o_fade: 'يختفي بهدوء', o_shrink: 'يصغر', o_fall: 'يقع', o_fold: 'يتلم', o_spin: 'يلف وهو خارج', o_fly: 'يبعد',
    advanced: 'تحكم كامل',
    camera: 'الكاميرا', tilt: 'الزاوية من فوق', dist: 'قوة المنظور', yaw: 'لفة الكاميرا', roll: 'ميلان', size: 'الحجم', x: 'يمين وشمال', y: 'فوق وتحت',
    cam_move: 'حركة كاميرا من البداية للنهاية', cam_hint: 'ظبّط المعاينة واضغط «البداية»، وبعدين ظبّطها تاني واضغط «النهاية».',
    cam_start: 'خلّي ده البداية', cam_end: 'خلّي ده النهاية', cam_clear: 'من غير حركة كاميرا', cam_set: 'الكاميرا هتتحرك من البداية للنهاية', cam_a: 'البداية اتسجلت ✓', view_reset: 'رجّع الكاميرا',
    cards: 'شكل الكروت', aspect: 'مقاس الكارت', csize: 'حجم الكروت', gap: 'المسافة بين الكروت', radius: 'وسع الحلقة', angle: 'زاوية الكروت', rows: 'صفوف',
    corner: 'الزوايا', border: 'إطار', border_c: 'لون الإطار', shadow: 'ظل', reflect: 'انعكاس على الأرض', thick: 'تخن الكارت', thick_c: 'لون الجنب',
    backs: 'ضهر الكارت', b_mirror: 'الصورة معكوسة', b_dim: 'غامق', b_color: 'لون', b_hide: 'مخفي', back_c: 'لون الضهر',
    fit: 'الصورة جوه الكارت', f_cover: 'تملا الكارت', f_contain: 'كاملة',
    depth: 'العمق', blur: 'بلور اللي ورا', dim: 'تغميق اللي ورا', fade: 'شفافية اللي ورا', focus: 'تكبير الكارت اللي قدام', glow: 'توهج الكارت اللي قدام', glow_c: 'لون التوهج',
    in_d: 'مدة الدخول', out_d: 'مدة الخروج',
    bg: 'الخلفية', bg_none: 'شفافة', bg_color: 'لون', bg_blur: 'من الصورة نفسها', bg_alpha: 'قوة الخلفية', bg_c: 'لون الخلفية',
    split: 'حطني جوه الحلقة (Split)', split_hint: 'بيطلّع طبقتين: اللي ورا تحت الفيديو واللي قدام فوقه. عشان الشخص يبان جوه الحلقة لازم يكون عليه ماسك (Object Mask / Roto) أو تكون شايل خلفيته.',
    replace: 'بدّل الكاروسيل اللي حطيته قبل كده', place: 'حطه على التايملاين', cancel: 'وقّف', remove_last: 'شيل آخر كاروسيل',
    rendering: 'برسم الكاروسيل… {p}%', prep: 'بجهّز الفيديوهات… {p}%', loading: 'لسه بجهّز الصور…', placing: 'بحطه على التايملاين…',
    done: 'اتحط على {tr} عند {at}', done_split: 'اتحط: اللي ورا على {b} تحت الفيديو، واللي قدام على {tr}', done_above: 'اتحط: الطبقتين فوق الفيديو (مفيش تراك فاضي تحته)',
    took: 'خد {s} ثانية', failed: 'الكاروسيل ماتعملش', cancelled: 'اتوقف', no_webgl: 'كارت الشاشة مش متاح للبانل، مش هقدر أرسم الكاروسيل.',
    no_seq: 'افتح سيكوينس الأول', no_ff: 'مش لاقي ffmpeg. شغّل الـ installer تاني أو حط ffmpeg.exe في فولدر runtime جوه البلاجن.',
    removed: 'اتشال {n} من التايملاين', no_node: 'البانل شغّال من غير Node — الرندر والتايملاين مش هيشتغلوا هنا.'
  };
  function t(k, v) { var s = L[k] || k; if (v) for (var x in v) s = s.replace('{' + x + '}', v[x]); return s; }

  /* ---------------- tiny DOM kit ---------------- */
  function h(tag, attrs, kids) {
    var el = D.createElement(tag);
    for (var a in (attrs || {})) {
      var v = attrs[a];
      if (v === undefined || v === null || v === false) continue;
      if (a === 'class') el.className = v; else if (a === 'text') el.textContent = v; else if (a === 'html') el.innerHTML = v;
      else if (a.slice(0, 2) === 'on') el.addEventListener(a.slice(2), v); else el.setAttribute(a, v);
    }
    (kids || []).forEach(function (k) { if (k) el.appendChild(typeof k === 'string' ? D.createTextNode(k) : k); });
    return el;
  }
  var ICON = {
    play: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M7 4.5v15l13-7.5z"/></svg>',
    pause: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M6 4h4v16H6zM14 4h4v16h-4z"/></svg>',
    eye: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1.5 12S5.5 5 12 5s10.5 7 10.5 7-4 7-10.5 7S1.5 12 1.5 12z"/><circle cx="12" cy="12" r="3"/></svg>',
    undo: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M9 14 4 9l5-5"/><path d="M4 9h10a6 6 0 0 1 0 12h-3"/></svg>',
    folder: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h6l2 2h10v11H3z"/></svg>',
    tl: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="5" width="12" height="5" rx="1"/><rect x="8" y="14" width="13" height="5" rx="1"/></svg>',
    pr: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>',
    spark: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l2.2 6.6L21 11l-6.8 2.4L12 20l-2.2-6.6L3 11l6.8-2.4z"/></svg>'
  };

  /* ---------------- storage ---------------- */
  function load(k, d) { try { var v = G.localStorage.getItem('c3d_' + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } }
  function save(k, v) { try { G.localStorage.setItem('c3d_' + k, JSON.stringify(v)); } catch (e) {} }

  /* ---------------- state ---------------- */
  var S;                 // settings
  var items = [];        // media
  var ui = {}, ctl = {}; // elements
  var R = null;          // renderer
  var clock = { on: false, t: 1.4, last: 0 };
  var seqSize = { w: 1080, h: 1920 };
  var lastFrame = null, raf = 0, phAspect = 0;
  var hist = { past: [], future: [], cur: '', timer: 0 };
  var videos = {}, markers = [], busy = false, stop = false, lastPlaced = load('last', null);
  var IMG_EXT = ['jpg','jpeg','png','webp','gif','bmp','tif','tiff','heic','heif','psd','tga','avif','jfif'];
  var VID_EXT = ['mp4','mov','m4v','mkv','webm','avi','mxf','mts','m2ts','wmv','mpg','mpeg','3gp'];

  function initSettings() {
    var saved = load('set', null);
    if (saved && saved.layout && E.LAYOUTS[saved.layout]) return E.norm(saved);
    var s = E.withLook({ dur: 6, aspect: '9:16' }, 'ring'); return E.norm(s);
  }

  function set(patch, quiet) {
    for (var k in patch) S[k] = patch[k];
    save('set', S);
    if (!quiet) remember();
    visibility(); draw();
  }
  function remember() {
    clearTimeout(hist.timer);
    hist.timer = setTimeout(function () {
      hist.timer = 0;
      var now = JSON.stringify(S);
      if (now !== hist.cur) { hist.past.push(hist.cur); if (hist.past.length > 80) hist.past.shift(); hist.future = []; hist.cur = now; }
      undoState();
    }, 350);
  }
  function flushHist() { if (hist.timer) { clearTimeout(hist.timer); hist.timer = 0; var now = JSON.stringify(S); if (now !== hist.cur) { hist.past.push(hist.cur); hist.cur = now; } } }
  function undo() { flushHist(); if (!hist.past.length) return; hist.future.push(hist.cur); hist.cur = hist.past.pop(); S = JSON.parse(hist.cur); save('set', S); syncAll(); }
  function redo() { if (!hist.future.length) return; hist.past.push(hist.cur); hist.cur = hist.future.pop(); S = JSON.parse(hist.cur); save('set', S); syncAll(); }
  function undoState() { if (ui.undo) { ui.undo.disabled = !hist.past.length && !hist.timer; ui.redo.disabled = !hist.future.length; } }

  /* ---------------- controls ---------------- */
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function sec(v) { return (+v).toFixed(1) + ' ث'; }
  function deg(v) { return Math.round(v) + '°'; }
  function pct(v) { return Math.round(v * 100) + '%'; }
  var RANGES = {
    dur: [2, 30, .5, sec], secPerCard: [.3, 4, .05, sec], hold: [0, 4, .05, sec], move: [.15, 2.5, .05, sec],
    introDur: [.2, 2.5, .05, sec], outroDur: [.2, 2.5, .05, sec],
    tilt: [-30, 70, 1, deg], yaw: [-60, 60, 1, deg], roll: [-30, 30, 1, deg], persp: [0, 1, .01, pct], scale: [.25, 2.5, .01, pct],
    x: [0, 1, .005, pct], y: [0, 1, .005, pct],
    size: [.5, 1.8, .01, pct], gap: [-.2, 1, .01, pct], radius: [.6, 2.4, .01, pct], angle: [5, 85, 1, deg], rows: [1, 4, 1, String],
    corner: [0, .5, .01, pct], border: [0, 8, .1, function (v) { return (+v).toFixed(1); }], shadow: [0, 1, .01, pct], reflect: [0, 1, .01, pct],
    thick: [0, .08, .001, function (v) { return Math.round(v * 1000) / 10 + '%'; }],
    blur: [0, 1, .01, pct], dim: [0, 1, .01, pct], fade: [0, 1, .01, pct], focus: [1, 1.4, .01, pct], glow: [0, 1, .01, pct], bgAlpha: [0, 1, .01, pct]
  };
  /* "perspective" is the camera distance turned around: 0 = flat, 1 = strong */
  function distToP(d) { return clamp((6 - d) / 5.2, 0, 1); }
  function pToDist(p) { return Math.round((6 - 5.2 * p) * 100) / 100; }
  function valueOf(k) {
    if (k === 'persp') return distToP(+S.dist || 2.4);
    if (k === 'angle') return +S.angle > 0 ? +S.angle : (E.LAYOUTS[S.layout].angle || 30);
    return S[k];
  }
  function slider(k, label) {
    var r = RANGES[k], val = h('b'), inp = h('input', { type: 'range', min: r[0], max: r[1], step: r[2] });
    var box = h('div', { class: 'sld' }, [h('div', { class: 'top' }, [h('span', { text: t(label) }), val]), inp]);
    box.setValue = function (v) { inp.value = v; val.textContent = r[3](+v); };
    inp.addEventListener('input', function () {
      var v = parseFloat(inp.value), p = {};
      val.textContent = r[3](v);
      if (k === 'persp') p.dist = pToDist(v); else p[k] = v;
      set(p);
    });
    box.setValue(valueOf(k));
    ctl[k] = box; return box;
  }
  function seg(k, opts) {
    var box = h('div', { class: 'seg' });
    opts.forEach(function (o) {
      box.appendChild(h('button', { type: 'button', 'data-v': String(o.v), text: o.label, onclick: function () {
        var p = {}; p[k] = /^-?\d+(\.\d+)?$/.test(String(o.v)) && k !== 'aspect' ? +o.v : o.v; set(p); box.setValue(p[k]);
      } }));
    });
    box.setValue = function (v) { [].forEach.call(box.children, function (b) { b.classList.toggle('on', b.getAttribute('data-v') === String(v)); }); };
    box.setValue(S[k]); ctl[k] = box; return box;
  }
  function select(k, opts) {
    var el = h('select', { class: 'sel' }, opts.map(function (o) { return h('option', { value: o.v, text: o.label }); }));
    el.value = String(S[k]);
    el.addEventListener('change', function () { var p = {}; p[k] = /^-?\d+$/.test(el.value) ? +el.value : el.value; set(p); });
    el.setValue = function (v) { el.value = String(v); };
    ctl[k] = el; return el;
  }
  function color(k, label) {
    var inp = h('input', { type: 'color', value: String(S[k] || '#ffffff').slice(0, 7) });
    inp.addEventListener('input', function () { var p = {}; p[k] = inp.value; set(p); });
    var lab = h('label', { class: 'cfield' }, [inp, h('span', { text: t(label) })]);
    lab.setValue = function (v) { inp.value = String(v || '#ffffff').slice(0, 7); };
    ctl[k] = lab; return lab;
  }
  function field(label, el) { return h('div', { class: 'field' }, [label ? h('span', { class: 'lbl', text: t(label) }) : null, el]); }
  function section(title, kids, open) {
    var body = h('div', { class: 'sb' }, kids), box = h('div', { class: 'sec' + (open ? '' : ' closed') });
    var key = 'sec_' + title;
    if (load(key, open) === false) box.classList.add('closed'); else if (load(key, open)) box.classList.remove('closed');
    box.appendChild(h('div', { class: 'sh', text: t(title), onclick: function () { box.classList.toggle('closed'); save(key, !box.classList.contains('closed')); } }));
    box.appendChild(body); return box;
  }
  function toggle(label, val, onChange) {
    var el = h('div', { class: 'tg' + (val ? ' on' : '') }, [h('span', { text: t(label) }), h('span', { class: 'sw' })]);
    el.addEventListener('click', function () { var v = !el.classList.contains('on'); el.classList.toggle('on', v); onChange(v); });
    el.setValue = function (v) { el.classList.toggle('on', !!v); };
    return el;
  }
  function btn(label, cls, icon, onClick) {
    return h('button', { type: 'button', class: 'btn ' + (cls || ''), html: (icon ? ICON[icon] : '') + '<span></span>', onclick: onClick }, []);
  }
  function setBtnText(b, s) { b.querySelector('span').textContent = s; return b; }
  function status(el, kind, msg) { el.className = 'status ' + (kind || ''); el.textContent = msg || ''; }

  function syncAll() {
    Object.keys(ctl).forEach(function (k) {
      var c = ctl[k]; if (!c || !c.setValue) return;
      if (k === 'persp') c.setValue(distToP(+S.dist || 2.4));
      else if (k === 'split') c.setValue(S.split);
      else c.setValue(valueOf(k));
    });
    lookSel(); visibility(); camState(); undoState(); draw();
  }

  /* which controls make sense for this layout / motion */
  var ONLY = { radius: ['ring','inside','wheel','slot','orbit','helix','sphere'], angle: ['coverflow','strip','fan'], rows: ['wall'], reflect: ['ring','coverflow','arc','strip'] };
  function show(el, on) { if (el) el.classList.toggle('hide', !on); }
  function visibility() {
    Object.keys(ONLY).forEach(function (k) { show(ctl[k], ONLY[k].indexOf(S.layout) >= 0); });
    var m = S.motion;
    show(ctl.secPerCard, m === 'spin'); show(ctl.hold, m === 'step'); show(ctl.move, m === 'step' || m === 'markers');
    show(ui.easeRow, m !== 'spin' && m !== 'still'); show(ui.dirRow, m !== 'still'); show(ui.markRow, m === 'markers');
    show(ctl.bgColor, S.bg === 'color'); show(ctl.bgAlpha, S.bg !== 'none');
    show(ctl.backColor, S.backs === 'color'); show(ctl.glowColor, +S.glow > 0); show(ctl.borderColor, +S.border > 0); show(ctl.thickColor, +S.thick > 0);
    if (m === 'markers') fetchMarkers();
  }
  function fetchMarkers() {
    Sys.call('cr_info').then(function (r) {
      if (!r || !r.ok || !r.hasSequence) return null;
      return Sys.call('cr_markers', { from: r.t, to: r.t + (+S.dur || 6) }).then(function (m) {
        markers = (m && m.ok ? m.markers : []).map(function (x) { return x - r.t; });
        if (ui.markN) ui.markN.textContent = t('markers_n', { n: markers.length });
        draw();
      });
    }).catch(function () {});
  }

  /* ---------------- preview ---------------- */
  function phKey(i) { return 'ph' + (i % 12); }
  function fitStage() {
    if (!ui.stage) return;
    var w = Math.max(160, ui.pvWrap.clientWidth || 300), ar = seqSize.w / seqSize.h;
    var hh = Math.min(G.K.pvH(460), w / ar), ww = hh * ar;
    ui.stage.style.width = Math.round(ww) + 'px'; ui.stage.style.height = Math.round(hh) + 'px';
    var dpr = Math.min(2, G.devicePixelRatio || 1);
    if (R) R.resize(Math.round(ww * dpr), Math.round(hh * dpr));
  }
  function draw() { if (R && !raf && !busy) raf = (G.requestAnimationFrame || setTimeout)(paint); }
  function paint() {
    raf = 0; if (!R || busy) return;
    var now = Date.now();
    if (clock.on) { clock.t += Math.min(.1, (now - (clock.last || now)) / 1000); if (clock.t > S.dur) clock.t = 0; clock.last = now; }
    var ar = E.aspectOf(S.aspect);
    if (Math.abs(ar - phAspect) > 1e-6) { phAspect = ar; for (var i = 0; i < 12; i++) R.setImage('ph' + i, CarGL.placeholderCanvas(i, ar)); }
    items.forEach(function (it) {
      var v = videos[it.key];
      if (it.state === 'ready' && v && v.readyState >= 2 && (clock.on || !v.__drawn)) { R.setImage('k_' + it.key, v); v.__drawn = true; }
    });
    var cv = R.canvas;
    lastFrame = E.frame(S, { n: items.length, w: cv.width, h: cv.height, t: clock.t, markers: markers });
    R.draw(lastFrame, { media: items.map(function (it) { return it.state === 'ready' ? 'k_' + it.key : null; }), placeholder: phKey });
    ui.scrub.max = String(S.dur);
    if (!ui.scrub.__drag) ui.scrub.value = String(clock.t);
    ui.time.textContent = clock.t.toFixed(1) + ' / ' + (+S.dur).toFixed(1) + 's';
    if (clock.on) draw();
  }
  function playing(on) {
    clock.on = on; clock.last = Date.now();
    Object.keys(videos).forEach(function (k) { try { on ? videos[k].play() : videos[k].pause(); } catch (e) {} });
    ui.play.innerHTML = ICON[on ? 'pause' : 'play']; ui.play.title = t(on ? 'pause' : 'play');
    draw();
  }
  function seekVideos() {
    Object.keys(videos).forEach(function (k) {
      var v = videos[k]; try { if (v.duration) { v.currentTime = clock.t % v.duration; v.__drawn = false; } } catch (e) {}
    });
  }
  function glide(to) {   // animate the front card to `to`
    var from = +S.start || 0, t0 = Date.now();
    (function step() {
      var p = Math.min(1, (Date.now() - t0) / 260), e = 1 - Math.pow(1 - p, 3);
      S.start = from + (to - from) * e;
      if (p >= 1) { S.start = to; save('set', S); remember(); }
      draw(); if (p < 1) (G.requestAnimationFrame || setTimeout)(step);
    })();
  }
  function underlay() {
    var on = !!load('eye', false);
    ui.eye.classList.toggle('on', on); ui.stage.classList.toggle('over', on);
    if (!on) { ui.under.removeAttribute('src'); return; }
    Sys.call('cr_under').then(function (r) {
      if (!r || !r.ok || r.none || !r.path) return;
      return Sys.grabFrame(r.path, r.src, Math.round(seqSize.w / 2), Math.round(seqSize.h / 2)).then(function (p) { if (load('eye', false)) ui.under.src = Sys.url(p); });
    }).catch(function () {});
  }
  function bindStage(cv) {
    var drag = null;
    cv.addEventListener('pointerdown', function (e) {
      if (busy) return; e.preventDefault();
      try { cv.setPointerCapture(e.pointerId); } catch (x) {}
      cv.focus();
      drag = { x: e.clientX, y: e.clientY, start: +S.start || 0, tilt: +S.tilt || 0, px: +S.x, py: +S.y, move: e.shiftKey, moved: false };
      if (clock.on) playing(false);
    });
    cv.addEventListener('pointermove', function (e) {
      if (!drag) return;
      var dx = e.clientX - drag.x, dy = e.clientY - drag.y;
      if (Math.abs(dx) + Math.abs(dy) > 2) drag.moved = true;
      var rc = cv.getBoundingClientRect();
      if (drag.move) { set({ x: clamp(drag.px + dx / rc.width, -.2, 1.2), y: clamp(drag.py + dy / rc.height, -.2, 1.2) }, true); ctl.x.setValue(S.x); ctl.y.setValue(S.y); return; }
      var cardPx = lastFrame ? Math.max(20, lastFrame.W * lastFrame.cam.s * rc.height) : 80;
      var vertical = S.layout === 'slot' || S.layout === 'wheel';
      var p = { start: drag.start + (vertical ? -dy : (G.document.dir === 'rtl' ? -dx : -dx)) / cardPx };
      if (!vertical) p.tilt = clamp(drag.tilt + dy * .25, -30, 70);
      set(p, true); ctl.tilt.setValue(S.tilt);
    });
    function end() { if (!drag) return; var d = drag; drag = null; if (d.moved) { if (S.motion !== 'spin') glide(Math.round(+S.start || 0)); remember(); } }
    cv.addEventListener('pointerup', end); cv.addEventListener('pointercancel', end);
    cv.addEventListener('dblclick', function (e) {
      if (!lastFrame) return;
      var rc = cv.getBoundingClientRect(), k = cv.width / Math.max(1, rc.width);
      var c = E.hit(lastFrame, (e.clientX - rc.left) * k, (e.clientY - rc.top) * k);
      if (c) glide((+S.start || 0) + E.wrapC(c.slot - lastFrame.f, lastFrame.N));
    });
    cv.addEventListener('wheel', function (e) {
      e.preventDefault();
      var f = Math.pow(1.0012, -e.deltaY);
      if (e.ctrlKey || e.altKey) { set({ dist: clamp((+S.dist || 2.4) / f, .8, 6) }, true); ctl.persp.setValue(distToP(S.dist)); }
      else { set({ scale: clamp((+S.scale || 1) * f, .25, 2.5) }, true); ctl.scale.setValue(S.scale); }
      remember();
    }, { passive: false });
    cv.addEventListener('keydown', function (e) {
      var k = e.key;
      if (k === 'ArrowLeft' || k === 'ArrowRight') { e.preventDefault(); glide(Math.round(+S.start || 0) + (k === 'ArrowLeft' ? 1 : -1)); }
      else if (k === 'ArrowUp' || k === 'ArrowDown') { e.preventDefault(); set({ tilt: clamp((+S.tilt || 0) + (k === 'ArrowUp' ? 2 : -2), -30, 70) }); ctl.tilt.setValue(S.tilt); }
      else if (k === '+' || k === '=') { set({ scale: clamp((+S.scale || 1) * 1.06, .25, 2.5) }); ctl.scale.setValue(S.scale); }
      else if (k === '-' || k === '_') { set({ scale: clamp((+S.scale || 1) / 1.06, .25, 2.5) }); ctl.scale.setValue(S.scale); }
      else if (k === ' ') { e.preventDefault(); playing(!clock.on); }
      else if ((e.ctrlKey || e.metaKey) && (k === 'z' || k === 'Z')) { e.preventDefault(); e.shiftKey ? redo() : undo(); }
      else if ((e.ctrlKey || e.metaKey) && (k === 'y' || k === 'Y')) { e.preventDefault(); redo(); }
    });
  }

  /* ---------------- media ---------------- */
  function saveItems() { save('items', items.map(function (it) { return { path: it.path, from: it.from || 0, name: it.name }; })); }
  function addPaths(list) {
    var added = [];
    (list || []).forEach(function (x) {
      var o = typeof x === 'string' ? { path: x } : x;
      if (!o || !o.path) return;
      var it = { path: o.path, from: +o.from || 0, name: o.name || String(o.path).split(/[\\\/]/).pop(), state: 'loading', key: '' };
      items.push(it); added.push(it);
    });
    if (!added.length) return Promise.resolve();
    saveItems(); strip();
    return added.reduce(function (p, it) {
      return p.then(function () {
        status(ui.mStat, 'busy', t('preparing', { n: it.name }));
        return Sys.media(it.path, it.from).then(function (m) {
          it.kind = m.kind; it.view = m.view; it.thumb = m.thumb; it.w = m.w; it.h = m.h; it.dur = m.dur; it.key = m.key;
          return toTexture(it);
        }).then(function () { it.state = 'ready'; }, function (e) {
          it.state = 'error'; it.err = String(e && e.message || e).slice(0, 200);
          status(ui.mStat, 'err', t('media_fail', { n: it.name }));
        }).then(function () { strip(); draw(); });
      });
    }, Promise.resolve()).then(function () { if (!items.some(function (i) { return i.state === 'error'; })) status(ui.mStat, '', ''); });
  }
  function toTexture(it) {
    if (!R) return Promise.resolve();
    if (it.kind === 'video' && /\.webm$/i.test(it.view)) {
      var v = videos[it.key];
      if (!v) {
        v = D.createElement('video'); v.muted = true; v.loop = true; v.preload = 'auto'; v.playsInline = true;
        v.src = Sys.url(it.view); videos[it.key] = v;
      }
      return new Promise(function (res) {
        var done = false; function ok() { if (done) return; done = true; v.__drawn = false; draw(); res(); }
        v.addEventListener('loadeddata', ok, { once: true }); v.addEventListener('error', ok, { once: true }); setTimeout(ok, 6000);
        if (clock.on) try { v.play(); } catch (e) {}
      });
    }
    return new Promise(function (res, rej) {
      var im = new Image();
      im.onload = function () { R.setImage('k_' + it.key, im); res(); };
      im.onerror = function () { rej(new Error('image_load')); };
      im.src = Sys.url(it.view);
    });
  }
  function removeItem(i) {
    var it = items.splice(i, 1)[0];
    if (it && it.key && !items.some(function (x) { return x.key === it.key; })) {
      if (videos[it.key]) { try { videos[it.key].pause(); videos[it.key].removeAttribute('src'); } catch (e) {} delete videos[it.key]; }
      if (R) R.drop('k_' + it.key);
    }
    saveItems(); strip(); draw();
  }
  function strip() {
    var s = ui.strip; if (!s) return; s.innerHTML = '';
    items.forEach(function (it, i) {
      var el = h('div', { class: 'th' + (it.state === 'error' ? ' err' : it.state === 'loading' ? ' busy' : ''), draggable: 'true', title: it.name + (it.err ? ' — ' + it.err : '') }, [
        it.thumb ? h('img', { src: Sys.url(it.thumb), draggable: 'false' }) : h('div', { class: 'ph', text: String(i + 1) }),
        it.kind === 'video' ? h('span', { class: 'v', text: '▶' }) : null,
        h('span', { class: 'n', text: String(i + 1) }),
        h('button', { type: 'button', class: 'x', html: '&times;', onclick: function (e) { e.stopPropagation(); removeItem(i); } })
      ]);
      el.addEventListener('click', function () { glide(i); });
      el.addEventListener('dragstart', function (e) { e.dataTransfer.setData('text/plain', 'c3d:' + i); });
      el.addEventListener('dragover', function (e) { e.preventDefault(); el.classList.add('over'); });
      el.addEventListener('dragleave', function () { el.classList.remove('over'); });
      el.addEventListener('drop', function (e) {
        e.preventDefault(); el.classList.remove('over');
        var m = /^c3d:(\d+)$/.exec(e.dataTransfer.getData('text/plain') || ''); if (!m) return;
        var from = +m[1]; if (from === i) return;
        var x = items.splice(from, 1)[0]; items.splice(i, 0, x); saveItems(); strip(); draw();
      });
      s.appendChild(el);
    });
    show(ui.clearBtn, items.length > 0); show(ui.mHint, items.length < 2);
  }
  function pickPC() {
    var list = Sys.pickFiles(t('pick_title'), IMG_EXT.concat(VID_EXT));
    if (list && list.length) addPaths(list);
  }
  function pickHost(from) {
    Sys.call('cr_pick', { from: from }).then(function (r) {
      if (!r || !r.ok) return status(ui.mStat, 'err', r && r.error === 'no_sequence' ? t('no_seq') : t('failed') + ' [' + (r && (r.error || r.detail)) + ']');
      if (!r.items || !r.items.length) return status(ui.mStat, 'warn', t(from === 'project' ? 'none_pr' : 'none_tl'));
      addPaths(r.items);
    });
  }

  /* ---------------- looks ---------------- */
  function lookSel() {
    if (!ui.looks) return;
    [].forEach.call(ui.looks.children, function (b) {
      var on = b.getAttribute('data-id') === S.look; b.classList.toggle('on', on);
      var img = b.querySelector('img'), want = 'assets/looks/' + b.getAttribute('data-id') + (on || b.__hover ? '.webp' : '.jpg');
      if (img.getAttribute('src') !== want) img.setAttribute('src', want);
    });
  }
  function pickLook(id) {
    var keep = {}, L0 = E.look(id);
    ['dur','aspect','x','scale','size','bg','bgColor','bgAlpha','dir','count','fit','border','borderColor','split','glowColor','thickColor','backs','backColor','outro','outroDur','introDur'].forEach(function (k) { keep[k] = S[k]; });
    S = E.norm(E.withLook(S, id));
    for (var k in keep) S[k] = keep[k];
    if (L0.set.aspect) S.aspect = L0.set.aspect;
    S.y = L0.set.y !== undefined ? L0.set.y : .5;
    save('set', S); remember(); syncAll();
  }

  /* ---------------- camera move ---------------- */
  function camNow() { return { tilt: +S.tilt || 0, yaw: +S.yaw || 0, roll: +S.roll || 0, dist: +S.dist || 2.4, x: +S.x, y: +S.y, scale: +S.scale || 1 }; }
  function camState() {
    if (!ui.camState) return;
    ui.camState.textContent = S.cam2 ? t('cam_set') : S.camA ? t('cam_a') : '';
    show(ui.camClear, !!S.cam2);
  }

  /* ---------------- render & place ---------------- */
  function progress(p) { ui.progBar.style.width = Math.round(p * 100) + '%'; }
  function placeIt() {
    if (busy) return;
    if (!Sys.hasNode) return status(ui.status, 'err', t('no_node'));
    if (items.some(function (i) { return i.state === 'loading'; })) return status(ui.status, 'warn', t('loading'));
    Sys.ffAvailable().then(function (ok) {
      if (!ok) { status(ui.status, 'err', t('no_ff')); return; }
      busy = true; stop = false; ui.place.disabled = true; show(ui.stop, true);
      if (clock.on) playing(false);
      progress(0); status(ui.status, 'busy', t('rendering', { p: 0 }));
      var info = null, dur = +S.dur || 6, mk = [];
      Sys.call('cr_info').then(function (r) {
        if (!r || !r.ok || !r.hasSequence) throw new Error('no_seq');
        info = r;
        if (S.motion !== 'markers') return null;
        return Sys.call('cr_markers', { from: r.t, to: r.t + dur }).then(function (m) { mk = (m && m.ok ? m.markers : []).map(function (x) { return x - r.t; }); });
      }).then(function () {
        var ready = items.filter(function (i) { return i.state === 'ready'; });
        var outDir = info.dir ? Sys.join(info.dir, 'ENP Renders') : '';
        return CarRender.render({
          R: R, settings: JSON.parse(JSON.stringify(S)), items: ready, frame: { w: info.w || seqSize.w, h: info.h || seqSize.h },
          fps: info.fps || 30, dur: dur, markers: mk, outDir: outDir, look: S.look, placeholder: phKey,
          onProgress: function (p, phase) { progress(p * .97); status(ui.status, 'busy', t(phase === 'prep' ? 'prep' : 'rendering', { p: Math.round(p * 100) })); },
          cancelled: function () { return stop; }
        });
      }).then(function (out) {
        status(ui.status, 'busy', t('placing'));
        var rep = load('replace', true) && lastPlaced ? lastPlaced.names : [];
        return Sys.call('cr_place', { front: out.path, back: out.back || '', at: info.t, duration: out.duration, replace: rep }).then(function (r) {
          if (!r || !r.ok) throw new Error(r && (r.error || r.detail) || 'place_failed');
          lastPlaced = { names: r.names || [], at: info.t }; save('last', lastPlaced); show(ui.removeBtn, true);
          var msg = r.back ? (r.backAbove ? t('done_above') : t('done_split', { b: r.back, tr: r.track })) : t('done', { tr: r.track, at: tc(info.t, info.fps) });
          progress(1); status(ui.status, 'ok', msg + ' · ' + t('took', { s: Math.round(out.ms / 100) / 10 }));
        });
      }).catch(function (e) {
        var m = e && e.message || String(e);
        if (m === 'cancelled') status(ui.status, 'warn', t('cancelled'));
        else if (m === 'no_seq') status(ui.status, 'err', t('no_seq'));
        else status(ui.status, 'err', t('failed') + '  [' + m.slice(0, 160) + ']');
        try { console.warn('[carousel3d]', e); } catch (x) {}
      }).then(function () {
        busy = false; ui.place.disabled = false; show(ui.stop, false);
        // back to preview size and textures
        fitStage(); items.forEach(function (it) { if (it.state === 'ready') toTexture(it).then(draw); }); draw();
      });
    });
  }
  function tc(sec, fps) {
    fps = Math.round(fps || 30); var f = Math.floor(sec * fps + 1e-6), ff = f % fps, s = Math.floor(f / fps);
    function p2(n) { return ('0' + n).slice(-2); }
    return p2(Math.floor(s / 3600)) + ':' + p2(Math.floor(s / 60) % 60) + ':' + p2(s % 60) + ':' + p2(ff);
  }
  function removeLast() {
    if (!lastPlaced || !lastPlaced.names) return;
    Sys.call('cr_remove', { names: lastPlaced.names }).then(function (r) {
      if (r && r.ok) { status(ui.status, 'ok', t('removed', { n: r.removed || 0 })); lastPlaced = null; save('last', null); show(ui.removeBtn, false); }
      else status(ui.status, 'err', t('failed'));
    });
  }

  /* ---------------- build ---------------- */
  function build() {
    S = initSettings(); hist.cur = JSON.stringify(S);
    var root = D.getElementById('tab-carousel');

    ui.cv = h('canvas', { tabindex: '0' });
    ui.under = h('img', { class: 'under', alt: '' });
    ui.stage = h('div', { class: 'stage' }, [ui.under, ui.cv]);
    ui.pvWrap = h('div', { class: 'pvwrap' }, [ui.stage]);
    ui.play = h('button', { type: 'button', class: 'ibtn', title: t('play'), html: ICON.play, onclick: function () { playing(!clock.on); } });
    ui.scrub = h('input', { type: 'range', class: 'scrub', min: 0, max: S.dur, step: .01, value: clock.t });
    ui.scrub.addEventListener('input', function () { ui.scrub.__drag = true; clock.t = parseFloat(ui.scrub.value) || 0; if (clock.on) playing(false); seekVideos(); draw(); });
    ui.scrub.addEventListener('change', function () { ui.scrub.__drag = false; });
    ui.time = h('span', { class: 'time' });
    ui.eye = h('button', { type: 'button', class: 'ibtn', title: t('eye'), html: ICON.eye, onclick: function () { save('eye', !load('eye', false)); underlay(); } });
    ui.undo = h('button', { type: 'button', class: 'ibtn', title: t('undo'), html: ICON.undo, onclick: undo });
    ui.redo = h('button', { type: 'button', class: 'ibtn flip', title: t('redo'), html: ICON.undo, onclick: redo });

    try { R = CarGL.create(ui.cv); } catch (e) { R = null; try { console.warn(e); } catch (x) {} }
    if (R) bindStage(ui.cv);

    /* looks */
    ui.looks = h('div', { class: 'looks' });
    E.LOOKS.forEach(function (lk) {
      var b = h('button', { type: 'button', class: 'look', 'data-id': lk.id, onclick: function () { pickLook(lk.id); } },
        [h('img', { src: 'assets/looks/' + lk.id + '.jpg', alt: '', draggable: 'false' }), h('span', { text: t('l_' + lk.id) })]);
      b.addEventListener('mouseenter', function () { b.__hover = true; lookSel(); });
      b.addEventListener('mouseleave', function () { b.__hover = false; lookSel(); });
      ui.looks.appendChild(b);
    });
    ui.looks.addEventListener('wheel', function (e) { if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) { e.preventDefault(); ui.looks.scrollLeft -= e.deltaY; } }, { passive: false });

    /* media */
    ui.strip = h('div', { class: 'strip' });
    ui.mStat = h('div', { class: 'status' });
    ui.mHint = h('div', { class: 'hint', text: t('media_hint'), style: 'margin-top:8px' });
    ui.clearBtn = setBtnText(btn('', 'ghost', null, function () { while (items.length) removeItem(0); }), t('clear'));
    var count = h('select', { class: 'sel' }, [h('option', { value: '0', text: t('count_auto') })].concat([3,4,5,6,7,8,9,10,12,14,16,20,24].map(function (n) { return h('option', { value: String(n), text: String(n) }); })));
    count.value = String(S.count || 0);
    count.addEventListener('change', function () { set({ count: +count.value }); });
    count.setValue = function (v) { count.value = String(v || 0); }; ctl.count = count;
    var mediaSec = section('media', [
      h('div', { class: 'adds' }, [
        setBtnText(btn('', '', 'folder', pickPC), t('add_pc')),
        setBtnText(btn('', '', 'tl', function () { pickHost('timeline'); }), t('add_tl')),
        setBtnText(btn('', '', 'pr', function () { pickHost('project'); }), t('add_pr'))
      ]),
      ui.strip, ui.mStat, ui.mHint,
      h('div', { class: 'row' }, [h('span', { class: 'lbl', text: t('count') }), count, ui.clearBtn])
    ], true);

    /* motion */
    ui.dirRow = field('dir', seg('dir', [{ v: -1, label: '→' }, { v: 1, label: '←' }]));
    ui.easeRow = field('ease', seg('ease', ['smooth','snappy','spring','back','linear'].map(function (k) { return { v: k, label: t('e_' + k) }; })));
    ui.markN = h('div', { class: 'hint' });
    ui.markRow = h('div', { class: 'field' }, [h('div', { class: 'hint', text: t('markers_hint') }), ui.markN]);
    var motionSec = section('motion', [
      field('', seg('motion', ['step','spin','once','markers','still'].map(function (k) { return { v: k, label: t('mo_' + k) }; }))),
      ui.markRow, slider('dur', 'dur'), slider('secPerCard', 'speed'), slider('hold', 'hold'), slider('move', 'move'),
      ui.dirRow, ui.easeRow,
      h('div', { class: 'two' }, [
        field('in', select('intro', ['none','fade','grow','rise','drop','unfold','spin','fly','pop'].map(function (k) { return { v: k, label: t('i_' + k) }; }))),
        field('out', select('outro', ['none','fade','shrink','fall','fold','spin','fly'].map(function (k) { return { v: k, label: t('o_' + k) }; })))
      ])
    ], true);

    /* camera */
    ui.camState = h('div', { class: 'hint', style: 'color:var(--acc2);margin-top:6px' });
    ui.camClear = setBtnText(btn('', 'ghost', null, function () { set({ cam2: null, camA: null }); camState(); }), t('cam_clear'));
    var camSec = section('camera', [
      slider('tilt', 'tilt'), slider('persp', 'dist'), slider('yaw', 'yaw'), slider('roll', 'roll'), slider('scale', 'size'), slider('x', 'x'), slider('y', 'y'),
      h('div', { class: 'cam' }, [
        h('div', { text: t('cam_move') }), h('div', { class: 'hint', text: t('cam_hint') }),
        h('div', { class: 'adds' }, [
          setBtnText(btn('', '', null, function () { set({ camA: camNow() }); camState(); }), t('cam_start')),
          setBtnText(btn('', '', null, function () {
            var end = camNow(), a = S.camA, p = { cam2: end };
            if (a) { p.tilt = a.tilt; p.yaw = a.yaw; p.roll = a.roll; p.dist = a.dist; p.x = a.x; p.y = a.y; p.scale = a.scale; }
            set(p); syncAll();
          }), t('cam_end')),
          ui.camClear
        ]), ui.camState
      ]),
      h('div', { style: 'margin-top:8px' }, [setBtnText(btn('', 'ghost', null, function () {
        var lk = E.look(S.look || 'ring');
        set({ tilt: lk.set.tilt !== undefined ? lk.set.tilt : 8, yaw: 0, roll: 0, dist: lk.set.dist || 2.4, x: .5, y: lk.set.y !== undefined ? lk.set.y : .5, scale: 1, cam2: null, camA: null });
        syncAll();
      }), t('view_reset'))])
    ], false);

    /* cards */
    var cardSec = section('cards', [
      field('aspect', seg('aspect', ['9:16','4:5','1:1','16:9'].map(function (a) { return { v: a, label: a }; }))),
      slider('size', 'csize'), slider('gap', 'gap'), slider('radius', 'radius'), slider('angle', 'angle'), slider('rows', 'rows'),
      slider('corner', 'corner'), slider('border', 'border'), h('div', { class: 'crow' }, [color('borderColor', 'border_c')]),
      slider('shadow', 'shadow'), slider('reflect', 'reflect'), slider('thick', 'thick'), h('div', { class: 'crow' }, [color('thickColor', 'thick_c')]),
      field('backs', seg('backs', ['mirror','dim','color','hide'].map(function (k) { return { v: k, label: t('b_' + k) }; }))),
      h('div', { class: 'crow' }, [color('backColor', 'back_c')]),
      field('fit', seg('fit', [{ v: 'cover', label: t('f_cover') }, { v: 'contain', label: t('f_contain') }]))
    ], false);

    var depthSec = section('depth', [
      slider('blur', 'blur'), slider('dim', 'dim'), slider('fade', 'fade'), slider('focus', 'focus'), slider('glow', 'glow'),
      h('div', { class: 'crow' }, [color('glowColor', 'glow_c')]), slider('introDur', 'in_d'), slider('outroDur', 'out_d')
    ], false);

    var bgSec = section('bg', [
      field('', seg('bg', [{ v: 'none', label: t('bg_none') }, { v: 'color', label: t('bg_color') }, { v: 'blur', label: t('bg_blur') }])),
      h('div', { class: 'crow' }, [color('bgColor', 'bg_c')]), slider('bgAlpha', 'bg_alpha')
    ], false);

    ui.adv = h('div', {}, [camSec, cardSec, depthSec, bgSec]);
    show(ui.adv, load('adv', false));
    var advT = toggle('advanced', load('adv', false), function (v) { save('adv', v); show(ui.adv, v); });

    /* output */
    var splitT = toggle('split', !!S.split, function (v) { set({ split: v }); }); ctl.split = splitT;
    var repT = toggle('replace', load('replace', true) !== false, function (v) { save('replace', v); });
    ui.place = btn('', 'pri', 'spark', placeIt); setBtnText(ui.place, t('place'));
    ui.stop = setBtnText(btn('', '', null, function () { stop = true; }), t('cancel')); show(ui.stop, false);
    ui.removeBtn = setBtnText(btn('', 'ghost', 'undo', removeLast), t('remove_last')); show(ui.removeBtn, !!lastPlaced);
    ui.progBar = h('i'); ui.status = h('div', { class: 'status' });

    root.appendChild(h('div', { class: 'hint intro', text: t('intro') }));
    if (!R) root.appendChild(h('div', { class: 'notice', text: t('no_webgl') }));
    if (!Sys.hasNode) root.appendChild(h('div', { class: 'notice', text: t('no_node') }));
    root.appendChild(h('div', { class: 'pv' }, [ui.pvWrap, h('div', { class: 'bar' }, [ui.play, ui.scrub, ui.time, ui.eye, ui.undo, ui.redo]), h('div', { class: 'hint', style: 'margin-top:6px', text: t('hint') })]));
    root.appendChild(h('div', { class: 'looks-t', text: t('looks') }));
    root.appendChild(ui.looks);
    root.appendChild(mediaSec);
    root.appendChild(motionSec);
    root.appendChild(h('div', { class: 'advtgl' }, [advT]));
    root.appendChild(ui.adv);
    root.appendChild(h('div', { class: 'out' }, [splitT, h('div', { class: 'hint', text: t('split_hint') }), repT,
      h('div', { style: 'margin-top:12px' }, [ui.place]), h('div', { class: 'tk' }, [ui.stop, ui.removeBtn]),
      h('div', { class: 'prog' }, [ui.progBar]), ui.status]));

    lookSel(); visibility(); camState(); undoState(); strip();
    var saved = load('items', []);
    if (saved.length && Sys.hasNode) addPaths(saved);
    setTimeout(function () { fitStage(); draw(); }, 0);
    G.addEventListener('resize', function () { fitStage(); draw(); });

    /* follow the active sequence's frame size */
    function syncSeq() {
      Sys.call('cr_info').then(function (r) {
        if (r && r.ok && r.hasSequence && r.w > 0 && r.h > 0 && (r.w !== seqSize.w || r.h !== seqSize.h)) { seqSize = { w: r.w, h: r.h }; fitStage(); draw(); }
      });
    }
    syncSeq();
    G.addEventListener('focus', function () { syncSeq(); if (load('eye', false)) underlay(); });
    if (load('eye', false)) underlay();
  }

  G.Carousel3D = { get settings() { return S; }, items: function () { return items; }, set: set, addPaths: addPaths, play: playing, clock: clock };
  if (D.readyState === 'loading') D.addEventListener('DOMContentLoaded', build); else build();
})(window);
