/* ENP — navigation: a short row of sections, then that section's tools in one scrolling row.
   Each tab is built the first time it's opened. The nav and every tab's preview stay put while the settings scroll. */
(function (G) {
  'use strict';
  var D = G.document, built = { carousel: true }, cur = null;
  var MOD = { text: 'TextTab', glass: 'GlassTab', fx: 'FxTab', path: 'PathTab', cut: 'CutTab', caption: 'CaptionTab', curves: 'CurvesTab', zoom: 'ZoomTab', track: 'TrackTab', sfx: 'SfxTab',
    clean: 'AudioCleanTab', ramp: 'SpeedRampTab', safe: 'SafeTab', icons: 'IconsTab', filters: 'FiltersTab', trans: 'TransTab', organize: 'OrganizeTab', admin: 'AdminTab' };
  var CATS = [{ id: 'gfx', name: 'جرافيك', ic: '✦' }, { id: 'vid', name: 'فيديو', ic: '▶' }, { id: 'aud', name: 'كلام وصوت', ic: '♪' }, { id: 'prj', name: 'المشروع', ic: '▦' }];
  var nav = D.getElementById('tabs'), cats = D.getElementById('cats'), tools = D.getElementById('tools');
  function store(k, v) { try { if (v === undefined) return G.localStorage.getItem(k); G.localStorage.setItem(k, v); } catch (e) {} return null; }
  if (G.AdminTab) {
    var b = D.createElement('button'); b.type = 'button'; b.setAttribute('data-tab', 'admin'); b.setAttribute('data-cat', 'prj'); b.textContent = 'التحكم'; b.className = 'admbtn';
    tools.appendChild(b);
  }
  function btns() { return [].slice.call(tools.querySelectorAll('button')); }
  function catOf(id) { var b = tools.querySelector('button[data-tab="' + id + '"]'); return b ? b.getAttribute('data-cat') : 'gfx'; }
  CATS.forEach(function (c) {
    var b = D.createElement('button'); b.type = 'button'; b.setAttribute('data-cat', c.id);
    b.innerHTML = '<i>' + c.ic + '</i><span></span>'; b.querySelector('span').textContent = c.name;
    b.addEventListener('click', function () { show(store('enp_tab_' + c.id) || btns().filter(function (x) { return x.getAttribute('data-cat') === c.id; })[0].getAttribute('data-tab')); });
    cats.appendChild(b);
  });
  function navH() { D.documentElement.style.setProperty('--navh', Math.round(nav.getBoundingClientRect().height) + 'px'); }
  function show(id) {
    if (cur === id) return;
    if (cur && MOD[cur] && G[MOD[cur]] && G[MOD[cur]].onHide) G[MOD[cur]].onHide();
    if (cur === 'carousel' && G.Carousel3D && G.Carousel3D.clock.on) G.Carousel3D.play(false);
    cur = id; var cat = catOf(id); store('enp_tab_' + cat, id);
    [].forEach.call(cats.children, function (b) { b.classList.toggle('on', b.getAttribute('data-cat') === cat); });
    btns().forEach(function (b) { b.classList.toggle('hide', b.getAttribute('data-cat') !== cat); b.classList.toggle('on', b.getAttribute('data-tab') === id); });
    var on = tools.querySelector('button.on'); if (on && on.scrollIntoView) try { on.scrollIntoView({ block: 'nearest', inline: 'center' }); } catch (e) {}
    [].forEach.call(D.querySelectorAll('.tab'), function (t) { t.classList.toggle('hide', t.id !== 'tab-' + id); });
    var el = D.getElementById('tab-' + id);
    if (el) { el.classList.remove('enter'); void el.offsetWidth; el.classList.add('enter'); }
    if (!built[id] && MOD[id] && G[MOD[id]]) { built[id] = true; try { G[MOD[id]].build(el); } catch (e) { el.textContent = String(e && e.stack || e); } }
    if (el) { var pv = el.querySelector(':scope > .pv'); if (pv) pv.classList.add('pvsticky'); }
    if (MOD[id] && G[MOD[id]] && G[MOD[id]].onShow) G[MOD[id]].onShow();
    store('enp_tab', id);
    G.scrollTo(0, 0); navH();
    setTimeout(function () { navH(); G.dispatchEvent(new Event('resize')); }, 0);
  }
  btns().forEach(function (b) { b.addEventListener('click', function () { show(b.getAttribute('data-tab')); }); });
  /* the mouse wheel scrolls the tool row sideways */
  tools.addEventListener('wheel', function (e) { if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) { tools.scrollLeft -= e.deltaY; e.preventDefault(); } }, { passive: false });
  G.addEventListener('resize', navH);
  var first = store('enp_tab') || 'carousel';
  if (first !== 'carousel' && !(MOD[first] && G[MOD[first]])) first = 'carousel';
  show(first);
  /* the panel started fine: an update that just went in is confirmed */
  setTimeout(function () { if (G.ENPBootOK) G.ENPBootOK(); }, 5000);
})(window);
