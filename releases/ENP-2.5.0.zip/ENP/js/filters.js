/* ENP — filters & colour: cinematic looks (built-in LUTs + your own .cube files), log-to-Rec.709, colour controls,
   fish-eye lens, vignette, grain, halation, letterbox bars, and background removal (green / blue screen or a clean
   background plate). One WebGL pipeline draws both the live preview and the final render, so what you see is what you get. */
(function (G) {
  'use strict';
  var K = G.K, h = K.h, st = K.store('enp_flt_');
  function cl(v, a, b) { return v < a ? a : v > b ? b : v; }
  function luma(c) { return c[0] * .2126 + c[1] * .7152 + c[2] * .0722; }
  function mixc(a, b, k) { return [a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k, a[2] + (b[2] - a[2]) * k]; }
  function sat(c, s) { var l = luma(c); return [l + (c[0] - l) * s, l + (c[1] - l) * s, l + (c[2] - l) * s]; }
  function scurve(c, k) { return c.map(function (v) { v = cl(v, 0, 1); var s = v * v * (3 - 2 * v); return v + (s - v) * k; }); }
  function lgg(c, lift, gamma, gain) { return c.map(function (v, i) { v = gain[i] * (v + lift[i] * (1 - v)); return Math.pow(Math.max(0, v), 1 / gamma[i]); }); }
  function split(c, sh, hi, amt) { var l = luma(c), a = Math.pow(1 - l, 2) * amt, b = Math.pow(l, 2) * amt; return [c[0] + (sh[0] - .5) * a + (hi[0] - .5) * b, c[1] + (sh[1] - .5) * a + (hi[1] - .5) * b, c[2] + (sh[2] - .5) * a + (hi[2] - .5) * b]; }
  function fade(c, f) { return c.map(function (v) { return v * (1 - f) + f * .12 + (v > .85 ? 0 : 0); }); }
  function hueSkew(c, warm, cool) {   // push warm hues toward orange, cool hues toward teal
    var r = c[0], g = c[1], b = c[2], w = cl(r - b, 0, 1), q = cl(b - r, 0, 1);
    return [r + w * warm * .25 - q * cool * .12, g + w * warm * .05 + q * cool * .06, b - w * warm * .2 + q * cool * .2];
  }
  function aces(x) { return cl((x * (2.51 * x + .03)) / (x * (2.43 * x + .59) + .14), 0, 1); }
  function oetf(v) { return v <= .0031308 ? v * 12.92 : 1.055 * Math.pow(v, 1 / 2.4) - .055; }
  var LOG = {
    slog3: function (x) { return x >= 171.2102946929 / 1023 ? Math.pow(10, (x * 1023 - 420) / 261.5) * .19 - .01 : (x * 1023 - 95) * .01125 / (171.2102946929 - 95); },
    logc3: function (x) { return x > 5.367655 * .010591 + .092809 ? (Math.pow(10, (x - .385537) / .24719) - .052272) / 5.555556 : (x - .092809) / 5.367655; },
    vlog: function (x) { return x < .181 ? (x - .125) / 5.6 : Math.pow(10, (x - .598206) / .241514) - .00873; },
    clog3: function (x) { return x < .097465473 ? -(Math.pow(10, (.12783901 - x) / .36726845) - 1) / 14.98325 : x <= .15277891 ? (x - .12512219) / 1.9754798 : (Math.pow(10, (x - .12240537) / .36726845) - 1) / 14.98325; }
  };
  function fromLog(f) { return function (c) { return c.map(function (v) { return oetf(aces(Math.max(0, f(v)) * .8)); }); }; }

  /* looks: f(rgb 0..1) -> rgb */
  var LOOKS = [
    { id: 'none', name: 'من غير', f: null },
    { id: 'teal', name: 'تيل وأورانج', f: function (c) { c = hueSkew(c, .9, .9); c = split(c, [.32, .58, .66], [.72, .56, .38], .55); c = scurve(c, .35); return sat(c, 1.12); } },
    { id: 'block', name: 'بلوكبستر', f: function (c) { c = hueSkew(c, 1.2, 1.1); c = split(c, [.25, .55, .7], [.8, .55, .3], .7); c = scurve(c, .6); return sat(c, 1.18); } },
    { id: 'film', name: 'فيلم دافي', f: function (c) { c = lgg(c, [.03, .02, .0], [1.02, 1, .95], [1.02, .99, .9]); c = scurve(c, .3); c = fade(c, .05); return sat(c, .95); } },
    { id: 'kodak', name: 'كوداك', f: function (c) { c = lgg(c, [.02, .01, .03], [1.05, 1.02, .96], [1.04, 1, .92]); c = split(c, [.45, .52, .58], [.62, .55, .42], .4); c = scurve(c, .4); return sat(c, 1.08); } },
    { id: 'golden', name: 'ساعة ذهبية', f: function (c) { c = lgg(c, [.02, .01, 0], [1.08, 1.02, .92], [1.1, 1.02, .85]); c = scurve(c, .25); return sat(c, 1.12); } },
    { id: 'moody', name: 'موودي أخضر', f: function (c) { c = split(c, [.38, .56, .5], [.6, .58, .46], .5); c = scurve(c, .45); c = fade(c, .06); return sat(c, .78); } },
    { id: 'cold', name: 'بارد أزرق', f: function (c) { c = lgg(c, [0, .01, .04], [.96, 1, 1.06], [.92, .98, 1.08]); c = scurve(c, .35); return sat(c, .9); } },
    { id: 'night', name: 'ليل (Day for night)', f: function (c) { c = lgg(c, [0, .0, .02], [.8, .85, .95], [.45, .55, .8]); return sat(c, .55); } },
    { id: 'bleach', name: 'بليتش', f: function (c) { var l = luma(c); c = mixc(c, [l, l, l], .55); return scurve(c, .7); } },
    { id: 'matte', name: 'مات باهت', f: function (c) { c = scurve(c, .15); c = c.map(function (v) { return .08 + v * .86; }); return sat(c, .85); } },
    { id: 'vintage', name: 'فينتدج السبعينات', f: function (c) { c = lgg(c, [.06, .03, 0], [1.05, 1, .9], [1, .95, .8]); c = fade(c, .1); return sat(c, .8); } },
    { id: 'pastel', name: 'باستيل', f: function (c) { c = lgg(c, [.06, .05, .07], [1.1, 1.08, 1.06], [1, 1, 1]); c = split(c, [.55, .5, .58], [.56, .53, .5], .3); return sat(c, .8); } },
    { id: 'cyber', name: 'سايبر بانك', f: function (c) { c = split(c, [.62, .3, .75], [.35, .7, .78], .8); c = scurve(c, .5); return sat(c, 1.3); } },
    { id: 'desert', name: 'صحرا', f: function (c) { c = lgg(c, [.03, .02, 0], [1.05, 1, .9], [1.08, .98, .8]); c = scurve(c, .3); return sat(c, .85); } },
    { id: 'punch', name: 'واضح ومشبّع', f: function (c) { c = scurve(c, .4); return sat(c, 1.35); } },
    { id: 'skin', name: 'بشرة دافية', f: function (c) { c = hueSkew(c, .5, .2); c = lgg(c, [.01, .005, 0], [1.03, 1, .97], [1.03, 1, .96]); return sat(c, 1.04); } },
    { id: 'noir', name: 'أبيض وأسود', f: function (c) { var l = luma(c); return scurve([l, l, l], .45); } },
    { id: 'noirhard', name: 'أبيض وأسود حاد', f: function (c) { var l = Math.pow(luma(c), 1.1); return scurve(scurve([l, l, l], .9), .5); } },
    { id: 'sepia', name: 'سيبيا', f: function (c) { var l = luma(c); return scurve([l * 1.07 + .03, l * .95 + .02, l * .76], .2); } },
    { id: 'slog3', name: 'S-Log3 ← عادي', f: fromLog(LOG.slog3), tech: true },
    { id: 'logc3', name: 'ARRI LogC ← عادي', f: fromLog(LOG.logc3), tech: true },
    { id: 'vlog', name: 'V-Log ← عادي', f: fromLog(LOG.vlog), tech: true },
    { id: 'clog3', name: 'C-Log3 ← عادي', f: fromLog(LOG.clog3), tech: true }
  ];
  var N = 33;
  function lutFromFn(f) {
    var d = new Uint8Array(N * N * N * 4);
    for (var b = 0; b < N; b++) for (var g = 0; g < N; g++) for (var r = 0; r < N; r++) {
      var o = f ? f([r / (N - 1), g / (N - 1), b / (N - 1)]) : [r / (N - 1), g / (N - 1), b / (N - 1)], x = b * N + r, y = g, i = (y * N * N + x) * 4;
      d[i] = cl(Math.round(o[0] * 255), 0, 255); d[i + 1] = cl(Math.round(o[1] * 255), 0, 255); d[i + 2] = cl(Math.round(o[2] * 255), 0, 255); d[i + 3] = 255;
    }
    return d;
  }
  /* a .cube file -> function by trilinear lookup */
  function parseCube(txt) {
    var size = 0, vals = [], dmin = [0, 0, 0], dmax = [1, 1, 1];
    txt.split(/\r?\n/).forEach(function (ln) {
      ln = ln.trim(); if (!ln || ln[0] === '#') return;
      var m = /^LUT_3D_SIZE\s+(\d+)/i.exec(ln); if (m) { size = +m[1]; return; }
      m = /^DOMAIN_MIN\s+(\S+)\s+(\S+)\s+(\S+)/i.exec(ln); if (m) { dmin = [+m[1], +m[2], +m[3]]; return; }
      m = /^DOMAIN_MAX\s+(\S+)\s+(\S+)\s+(\S+)/i.exec(ln); if (m) { dmax = [+m[1], +m[2], +m[3]]; return; }
      if (/^[A-Z_]/i.test(ln)) return;
      var p = ln.split(/\s+/); if (p.length >= 3) vals.push(+p[0], +p[1], +p[2]);
    });
    if (!size || vals.length < size * size * size * 3) throw new Error('cube');
    var S1 = size - 1;
    return function (c) {
      var x = [0, 1, 2].map(function (i) { return cl((c[i] - dmin[i]) / (dmax[i] - dmin[i]), 0, 1) * S1; });
      var i0 = x.map(Math.floor), f = x.map(function (v, i) { return v - i0[i]; }), i1 = i0.map(function (v) { return Math.min(S1, v + 1); });
      function V(r, g, b, k) { return vals[(r + g * size + b * size * size) * 3 + k]; }
      var o = [0, 0, 0];
      for (var k = 0; k < 3; k++) {
        var c00 = V(i0[0], i0[1], i0[2], k) * (1 - f[0]) + V(i1[0], i0[1], i0[2], k) * f[0], c10 = V(i0[0], i1[1], i0[2], k) * (1 - f[0]) + V(i1[0], i1[1], i0[2], k) * f[0];
        var c01 = V(i0[0], i0[1], i1[2], k) * (1 - f[0]) + V(i1[0], i0[1], i1[2], k) * f[0], c11 = V(i0[0], i1[1], i1[2], k) * (1 - f[0]) + V(i1[0], i1[1], i1[2], k) * f[0];
        o[k] = (c00 * (1 - f[1]) + c10 * f[1]) * (1 - f[2]) + (c01 * (1 - f[1]) + c11 * f[1]) * f[2];
      }
      return o;
    };
  }

  /* ---------------- the GL pipeline ---------------- */
  var VS = 'attribute vec2 aP; varying vec2 vUV; void main(){ vUV = vec2(aP.x * .5 + .5, .5 - aP.y * .5); gl_Position = vec4(aP, 0., 1.); }';
  var FS = [
    'precision highp float; varying vec2 vUV;',
    'uniform sampler2D uImg; uniform sampler2D uLut; uniform sampler2D uPlate; uniform vec2 uRes; uniform float uN, uLutMix, uExp, uCon, uSat, uTemp, uTint, uVig, uGrain, uSeed, uBars, uFish, uFishC, uBloom, uSharp, uSplit;',
    'uniform int uKey; uniform vec3 uKeyCol; uniform float uSim, uSoft, uSpill, uFlipY;',
    'vec3 lut(vec3 c){ c = clamp(c, 0., 1.); float b = c.b * (uN - 1.), b0 = floor(b), b1 = min(b0 + 1., uN - 1.), f = b - b0;',
    '  vec2 a0 = vec2((b0 * uN + c.r * (uN - 1.) + .5) / (uN * uN), (c.g * (uN - 1.) + .5) / uN), a1 = vec2((b1 * uN + c.r * (uN - 1.) + .5) / (uN * uN), a0.y);',
    '  return mix(texture2D(uLut, a0).rgb, texture2D(uLut, a1).rgb, f); }',
    'vec2 cbcr(vec3 c){ return vec2(-.1687 * c.r - .3313 * c.g + .5 * c.b, .5 * c.r - .4187 * c.g - .0813 * c.b); }',
    'float hash(vec2 p){ return fract(sin(dot(p, vec2(12.9898, 78.233)) + uSeed) * 43758.5453); }',
    'void main(){',
    '  vec2 uv = vUV; if (uFlipY > .5) uv.y = 1. - uv.y;',
    '  float ar = uRes.x / uRes.y; vec2 p = (uv - .5) * vec2(ar, 1.); float R = .5 * length(vec2(ar, 1.)), rn = length(p) / R, edge = 1.;',
    '  if (uFish > 0.) {',
    '    if (uFishC > .5) { float rc = .5 * min(ar, 1.) * 1.02, r = length(p) / rc; edge = 1. - smoothstep(.97, 1., r); float th = r * 1.5707963 * (.35 + uFish * .65); p = r > 0. ? p / max(r, 1e-4) * (tan(min(th, 1.5)) / tan(1.5707963 * (.35 + uFish * .65) * .999)) * rc * 1.15 : p; }',
    '    else { float k = uFish * 1.6; p = p * (1. + k * rn * rn) / (1. + k); }',
    '  }',
    '  vec2 s = p / vec2(ar, 1.) + .5;',
    '  vec3 raw = texture2D(uImg, s).rgb; float srcA = texture2D(uImg, s).a;',
    '  if (s.x < 0. || s.y < 0. || s.x > 1. || s.y > 1.) raw = vec3(0.);',
    '  vec3 c = raw;',
    '  if (uSharp > 0.) { vec2 px = 1. / uRes; vec3 bl = (texture2D(uImg, s + vec2(px.x, 0.)).rgb + texture2D(uImg, s - vec2(px.x, 0.)).rgb + texture2D(uImg, s + vec2(0., px.y)).rgb + texture2D(uImg, s - vec2(0., px.y)).rgb) * .25; c += (c - bl) * uSharp * 1.5; }',
    '  float a = 1.;',
    '  if (uKey == 1) { float d = distance(cbcr(raw), cbcr(uKeyCol)); a = smoothstep(uSim * .35, uSim * .35 + uSoft * .25 + .001, d);',
    '    if (uKeyCol.g >= uKeyCol.b) c.g = mix(c.g, min(c.g, max(c.r, c.b)), uSpill); else c.b = mix(c.b, min(c.b, max(c.r, c.g)), uSpill); }',
    '  else if (uKey == 2) { vec3 pc = texture2D(uPlate, s).rgb; float d = length(raw - pc); a = smoothstep(uSim * .3, uSim * .3 + uSoft * .3 + .001, d); }',
    '  c *= exp2(uExp); c *= vec3(1. + uTemp * .12, 1. - uTint * .08, 1. - uTemp * .12);',
    '  if (uLutMix > 0.) c = mix(c, lut(c), uLutMix);',
    '  c = (c - .5) * (1. + uCon) + .5;',
    '  float l = dot(c, vec3(.2126, .7152, .0722)); c = mix(vec3(l), c, 1. + uSat);',
    '  if (uBloom > 0.) { vec3 bs = vec3(0.); for (int i = 0; i < 12; i++) { float an = float(i) * .5236, rr = .012 + .012 * mod(float(i), 3.); vec3 t = texture2D(uImg, s + vec2(cos(an), sin(an) * ar) * rr).rgb; bs += max(t - .62, 0.); }',
    '    c += bs / 12. * uBloom * vec3(1.6, .9, .6) * 2.2; }',
    '  if (uVig > 0.) c *= 1. - uVig * smoothstep(.35, 1.05, rn) * .85;',
    '  if (uGrain > 0.) { float n = hash(floor(vUV * uRes)) - .5; c += n * uGrain * .14 * (1. - abs(l - .5)); }',
    '  c *= edge;',
    '  if (uBars > 0.) { float vis = uRes.x / uBars / uRes.y; if (abs(vUV.y - .5) > vis * .5) { c = vec3(0.); } }',
    '  if (uSplit > 0. && vUV.x < uSplit) { c = raw; a = 1.; }',
    '  if (uSplit > 0. && abs(vUV.x - uSplit) < 1. / uRes.x) c = vec3(1.);',
    '  gl_FragColor = vec4(clamp(c, 0., 1.), a * srcA);',
    '}'].join('\n');
  function Renderer() {
    var cv = G.document.createElement('canvas');
    var gl = cv.getContext('webgl', { alpha: true, premultipliedAlpha: false, preserveDrawingBuffer: true, antialias: false });
    if (!gl) throw new Error('no_webgl');
    function sh(t, s) { var o = gl.createShader(t); gl.shaderSource(o, s); gl.compileShader(o); if (!gl.getShaderParameter(o, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(o)); return o; }
    var pr = gl.createProgram(); gl.attachShader(pr, sh(gl.VERTEX_SHADER, VS)); gl.attachShader(pr, sh(gl.FRAGMENT_SHADER, FS)); gl.linkProgram(pr); gl.useProgram(pr);
    var U = {}; ['uImg', 'uLut', 'uPlate', 'uRes', 'uN', 'uLutMix', 'uExp', 'uCon', 'uSat', 'uTemp', 'uTint', 'uVig', 'uGrain', 'uSeed', 'uBars', 'uFish', 'uFishC', 'uBloom', 'uSharp', 'uSplit', 'uKey', 'uKeyCol', 'uSim', 'uSoft', 'uSpill', 'uFlipY'].forEach(function (n) { U[n] = gl.getUniformLocation(pr, n); });
    var b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
    var al = gl.getAttribLocation(pr, 'aP'); gl.enableVertexAttribArray(al); gl.vertexAttribPointer(al, 2, gl.FLOAT, false, 0, 0);
    function tex(unit) { var t = gl.createTexture(); gl.activeTexture(gl.TEXTURE0 + unit); gl.bindTexture(gl.TEXTURE_2D, t);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array([0, 0, 0, 255])); return t; }
    var tImg = tex(0), tLut = tex(1), tPlate = tex(2), lutKey = null;
    gl.uniform1i(U.uImg, 0); gl.uniform1i(U.uLut, 1); gl.uniform1i(U.uPlate, 2);
    return {
      canvas: cv, gl: gl,
      setImage: function (src) { gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, tImg); gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, src); },
      setPlate: function (src) { gl.activeTexture(gl.TEXTURE2); gl.bindTexture(gl.TEXTURE_2D, tPlate); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, src); },
      setLut: function (key, data) { if (key === lutKey) return; lutKey = key; gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, tLut); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, N * N, N, 0, gl.RGBA, gl.UNSIGNED_BYTE, data); },
      draw: function (W, H, s, o) {
        o = o || {};
        if (cv.width !== W || cv.height !== H) { cv.width = W; cv.height = H; }
        gl.viewport(0, 0, W, H); gl.disable(gl.BLEND); gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT);
        var kc = hexRgb(s.keyCol);
        gl.uniform2f(U.uRes, W, H); gl.uniform1f(U.uN, N); gl.uniform1f(U.uLutMix, s.look === 'none' ? 0 : s.mix);
        gl.uniform1f(U.uExp, s.exp); gl.uniform1f(U.uCon, s.con); gl.uniform1f(U.uSat, s.sat); gl.uniform1f(U.uTemp, s.temp); gl.uniform1f(U.uTint, s.tint);
        gl.uniform1f(U.uVig, s.vig); gl.uniform1f(U.uGrain, s.grain); gl.uniform1f(U.uSeed, o.seed || 0); gl.uniform1f(U.uBars, +s.bars || 0);
        gl.uniform1f(U.uFish, s.fish); gl.uniform1f(U.uFishC, s.fishMode === 'circle' ? 1 : 0); gl.uniform1f(U.uBloom, s.bloom); gl.uniform1f(U.uSharp, s.sharp);
        gl.uniform1f(U.uSplit, o.split || 0); gl.uniform1i(U.uKey, s.key === 'chroma' ? 1 : s.key === 'plate' ? 2 : 0); gl.uniform3f(U.uKeyCol, kc[0], kc[1], kc[2]);
        gl.uniform1f(U.uSim, s.sim); gl.uniform1f(U.uSoft, s.soft); gl.uniform1f(U.uSpill, s.spill); gl.uniform1f(U.uFlipY, o.flipY ? 1 : 0);
        gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
      },
      read: function (W, H, buf) { gl.readPixels(0, 0, W, H, gl.RGBA, gl.UNSIGNED_BYTE, buf); return buf; }
    };
  }
  function hexRgb(c) { var n = parseInt(String(c || '#00ff00').slice(1, 7), 16) || 0; return [(n >> 16 & 255) / 255, (n >> 8 & 255) / 255, (n & 255) / 255]; }

  /* ---------------- settings ---------------- */
  var DEF = { look: 'teal', mix: .85, exp: 0, con: 0, sat: 0, temp: 0, tint: 0, vig: .25, grain: .15, bloom: 0, sharp: 0, bars: 0, fish: 0, fishMode: 'barrel',
    key: 'none', keyCol: '#00b140', sim: .35, soft: .3, spill: .6, off: true };
  var S = (function () { var o = {}, k, v = st.get('set', {}); for (k in DEF) o[k] = DEF[k]; for (k in v) o[k] = v[k]; return o; })();
  if (S.key === 'ai') S.key = 'none';
  function save() { st.set('set', S); }
  var userLuts = st.get('luts', []);   // [{id, name, path}]
  var lutCache = {};
  function lookFn(id) {
    var L = LOOKS.filter(function (x) { return x.id === id; })[0]; if (L) return L.f;
    var u = userLuts.filter(function (x) { return x.id === id; })[0]; if (!u) return null;
    if (!u.fn) { try { u.fn = parseCube(Sys.req('fs').readFileSync(u.path, 'utf8')); } catch (e) { u.fn = null; } }
    return u.fn;
  }
  function lutData(id) { if (!lutCache[id]) lutCache[id] = lutFromFn(lookFn(id)); return lutCache[id]; }

  /* ---------------- tab ---------------- */
  var ui = {}, ctl = {}, R = null, under = null, plate = null, seq = { w: 1080, h: 1920 }, busy = false, stopReq = false, frameCv = null, picking = false, splitX = 0;
  function set(p) { for (var k in p) S[k] = p[k]; save(); paint(); }
  function sl(k, label, min, max, step, fmt) { var c = K.slider({ label: label, min: min, max: max, step: step, value: S[k], fmt: fmt, onInput: function (v) { var p = {}; p[k] = v; set(p); } }); ctl[k] = c; return c; }
  function pct(v) { return Math.round(v * 100) + '%'; }
  function sgn(v) { return (v > 0 ? '+' : '') + Math.round(v * 100); }
  function fit() {
    if (!ui.wrap) return;
    var w = Math.max(160, ui.wrap.clientWidth || 300), ar = seq.w / seq.h, hh = Math.min(K.pvH(420), w / ar), ww = hh * ar;
    ui.stage.style.width = Math.round(ww) + 'px'; ui.stage.style.height = Math.round(hh) + 'px';
    var d = Math.min(2, G.devicePixelRatio || 1); ui.cv.width = Math.round(ww * d); ui.cv.height = Math.round(hh * d);
    prepFrame(); paint();
  }
  function sampleCv(W, H) {
    var c = G.document.createElement('canvas'); c.width = W; c.height = H; var x = c.getContext('2d');
    var g = x.createLinearGradient(0, 0, 0, H); g.addColorStop(0, '#7fb3d9'); g.addColorStop(.55, '#e8c49a'); g.addColorStop(.56, '#6f7a4a'); g.addColorStop(1, '#2f3b22'); x.fillStyle = g; x.fillRect(0, 0, W, H);
    x.fillStyle = '#f2d6b3'; x.beginPath(); x.arc(W * .5, H * .42, Math.min(W, H) * .12, 0, 7); x.fill(); x.fillStyle = '#9c3b2e'; x.fillRect(W * .38, H * .53, W * .24, H * .3);
    return c;
  }
  function prepFrame() {
    var W = ui.cv.width, H = ui.cv.height; if (!W) return;
    if (!frameCv) frameCv = G.document.createElement('canvas'); frameCv.width = W; frameCv.height = H;
    var x = frameCv.getContext('2d');
    if (under && under.img) Out.drawClip(x, under, W, H); else x.drawImage(sampleCv(W, H), 0, 0);
    if (R) { R.setImage(frameCv); if (plate) { var pc = G.document.createElement('canvas'); pc.width = W; pc.height = H; Out.drawClip(pc.getContext('2d'), plate, W, H); R.setPlate(pc); } }
  }
  function paint() {
    if (!R || !ui.cv || !ui.cv.width) return;
    R.setLut(S.look, lutData(S.look)); R.draw(ui.cv.width, ui.cv.height, S, { split: splitX, seed: 1 });
    var x = ui.cv.getContext('2d'); x.clearRect(0, 0, ui.cv.width, ui.cv.height);
    if (S.key !== 'none') { var s = 12, W = ui.cv.width, H = ui.cv.height; for (var yy = 0; yy < H; yy += s) for (var xx = 0; xx < W; xx += s) { x.fillStyle = ((xx + yy) / s) % 2 ? '#3a3a3a' : '#555'; x.fillRect(xx, yy, s, s); } }
    x.drawImage(R.canvas, 0, 0);
  }
  /* small previews of every look on the current frame */
  function tiles() {
    if (!R || !ui.tiles) return;
    var tw = 120, th = Math.round(120 / (seq.w / seq.h) * .6), src = G.document.createElement('canvas'); th = 76;
    src.width = tw; src.height = th; var x = src.getContext('2d');
    var fw = frameCv ? frameCv.width : 1, fh = frameCv ? frameCv.height : 1, s = Math.max(tw / fw, th / fh);
    if (frameCv) x.drawImage(frameCv, (tw - fw * s) / 2, (th - fh * s) / 2, fw * s, fh * s);
    R.setImage(src);
    var plain = { exp: 0, con: 0, sat: 0, temp: 0, tint: 0, vig: 0, grain: 0, bloom: 0, sharp: 0, bars: 0, fish: 0, key: 'none', mix: 1 };
    [].forEach.call(ui.tiles.children, function (b) {
      var id = b.getAttribute('data-v'), c = b.querySelector('canvas'), o = {}; for (var k in plain) o[k] = plain[k]; o.look = id;
      R.setLut(id, lutData(id)); R.draw(tw, th, o, {}); c.width = tw; c.height = th; c.getContext('2d').drawImage(R.canvas, 0, 0);
    });
    prepFrame(); paint();
  }
  function grab() {
    ui.status.show('busy', 'بجيب الفريم…');
    return Out.grabClip(1280).then(function (u) {
      seq = u.seq; under = u.img ? u : null; fit(); tiles();
      ui.status.show(u.img ? 'ok' : 'warn', u.img ? 'الفريم ✓ — اسحب على المعاينة عشان تقارن قبل/بعد' : 'مفيش فيديو تحت المؤشر.');
    }).catch(function (e) { ui.status.show('err', Out.errText(e)); });
  }
  function grabPlate() {
    ui.status.show('busy', 'بجيب فريم الخلفية…');
    Out.grabClip(1280).then(function (u) { if (!u.img) throw new Error('مفيش فيديو تحت المؤشر.'); plate = u; set({ key: 'plate' }); ui.keySeg.setValue('plate'); prepFrame(); paint(); ui.status.show('ok', 'اتخزنت الخلفية الفاضية ✓ — دلوقتي روح لفريم فيه الشخص ودوس «هات الفريم».'); })
      .catch(function (e) { ui.status.show('err', e.message || String(e)); });
  }
  function bindStage() {
    var down = false;
    function at(e) { var r = ui.cv.getBoundingClientRect(); return { x: (e.clientX - r.left) / r.width, y: (e.clientY - r.top) / r.height }; }
    ui.cv.addEventListener('pointerdown', function (e) {
      var p = at(e);
      if (picking) {   // eyedropper for the key colour
        picking = false; var x = frameCv.getContext('2d'), d = x.getImageData(Math.floor(p.x * frameCv.width), Math.floor(p.y * frameCv.height), 1, 1).data;
        var hx = '#' + [d[0], d[1], d[2]].map(function (v) { return ('0' + v.toString(16)).slice(-2); }).join(''); ui.keyCol.value = hx; set({ keyCol: hx, key: 'chroma' }); ui.keySeg.setValue('chroma'); ui.status.show('ok', 'اللون اتاخد ✓'); return;
      }
      down = true; try { ui.cv.setPointerCapture(e.pointerId); } catch (x2) {} splitX = cl(p.x, .001, 1); paint();
    });
    ui.cv.addEventListener('pointermove', function (e) { if (!down) return; splitX = cl(at(e).x, .001, 1); paint(); });
    function up() { if (!down) return; down = false; splitX = 0; paint(); }
    ui.cv.addEventListener('contextmenu', function (e) { e.preventDefault(); });
    ui.cv.addEventListener('pointerup', up); ui.cv.addEventListener('pointercancel', up);
  }
  function addLuts() {
    var files = Sys.pickFiles('اختار ملفات LUT', ['cube']); if (!files.length) return;
    var n = 0; files.forEach(function (p) { var nm = String(p).split(/[\\/]/).pop().replace(/\.cube$/i, ''); if (userLuts.some(function (u) { return u.path === p; })) return;
      try { parseCube(Sys.req('fs').readFileSync(p, 'utf8')); userLuts.push({ id: 'u' + Date.now() + '_' + n, name: nm, path: p }); n++; } catch (e) {} });
    st.set('luts', userLuts.map(function (u) { return { id: u.id, name: u.name, path: u.path }; })); buildTiles(); tiles();
    ui.status.show(n ? 'ok' : 'warn', n ? 'اتضاف ' + n + ' LUT ✓' : 'الملفات دي مش LUT 3D (.cube) سليمة.');
  }
  function buildTiles() {
    ui.tiles.innerHTML = '';
    var all = LOOKS.concat(userLuts.map(function (u) { return { id: u.id, name: u.name, user: true }; }));
    all.forEach(function (L) {
      var b = h('button', { type: 'button', class: 'tl' + (S.look === L.id ? ' on' : ''), 'data-v': L.id, title: L.name }, [h('canvas'), h('span', { text: (L.user ? '★ ' : '') + L.name })]);
      b.addEventListener('click', function () { set({ look: L.id }); [].forEach.call(ui.tiles.children, function (x) { x.classList.toggle('on', x === b); }); });
      if (L.user) b.addEventListener('contextmenu', function (e) { e.preventDefault(); userLuts = userLuts.filter(function (u) { return u.id !== L.id; }); st.set('luts', userLuts.map(function (u) { return { id: u.id, name: u.name, path: u.path }; })); buildTiles(); tiles(); });
      ui.tiles.appendChild(b);
    });
  }
  /* render the selected clips (or the one under the playhead) through the pipeline */
  function apply() {
    if (busy) return; busy = true; stopReq = false; ui.go.disabled = true; K.show(ui.stop, true);
    var SS = JSON.parse(JSON.stringify(S)), done = 0, refs = [], plateUse = plate;
    Sys.call('cr_clips', {}).then(function (r) {
      if (!r || !r.ok) throw new Error('no_seq');
      var cs = (r.clips || []).filter(function (c) { return c.path; }); if (!cs.length) throw new Error('اختار كليب في التايملاين (أو قف عليه).');
      seq = { w: r.w, h: r.h, fps: r.fps };
      var i = 0, RR = Renderer(), fcv = G.document.createElement('canvas'), pcv = null;
      RR.setLut(SS.look, lutData(SS.look));
      function one() {
        if (i >= cs.length) return null;
        var c = cs[i], sp = c.speed || 1, dur = c.end - c.start, info = null, dir = null;
        ui.status.show('busy', 'بفك فريمات الكليب ' + (i + 1) + ' من ' + cs.length + '…');
        return Sys.probe(c.path).then(function (inf) { info = inf; return Sys.clipFrames(c.path, c.inPoint, dur * sp, (r.fps || 30) / sp, Math.max(r.w, r.h)); }).then(function (d) {
          dir = d; var u = { clip: c, srcW: info.w || r.w, srcH: info.h || r.h, seq: { w: r.w, h: r.h } }, cache = {};
          function pic(j) { var key = j; if (cache[key]) return cache[key]; var p = new Promise(function (res) { var im = new Image(); im.onload = function () { res(im); }; im.onerror = function () { res(null); }; im.src = Sys.url(Sys.join(dir, ('0000' + (j + 1)).slice(-5) + '.jpg')); }); cache[key] = p; delete cache[key - 3]; return p; }
          var buf = null;
          return Out.renderAndPlace({
            prefix: 'ENP_Look', bin: 'ENP Filters', dur: dur, at: c.start, replace: [], flip: true,
            prepare: function (o) { fcv.width = o.w; fcv.height = o.h; buf = new Uint8Array(o.w * o.h * 4);
              if (SS.key === 'plate' && plateUse) { pcv = G.document.createElement('canvas'); pcv.width = o.w; pcv.height = o.h; Out.drawClip(pcv.getContext('2d'), plateUse, o.w, o.h); RR.setPlate(pcv); } },
            frame: function (t, k, o) {
              return pic(k).then(function (im) {
                var x = fcv.getContext('2d'); if (im) { u.img = im; Out.drawClip(x, u, o.w, o.h); }
                RR.setImage(fcv); RR.draw(o.w, o.h, SS, { seed: k * 1.37 % 97 }); return RR.read(o.w, o.h, buf);
              });
            },
            onProgress: function (p) { ui.prog.set((i + p) / cs.length); ui.status.show('busy', 'برندر الكليب ' + (i + 1) + ' من ' + cs.length + '… ' + Math.round(p * 100) + '%'); },
            cancelled: function () { return stopReq; }
          }).then(function (res) { done++; refs.push({ type: 'v', track: c.track, id: c.id, start: c.start }); i++; return one(); });
        });
      }
      return one();
    }).then(function () {
      return (SS.off && refs.length ? Sys.call('cr_disable', { refs: refs }) : Promise.resolve()).then(function () {
        ui.status.show('ok', 'اتعمل ' + done + ' كليب واتحط فوق الأصلي' + (SS.off ? ' (والأصلي اتقفل)' : '') + ' ✓');
      });
    }).catch(function (e) { ui.status.show(e && e.message === 'cancelled' ? 'warn' : 'err', /[؀-ۿ]/.test(e && e.message) ? e.message : Out.errText(e)); })
      .then(function () { busy = false; ui.go.disabled = false; K.show(ui.stop, false); ui.prog.done(); });
  }
  function build(root) {
    try { R = Renderer(); } catch (e) { root.appendChild(h('div', { class: 'notice', text: 'كارت الشاشة مش متاح للبانل.' })); return; }
    ui.status = K.status(); ui.prog = K.progress();
    ui.cv = h('canvas', { style: 'cursor:ew-resize' }); ui.stage = h('div', { class: 'stage' }, [ui.cv]); ui.wrap = h('div', { class: 'pvwrap' }, [ui.stage]);
    ui.tiles = h('div', { class: 'tiles' }); buildTiles();
    ui.keyCol = h('input', { type: 'color', value: S.keyCol }); ui.keyCol.addEventListener('input', function () { set({ keyCol: ui.keyCol.value }); });
    ui.keySeg = K.seg({ items: [{ v: 'none', label: 'من غير' }, { v: 'chroma', label: 'جرين / بلو سكرين' }, { v: 'plate', label: 'خلفية ثابتة' }], value: S.key, onChange: function (v) { set({ key: v }); } });
    ui.go = K.btn('طبّق على الكليبات المختارة', { cls: 'pri', icon: 'spark', onClick: apply });
    ui.stop = K.btn('وقّف', { icon: 'stop', onClick: function () { stopReq = true; } }); K.show(ui.stop, false);
    bindStage();
    [h('div', { class: 'pv' }, [ui.wrap, h('div', { class: 'adds', style: 'margin-top:8px' }, [K.btn('هات الفريم اللي تحت المؤشر', { icon: 'target', onClick: grab })]),
        h('div', { class: 'hint', style: 'margin-top:4px', text: 'دوس واسحب على المعاينة عشان تشوف قبل/بعد.' })]),
      K.section('ألوان سينمائية و LUTs', [ui.tiles, sl('mix', 'قوة اللوك', 0, 1, .01, pct),
        h('div', { class: 'adds', style: 'margin-top:6px' }, [K.btn('ضيف LUTs بتاعتك (.cube)', { icon: 'plus', onClick: addLuts })]),
        h('div', { class: 'hint', text: 'آخر 4 بيحولوا تصوير اللوج (Sony / ARRI / Panasonic / Canon) لألوان عادية. كليك يمين على LUT بتاعتك يشيلها.' })], true, 'fl_looks'),
      K.section('تظبيط الألوان', [sl('exp', 'إضاءة', -2, 2, .01, function (v) { return (+v).toFixed(2); }), sl('con', 'كونتراست', -.6, .8, .01, sgn), sl('sat', 'تشبّع', -1, 1, .01, sgn),
        sl('temp', 'حرارة (أزرق ↔ أصفر)', -1, 1, .01, sgn), sl('tint', 'تينت (أخضر ↔ بمبي)', -1, 1, .01, sgn)], false, 'fl_adj'),
      K.section('لمسة سينما', [sl('vig', 'فينييت', 0, 1, .01, pct), sl('grain', 'جرين فيلم', 0, 1, .01, pct), sl('bloom', 'هالة على الإضاءة (Halation)', 0, 1, .01, pct), sl('sharp', 'حدة', 0, 1, .01, pct),
        K.field('شرايط سينما', K.seg({ items: [{ v: 0, label: 'من غير' }, { v: 2.39, label: '2.39:1' }, { v: 2, label: '2:1' }, { v: 1.85, label: '1.85:1' }], value: S.bars, onChange: function (v) { set({ bars: +v }); } }))], false, 'fl_cine'),
      K.section('عدسة عين السمكة', [sl('fish', 'قوة العدسة', 0, 1, .01, pct), K.field('الشكل', K.seg({ items: [{ v: 'barrel', label: 'مالي الكادر' }, { v: 'circle', label: 'دايرة (زي GoPro)' }], value: S.fishMode, onChange: function (v) { set({ fishMode: v }); } }))], false, 'fl_fish'),
      K.section('إزالة الخلفية', [ui.keySeg,
        h('div', { class: 'crow', style: 'margin-top:6px' }, [h('label', { class: 'cfield' }, [ui.keyCol, h('span', { text: 'لون الخلفية' })]), K.btn('خد اللون من الصورة', { icon: 'target', onClick: function () { picking = true; ui.status.show('ok', 'دوس على الخلفية الخضرا في المعاينة.'); } })]),
        sl('sim', 'قد إيه يشيل', 0, 1, .01, pct), sl('soft', 'نعومة الحواف', 0, 1, .01, pct), sl('spill', 'شيل الانعكاس الأخضر', 0, 1, .01, pct),
        h('div', { class: 'adds', style: 'margin-top:6px' }, [K.btn('خد فريم الخلفية الفاضية', { icon: 'target', onClick: grabPlate })]),
        h('div', { class: 'hint', text: '«خلفية ثابتة»: لو الكاميرا ثابتة، قف على فريم مافيهوش حد ودوس «خد فريم الخلفية الفاضية» — أي حاجة مختلفة عنه بتفضل.' })], false, 'fl_key'),
      h('div', { class: 'out' }, [K.toggle('اقفل الكليب الأصلي بعد التطبيق', S.off, function (v) { S.off = v; save(); }),
        h('div', { class: 'hint', text: 'بيترندر نسخة جديدة فوق الكليب الأصلي بالظبط (الصوت مش بيتغيّر).' }), h('div', { style: 'margin-top:10px' }, [ui.go]), h('div', { class: 'tk' }, [ui.stop]), ui.prog, ui.status])
    ].forEach(function (el) { root.appendChild(el); });
    G.addEventListener('resize', fit);
    Sys.call('cr_info').then(function (r) { if (r && r.ok && r.hasSequence && r.w) { seq = { w: r.w, h: r.h }; fit(); tiles(); } });
    fit(); tiles();
  }
  G.FiltersTab = { build: build, LOOKS: LOOKS, _lut: lutFromFn, _parseCube: parseCube, _Renderer: Renderer, _S: function () { return S; } };
})(window);
