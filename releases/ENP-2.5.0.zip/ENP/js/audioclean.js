/* ENP — voice clean-up. Selected audio clips go through a studio chain (hum, rumble, broadband noise,
   neural speech denoise, room echo, mud, presence, de-ess, leveling, loudness) in ffmpeg, and the clean
   copy is laid on its own audio track exactly under the original. */
(function (G) {
  'use strict';
  var K = G.K, h = K.h, st = K.store('enp_aclean_');
  var DEF = { preset: 'medium', nr: .55, ai: .7, model: 'sh', hum: 0, declick: false, room: .2, clarity: .5, warm: .2, ess: .35, comp: .5, lufs: -16, hp: 80, mute: true };
  var PRESETS = [
    { id: 'light', name: 'خفيف', hint: 'تسجيل كويس محتاج لمسة', set: { nr: .3, ai: .35, room: 0, clarity: .35, warm: .15, ess: .2, comp: .35, hp: 70, hum: 0, declick: false } },
    { id: 'medium', name: 'متوسط', hint: 'مروحة / تكييف / كمبيوتر', set: { nr: .55, ai: .7, room: .2, clarity: .5, warm: .2, ess: .35, comp: .5, hp: 80, hum: 0, declick: false } },
    { id: 'strong', name: 'قوي', hint: 'دوشة عالية', set: { nr: .85, ai: 1, room: .35, clarity: .6, warm: .2, ess: .45, comp: .6, hp: 95, hum: 0, declick: true } },
    { id: 'studio', name: 'صوت استوديو', hint: 'دافي وواضح ومليان', set: { nr: .5, ai: .85, room: .3, clarity: .7, warm: .45, ess: .4, comp: .75, hp: 75, lufs: -14, hum: 0, declick: false } },
    { id: 'street', name: 'موبايل / شارع', hint: 'عربيات وهوا وناس', set: { nr: .95, ai: 1, model: 'cb', room: .45, clarity: .8, warm: .25, ess: .5, comp: .75, hp: 110, hum: 0, declick: true } },
    { id: 'room', name: 'أوضة فيها صدى', hint: 'صدى وأوضة فاضية', set: { nr: .5, ai: .8, room: .85, clarity: .55, warm: .15, ess: .35, comp: .55, hp: 85, hum: 0, declick: false } },
    { id: 'hum', name: 'زنّة كهربا', hint: 'طنين 50 هرتز', set: { nr: .5, ai: .6, room: .15, clarity: .5, warm: .1, ess: .3, comp: .5, hp: 90, hum: 50, declick: false } }
  ];
  var S = (function () { var o = {}, k, v = st.get('set', {}); for (k in DEF) o[k] = DEF[k]; for (k in v) o[k] = v[k]; return o; })();
  function save() { st.set('set', S); }
  function f2(v) { return (+v).toFixed(2); }

  /* the filter chain, from the settings */
  function chain(o, useAi, useMix) {
    var f = [];
    f.push('highpass=f=' + Math.round(o.hp || 80) + ':poles=2');
    if (o.hum) [1, 2, 3, 4, 5].forEach(function (k) { f.push('bandreject=f=' + (o.hum * k) + ':width_type=q:w=' + (k === 1 ? 18 : 25)); });
    if (o.declick) f.push('adeclick=w=55:o=75');
    if (useAi && o.ai > 0) f.push('arnndn=m=' + (o.model === 'cb' ? 'cb' : 'sh') + '.rnnn' + (useMix ? ':mix=' + f2(Math.min(1, o.ai)) : ''));
    if (o.nr > 0) f.push('afftdn=nr=' + f2(6 + o.nr * 30) + ':nf=' + f2(-50 + o.nr * 12) + ':tn=1');
    if (o.room > 0) f.push('agate=threshold=' + f2(.008 + o.room * .03) + ':ratio=' + f2(1.5 + o.room * 2.5) + ':range=' + f2(Math.max(.06, 1 - o.room * .8)) + ':attack=4:release=' + Math.round(220 - o.room * 140) + ':knee=4');
    if (o.warm > 0) f.push('equalizer=f=140:t=q:w=0.9:g=' + f2(o.warm * 3.5));
    if (o.clarity > 0) {
      f.push('equalizer=f=320:t=q:w=1.1:g=' + f2(-o.clarity * 3.5));
      f.push('equalizer=f=3400:t=q:w=1.2:g=' + f2(o.clarity * 4));
      f.push('equalizer=f=11000:t=q:w=0.8:g=' + f2(o.clarity * 2.2));
    }
    if (o.ess > 0) f.push('deesser=i=' + f2(Math.min(1, o.ess)) + ':m=0.5:f=0.5:s=o');
    if (o.comp > 0) f.push('acompressor=threshold=' + f2(.25 - o.comp * .17) + ':ratio=' + f2(2 + o.comp * 3) + ':attack=8:release=140:makeup=' + f2(1 + o.comp * 1.5) + ':knee=3');
    if (o.lufs) f.push('loudnorm=I=' + o.lufs + ':TP=-1.5:LRA=9');
    f.push('alimiter=limit=0.94:attack=3:release=40:level=disabled', 'aresample=48000');
    return f.join(',');
  }
  function tempo(sp) { var f = [], x = sp; while (x > 2) { f.push('atempo=2'); x /= 2; } while (x < .5) { f.push('atempo=0.5'); x /= .5; } if (Math.abs(x - 1) > 1e-3) f.push('atempo=' + x.toFixed(5)); return f; }
  function modelDir() { return Sys.join(Sys.extDir(), 'models'); }

  /* one clip range -> clean wav. src: start in the media file (s), len: media seconds, speed: playback speed */
  var aiState = st.get('ai', 'mix');   // 'mix' | 'nomix' | 'off' — what this ffmpeg build can do
  function process(o, file, src, len, speed, out, raw) {
    var pre = Math.min(1, Math.max(0, src)), af;
    function args(c) {
      af = (raw ? 'anull' : c) + ',atrim=start=' + pre.toFixed(3) + ',asetpts=PTS-STARTPTS';
      var t = tempo(speed || 1); if (t.length) af += ',' + t.join(',');
      return ['-y', '-hide_banner', '-loglevel', 'error', '-ss', (src - pre).toFixed(3), '-t', (len + pre).toFixed(3), '-i', file, '-vn', '-af', af, '-ar', '48000', '-c:a', 'pcm_s24le', out];
    }
    function go(mode) {
      return Sys.run(args(chain(o, mode !== 'off', mode === 'mix')), { cwd: modelDir(), timeout: 20 * 60000 }).then(function (r) {
        if (r.code === 0 && Sys.exists(out)) return mode;
        if (!raw && mode === 'mix') return go('nomix');
        if (!raw && mode === 'nomix') return go('off');
        throw new Error((r.err || '').split('\n').filter(Boolean).slice(-2).join(' ') || 'ffmpeg');
      });
    }
    return go(raw ? 'off' : aiState).then(function (m) { if (!raw && m !== aiState) { aiState = m; st.set('ai', m); } return out; });
  }

  /* ---------------- tab ---------------- */
  var ui = {}, ctl = {}, busy = false, stopReq = false, ab = { a: null, b: null, which: 'b' };
  function set(p) { for (var k in p) S[k] = p[k]; save(); stale(); }
  function stale() { if (ab.b) { ui.abHint.textContent = 'غيّرت الإعدادات — دوس «جرّب على 8 ثواني» تاني عشان تسمع التعديل.'; } }
  function sl(k, label, min, max, step, fmt) { var c = K.slider({ label: label, min: min, max: max, step: step, value: S[k], fmt: fmt, onInput: function (v) { var p = {}; p[k] = v; set(p); } }); ctl[k] = c; return c; }
  function pct(v) { return Math.round(v * 100) + '%'; }
  function syncAll() { Object.keys(ctl).forEach(function (k) { if (ctl[k].setValue && S[k] !== undefined) ctl[k].setValue(S[k]); }); }
  function pick() {
    return Sys.call('cr_selAudio').then(function (r) {
      if (!r || !r.ok) throw new Error('افتح سيكوينس الأول.');
      var cl = (r.clips || []).filter(function (c) { return c.path && c.on !== false; });
      if (!cl.length) throw new Error('اختار الكليبات اللي عايز تنضّف صوتها في التايملاين (الصوت أو الفيديو المربوط بيه).');
      r.clips = cl; return r;
    });
  }
  function dirFor() {
    return Sys.call('cr_info').then(function (inf) {
      var d = inf && inf.dir ? Sys.join(inf.dir, 'ENP Renders', 'Clean Audio') : Sys.join(Sys.workDir(), 'clean-audio');
      Sys.mkdirp(d); return d;
    });
  }
  function stamp() { var d = new Date(); function p(n) { return (n < 10 ? '0' : '') + n; } return p(d.getHours()) + p(d.getMinutes()) + p(d.getSeconds()); }
  function lock(on) { busy = on; ui.go.disabled = on; ui.test.disabled = on; K.show(ui.stop, on); }

  /* A/B: 8 seconds of the first selected clip, around the playhead when it's inside it */
  function test() {
    if (busy) return; lock(true); stopReq = false; stopAB();
    ui.status.show('busy', 'بجهّز عيّنة…');
    pick().then(function (r) {
      var c = r.clips[0], len = Math.min(8, c.end - c.start), at = r.t > c.start && r.t < c.end - 1 ? Math.max(c.start, Math.min(r.t - 1, c.end - len)) : c.start;
      var src = c.inPoint + (at - c.start) * (c.speed || 1), dir = Sys.join(Sys.workDir(), 'clean-ab'); Sys.mkdirp(dir);
      var A = Sys.join(dir, 'a-' + stamp() + '.wav'), B = Sys.join(dir, 'b-' + stamp() + '.wav');
      return process(S, c.path, src, len * (c.speed || 1), c.speed, A, true).then(function () {
        ui.status.show('busy', 'بنضّف العيّنة…');
        return process(S, c.path, src, len * (c.speed || 1), c.speed, B, false);
      }).then(function () {
        if (ab.files) ab.files.forEach(Sys.remove);
        ab.files = [A, B];
        ab.a = new Audio(Sys.url(A)); ab.b = new Audio(Sys.url(B)); ab.a.loop = ab.b.loop = true;
        ui.abHint.textContent = 'العيّنة جاهزة — بدّل بين قبل وبعد وهي شغالة.';
        K.show(ui.abBox, true); playAB('b');
        ui.status.show(aiState === 'off' ? 'warn' : 'ok', aiState === 'off' ? 'نسخة ffmpeg عندك مافيهاش فلتر الذكاء الاصطناعي — اشتغلت بباقي الفلاتر.' : 'اسمع الفرق ✓');
      });
    }).catch(function (e) { ui.status.show('err', e.message || String(e)); })
      .then(function () { lock(false); });
  }
  function playAB(w) {
    if (!ab.a) return;
    var from = ab.which === 'a' ? ab.a : ab.b, to = w === 'a' ? ab.a : ab.b, t = from.currentTime || 0;
    ab.which = w; from.pause(); try { to.currentTime = t; } catch (e) {} to.play();
    ui.abSeg.setValue(w); ui.abPlay.innerHTML = K.ICON.stop;
  }
  function stopAB() { if (ab.a) { ab.a.pause(); ab.b.pause(); } if (ui.abPlay) ui.abPlay.innerHTML = K.ICON.play; }

  function apply() {
    if (busy) return; lock(true); stopReq = false; stopAB();
    var made = [], clips = [];
    pick().then(function (r) {
      clips = r.clips;
      return dirFor().then(function (dir) {
        var i = 0;
        function next() {
          if (stopReq) throw new Error('cancelled');
          if (i >= clips.length) return;
          var c = clips[i], dur = c.end - c.start, sp = c.speed || 1;
          ui.status.show('busy', 'بنضّف ' + (i + 1) + ' من ' + clips.length + ' — ' + (c.name || ''));
          ui.prog.set(i / clips.length);
          var out = Sys.join(dir, 'ENP_Clean_' + String(c.name || 'clip').replace(/\.[^.]+$/, '').replace(/[^\w؀-ۿ-]+/g, '_').slice(0, 40) + '_' + stamp() + '_' + i + '.wav');
          return process(S, c.path, c.inPoint, dur * sp, sp, out, false).then(function () {
            made.push({ path: out, at: c.start, dur: dur, src: { track: c.track, id: c.id, start: c.start } }); i++; return next();
          });
        }
        return next();
      });
    }).then(function () {
      ui.prog.set(1); ui.status.show('busy', 'بحط الصوت النضيف على التايملاين…');
      return Sys.call('cr_placeClean', { items: made, mute: S.mute });
    }).then(function (r) {
      if (!r || !r.ok) throw new Error(r && r.error === 'no_free_track' ? 'مفيش تراك صوت فاضي — زوّد تراك صوت وجرّب تاني.' : (r && (r.error || r.detail)) || 'place');
      ui.status.show('ok', 'اتنضّف ' + r.placed + ' كليب واتحط على ' + r.track + (r.muted ? ' — والأصلي اتقفل (تقدر ترجّعه: كليك يمين ← Enable)' : '') + (aiState === 'off' ? ' · فلتر الذكاء الاصطناعي مش مدعوم في ffmpeg عندك' : '') + ' ✓');
    }).catch(function (e) { ui.status.show(e && e.message === 'cancelled' ? 'warn' : 'err', e && e.message === 'cancelled' ? 'وقفت.' : (e.message || String(e))); })
      .then(function () { lock(false); ui.prog.done(); });
  }

  function build(root) {
    ui.status = K.status(); ui.prog = K.progress();
    var chips = h('div', { class: 'chips' });
    function mark() { [].forEach.call(chips.children, function (b) { b.classList.toggle('on', b.getAttribute('data-v') === S.preset); }); }
    PRESETS.forEach(function (p) {
      chips.appendChild(h('button', { type: 'button', class: 'chip', 'data-v': p.id, title: p.hint, text: p.name, onclick: function () {
        var keep = { lufs: S.lufs, mute: S.mute, model: 'sh' }; for (var k in keep) S[k] = keep[k]; for (k in p.set) S[k] = p.set[k];
        S.preset = p.id; save(); syncAll(); mark(); ui.hum.setValue(String(S.hum)); ui.lufs.setValue(String(S.lufs)); ui.declick.setValue(S.declick); ui.pHint.textContent = p.hint; stale();
      } }));
    });
    ui.pHint = h('div', { class: 'hint' });
    ui.hum = K.seg({ items: [{ v: '0', label: 'مفيش' }, { v: '50', label: '50Hz (مصر)' }, { v: '60', label: '60Hz' }], value: String(S.hum), onChange: function (v) { set({ hum: +v }); } });
    ui.lufs = K.seg({ items: [{ v: '-14', label: 'ريلز -14' }, { v: '-16', label: 'يوتيوب -16' }, { v: '-19', label: 'بودكاست -19' }, { v: '0', label: 'زي ما هو' }], value: String(S.lufs), onChange: function (v) { set({ lufs: +v }); } });
    ui.declick = K.toggle('شيل الطقطقة وصوت البُق', S.declick, function (v) { set({ declick: v }); });
    ui.test = K.btn('جرّب على 8 ثواني (قبل/بعد)', { icon: 'play', onClick: test });
    ui.go = K.btn('نضّف الكليبات المختارة', { cls: 'pri', icon: 'spark', onClick: apply });
    ui.stop = K.btn('وقّف', { icon: 'stop', onClick: function () { stopReq = true; } }); K.show(ui.stop, false);
    ui.abSeg = K.seg({ items: [{ v: 'a', label: 'قبل' }, { v: 'b', label: 'بعد' }], value: 'b', onChange: function (v) { playAB(v); } });
    ui.abPlay = h('button', { type: 'button', class: 'ibtn', html: K.ICON.play, onclick: function () { if (!ab.a) return; var cur = ab.which === 'a' ? ab.a : ab.b; if (cur.paused) playAB(ab.which); else stopAB(); } });
    ui.abHint = h('div', { class: 'hint' });
    ui.abBox = h('div', { class: 'cam' }, [h('div', { class: 'bar' }, [ui.abPlay, ui.abSeg]), ui.abHint]); K.show(ui.abBox, false);
    [h('div', { class: 'hint intro', text: 'نضّف الصوت باحتراف مهما كانت ظروف التسجيل: اختار الكليبات في التايملاين، اختار الحالة، جرّب قبل/بعد، وبعدين نضّف. النسخة النضيفة بتتحط على تراك صوت لوحدها بالظبط تحت الأصلي.' }),
      K.section('حالة التسجيل', [chips, ui.pHint], true, 'ac_pre'),
      K.section('التنضيف', [sl('nr', 'شيل الدوشة', 0, 1, .01, pct), sl('ai', 'تنضيف بالذكاء الاصطناعي (فصل الكلام)', 0, 1, .01, pct),
        K.field('زنّة الكهربا', ui.hum), sl('room', 'قلّل صدى الأوضة', 0, 1, .01, pct), sl('hp', 'شيل الخبط والهوا (تحت)', 40, 160, 1, function (v) { return Math.round(v) + 'Hz'; }), ui.declick], true, 'ac_clean'),
      K.section('الوضوح والدفا', [sl('clarity', 'وضوح الكلام', 0, 1, .01, pct), sl('warm', 'دفا وتخانة', 0, 1, .01, pct), sl('ess', 'تهدية حرف السين', 0, 1, .01, pct),
        sl('comp', 'ثبات مستوى الصوت', 0, 1, .01, pct), K.field('العلو النهائي', ui.lufs)], false, 'ac_tone'),
      h('div', { class: 'out' }, [h('div', { class: 'adds' }, [ui.test]), ui.abBox,
        K.toggle('اقفل الصوت الأصلي بعد التنضيف', S.mute, function (v) { set({ mute: v }); }),
        h('div', { style: 'margin-top:10px' }, [ui.go]), h('div', { class: 'tk' }, [ui.stop]), ui.prog, ui.status])
    ].forEach(function (el) { root.appendChild(el); });
    mark(); var p0 = PRESETS.filter(function (p) { return p.id === S.preset; })[0]; if (p0) ui.pHint.textContent = p0.hint;
  }
  G.AudioCleanTab = { build: build, onHide: stopAB, _chain: chain };
})(window);
