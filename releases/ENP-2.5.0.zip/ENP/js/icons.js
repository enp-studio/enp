/* ENP — icon library: ~2000 open-license line icons (Lucide, ISC licence) with search in Arabic or English,
   colours, glow, 3D depth, badges and entrances (draw-on, pop, spin…), rendered with alpha onto the timeline. */
(function (G) {
  'use strict';
  var K = G.K, h = K.h, st = K.store('enp_icons_');
  var CAT_AR = { accessibility: 'إتاحة', account: 'حساب', animals: 'حيوانات', arrows: 'أسهم', buildings: 'مباني', charts: 'رسوم بيانية', communication: 'تواصل', connectivity: 'اتصال',
    cursors: 'مؤشرات', design: 'تصميم', development: 'برمجة', devices: 'أجهزة', emoji: 'إيموجي', files: 'ملفات', finance: 'فلوس', 'food-beverage': 'أكل وشرب', gaming: 'ألعاب', home: 'بيت',
    layout: 'تخطيط', 'letters-digits': 'حروف وأرقام', mail: 'بريد', math: 'رياضيات', medical: 'طبي', multimedia: 'ميديا', nature: 'طبيعة', navigation: 'خرايط', notifications: 'إشعارات',
    people: 'ناس', photography: 'تصوير', science: 'علوم', seasons: 'مواسم', security: 'أمان', shapes: 'أشكال', shopping: 'شوبينج', social: 'سوشيال', sports: 'رياضة',
    sustainability: 'بيئة', text: 'نص', time: 'وقت', tools: 'أدوات', transportation: 'مواصلات', travel: 'سفر', weather: 'طقس' };
  /* Arabic words -> English terms used by the icon names / tags */
  var AR = {
    'قلب': 'heart', 'حب': 'heart', 'نجمة': 'star', 'نجم': 'star', 'بيت': 'house home', 'منزل': 'house home', 'تليفون': 'phone', 'موبايل': 'smartphone phone', 'هاتف': 'phone', 'كاميرا': 'camera',
    'فيديو': 'video film clapperboard', 'صورة': 'image', 'صور': 'image images', 'مزيكا': 'music', 'موسيقى': 'music', 'صوت': 'volume audio mic speaker', 'مايك': 'mic', 'ميكروفون': 'mic',
    'بحث': 'search', 'دور': 'search', 'إعدادات': 'settings cog', 'اعدادات': 'settings cog', 'ترس': 'cog settings', 'مستخدم': 'user', 'شخص': 'user person', 'ناس': 'users', 'فريق': 'users',
    'رسالة': 'message mail', 'رسائل': 'message', 'شات': 'message chat', 'ايميل': 'mail', 'إيميل': 'mail', 'بريد': 'mail', 'جرس': 'bell', 'إشعار': 'bell notification', 'اشعار': 'bell',
    'سهم': 'arrow', 'أسهم': 'arrow', 'يمين': 'right', 'شمال': 'left', 'فوق': 'up', 'تحت': 'down', 'تحميل': 'download', 'رفع': 'upload', 'لينك': 'link', 'رابط': 'link',
    'قفل': 'lock', 'أمان': 'shield lock', 'امان': 'shield lock', 'درع': 'shield', 'مفتاح': 'key', 'فلوس': 'dollar wallet banknote coins', 'دولار': 'dollar', 'محفظة': 'wallet', 'كارت': 'credit-card',
    'عربية': 'cart car shopping', 'شنطة': 'bag briefcase', 'تسوق': 'shopping cart bag', 'هدية': 'gift', 'ساعة': 'clock watch', 'وقت': 'clock timer', 'تقويم': 'calendar', 'تاريخ': 'calendar',
    'شمس': 'sun', 'قمر': 'moon', 'سحابة': 'cloud', 'مطر': 'cloud-rain umbrella', 'برق': 'zap bolt', 'نار': 'flame fire', 'مية': 'droplet water', 'ماء': 'droplet water', 'شجرة': 'tree',
    'ورد': 'flower', 'وردة': 'flower', 'زرع': 'leaf sprout', 'عربيه': 'car', 'سيارة': 'car', 'طيارة': 'plane', 'طائرة': 'plane', 'قطر': 'train', 'دراجة': 'bike', 'خريطة': 'map', 'مكان': 'map-pin pin',
    'لوكيشن': 'map-pin', 'كتاب': 'book', 'قلم': 'pen pencil', 'ملف': 'file', 'ملفات': 'file folder', 'فولدر': 'folder', 'كمبيوتر': 'computer laptop monitor', 'لابتوب': 'laptop', 'شاشة': 'monitor tv',
    'تلفزيون': 'tv', 'لعبة': 'gamepad', 'العاب': 'gamepad', 'كورة': 'ball volleyball', 'كاس': 'trophy cup', 'كأس': 'trophy', 'جايزة': 'trophy award medal', 'ميدالية': 'medal', 'تاج': 'crown',
    'صح': 'check', 'علامة': 'check', 'غلط': 'x', 'إكس': 'x', 'زائد': 'plus', 'ناقص': 'minus', 'معلومة': 'info', 'سؤال': 'help circle-question', 'تحذير': 'alert triangle', 'خطر': 'alert siren',
    'لايك': 'thumbs-up heart', 'اعجاب': 'thumbs-up', 'مشاركة': 'share', 'شير': 'share', 'حفظ': 'save bookmark', 'سلة': 'trash basket', 'مسح': 'trash eraser', 'تعديل': 'edit pencil',
    'قهوة': 'coffee', 'أكل': 'utensils pizza', 'اكل': 'utensils pizza', 'بيتزا': 'pizza', 'كيك': 'cake', 'تورتة': 'cake', 'دكتور': 'stethoscope', 'دوا': 'pill', 'مستشفى': 'hospital',
    'رياضة': 'dumbbell bike', 'جيم': 'dumbbell', 'قط': 'cat', 'كلب': 'dog', 'عصفور': 'bird', 'سمكة': 'fish', 'وش': 'smile face', 'ضحك': 'laugh smile', 'زعل': 'frown', 'إيموجي': 'smile',
    'نجاح': 'trophy rocket', 'صاروخ': 'rocket', 'فكرة': 'lightbulb', 'لمبة': 'lightbulb', 'هدف': 'target goal', 'رسم': 'chart', 'جراف': 'chart', 'احصائيات': 'chart bar', 'نمو': 'trending-up',
    'تشغيل': 'play', 'ايقاف': 'pause', 'سماعة': 'headphones', 'واي فاي': 'wifi', 'نت': 'wifi globe', 'عالم': 'globe earth', 'بطارية': 'battery', 'كهربا': 'plug zap', 'ستار': 'sparkles',
    'لمعة': 'sparkles', 'سحر': 'wand sparkles', 'بوكس': 'box package', 'شحن': 'truck package', 'توصيل': 'truck', 'مبنى': 'building', 'شركة': 'building briefcase', 'مدرسة': 'school graduation',
    'تخرج': 'graduation', 'قانون': 'scale gavel', 'ميزان': 'scale', 'كاميرا فيديو': 'video', 'تصوير': 'camera aperture', 'كليب': 'clapperboard', 'مونتاج': 'scissors film', 'مقص': 'scissors'
  };
  var DEF = { icon: 'heart', color: '#ffffff', color2: '#e48aa6', grad: false, sw: 2, fill: 0, glow: .5, depth: 0, badge: 'none', badgeColor: '#8f1f3f', size: .28, x: .5, y: .45,
    anim: 'draw', loop: 'float', outAnim: 'pop', dur: 3, inDur: .8, outDur: .4, cat: '' };
  var S = (function () { var o = {}, k, v = st.get('set', {}); for (k in DEF) o[k] = DEF[k]; for (k in v) o[k] = v[k]; return o; })();
  function save() { st.set('set', S); }
  var ANIMS = { draw: 'بتترسم بالخط', pop: 'بوب', spin: 'بتلف وتظهر', rise: 'طالعة من تحت', drop: 'نازلة من فوق', fade: 'ظهور هادي', bounce: 'بتنط', none: 'من غير' };
  var LOOPS = { none: 'ثابتة', float: 'عايمة', pulse: 'نبض', wiggle: 'بتتهز', rotate: 'بتلف', glowp: 'توهج بينبض' };
  var OUTS = { pop: 'تصغر وتختفي', fade: 'تختفي بهدوء', undraw: 'تتمسح بالخط', drop: 'تنزل', none: 'من غير' };
  var BADGES = { none: 'من غير', circle: 'دايرة', square: 'مربع', glass: 'زجاج', ring: 'حلقة' };

  var DATA = null, MAP = {};
  function loadData() {
    if (DATA) return Promise.resolve(DATA);
    return new Promise(function (res, rej) {
      if (G.ENP_ICONS) { DATA = G.ENP_ICONS; DATA.icons.forEach(function (x) { MAP[x[0]] = x; }); return res(DATA); }
      var sc = G.document.createElement('script'); sc.src = 'js/icons-data.js';
      sc.onload = function () { DATA = G.ENP_ICONS; DATA.icons.forEach(function (x) { MAP[x[0]] = x; }); res(DATA); };
      sc.onerror = function () { rej(new Error('icons-data')); }; G.document.head.appendChild(sc);
    });
  }
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function eo(x) { x = clamp(x, 0, 1); return 1 - Math.pow(1 - x, 3); }
  function eback(x) { x = clamp(x, 0, 1); var c = 1.9; return 1 + (c + 1) * Math.pow(x - 1, 3) + c * Math.pow(x - 1, 2); }
  function ebounce(x) { x = clamp(x, 0, 1); var n = 7.5625, d = 2.75; if (x < 1 / d) return n * x * x; if (x < 2 / d) return n * (x -= 1.5 / d) * x + .75; if (x < 2.5 / d) return n * (x -= 2.25 / d) * x + .9375; return n * (x -= 2.625 / d) * x + .984375; }
  function shade(hex, k) { var n = parseInt(String(hex).slice(1, 7), 16) || 0, r = n >> 16 & 255, g = n >> 8 & 255, b = n & 255; function f(c) { return Math.round(c * k); } return 'rgb(' + f(r) + ',' + f(g) + ',' + f(b) + ')'; }

  /* the icon as an SVG; draw = 0..1 how much of every stroke is drawn */
  function svg(name, s, px, draw, color) {
    var it = MAP[name]; if (!it) return '';
    var inner = it[1], col = color || s.color, stroke = s.grad && !color ? 'url(#g)' : col;
    if (draw < 1) inner = inner.replace(/<(path|circle|rect|line|polyline|polygon|ellipse)\b/g, '<$1 pathLength="1" stroke-dasharray="1 1" stroke-dashoffset="' + (1 - Math.max(0, draw)).toFixed(4) + '"');
    var defs = s.grad && !color ? '<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="' + s.color + '"/><stop offset="1" stop-color="' + s.color2 + '"/></linearGradient></defs>' : '';
    var fill = s.fill > 0 ? (s.grad && !color ? 'url(#g)' : col) : 'none';
    return '<svg xmlns="http://www.w3.org/2000/svg" width="' + px + '" height="' + px + '" viewBox="0 0 24 24" fill="' + fill + '" fill-opacity="' + (s.fill * .35).toFixed(3) + '" stroke="' + stroke + '" stroke-width="' + s.sw + '" stroke-linecap="round" stroke-linejoin="round">' + defs + inner + '</svg>';
  }
  var imgs = {}, order = [];
  function img(code) {
    if (imgs[code]) return imgs[code];
    var p = new Promise(function (res) { var im = new Image(); im.onload = function () { res(im); }; im.onerror = function () { res(null); }; im.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(code); });
    imgs[code] = p; order.push(code); while (order.length > 60) delete imgs[order.shift()];
    return p;
  }
  /* state at time t */
  function at(s, t) {
    var dur = Math.max(.5, s.dur), pi = s.anim === 'none' ? 1 : clamp(t / Math.max(.05, s.inDur), 0, 1), po = s.outAnim === 'none' ? 1 : clamp((dur - t) / Math.max(.05, s.outDur), 0, 1);
    var o = { sc: 1, a: 1, rot: 0, dx: 0, dy: 0, draw: 1, glow: 1 };
    switch (s.anim) {
      case 'draw': o.draw = eo(pi * 1.05); o.sc = .9 + .1 * eo(pi); break;
      case 'pop': o.sc = eback(pi); o.a = clamp(pi * 4, 0, 1); break;
      case 'spin': o.sc = eback(pi); o.rot = (1 - eo(pi)) * -200; o.a = clamp(pi * 3, 0, 1); break;
      case 'rise': o.dy = (1 - eback(pi)) * .35; o.a = eo(pi); break;
      case 'drop': o.dy = -(1 - eo(pi)) * .5; o.a = clamp(pi * 3, 0, 1); break;
      case 'fade': o.a = eo(pi); break;
      case 'bounce': o.dy = -(1 - ebounce(pi)) * .6; o.a = clamp(pi * 5, 0, 1); break;
    }
    switch (s.loop) {
      case 'float': o.dy += Math.sin(t * 2.1) * .04; o.rot += Math.sin(t * 1.3) * 3; break;
      case 'pulse': o.sc *= 1 + Math.max(0, Math.sin(t * 4.5)) * .07; break;
      case 'wiggle': o.rot += Math.sin(t * 14) * 7 * Math.max(0, Math.sin(t * 2.2)); break;
      case 'rotate': o.rot += t * 90; break;
      case 'glowp': o.glow = .55 + .45 * Math.sin(t * 3.4); break;
    }
    switch (s.outAnim) {
      case 'pop': o.sc *= .2 + .8 * eo(po); o.a *= po; break;
      case 'fade': o.a *= po; break;
      case 'undraw': o.draw = Math.min(o.draw, eo(po)); break;
      case 'drop': o.dy += (1 - eo(po)) * .5; o.a *= po; break;
    }
    return o;
  }
  function badge(ctx, s, R) {
    if (s.badge === 'none') return;
    ctx.save();
    if (s.badge === 'circle' || s.badge === 'glass' || s.badge === 'ring') { ctx.beginPath(); ctx.arc(0, 0, R, 0, Math.PI * 2); }
    else { var r = R * .32, w = R * 2; ctx.beginPath(); ctx.moveTo(-R + r, -R); ctx.arcTo(R, -R, R, R, r); ctx.arcTo(R, R, -R, R, r); ctx.arcTo(-R, R, -R, -R, r); ctx.arcTo(-R, -R, R, -R, r); ctx.closePath(); }
    if (s.badge === 'ring') { ctx.lineWidth = R * .08; ctx.strokeStyle = s.badgeColor; ctx.shadowColor = s.badgeColor; ctx.shadowBlur = R * .3 * s.glow; ctx.stroke(); }
    else if (s.badge === 'glass') {
      var g = ctx.createLinearGradient(0, -R, 0, R); g.addColorStop(0, 'rgba(255,255,255,.28)'); g.addColorStop(1, 'rgba(255,255,255,.06)');
      ctx.fillStyle = g; ctx.fill(); ctx.lineWidth = R * .03; ctx.strokeStyle = 'rgba(255,255,255,.55)'; ctx.stroke();
    } else {
      var g2 = ctx.createLinearGradient(0, -R, 0, R); g2.addColorStop(0, shade(s.badgeColor, 1.25)); g2.addColorStop(1, shade(s.badgeColor, .7));
      ctx.shadowColor = 'rgba(0,0,0,.45)'; ctx.shadowBlur = R * .25; ctx.shadowOffsetY = R * .08; ctx.fillStyle = g2; ctx.fill();
    }
    ctx.restore();
  }
  /* one frame */
  function compose(ctx, s, W, H, t) {
    var o = at(s, t), px = Math.max(8, s.size * Math.min(W, H)), q = Math.ceil(px * 1.5);
    var code = svg(s.icon, s, q, o.draw), dark = s.depth > 0 ? svg(s.icon, s, q, o.draw, shade(s.color, .35)) : null;
    return Promise.all([img(code), dark ? img(dark) : null]).then(function (r) {
      var im = r[0], dk = r[1];
      ctx.clearRect(0, 0, W, H);
      if (!im || o.a <= .003) return;
      ctx.save(); ctx.globalAlpha = o.a;
      ctx.translate(s.x * W + o.dx * px, s.y * H + o.dy * px); ctx.rotate(o.rot * Math.PI / 180); ctx.scale(o.sc, o.sc);
      badge(ctx, s, px * .78);
      var sz = s.badge === 'none' ? px : px * .8;
      if (dk) { var n = Math.round(4 + s.depth * 8); for (var i = n; i >= 1; i--) ctx.drawImage(dk, -sz / 2, -sz / 2 + i * sz * .012 * s.depth * 1.6, sz, sz); }
      if (s.glow > 0) { ctx.shadowColor = s.grad ? s.color2 : s.color; ctx.shadowBlur = sz * .18 * s.glow * o.glow; }
      ctx.drawImage(im, -sz / 2, -sz / 2, sz, sz);
      if (s.glow > .6) { ctx.shadowBlur = sz * .4 * (s.glow - .6) * o.glow; ctx.globalAlpha = o.a * .6; ctx.drawImage(im, -sz / 2, -sz / 2, sz, sz); }
      ctx.restore();
    });
  }

  /* ---------------- tab ---------------- */
  var ui = {}, ctl = {}, clock = { on: true, t: 0, last: 0 }, raf = 0, busyF = false, under = null, busy = false, stopReq = false, last = st.get('last', null), seq = { w: 1080, h: 1920 };
  function set(p) { for (var k in p) S[k] = p[k]; save(); }
  function sl(k, label, min, max, step, fmt) { var c = K.slider({ label: label, min: min, max: max, step: step, value: S[k], fmt: fmt, onInput: function (v) { var p = {}; p[k] = v; set(p); } }); ctl[k] = c; return c; }
  function col(k, label) { var inp = h('input', { type: 'color', value: S[k] }); inp.addEventListener('input', function () { var p = {}; p[k] = inp.value; set(p); }); return h('label', { class: 'cfield' }, [inp, h('span', { text: label })]); }
  function sel(k, map) { var e = h('select', { class: 'sel' }, Object.keys(map).map(function (v) { return h('option', { value: v, text: map[v] }); })); e.value = S[k]; e.addEventListener('change', function () { var p = {}; p[k] = e.value; set(p); clock.t = 0; }); return e; }
  function pct(v) { return Math.round(v * 100) + '%'; }
  function sec(v) { return (+v).toFixed(1) + ' ث'; }
  function fit() {
    if (!ui.wrap) return;
    var w = Math.max(160, ui.wrap.clientWidth || 300), ar = seq.w / seq.h, hh = Math.min(K.pvH(420), w / ar), ww = hh * ar;
    ui.stage.style.width = Math.round(ww) + 'px'; ui.stage.style.height = Math.round(hh) + 'px';
    var d = Math.min(2, G.devicePixelRatio || 1); ui.cv.width = Math.round(ww * d); ui.cv.height = Math.round(hh * d);
    ui.bg.width = ui.cv.width; ui.bg.height = ui.cv.height; paintBg();
  }
  function paintBg() {
    var x = ui.bg.getContext('2d'), W = ui.bg.width, H = ui.bg.height;
    if (under && under.img) Out.drawClip(x, under, W, H);
    else { x.fillStyle = '#000'; x.fillRect(0, 0, W, H); }
  }
  function loop() {
    raf = G.requestAnimationFrame(loop);
    if (!ui.cv || !ui.cv.offsetParent || busyF) return;
    var now = Date.now(); if (clock.on) { clock.t += Math.min(.1, (now - (clock.last || now)) / 1000); if (clock.t > S.dur + .5) clock.t = 0; } clock.last = now;
    busyF = true; compose(ui.cv.getContext('2d'), S, ui.cv.width, ui.cv.height, Math.min(clock.t, S.dur)).then(function () { busyF = false; }, function () { busyF = false; });
  }
  var shown = [], page = 0;
  function list() {
    if (!DATA) return;
    var q = (ui.q.value || '').trim().toLowerCase(), terms = [];
    if (q) { terms = q.split(/\s+/).map(function (w) { return (AR[w] || w).split(' '); }); if (AR[q]) terms = [AR[q].split(' ')]; }
    var ci = S.cat ? DATA.cats.indexOf(S.cat) : -1;
    shown = DATA.icons.filter(function (x) {
      if (ci >= 0 && x[3].indexOf(ci) < 0) return false;
      if (!terms.length) return true;
      var hay = x[0] + ' ' + x[2];
      return terms.every(function (alts) { return alts.some(function (a) { return hay.indexOf(a) >= 0; }); });
    });
    page = 0; ui.grid.innerHTML = ''; more();
    ui.count.textContent = shown.length + ' أيقونة';
  }
  function more() {
    var from = page * 120, to = Math.min(shown.length, from + 120);
    for (var i = from; i < to; i++) (function (x) {
      var b = h('button', { type: 'button', class: 'it' + (x[0] === S.icon ? ' on' : ''), title: x[0] });
      b.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="#f6edf1" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' + x[1] + '</svg>';
      b.addEventListener('click', function () { set({ icon: x[0] }); [].forEach.call(ui.grid.children, function (c) { c.classList.remove('on'); }); b.classList.add('on'); clock.t = 0; ui.name.textContent = x[0]; });
      ui.grid.appendChild(b);
    })(shown[i]);
    page++;
  }
  function grab() {
    ui.status.show('busy', 'بجيب الفريم…');
    Out.grabClip(720).then(function (u) { seq = u.seq; under = u.img ? u : null; fit(); ui.status.show(u.img ? 'ok' : 'warn', u.img ? 'الفريم ✓' : 'مفيش فيديو تحت المؤشر.'); })
      .catch(function (e) { ui.status.show('err', Out.errText(e)); });
  }
  function bindDrag() {
    var d = null;
    ui.cv.addEventListener('pointerdown', function (e) { var r = ui.cv.getBoundingClientRect(); try { ui.cv.setPointerCapture(e.pointerId); } catch (x) {} d = { x: e.clientX, y: e.clientY, sx: S.x, sy: S.y, w: r.width, h: r.height }; });
    ui.cv.addEventListener('pointermove', function (e) { if (!d) return; set({ x: clamp(d.sx + (e.clientX - d.x) / d.w, 0, 1), y: clamp(d.sy + (e.clientY - d.y) / d.h, 0, 1) }); });
    ui.cv.addEventListener('pointerup', function () { d = null; if (ctl.x) { ctl.x.setValue(S.x); ctl.y.setValue(S.y); } });
    ui.cv.addEventListener('wheel', function (e) { e.preventDefault(); set({ size: clamp(S.size * (e.deltaY < 0 ? 1.06 : .94), .03, 1) }); if (ctl.size) ctl.size.setValue(S.size); }, { passive: false });
  }
  function place() {
    if (busy) return; busy = true; stopReq = false; ui.place.disabled = true; K.show(ui.stop, true);
    var SS = JSON.parse(JSON.stringify(S)), cv = G.document.createElement('canvas'), x;
    Out.renderAndPlace({
      prefix: 'ENP_Icon', bin: 'ENP Icons', dur: SS.dur, replace: st.get('replace', false) && last ? last.names : [],
      prepare: function (o) { cv.width = o.w; cv.height = o.h; x = cv.getContext('2d'); },
      frame: function (t, i, o) { return compose(x, SS, o.w, o.h, t).then(function () { return x.getImageData(0, 0, o.w, o.h).data; }); },
      onProgress: function (p) { ui.prog.set(p); ui.status.show('busy', 'برندر الأيقونة… ' + Math.round(p * 100) + '%'); },
      cancelled: function () { return stopReq; }
    }).then(function (r) { last = { names: r.names }; st.set('last', last); ui.status.show('ok', 'اتحطت على ' + r.track + ' ✓'); })
      .catch(function (e) { ui.status.show(e && e.message === 'cancelled' ? 'warn' : 'err', Out.errText(e)); })
      .then(function () { busy = false; ui.place.disabled = false; K.show(ui.stop, false); ui.prog.done(); });
  }
  function build(root) {
    ui.status = K.status(); ui.prog = K.progress();
    ui.bg = h('canvas', { class: 'under' }); ui.cv = h('canvas');
    ui.stage = h('div', { class: 'stage' }, [ui.bg, ui.cv]); ui.wrap = h('div', { class: 'pvwrap' }, [ui.stage]);
    ui.q = h('input', { class: 'search', type: 'search', dir: 'auto', placeholder: 'دوّر بالعربي أو بالإنجليزي… (قلب، كاميرا، فلوس، rocket)' });
    var tmr = 0; ui.q.addEventListener('input', function () { clearTimeout(tmr); tmr = setTimeout(list, 160); });
    ui.grid = h('div', { class: 'lib' }); ui.grid.addEventListener('scroll', function () { if (ui.grid.scrollTop + ui.grid.clientHeight > ui.grid.scrollHeight - 60 && page * 120 < shown.length) more(); });
    ui.count = h('span', { class: 'hint' }); ui.name = h('span', { class: 'hint', dir: 'ltr', text: S.icon });
    ui.cats = h('select', { class: 'sel' }); ui.cats.addEventListener('change', function () { set({ cat: ui.cats.value }); list(); });
    ui.place = K.btn('حطها على التايملاين', { cls: 'pri', icon: 'spark', onClick: place });
    ui.stop = K.btn('وقّف', { icon: 'stop', onClick: function () { stopReq = true; } }); K.show(ui.stop, false);
    bindDrag();
    [h('div', { class: 'pv' }, [ui.wrap, h('div', { class: 'bar', style: 'justify-content:space-between' }, [ui.name, K.btn('هات الفريم اللي تحت المؤشر', { icon: 'target', onClick: grab })])]),
      K.section('المكتبة', [ui.q, K.field('القسم', ui.cats), h('div', { style: 'margin:4px 0 6px' }, [ui.count]), ui.grid], true, 'ic_lib'),
      K.section('الشكل', [h('div', { class: 'crow' }, [col('color', 'اللون'), col('color2', 'لون التدرج')]), K.toggle('تدرج لوني', S.grad, function (v) { set({ grad: v }); }),
        sl('sw', 'سُمك الخط', .5, 3.5, .05, function (v) { return (+v).toFixed(2); }), sl('fill', 'ملو خفيف', 0, 1, .01, pct), sl('glow', 'توهج', 0, 1.5, .01, pct), sl('depth', 'عمق 3D', 0, 1, .01, pct),
        K.field('الخلفية', sel('badge', BADGES)), h('div', { class: 'crow' }, [col('badgeColor', 'لون الخلفية')]),
        sl('size', 'الحجم (أو العجلة على المعاينة)', .03, 1, .005, pct), sl('x', 'يمين وشمال', 0, 1, .005, pct), sl('y', 'فوق وتحت', 0, 1, .005, pct)], true, 'ic_look'),
      K.section('الحركة', [K.field('الدخول', sel('anim', ANIMS)), sl('inDur', 'مدة الدخول', .1, 2.5, .05, sec), K.field('حركة مستمرة', sel('loop', LOOPS)),
        K.field('الخروج', sel('outAnim', OUTS)), sl('outDur', 'مدة الخروج', .1, 2, .05, sec), sl('dur', 'المدة', 1, 20, .1, sec)], false, 'ic_anim'),
      h('div', { class: 'out' }, [K.toggle('بدّل آخر أيقونة حطيتها', st.get('replace', false), function (v) { st.set('replace', v); }), h('div', { style: 'margin-top:10px' }, [ui.place]), h('div', { class: 'tk' }, [ui.stop]), ui.prog, ui.status]),
      h('div', { class: 'hint', style: 'margin-top:8px;opacity:.7', text: 'الأيقونات من مكتبة Lucide (رخصة ISC).' })
    ].forEach(function (el) { root.appendChild(el); });
    G.addEventListener('resize', fit);
    Sys.call('cr_info').then(function (r) { if (r && r.ok && r.hasSequence && r.w) { seq = { w: r.w, h: r.h }; fit(); } });
    loadData().then(function (d) {
      ui.cats.appendChild(h('option', { value: '', text: 'كل الأقسام' }));
      d.cats.forEach(function (c) { ui.cats.appendChild(h('option', { value: c, text: CAT_AR[c] || c })); });
      ui.cats.value = S.cat || ''; if (!MAP[S.icon]) S.icon = 'heart'; list();
    }).catch(function () { ui.status.show('err', 'مكتبة الأيقونات ماتحملتش.'); });
    fit(); loop();
  }
  G.IconsTab = { build: build, onHide: function () { clock.on = false; }, onShow: function () { clock.on = true; }, _compose: compose, _load: loadData, _S: function () { return S; } };
})(window);
