/* ENP — project organizer: every item in the Project panel goes into a clear bin by its kind
   (sequences, video, audio, images, graphics, ENP renders), with optional bins for unused and offline media. */
(function (G) {
  'use strict';
  var K = G.K, h = K.h, st = K.store('enp_org_');
  var KINDS = [
    { k: 'seq', name: 'سيكوينسات', bin: '01 Sequences', col: '#4dd2ff' },
    { k: 'video', name: 'فيديو', bin: '02 Video', col: '#8f7bff' },
    { k: 'audio', name: 'صوت ومزيكا', bin: '03 Audio', col: '#4fd18b' },
    { k: 'image', name: 'صور', bin: '04 Images', col: '#f2c26b' },
    { k: 'gfx', name: 'جرافيك وماتات', bin: '05 Graphics', col: '#ff8fb1' },
    { k: 'enp', name: 'رندرات ENP', bin: '06 ENP', col: '#e48aa6' },
    { k: 'other', name: 'ملفات تانية', bin: '07 Other', col: '#b79da9' },
    { k: 'unused', name: 'مش مستخدم', bin: '08 Unused', col: '#9aa0a6' },
    { k: 'offline', name: 'ملفات مفقودة', bin: '09 Offline', col: '#ff6b7d' }
  ];
  var DEF = { scope: 'loose', unused: true, offline: true, colors: true, empty: true, backup: true };
  var S = (function () { var o = {}, k, v = st.get('set', {}); for (k in DEF) o[k] = DEF[k]; for (k in v) o[k] = v[k]; return o; })();
  function save() { st.set('set', S); }
  function names() { var o = {}; KINDS.forEach(function (x) { o[x.k] = x.bin; }); return o; }
  function args(dry) { return { scope: S.scope, unused: S.unused, offline: S.offline, colors: S.colors, empty: S.empty, dry: dry, names: names() }; }
  var ui = {}, busy = false;
  function report(r, done) {
    var rows = KINDS.filter(function (x) { return r.plan && r.plan[x.k]; }).map(function (x) {
      return '<div><span style="display:inline-block;width:9px;height:9px;border-radius:3px;background:' + x.col + ';margin-inline-end:6px"></span><b>' + r.plan[x.k] + '</b> ' + x.name + ' ← <span dir="ltr">' + x.bin + '</span></div>';
    });
    ui.rep.innerHTML = rows.length ? rows.join('') : 'المشروع متنظم — مفيش حاجة تتنقل.';
    if (done) ui.rep.innerHTML += '<div style="margin-top:6px">اتنقل <b>' + r.moved + '</b> عنصر' + (r.removed ? ' · اتمسح <b>' + r.removed + '</b> فولدر فاضي' : '') + (r.colored ? ' · اتلوّن <b>' + r.colored + '</b>' : '') + '</div>';
    K.show(ui.rep, true);
  }
  function scan() {
    if (busy) return; busy = true; ui.status.show('busy', 'بشوف المشروع…');
    Sys.call('cr_organize', args(true)).then(function (r) {
      if (!r || !r.ok) throw new Error(r && r.error === 'no_project' ? 'افتح بروجكت الأول.' : (r && (r.error || r.detail)) || 'scan');
      report(r, false); ui.status.show('ok', r.total ? 'ده اللي هيحصل — دوس «نظّم» لو تمام.' : '');
    }).catch(function (e) { ui.status.show('err', e.message || String(e)); }).then(function () { busy = false; });
  }
  function backup() {
    if (!S.backup) return Promise.resolve(null);
    return Sys.call('cr_projSave').then(function (r) {
      if (!r || !r.ok || !r.path) return null;
      var fs = Sys.req && Sys.req('fs'); if (!fs) return null;
      var p = r.path, out = p.replace(/\.prproj$/i, '') + ' - قبل التنظيم.prproj';
      try { fs.copyFileSync(p, out); return out; } catch (e) { return null; }
    });
  }
  function run() {
    if (busy) return; busy = true; ui.go.disabled = true; ui.status.show('busy', 'بحفظ نسخة احتياطي…');
    var bk = null;
    backup().then(function (b) { bk = b; ui.status.show('busy', 'بنظّم المشروع…'); return Sys.call('cr_organize', args(false)); }).then(function (r) {
      if (!r || !r.ok) throw new Error((r && (r.error || r.detail)) || 'organize');
      report(r, true); ui.status.show('ok', 'المشروع اتنظم ✓' + (bk ? ' — النسخة القديمة محفوظة جنب البروجكت باسم «… - قبل التنظيم»' : ''));
    }).catch(function (e) { ui.status.show('err', e.message || String(e)); }).then(function () { busy = false; ui.go.disabled = false; });
  }
  function build(root) {
    ui.status = K.status(); ui.rep = h('div', { class: 'report' }); K.show(ui.rep, false);
    var legend = h('div', { class: 'report', style: 'max-height:none' }, KINDS.map(function (x) {
      return h('div', {}, [h('span', { style: 'display:inline-block;width:9px;height:9px;border-radius:3px;background:' + x.col + ';margin-inline-end:6px' }), h('span', { text: x.name + ' ← ' }), h('span', { dir: 'ltr', text: x.bin })]);
    }));
    ui.go = K.btn('نظّم المشروع', { cls: 'pri', icon: 'spark', onClick: run });
    [h('div', { class: 'hint intro', text: 'رتّب البروجكت بدوسة: كل ملف بيروح فولدر (Bin) حسب نوعه، والحاجات اللي مش مستخدمة في أي سيكوينس والملفات المفقودة ليهم فولدر لوحدهم. الأول دوس «شوف هيعمل إيه».' }),
      K.section('الفولدرات', [legend], true, 'org_bins'),
      K.section('الإعدادات', [
        K.field('أنهي ملفات', K.seg({ items: [{ v: 'loose', label: 'السايبة بس (برا أي فولدر)' }, { v: 'all', label: 'كل المشروع' }], value: S.scope, onChange: function (v) { S.scope = v; save(); } })),
        h('div', { class: 'hint', text: '«كل المشروع» بيطلّع الملفات من الفولدرات اللي انت عاملها كمان ويرتبها من الأول.' }),
        K.toggle('حط اللي مش مستخدم في فولدر لوحده', S.unused, function (v) { S.unused = v; save(); }),
        K.toggle('حط الملفات المفقودة (Offline) لوحدها', S.offline, function (v) { S.offline = v; save(); }),
        K.toggle('لوّن كل نوع بلون (Label)', S.colors, function (v) { S.colors = v; save(); }),
        K.toggle('امسح الفولدرات الفاضية', S.empty, function (v) { S.empty = v; save(); }),
        K.toggle('احفظ نسخة من البروجكت قبل التنظيم', S.backup, function (v) { S.backup = v; save(); })], true, 'org_set'),
      h('div', { class: 'out' }, [h('div', { class: 'adds' }, [K.btn('شوف هيعمل إيه', { icon: 'target', onClick: scan })]), ui.rep,
        h('div', { style: 'margin-top:10px' }, [ui.go]), ui.status])
    ].forEach(function (el) { root.appendChild(el); });
  }
  G.OrganizeTab = { build: build };
})(window);
