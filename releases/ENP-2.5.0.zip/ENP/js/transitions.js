/* ENP — transitions library. Stand the playhead near a cut, pick a transition: both shots are read around
   the cut (with handles from the media when there are any) and the transition is rendered over the cut. */
(function (G) {
  'use strict';
  var K = G.K, h = K.h, st = K.store('enp_trans_');
  function cl(v, a, b) { return v < a ? a : v > b ? b : v; }
  function io(x) { x = cl(x, 0, 1); return x < .5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2; }
  function io5(x) { x = cl(x, 0, 1); return x < .5 ? 16 * Math.pow(x, 5) : 1 - Math.pow(-2 * x + 2, 5) / 2; }
  function rnd(i) { var x = Math.sin(i * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); }
  var scr = {};
  function cv(n, W, H) { var c = scr[n] || (scr[n] = G.document.createElement('canvas')); if (c.width !== W || c.height !== H) { c.width = W; c.height = H; } return c; }

  /* draw img scaled about the centre, with optional blur */
  function put(x, img, W, H, s, dx, dy, rot, a, blur) {
    x.save(); x.globalAlpha = a === undefined ? 1 : a; if (blur > .3) x.filter = 'blur(' + blur.toFixed(1) + 'px)';
    x.translate(W / 2 + (dx || 0), H / 2 + (dy || 0)); if (rot) x.rotate(rot); x.scale(s, s); x.drawImage(img, -W / 2, -H / 2, W, H); x.restore();
  }
  /* motion blur by averaging copies along a move */
  function smear(x, img, W, H, n, f) {
    for (var i = 0; i < n; i++) { var q = f(n > 1 ? i / (n - 1) - .5 : 0); put(x, img, W, H, q.s, q.dx, q.dy, q.rot, 1 / (i + 1), q.blur || 0); }
  }
  function mix(x, A, B, W, H, k) { put(x, A, W, H, 1); put(x, B, W, H, 1, 0, 0, 0, k); }
  function channels(x, img, W, H, off, ang) {
    var r = cv('r', W, H), g = cv('g', W, H), b = cv('b', W, H), cols = ['#f00', '#0f0', '#00f'], cs = [r, g, b], ox = Math.cos(ang || 0) * off, oy = Math.sin(ang || 0) * off;
    cs.forEach(function (c, i) { var y = c.getContext('2d'); y.globalCompositeOperation = 'source-over'; y.clearRect(0, 0, W, H); y.drawImage(img, (i - 1) * ox, (i - 1) * oy, W, H); y.globalCompositeOperation = 'multiply'; y.fillStyle = cols[i]; y.fillRect(0, 0, W, H); });
    x.save(); x.fillStyle = '#000'; x.fillRect(0, 0, W, H); x.globalCompositeOperation = 'lighter'; cs.forEach(function (c) { x.drawImage(c, 0, 0); }); x.restore();
  }

  /* p: 0..1 through the transition; k: strength; dir: 1 / -1 */
  var FX = {
    zoomIn: { name: 'زووم دخول', f: function (x, A, B, W, H, p, o) {
      var e = io5(p), n = Math.round(4 + 8 * o.k);
      if (e < .5) { var u = e * 2; smear(x, A, W, H, n, function (q) { return { s: 1 + Math.pow(u, 2) * 2.2 * o.k + q * u * .5 * o.k }; }); }
      else { var v = (1 - e) * 2; smear(x, B, W, H, n, function (q) { return { s: 1 / (1 + Math.pow(v, 2) * 1.2 * o.k) * (1 + q * v * .3 * o.k) }; }); }
    } },
    zoomOut: { name: 'زووم خروج', f: function (x, A, B, W, H, p, o) {
      var e = io5(p), n = Math.round(4 + 8 * o.k);
      if (e < .5) { var u = e * 2; smear(x, A, W, H, n, function (q) { return { s: 1 / (1 + Math.pow(u, 2) * 1.2 * o.k) * (1 + q * u * .3 * o.k) }; }); }
      else { var v = (1 - e) * 2; smear(x, B, W, H, n, function (q) { return { s: 1 + Math.pow(v, 2) * 2.2 * o.k + q * v * .5 * o.k }; }); }
    } },
    whipL: { name: 'ويب شمال', f: function (x, A, B, W, H, p, o) { whip(x, A, B, W, H, p, o, -1, 0); } },
    whipR: { name: 'ويب يمين', f: function (x, A, B, W, H, p, o) { whip(x, A, B, W, H, p, o, 1, 0); } },
    whipU: { name: 'ويب لفوق', f: function (x, A, B, W, H, p, o) { whip(x, A, B, W, H, p, o, 0, -1); } },
    whipD: { name: 'ويب لتحت', f: function (x, A, B, W, H, p, o) { whip(x, A, B, W, H, p, o, 0, 1); } },
    spin: { name: 'لفة', f: function (x, A, B, W, H, p, o) {
      var e = io5(p), n = Math.round(5 + 8 * o.k), img = e < .5 ? A : B, base = (e - (e < .5 ? 0 : 1)) * Math.PI * 2 * o.dir, sp = Math.sin(e * Math.PI);
      x.fillStyle = '#000'; x.fillRect(0, 0, W, H);
      smear(x, img, W, H, n, function (q) { return { s: 1 + sp * .45, rot: base + q * sp * .5 * o.k }; });
    } },
    flash: { name: 'فلاش أبيض', f: function (x, A, B, W, H, p, o) {
      put(x, p < .5 ? A : B, W, H, 1 + Math.sin(p * Math.PI) * .06 * o.k);
      x.save(); x.globalAlpha = Math.pow(Math.sin(p * Math.PI), 1.6) * (.7 + .3 * o.k); x.fillStyle = '#fff'; x.fillRect(0, 0, W, H); x.restore();
    } },
    dip: { name: 'غمقان', f: function (x, A, B, W, H, p) { x.fillStyle = '#000'; x.fillRect(0, 0, W, H); put(x, p < .5 ? A : B, W, H, 1, 0, 0, 0, Math.abs(1 - io(p) * 2)); } },
    blur: { name: 'بلور ناعم', f: function (x, A, B, W, H, p, o) { var b = Math.sin(p * Math.PI) * W * .03 * o.k; x.fillStyle = '#000'; x.fillRect(0, 0, W, H); put(x, A, W, H, 1 + Math.sin(p * Math.PI) * .05, 0, 0, 0, 1, b); put(x, B, W, H, 1 + Math.sin(p * Math.PI) * .05, 0, 0, 0, io(p), b); } },
    fade: { name: 'ديزولف', f: function (x, A, B, W, H, p) { mix(x, A, B, W, H, io(p)); } },
    glitch: { name: 'جليتش', f: function (x, A, B, W, H, p, o) {
      var img = p < .5 ? A : B, amt = Math.pow(Math.sin(p * Math.PI), 1.4) * o.k, f = Math.floor(p * 24);
      channels(x, img, W, H, amt * W * .03, 0);
      var n = Math.round(6 + amt * 14);
      for (var i = 0; i < n; i++) { if (rnd(i * 7 + f) > amt * 1.1) continue; var y = rnd(i + f * 13) * H, hh = (.01 + rnd(i * 3 + f) * .07) * H, dx = (rnd(i * 5 + f * 3) - .5) * W * .25 * amt; x.drawImage(img === A ? A : B, 0, y, W, hh, dx, y, W, hh); }
    } },
    rgb: { name: 'ألوان متفرقة', f: function (x, A, B, W, H, p, o) { var s = Math.sin(p * Math.PI); channels(x, p < .5 ? A : B, W, H, s * W * .045 * o.k, p * 3); x.save(); x.globalAlpha = s * .25; x.fillStyle = '#fff'; x.fillRect(0, 0, W, H); x.restore(); } },
    leak: { name: 'لايت ليك', f: function (x, A, B, W, H, p, o) {
      mix(x, A, B, W, H, cl((p - .3) / .4, 0, 1)); var s = Math.sin(p * Math.PI) * o.k;
      x.save(); x.globalCompositeOperation = 'screen';
      [[.2 + p * .6, .3, '#ff8a3d'], [.8 - p * .5, .7, '#ffcf6b'], [.5, .2 + p * .5, '#ff4f6d']].forEach(function (c) {
        var g = x.createRadialGradient(c[0] * W, c[1] * H, 0, c[0] * W, c[1] * H, Math.max(W, H) * .65); g.addColorStop(0, c[2]); g.addColorStop(1, 'rgba(0,0,0,0)');
        x.globalAlpha = s * .9; x.fillStyle = g; x.fillRect(0, 0, W, H);
      }); x.restore();
    } },
    burn: { name: 'حريق فيلم', f: function (x, A, B, W, H, p, o) {
      mix(x, A, B, W, H, cl((p - .35) / .3, 0, 1)); var s = Math.sin(p * Math.PI) * o.k;
      x.save(); x.globalCompositeOperation = 'lighter';
      for (var i = 0; i < 5; i++) { var cx = (rnd(i) * .8 + .1) * W + Math.sin(p * 4 + i) * W * .1, cy = (rnd(i + 9) * .8 + .1) * H, r = Math.max(W, H) * (.2 + rnd(i + 3) * .35) * (.4 + s);
        var g = x.createRadialGradient(cx, cy, 0, cx, cy, r); g.addColorStop(0, 'rgba(255,250,235,' + (s * .95) + ')'); g.addColorStop(.35, 'rgba(255,150,40,' + (s * .7) + ')'); g.addColorStop(1, 'rgba(120,20,0,0)'); x.fillStyle = g; x.fillRect(0, 0, W, H); }
      x.restore();
    } },
    push: { name: 'دفع', f: function (x, A, B, W, H, p, o) { var e = io5(p), d = o.dir; put(x, A, W, H, 1, -e * W * d); put(x, B, W, H, 1, (1 - e) * W * d); } },
    iris: { name: 'دايرة', f: function (x, A, B, W, H, p) { var e = io(p), r = Math.hypot(W, H) / 2 * e; put(x, A, W, H, 1 + e * .08); x.save(); x.beginPath(); x.arc(W / 2, H / 2, Math.max(.1, r), 0, Math.PI * 2); x.clip(); put(x, B, W, H, 1.08 - e * .08); x.restore(); } },
    wipe: { name: 'مسح مايل', f: function (x, A, B, W, H, p) {
      var e = io(p), L = W + H, pos = -H + e * (L + H * .2);
      put(x, A, W, H, 1); x.save(); x.beginPath(); x.moveTo(pos, 0); x.lineTo(pos + H, H); x.lineTo(-W, H); x.lineTo(-W, 0); x.closePath();
      x.moveTo(0, 0); x.clip(); put(x, B, W, H, 1); x.restore();
      x.save(); x.strokeStyle = 'rgba(255,255,255,.6)'; x.lineWidth = Math.max(2, W * .004); x.shadowColor = '#fff'; x.shadowBlur = W * .02; x.globalAlpha = Math.sin(e * Math.PI); x.beginPath(); x.moveTo(pos, 0); x.lineTo(pos + H, H); x.stroke(); x.restore();
    } },
    shake: { name: 'هزة', f: function (x, A, B, W, H, p, o) { var s = Math.sin(p * Math.PI) * o.k, f = Math.floor(p * 30); put(x, p < .5 ? A : B, W, H, 1.08 + s * .08, (rnd(f) - .5) * W * .08 * s, (rnd(f + 5) - .5) * H * .06 * s, (rnd(f + 9) - .5) * .06 * s, 1, s * W * .006);
      x.save(); x.globalAlpha = Math.max(0, 1 - Math.abs(p - .5) * 8) * .7; x.fillStyle = '#fff'; x.fillRect(0, 0, W, H); x.restore(); } },
    pixel: { name: 'بكسلة', f: function (x, A, B, W, H, p) { var s = Math.sin(p * Math.PI), n = Math.max(1, Math.round(1 + s * 40)), c = cv('px', Math.max(1, Math.round(W / n)), Math.max(1, Math.round(H / n))), y = c.getContext('2d');
      y.drawImage(p < .5 ? A : B, 0, 0, c.width, c.height); x.save(); x.imageSmoothingEnabled = false; x.drawImage(c, 0, 0, W, H); x.restore(); } },
    stretch: { name: 'مط', f: function (x, A, B, W, H, p, o) { var e = io5(p); x.fillStyle = '#000'; x.fillRect(0, 0, W, H);
      if (e < .5) { var u = e * 2; x.save(); x.translate(W / 2, H / 2); x.scale(1 + u * 3 * o.k, 1 - u * .6); x.globalAlpha = 1 - u * .6; x.drawImage(A, -W / 2, -H / 2, W, H); x.restore(); }
      else { var v = (1 - e) * 2; x.save(); x.translate(W / 2, H / 2); x.scale(1 + v * 3 * o.k, 1 - v * .6); x.globalAlpha = 1 - v * .6; x.drawImage(B, -W / 2, -H / 2, W, H); x.restore(); } } },
    doors: { name: 'باب', f: function (x, A, B, W, H, p) { var e = io(p); put(x, B, W, H, 1.1 - e * .1);
      x.save(); x.beginPath(); x.rect(0, 0, W / 2 * (1 - e), H); x.clip(); x.drawImage(A, -W / 2 * e, 0, W, H); x.restore();
      x.save(); x.beginPath(); x.rect(W / 2 + W / 2 * e, 0, W / 2, H); x.clip(); x.drawImage(A, W / 2 * e, 0, W, H); x.restore(); } },
    split: { name: 'شرايح', f: function (x, A, B, W, H, p) { var n = 6; put(x, A, W, H, 1);
      for (var i = 0; i < n; i++) { var e = io(cl(p * 1.6 - i * .6 / n, 0, 1)), y0 = i * H / n; x.save(); x.beginPath(); x.rect(0, y0, W, H / n + 1); x.clip(); x.drawImage(B, (i % 2 ? 1 : -1) * W * (1 - e), 0, W, H); x.restore(); } } }
  };
  function whip(x, A, B, W, H, p, o, dx, dy) {
    var e = io5(p), n = Math.round(6 + 10 * o.k), sp = Math.sin(p * Math.PI);
    smear(x, A, W, H, n, function (q) { return { s: 1, dx: (-e + q * sp * .5 * o.k) * W * dx, dy: (-e + q * sp * .5 * o.k) * H * dy }; });
    smear(x, B, W, H, n, function (q) { return { s: 1, dx: ((1 - e) + q * sp * .5 * o.k) * W * dx, dy: ((1 - e) + q * sp * .5 * o.k) * H * dy }; });
  }

  /* ---------- sample pictures for the tiles before a real cut is loaded ---------- */
  function sample(W, H, hue, label) {
    var c = G.document.createElement('canvas'); c.width = W; c.height = H; var x = c.getContext('2d');
    var g = x.createLinearGradient(0, 0, W, H); g.addColorStop(0, 'hsl(' + hue + ',55%,45%)'); g.addColorStop(1, 'hsl(' + (hue + 50) + ',60%,22%)'); x.fillStyle = g; x.fillRect(0, 0, W, H);
    x.fillStyle = 'rgba(255,255,255,.18)'; for (var i = 0; i < 7; i++) { x.beginPath(); x.arc(rnd(i + hue) * W, rnd(i * 3 + hue) * H, (.05 + rnd(i * 7) * .12) * W, 0, 7); x.fill(); }
    x.fillStyle = '#fff'; x.font = '800 ' + Math.round(H * .32) + 'px sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText(label, W / 2, H / 2);
    return c;
  }

  /* ---------- frames around the cut ---------- */
  function grabRange(c, from, len, fps, W, H, dir) {
    /* from: media seconds (may be < 0 or past the end: the nearest picture is held) */
    var start = Math.max(0, from), pre = start - from;
    Sys.mkdirp(dir);
    return Sys.run(['-y', '-hide_banner', '-loglevel', 'error', '-ss', start.toFixed(3), '-i', c.path, '-t', (len - pre + .2).toFixed(3), '-an',
      '-vf', 'fps=' + fps + ',scale=' + W + ':' + H + ':force_original_aspect_ratio=decrease', '-q:v', '3', Sys.join(dir, '%05d.jpg')], { timeout: 300000 }).then(function () {
      var fs = Sys.req('fs'), files = fs.readdirSync(dir).filter(function (f) { return /\.jpg$/.test(f); }).sort();
      if (!files.length) {   // a still image or nothing there: one picture
        return Sys.grabFrame(c.path, start, W, H).then(function (p) { return { files: [p], pre: 0 }; });
      }
      return { files: files.map(function (f) { return Sys.join(dir, f); }), pre: Math.round(pre * fps) };
    });
  }
  function load(src) { return new Promise(function (res) { var im = new Image(); im.onload = function () { res(im); }; im.onerror = function () { res(null); }; im.src = Sys.url(src); }); }
  /* the shot drawn as it sits in the sequence */
  function frameCanvas(name, im, clip, W, H, seqW, srcW, srcH) {
    var c = cv(name, W, H), x = c.getContext('2d'); x.fillStyle = '#000'; x.fillRect(0, 0, W, H);
    if (!im) return c;
    var k = (clip.scale || 100) / 100, P = clip.pos || [.5, .5], A = clip.anchor || [.5, .5], f = W / seqW, dw = srcW * k * f, dh = srcH * k * f;
    x.drawImage(im, P[0] * W - A[0] * dw, P[1] * H - A[1] * dh, dw, dh); return c;
  }

  /* ---------------- tab ---------------- */
  var DEF = { fx: 'zoomIn', dur: .6, k: .8, dir: 1 };
  var S = (function () { var o = {}, k, v = st.get('set', {}); for (k in DEF) o[k] = DEF[k]; for (k in v) o[k] = v[k]; return o; })();
  function save() { st.set('set', S); }
  var ui = {}, ctl = {}, cut = null, pvA = null, pvB = null, busy = false, stopReq = false, raf = 0, t0 = Date.now(), seq = { w: 1080, h: 1920 }, hover = null;
  function sl(k, label, min, max, step, fmt) { var c = K.slider({ label: label, min: min, max: max, step: step, value: S[k], fmt: fmt, onInput: function (v) { S[k] = v; save(); } }); ctl[k] = c; return c; }
  function fit() {
    if (!ui.wrap) return;
    var w = Math.max(160, ui.wrap.clientWidth || 300), ar = seq.w / seq.h, hh = Math.min(K.pvH(400), w / ar), ww = hh * ar;
    ui.stage.style.width = Math.round(ww) + 'px'; ui.stage.style.height = Math.round(hh) + 'px';
    ui.cv.width = Math.round(ww); ui.cv.height = Math.round(hh);
  }
  function tileImgs(W, H) { if (!tileImgs.c) tileImgs.c = { a: sample(W, H, 330, 'A'), b: sample(W, H, 200, 'B') }; return tileImgs.c; }
  function frame() {
    raf = G.requestAnimationFrame(frame);
    if (!ui.cv || !ui.cv.offsetParent) return;
    var cyc = S.dur + .9, tt = ((Date.now() - t0) / 1000) % cyc, p = cl((tt - .45) / S.dur, 0, 1), W = ui.cv.width, H = ui.cv.height;
    var A = pvA || (tileImgs(160, 100).a), B = pvB || tileImgs(160, 100).b;
    var a2 = cv('pa', W, H), b2 = cv('pb', W, H); a2.getContext('2d').drawImage(A, 0, 0, W, H); b2.getContext('2d').drawImage(B, 0, 0, W, H);
    var x = ui.cv.getContext('2d'); x.save(); FX[S.fx].f(x, a2, b2, W, H, p, { k: S.k, dir: S.dir }); x.restore();
    if (hover) { var tp = ((Date.now() - t0) / 1000 % 1.6) / 1.2, ti = tileImgs(160, 100), hx = hover.c.getContext('2d'); hx.save(); FX[hover.k].f(hx, ti.a, ti.b, 160, 100, cl(tp, 0, 1), { k: S.k, dir: S.dir }); hx.restore(); }
  }
  function still(c, k) { var ti = tileImgs(160, 100), x = c.getContext('2d'); x.save(); FX[k].f(x, ti.a, ti.b, 160, 100, .42, { k: .8, dir: 1 }); x.restore(); }
  function findCut() {
    ui.status.show('busy', 'بدوّر على القطع…');
    return Sys.call('cr_cutAt', { within: 3 }).then(function (r) {
      if (!r || !r.ok) throw new Error('افتح سيكوينس الأول.');
      if (r.none) throw new Error('مفيش قطع بين مشهدين جنب المؤشر — قف قريب من القطع (في حدود 3 ثواني).');
      cut = r; seq = { w: r.w, h: r.h, fps: r.fps }; fit();
      var dir = Sys.join(Sys.workDir(), 'trans-pv'), mw = 360, mh = Math.round(360 * r.h / r.w / 2) * 2;
      return Promise.all([r.a, r.b].map(function (c, i) {
        var tm = i === 0 ? c.inPoint + (r.cut - c.start - .04) * (c.speed || 1) : c.inPoint + .02;
        return Sys.probe(c.path).then(function (inf) { c.srcW = inf.w || r.w; c.srcH = inf.h || r.h; return Sys.grabFrame(c.path, tm, Math.round(c.srcW * mw / Math.max(c.srcW, c.srcH) / 2) * 2, Math.round(c.srcH * mw / Math.max(c.srcW, c.srcH) / 2) * 2); }).then(load);
      })).then(function (ims) {
        var W = 360, H = Math.round(360 * r.h / r.w);
        pvA = cloneCv(frameCanvas('fa', ims[0], r.a, W, H, r.w, r.a.srcW, r.a.srcH)); pvB = cloneCv(frameCanvas('fb', ims[1], r.b, W, H, r.w, r.b.srcW, r.b.srcH));
        ui.status.show('ok', 'القطع عند ' + r.cut.toFixed(2) + 'ث على V' + (r.track + 1) + ' ✓');
      });
    }).catch(function (e) { ui.status.show('err', e.message || String(e)); throw e; });
  }
  function cloneCv(c) { var d = G.document.createElement('canvas'); d.width = c.width; d.height = c.height; d.getContext('2d').drawImage(c, 0, 0); return d; }
  function apply() {
    if (busy) return; busy = true; stopReq = false; ui.go.disabled = true; K.show(ui.stop, true);
    var SS = JSON.parse(JSON.stringify(S)), r = null, fr = {}, W = 0, H = 0, fps = 30, ims = { a: {}, b: {} };
    findCut().then(function () {
      r = cut; fps = r.fps || 30; var d = SS.dur, half = d / 2, base = Sys.join(Sys.workDir(), 'trans', String(Date.now()));
      W = r.w; H = r.h; ui.status.show('busy', 'بقرا المشهدين…');
      var A = r.a, B = r.b, sa = A.speed || 1, sb = B.speed || 1;
      return Promise.all([
        grabRange(A, A.inPoint + (r.cut - half - A.start) * sa, d * sa, fps / sa, A.srcW, A.srcH, Sys.join(base, 'a')),
        grabRange(B, B.inPoint - half * sb, d * sb, fps / sb, B.srcW, B.srcH, Sys.join(base, 'b'))
      ]).then(function (x) { fr.a = x[0]; fr.b = x[1]; });
    }).then(function () {
      function pic(which, i) {
        var f = fr[which], j = cl(i - f.pre, 0, f.files.length - 1), key = j;
        if (ims[which][key]) return ims[which][key];
        var p = load(f.files[j]); ims[which][key] = p; return p;
      }
      return Out.renderAndPlace({
        prefix: 'ENP_Trans', bin: 'ENP Transitions', dur: SS.dur, at: r.cut - SS.dur / 2, replace: [],
        prepare: function (o) { W = o.w; H = o.h; },
        frame: function (t, i, o) {
          return Promise.all([pic('a', i), pic('b', i)]).then(function (pp) {
            var a = frameCanvas('ra', pp[0], r.a, W, H, r.w, r.a.srcW, r.a.srcH), b = frameCanvas('rb', pp[1], r.b, W, H, r.w, r.b.srcW, r.b.srcH);
            var out = cv('out', W, H), x = out.getContext('2d'); x.clearRect(0, 0, W, H); x.save();
            FX[SS.fx].f(x, a, b, W, H, cl((t + .5 / o.fps) / SS.dur, 0, 1), { k: SS.k, dir: SS.dir }); x.restore();
            if (i % 10 === 0) { delete ims.a[i - 12]; delete ims.b[i - 12]; }
            return x.getImageData(0, 0, W, H).data;
          });
        },
        onProgress: function (p) { ui.prog.set(p); ui.status.show('busy', 'برندر الانتقال… ' + Math.round(p * 100) + '%'); },
        cancelled: function () { return stopReq; }
      });
    }).then(function (res) { ui.status.show('ok', 'الانتقال اتحط على ' + res.track + ' فوق القطع ✓'); })
      .catch(function (e) { if (e && e.message && /قطع|سيكوينس/.test(e.message)) return; ui.status.show(e && e.message === 'cancelled' ? 'warn' : 'err', Out.errText(e)); })
      .then(function () { busy = false; ui.go.disabled = false; K.show(ui.stop, false); ui.prog.done(); });
  }
  function build(root) {
    ui.status = K.status(); ui.prog = K.progress();
    ui.cv = h('canvas'); ui.stage = h('div', { class: 'stage' }, [ui.cv]); ui.wrap = h('div', { class: 'pvwrap' }, [ui.stage]);
    var tiles = h('div', { class: 'tiles' });
    Object.keys(FX).forEach(function (k) {
      var c = h('canvas', { width: 160, height: 100 }), b = h('button', { type: 'button', class: 'tl' + (S.fx === k ? ' on' : '') }, [c, h('span', { text: FX[k].name })]);
      still(c, k);
      b.addEventListener('mouseenter', function () { hover = { c: c, k: k }; t0 = Date.now(); });
      b.addEventListener('mouseleave', function () { hover = null; still(c, k); });
      b.addEventListener('click', function () { S.fx = k; save(); t0 = Date.now(); [].forEach.call(tiles.children, function (x) { x.classList.remove('on'); }); b.classList.add('on'); });
      tiles.appendChild(b);
    });
    ui.go = K.btn('حط الانتقال على القطع', { cls: 'pri', icon: 'spark', onClick: apply });
    ui.stop = K.btn('وقّف', { icon: 'stop', onClick: function () { stopReq = true; } }); K.show(ui.stop, false);
    [h('div', { class: 'pv' }, [ui.wrap, h('div', { class: 'adds', style: 'margin-top:8px' }, [K.btn('هات القطع اللي جنب المؤشر', { icon: 'target', onClick: function () { findCut().catch(function () {}); } })])]),
      h('div', { class: 'hint intro', text: 'قف بالمؤشر عند القطع بين مشهدين، اختار الانتقال، ودوس «حط». بيترندر فوق القطع بالظبط (نص المدة قبل القطع ونصها بعده). عدّي بالماوس على أي انتقال تشوفه بيتحرك.' }),
      K.section('الانتقالات', [tiles], true, 'tr_lib'),
      K.section('الضبط', [sl('dur', 'المدة', .2, 2, .05, function (v) { return (+v).toFixed(2) + ' ث'; }), sl('k', 'القوة', .1, 1, .01, function (v) { return Math.round(v * 100) + '%'; }),
        K.field('الاتجاه (للدفع واللفة)', K.seg({ items: [{ v: 1, label: 'عادي' }, { v: -1, label: 'بالعكس' }], value: S.dir, onChange: function (v) { S.dir = +v; save(); } }))], true, 'tr_set'),
      h('div', { class: 'out' }, [h('div', { class: 'hint', text: 'لو المشهد مالوش زيادة (Handles) قبل/بعد القطع، الانتقال بيثبّت أول/آخر فريم.' }), h('div', { style: 'margin-top:10px' }, [ui.go]), h('div', { class: 'tk' }, [ui.stop]), ui.prog, ui.status])
    ].forEach(function (el) { root.appendChild(el); });
    G.addEventListener('resize', fit);
    Sys.call('cr_info').then(function (r) { if (r && r.ok && r.hasSequence && r.w) { seq = { w: r.w, h: r.h }; fit(); } });
    fit(); frame();
  }
  G.TransTab = { build: build, FX: FX, _sample: sample };
})(window);
