/* ENP — automatic captions: Arabic (فصحى / مصري / سعودي) or English, word-timed,
   editable, then either animated captions rendered by ENP or Premiere's own caption track. */
(function (G) {
  'use strict';
  var K = G.K, h = K.h, st = K.store('enp_cap_'), FX = G.TextFX;
  var DEF = {
    lang: 'eg', quality: 'best', range: 'auto', track: 'all', maxWords: 3, maxChars: 22,
    font: 'Arial', weight: 800, size: .058, color: '#ffffff', hi: '#ffd34d', style: 'box', anim: 'pop',
    y: .72, maxW: .82, stroke: .9, strokeColor: '#000000', shadow: .45, bg: false, bgColor: '#000000', bgAlpha: .55, out: 'enp'
  };
  var C = (function () { var o = {}, s = st.get('set', {}), k; for (k in DEF) o[k] = DEF[k]; for (k in s) o[k] = s[k]; return o; })();
  function save() { st.set('set', C); }
  var job = null;   // { clip, fps, w, h, words:[{w,a,b}] (sequence s), caps:[{a,b,words:[{w,a,b}]}] }
  var ui = {}, busy = false, stop = false, clock = { on: false, t: 0, last: 0 }, raf = 0, seq = { w: 1080, h: 1920 };

  /* ---------- words -> captions ---------- */
  function group(words) {
    var caps = [], cur = null;
    words.forEach(function (w, i) {
      var prev = words[i - 1];
      var brk = !cur || cur.words.length >= C.maxWords || (cur.text + ' ' + w.w).length > C.maxChars || (prev && w.a - prev.b > .5) || (prev && /[.!?؟…]$/.test(prev.w));
      if (brk) { cur = { words: [], text: '' }; caps.push(cur); }
      cur.words.push({ w: w.w, a: w.a, b: w.b }); cur.text = cur.text ? cur.text + ' ' + w.w : w.w;
    });
    caps.forEach(function (c) { c.a = c.words[0].a; c.b = c.words[c.words.length - 1].b; });
    caps.forEach(function (c, i) {
      var next = caps[i + 1]; c.b = Math.max(c.b, Math.min(c.b + .35, next ? next.a : c.b + .35));
      if (next && c.b > next.a) c.b = next.a;
      delete c.text;
    });
    return caps;
  }
  function capText(c) { return c.words.map(function (w) { return w.w; }).join(' '); }
  /* the editor changed a caption's text: keep timings, spread new words over the caption */
  function editCap(c, text) {
    var ws = String(text).trim().split(/\s+/).filter(Boolean);
    if (!ws.length) { c.words = []; return; }
    if (ws.length === c.words.length) { ws.forEach(function (w, i) { c.words[i].w = w; }); return; }
    var a = c.a, b = c.words.length ? c.words[c.words.length - 1].b : c.b, tot = ws.reduce(function (s, w) { return s + w.length + 1; }, 0), t = a;
    c.words = ws.map(function (w) { var d = (b - a) * (w.length + 1) / tot, o = { w: w, a: t, b: t + d }; t += d; return o; });
  }

  /* ---------- drawing ---------- */
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function outBack(x) { x = clamp(x, 0, 1); var c = 1.9; return 1 + (c + 1) * Math.pow(x - 1, 3) + c * Math.pow(x - 1, 2); }
  function paint(ctx, L, px, color, withStyle) {
    ctx.direction = L.rtl ? 'rtl' : 'ltr'; ctx.textAlign = L.rtl ? 'right' : 'left'; ctx.textBaseline = 'middle';
    var x = L.rtl ? L.right : L.left;
    if (withStyle && C.shadow > 0) { ctx.shadowColor = 'rgba(0,0,0,' + C.shadow + ')'; ctx.shadowBlur = px * .2; ctx.shadowOffsetY = px * .06; }
    if (withStyle && C.stroke > 0) { ctx.lineJoin = 'round'; ctx.lineWidth = C.stroke * px * .16; ctx.strokeStyle = C.strokeColor; ctx.strokeText(L.s, x, L.y); ctx.shadowColor = 'transparent'; }
    ctx.fillStyle = color; ctx.fillText(L.s, x, L.y); ctx.shadowColor = 'transparent';
  }
  /* draw the captions at sequence time t; W x H is the full frame; oy shifts everything up (for band renders) */
  function draw(ctx, caps, t, W, H, oy) {
    var cap = null;
    for (var i = 0; i < caps.length; i++) if (t >= caps[i].a && t < caps[i].b && caps[i].words.length) { cap = caps[i]; break; }
    if (!cap) return;
    var T = { text: capText(cap), font: C.font, weight: C.weight, size: C.size, lineH: 1.18, maxW: C.maxW, align: 'center', x: .5, y: C.y };
    var Lo = FX.layout(ctx, FX.norm(T), W, H), px = Lo.px;
    var p = clamp((t - cap.a) / .2, 0, 1), sc = 1, dy = 0, al = 1;
    if (C.anim === 'pop') { sc = .72 + .28 * outBack(p); al = clamp(p * 3, 0, 1); }
    else if (C.anim === 'fade') al = p;
    else if (C.anim === 'rise') { dy = (1 - (1 - Math.pow(1 - p, 3))) * px * .6; al = p; }
    var flat = []; Lo.lines.forEach(function (L) { L.words.forEach(function (w) { flat.push({ L: L, x0: w.x0, x1: w.x1 }); }); });
    var k = -1; cap.words.forEach(function (w, j) { if (t >= w.a) k = j; });
    ctx.save();
    ctx.translate(0, -(oy || 0));
    var cy = Lo.top + Lo.blockH / 2;
    ctx.translate(W / 2, cy + dy); ctx.scale(sc, sc); ctx.translate(-W / 2, -cy);
    ctx.globalAlpha = al;
    ctx.font = FX.fontStr(FX.norm(T), px);
    if (C.bg) {
      var pad = px * .35; ctx.save(); ctx.globalAlpha = al * C.bgAlpha; ctx.fillStyle = C.bgColor;
      FX.roundRect(ctx, Lo.minX - pad, Lo.top - pad * .5, Lo.maxX - Lo.minX + pad * 2, Lo.blockH + pad, px * .3); ctx.fill(); ctx.restore();
    }
    // the highlight box sits behind the words
    if (C.style === 'box' && k >= 0 && flat[k]) {
      var f = flat[k], bp = px * .14, wp = 1 + .08 * outBack(clamp((t - cap.words[k].a) / .12, 0, 1)) - .08;
      ctx.save(); ctx.fillStyle = C.hi;
      var bw = (f.x1 - f.x0 + bp * 2) * wp, bx = (f.x0 + f.x1) / 2 - bw / 2;
      FX.roundRect(ctx, bx, f.L.y - px * .58, bw, px * 1.16, px * .22); ctx.fill(); ctx.restore();
    }
    Lo.lines.forEach(function (L) {
      if (C.style === 'reveal') {   // only words already spoken
        ctx.save(); ctx.beginPath();
        flat.forEach(function (f, j) { if (f.L === L && j <= k) ctx.rect(f.x0 - px * .2, L.y - px, f.x1 - f.x0 + px * .4, px * 2); });
        ctx.clip(); paint(ctx, L, px, C.color, true); ctx.restore();
      } else paint(ctx, L, px, C.color, true);
    });
    // colour on the spoken word(s)
    if ((C.style === 'color' || C.style === 'fill') && k >= 0) {
      flat.forEach(function (f, j) {
        if (C.style === 'color' ? j !== k : j > k) return;
        ctx.save(); ctx.beginPath(); ctx.rect(f.x0 - px * .08, f.L.y - px, f.x1 - f.x0 + px * .16, px * 2); ctx.clip();
        paint(ctx, f.L, px, C.hi, false); ctx.restore();
      });
    }
    ctx.restore();
  }
  function bandOf(H) {   // the strip of the frame the captions use
    var px = C.size * H, half = px * 1.18 * 3 / 2 + px * 1.1;
    var top = Math.max(0, Math.floor(C.y * H - half)), bot = Math.min(H, Math.ceil(C.y * H + half));
    var hh = bot - top; if (hh % 2) hh++;
    return { top: top, h: Math.min(H, hh) };
  }

  /* ---------- preview ---------- */
  function fit() {
    if (!ui.wrap) return;
    var w = Math.max(160, ui.wrap.clientWidth || 300), ar = seq.w / seq.h, hh = Math.min(K.pvH(400), w / ar), ww = hh * ar;
    ui.stage.style.width = Math.round(ww) + 'px'; ui.stage.style.height = Math.round(hh) + 'px';
    var dpr = Math.min(2, G.devicePixelRatio || 1); ui.cv.width = Math.round(ww * dpr); ui.cv.height = Math.round(hh * dpr); paintNow();
  }
  function demoCaps() {
    var txt = C.lang === 'en' ? 'this is how your captions will look' : C.lang === 'sa' ? 'كذا بيطلع الكابشن حقك يا غالي' : C.lang === 'eg' ? 'كده الكابشن بتاعك هيبان يا باشا' : 'هكذا ستظهر الترجمة على الفيديو';
    var ws = txt.split(' '), t = 0;
    return group(ws.map(function (w) { var o = { w: w, a: t, b: t + .32 }; t += .36; return o; }));
  }
  function paintNow() {
    raf = 0;
    var x = ui.cv.getContext('2d'); x.setTransform(1, 0, 0, 1, 0, 0); x.clearRect(0, 0, ui.cv.width, ui.cv.height);
    var caps = job && job.caps.length ? job.caps : demoCaps(), now = Date.now();
    var t0 = caps.length ? caps[0].a : 0, t1 = caps.length ? caps[caps.length - 1].b : 1;
    if (clock.on) { clock.t += (now - clock.last) / 1000; clock.last = now; if (clock.t > t1 - t0 + .3) clock.t = 0; }
    draw(x, caps, t0 + clock.t, ui.cv.width, ui.cv.height, 0);
    if (clock.on) raf = (G.requestAnimationFrame || setTimeout)(paintNow);
  }
  function redraw() { if (!raf) raf = (G.requestAnimationFrame || setTimeout)(paintNow); }

  /* ---------- engine ---------- */
  function engineState() {
    if (!G.Whisper) { ui.eng.textContent = 'محتاج بريمير'; return false; }
    var s = Whisper.status(), ok = s.cli && s[C.quality];
    ui.eng.className = 'status ' + (ok ? 'ok' : 'warn');
    ui.eng.textContent = ok ? 'المحرك جاهز ✓ (' + Whisper.MODELS[C.quality].label + ')' : 'محتاج تنزّل المحرك مرة واحدة (' + Whisper.MODELS[C.quality].mb + ' ميجا تقريبًا).';
    K.show(ui.getBtn, !ok);
    return ok;
  }
  function getEngine() {
    if (busy) return; busy = true; ui.getBtn.disabled = true;
    Whisper.install(C.quality, function (what, p) { ui.prog.set(p); ui.status.show('busy', (what === 'engine' ? 'بنزّل المحرك… ' : 'بنزّل موديل اللغة… ') + Math.round(p * 100) + '%'); })
      .then(function () { ui.status.show('ok', 'المحرك جاهز ✓'); })
      .catch(function (e) { ui.status.show('err', 'التحميل ماكملش [' + (e.message || e) + '] — جرّب تاني، هيكمل من الأول.'); })
      .then(function () { busy = false; ui.getBtn.disabled = false; ui.prog.done(); engineState(); });
  }

  /* ---------- transcribe ---------- */
  function run() {
    if (busy) return;
    if (!engineState()) { ui.status.show('warn', 'نزّل المحرك الأول.'); return; }
    if (!G.SeqAudio) { ui.status.show('err', 'محتاج بريمير'); return; }
    busy = true; stop = false; ui.go.disabled = true; K.show(ui.stop, true); ui.prog.set(0);
    var col = null, wav = '';
    SeqAudio.collect({ range: C.range, tracks: C.track === 'all' ? [] : [+C.track] }).then(function (c) {
      col = c; seq = { w: c.info.w, h: c.info.h }; fit(); fillTracks(c.info.tracks);
      if (!c.clips.length) throw new Error('مفيش صوت في ' + (c.range === 'sel' ? 'الكليبات المختارة' : c.range === 'inout' ? 'الـ In/Out' : 'السيكوينس') + ' — شوف تراك الصوت.');
      ui.status.show('busy', 'بجمع صوت ' + (c.range === 'sel' ? 'الجزء المختار' : c.range === 'inout' ? 'الـ In/Out' : 'السيكوينس كله') + '…');
      return SeqAudio.mix(c, 16000, function (p) { ui.prog.set(p * .1); }, function () { return stop; });
    }).then(function (m) {
      var dir = Sys.join(Sys.workDir(), 'asr'); Sys.mkdirp(dir);
      wav = SeqAudio.writeWav(Sys.join(dir, 'seq' + Date.now() + '.wav'), m.pcm, m.sr);
      var v = SeqAudio.vad(m, { sens: .3, minSil: .35, minSpeech: .12 });
      if (!v.speech.length) throw new Error('ماسمعتش كلام في الجزء ده.');
      var chunks = Whisper.plan(v.speech, m.t0, 26), t0 = Date.now();
      ui.status.show('busy', 'بسمع وبكتب… 0% (' + chunks.length + ' جزء)');
      return Whisper.transcribeChunks(wav, C.lang, C.quality, chunks, function (p) {
        ui.prog.set(.1 + p * .9); var el = (Date.now() - t0) / 1000, left = p > .04 ? el / p - el : 0;
        ui.status.show('busy', 'بسمع وبكتب… ' + Math.round(p * 100) + '%' + (left ? ' · فاضل حوالي ' + Math.max(1, Math.ceil(left / 60)) + ' دقيقة' : ''));
      }, function () { return stop; }).then(function (words) {
        words = words.map(function (w) { return { w: w.w, a: m.t0 + w.a, b: m.t0 + w.b }; }).filter(function (w) { return w.a < m.t1; }).sort(function (x, y) { return x.a - y.a; });
        if (!words.length) throw new Error('ماسمعتش كلام في الجزء ده.');
        job = { clip: { start: m.t0, end: m.t1 }, fps: col.info.fps, w: col.info.w, h: col.info.h, words: words, caps: group(words) };
        renderList(); clock.t = 0;
        ui.status.show('ok', 'تمام — ' + words.length + ' كلمة في ' + job.caps.length + ' كابشن. راجعهم وعدّل اللي محتاج، وبعدين «حطهم على التايملاين».');
      });
    }).catch(function (e) { ui.status.show(e.message === 'cancelled' ? 'warn' : 'err', e.message === 'cancelled' ? 'اتوقف.' : SeqAudio.errText(e)); })
      .then(function () { if (wav) { try { req('fs').unlinkSync(wav); } catch (e) {} } busy = false; ui.go.disabled = false; K.show(ui.stop, false); ui.prog.done(); });
  }
  function fillTracks(tracks) {
    if (!ui.trackSel) return;
    var cur = C.track; ui.trackSel.innerHTML = '';
    ui.trackSel.appendChild(h('option', { value: 'all', text: 'كل تراكات الصوت (غير المكتومة)' }));
    (tracks || []).forEach(function (t) { ui.trackSel.appendChild(h('option', { value: String(t.i), text: 'A' + (t.i + 1) + (t.name && t.name !== 'A' + (t.i + 1) ? ' · ' + t.name : '') + (t.n ? '' : ' (فاضي)') + (t.muted ? ' (مكتوم)' : '') })); });
    ui.trackSel.value = [].some.call(ui.trackSel.options, function (o) { return o.value === String(cur); }) ? String(cur) : 'all';
  }
  var req = (G.Sys && G.Sys.req) || function () { return {}; };

  function renderList() {
    ui.list.innerHTML = '';
    if (!job) return;
    job.caps.forEach(function (c, i) {
      var inp = h('input', { type: 'text', class: 'inp capin', dir: 'auto' }); inp.value = capText(c);
      inp.addEventListener('change', function () { editCap(c, inp.value); if (!c.words.length) { job.caps.splice(i, 1); renderList(); } redraw(); });
      inp.addEventListener('focus', function () { clock.on = false; clock.t = c.a - job.caps[0].a + .05; redraw(); Sys.call('cr_seek', { t: c.a }); });
      /* Enter = split here, Backspace at the start = join with the one before */
      inp.addEventListener('keydown', function (e) {
        var pos = inp.selectionStart, sel = inp.selectionEnd !== pos;
        if (e.key === 'Enter') {
          e.preventDefault(); editCap(c, inp.value);
          var k = inp.value.slice(0, pos).trim() ? inp.value.slice(0, pos).trim().split(/\s+/).length : 0;
          if (k <= 0 || k >= c.words.length) { ui.status.show('warn', 'حط المؤشر بين كلمتين ودوس Enter عشان يتقسم.'); return; }
          var c2 = { words: c.words.slice(k), b: c.b }; c.words = c.words.slice(0, k);
          c2.a = c2.words[0].a; c.b = Math.min(c2.a, Math.max(c.words[c.words.length - 1].b, c.a + .1));
          job.caps.splice(i + 1, 0, c2); renderList(); focusRow(i + 1, 0); redraw();
        } else if (e.key === 'Backspace' && pos === 0 && !sel && i > 0) {
          e.preventDefault(); editCap(c, inp.value);
          var pr = job.caps[i - 1], at = capText(pr).length + 1;
          pr.words = pr.words.concat(c.words); pr.b = c.b; job.caps.splice(i, 1); renderList(); focusRow(i - 1, at); redraw();
        }
      });
      ui.list.appendChild(h('div', { class: 'caprow' }, [h('span', { class: 'ct', text: K.mmss(c.a - job.clip.start) }), inp]));
    });
    K.show(ui.listWrap, true);
  }
  function focusRow(i, at) { var ins = ui.list.querySelectorAll('input'); var el = ins[i]; if (!el) return; el.focus(); try { el.setSelectionRange(at, at); } catch (e) {} }
  function regroup() { if (!job) return; job.caps = group(job.caps.reduce(function (a, c) { return a.concat(c.words); }, [])); renderList(); redraw(); }

  /* ---------- out ---------- */
  /* save the captions as an .srt (sequence time) wherever the editor wants */
  function saveSrt() {
    if (!job) { ui.status.show('warn', 'اعمل الكابشن الأول.'); return; }
    var name = 'Captions_' + new Date().toISOString().slice(0, 10) + '.srt', f = '';
    try {
      var cf = G.cep && G.cep.fs, r = cf && (cf.showSaveDialogEx ? cf.showSaveDialogEx('احفظ ملف الكابشن', '', ['srt'], name, 'SubRip (*.srt)') : null);
      f = (r && r.data) ? (Array.isArray(r.data) ? r.data[0] : r.data) : '';
    } catch (e) { f = ''; }
    if (!f) { var d = Sys.pickFolder('اختار الفولدر اللي هيتحفظ فيه الكابشن'); if (d) f = Sys.join(d, name); }
    if (!f) return;
    if (!/\.srt$/i.test(f)) f += '.srt';
    try { req('fs').writeFileSync(f, '\ufeff' + srtText(0), 'utf8'); ui.status.show('ok', 'اتحفظ ✓ ' + f); }
    catch (e) { ui.status.show('err', 'مقدرتش أحفظ الملف هنا [' + (e.message || e) + ']'); }
  }
  function srtText(baseOverride) {
    function tc(s) { s = Math.max(0, s); var hh = Math.floor(s / 3600), m = Math.floor(s / 60) % 60, se = Math.floor(s) % 60, ms = Math.round((s - Math.floor(s)) * 1000); function p(n, l) { return ('000' + n).slice(-l); } return p(hh, 2) + ':' + p(m, 2) + ':' + p(se, 2) + ',' + p(ms === 1000 ? 999 : ms, 3); }
    var base = baseOverride !== undefined ? baseOverride : job.clip.start;
    return job.caps.map(function (c, i) { return (i + 1) + '\n' + tc(c.a - base) + ' --> ' + tc(c.b - base) + '\n' + capText(c) + '\n'; }).join('\n');
  }
  function place() {
    if (!job || busy) return;
    if (C.out === 'srt') {
      Sys.call('cr_info').then(function (r) {
        var dir = r && r.dir ? Sys.join(r.dir, 'ENP Renders') : Sys.join(Sys.workDir(), 'renders'); Sys.mkdirp(dir);
        var f = Sys.join(dir, 'ENP_Captions_' + Date.now() + '.srt');
        req('fs').writeFileSync(f, '﻿' + srtText(), 'utf8');
        return Sys.call('cr_srtCaptions', { path: f, at: job.clip.start }).then(function (x) {
          if (!x || !x.ok) throw new Error('حصلت مشكلة [' + (x && (x.error || x.detail)) + ']');
          ui.status.show('ok', x.track ? 'اتعمل تراك كابشن في بريمير ✓ تقدر تعدّله من Essential Graphics / Captions.' : 'ملف الـ SRT اتحط في البروجكت (فولدر ENP Captions) — اسحبه على التايملاين.');
        });
      }).catch(function (e) { ui.status.show('err', e.message || String(e)); });
      return;
    }
    busy = true; stop = false; ui.place.disabled = true; K.show(ui.stop, true);
    var c = job.clip, W = job.w, H = job.h, band = bandOf(H), cv = G.document.createElement('canvas'), x;
    var caps = job.caps;
    Out.renderAndPlace({
      prefix: 'ENP_Captions', bin: 'ENP Captions', dur: c.end - c.start, at: c.start, w: W, h: band.h, codec: 'qtrle',
      prepare: function (o) { cv.width = o.w; cv.height = o.h; x = cv.getContext('2d'); return Fonts.ensure(C.font, +C.weight); },
      frame: function (t) { x.setTransform(1, 0, 0, 1, 0, 0); x.clearRect(0, 0, cv.width, cv.height); draw(x, caps, c.start + t, W, H, band.top); return x.getImageData(0, 0, cv.width, cv.height).data; },
      onProgress: function (p) { ui.prog.set(p); ui.status.show('busy', 'برسم الكابشن… ' + Math.round(p * 100) + '%'); },
      cancelled: function () { return stop; }
    }).then(function (r) {
      // the strip sits where the captions belong on the frame
      if (!r.ref) return r;
      return Sys.call('cr_keys', { clip: r.ref, prop: 'pos', keys: [], reset: true, value: [.5, (band.top + band.h / 2) / H] })
        .then(function () { return Sys.call('cr_keys', { clip: r.ref, prop: 'scale', keys: [], reset: true, value: 100 }); }).then(function () { return r; });
    }).then(function (r) { ui.status.show('ok', 'الكابشن اتحط على ' + r.track + ' ✓ (' + caps.length + ' كابشن)'); })
      .catch(function (e) { ui.status.show(e && e.message === 'cancelled' ? 'warn' : 'err', Out.errText(e)); })
      .then(function () { busy = false; ui.place.disabled = false; K.show(ui.stop, false); ui.prog.done(); });
  }

  /* ---------- build ---------- */
  function sl(k, label, min, max, step, fmt, re) { return K.slider({ label: label, min: min, max: max, step: step, value: C[k], fmt: fmt, onInput: function (v) { C[k] = v; save(); if (re) regroup(); redraw(); } }); }
  function col(k, label) { var i = h('input', { type: 'color', value: C[k] }); i.addEventListener('input', function () { C[k] = i.value; save(); redraw(); }); return h('label', { class: 'cfield' }, [i, h('span', { text: label })]); }
  function sg(k, items, cb) { return K.seg({ items: items, value: C[k], onChange: function (v) { C[k] = v; save(); if (cb) cb(v); redraw(); } }); }
  function pct(v) { return Math.round(v * 100) + '%'; }
  function build(root) {
    ui.status = K.status(); ui.prog = K.progress(); ui.eng = h('div', { class: 'status' });
    ui.cv = h('canvas'); ui.stage = h('div', { class: 'stage' }, [ui.cv]); ui.wrap = h('div', { class: 'pvwrap' }, [ui.stage]);
    var playB = h('button', { type: 'button', class: 'ibtn', html: K.ICON.play, onclick: function () { clock.on = !clock.on; clock.last = Date.now(); playB.innerHTML = K.ICON[clock.on ? 'stop' : 'play']; redraw(); } });
    ui.getBtn = K.btn('نزّل المحرك', { icon: 'folder', onClick: getEngine });
    ui.trackSel = h('select', { class: 'sel' }); ui.trackSel.addEventListener('change', function () { C.track = ui.trackSel.value; save(); }); fillTracks([]);
    ui.go = K.btn('اسمع واكتب الكابشن', { cls: 'pri', icon: 'target', onClick: run });
    ui.stop = K.btn('وقّف', { icon: 'stop', onClick: function () { stop = true; } }); K.show(ui.stop, false);
    ui.list = h('div', { class: 'caplist' });
    ui.listWrap = K.section('راجع الكلام', [h('div', { class: 'hint', text: 'عدّل أي كلمة غلط. عايز تقسم جملة؟ حط المؤشر بين الكلمتين ودوس Enter. Backspace في أول السطر بيلزقه في اللي قبله.' }),
      sl('maxWords', 'أقصى كلمات في الكابشن', 1, 8, 1, String, true), sl('maxChars', 'أقصى حروف', 8, 40, 1, String, true), ui.list], true, 'cap_list');
    K.show(ui.listWrap, false);
    ui.place = K.btn('حطهم على التايملاين', { cls: 'pri', icon: 'spark', onClick: place });
    ui.saveSrt = K.btn('احفظ ملف الكابشن (SRT)', { icon: 'folder', onClick: saveSrt });
    var picker = Fonts.picker({ value: C.font, onChange: function (f) { C.font = f; save(); Fonts.ensure(f, +C.weight).then(redraw); } });
    [h('div', { class: 'hint intro', text: 'كابشن تلقائي بيتعمل على جهازك (من غير نت ومن غير كريديت): عربي فصحى، مصري، سعودي، أو إنجليزي — بتوقيت كل كلمة، تراجعه وتعدّله، وبعدين ينزل كابشن متحرك بستايلك أو تراك كابشن عادي في بريمير.' }),
      h('div', { class: 'pv' }, [ui.wrap, h('div', { class: 'bar' }, [playB, h('span', { class: 'hint', text: 'معاينة الستايل' })])]),
      K.section('اللغة والمحرك', [
        K.field('اللغة / اللهجة', sg('lang', [{ v: 'eg', label: 'مصري' }, { v: 'sa', label: 'سعودي' }, { v: 'ar', label: 'فصحى' }, { v: 'en', label: 'English' }, { v: 'auto', label: 'تلقائي' }])),
        K.field('الجودة', sg('quality', [{ v: 'best', label: 'دقيق (أنسب للعربي)' }, { v: 'fast', label: 'سريع' }], engineState)),
        ui.eng, h('div', { class: 'adds' }, [ui.getBtn]),
        K.field('الجزء', sg('range', [{ v: 'auto', label: 'المختار أو In/Out' }, { v: 'all', label: 'السيكوينس كله' }])),
        K.field('صوت الكلام', ui.trackSel),
        h('div', { style: 'margin-top:10px' }, [ui.go]), h('div', { class: 'tk' }, [ui.stop]),
        h('div', { class: 'hint', style: 'margin-top:6px', text: 'بيسمع صوت السيكوينس كله (كل الكليبات مع بعض)، أو الكليبات اللي مختارها بس، أو ما بين الـ In والـ Out. «دقيق» بياخد تقريبًا من نص لضعف المدة حسب الجهاز.' })
      ], true, 'cap_eng'),
      ui.listWrap,
      K.section('الستايل', [
        K.field('شكل الكلمة اللي بتتقال', sg('style', [{ v: 'box', label: 'خلفية' }, { v: 'color', label: 'لون' }, { v: 'fill', label: 'بيتملى' }, { v: 'reveal', label: 'تظهر كلمة كلمة' }, { v: 'plain', label: 'عادي' }])),
        K.field('الدخول', sg('anim', [{ v: 'pop', label: 'بوب' }, { v: 'rise', label: 'طالع' }, { v: 'fade', label: 'هادي' }, { v: 'none', label: 'من غير' }])),
        K.field('الخط', picker), sl('size', 'الحجم', .03, .12, .001, pct), sl('y', 'المكان (فوق ↔ تحت)', .1, .92, .005, pct), sl('maxW', 'أقصى عرض', .4, .96, .01, pct),
        h('div', { class: 'crow' }, [col('color', 'اللون'), col('hi', 'لون التمييز'), col('strokeColor', 'الإطار')]),
        sl('stroke', 'إطار', 0, 2, .05, function (v) { return v.toFixed(2); }), sl('shadow', 'ظل', 0, 1, .01, pct),
        K.toggle('خلفية ورا الكابشن', C.bg, function (v) { C.bg = v; save(); redraw(); }), h('div', { class: 'crow' }, [col('bgColor', 'لون الخلفية')]), sl('bgAlpha', 'شفافية الخلفية', 0, 1, .01, pct)
      ], true, 'cap_style'),
      h('div', { class: 'out' }, [
        K.field('الناتج', sg('out', [{ v: 'enp', label: 'كابشن متحرك (ENP)' }, { v: 'srt', label: 'تراك كابشن بريمير' }])),
        h('div', { style: 'margin-top:10px' }, [ui.place]), h('div', { class: 'adds', style: 'margin-top:6px' }, [ui.saveSrt]), ui.prog, ui.status])
    ].forEach(function (el) { root.appendChild(el); });
    G.addEventListener('resize', fit);
    Sys.call('cr_info').then(function (r) { if (r && r.ok && r.hasSequence && r.w) { seq = { w: r.w, h: r.h }; fit(); } });
    Sys.call('cr_audioClips').then(function (r) { if (r && r.ok) fillTracks(r.tracks); });
    fit(); engineState(); Fonts.ensure(C.font, +C.weight).then(redraw);
  }
  G.CaptionTab = { build: build, onShow: function () { if (ui.eng) { engineState(); Sys.call('cr_audioClips').then(function (r) { if (r && r.ok) fillTracks(r.tracks); }); } }, onHide: function () { clock.on = false; }, _group: group, _draw: draw, _C: C, _job: function (j) { job = j; } };
})(window);
