/* ENP — speed ramp. The selected clips (in timeline order) are treated as ONE shot: one smooth speed
   curve runs across all of them, frames are blended in slow motion and motion-blurred when fast,
   and the result is rendered and laid above the originals. */
(function (G) {
  'use strict';
  var K = G.K, h = K.h, st = K.store('enp_ramp_');
  function cl(v, a, b) { return v < a ? a : v > b ? b : v; }
  function ss(x) { x = cl(x, 0, 1); return x * x * x * (x * (x * 6 - 15) + 10); }   // smootherstep: no kinks in the speed
  function plateau(u, a, b, w) { return ss((u - a) / w + .5) * (1 - ss((u - b) / w + .5)); }

  /* h(u): 0 = slow, 1 = fast, u = 0..1 of the OUTPUT time */
  var CURVES = {
    slowMid: { name: 'سريع ← سلو موشن ← سريع', f: function (u, o) { return 1 - plateau(u, o.c - o.hold / 2, o.c + o.hold / 2, o.soft); } },
    fastMid: { name: 'بطيء ← سريع ← بطيء', f: function (u, o) { return plateau(u, o.c - o.hold / 2, o.c + o.hold / 2, o.soft); } },
    up: { name: 'بطيء وبيسرع', f: function (u, o) { return ss((u - o.c) / o.soft + .5); } },
    down: { name: 'سريع وبيبطأ', f: function (u, o) { return 1 - ss((u - o.c) / o.soft + .5); } },
    hit: { name: 'ضربة: سريع وفجأة سلو', f: function (u, o) { var d = .035; return u < o.c ? 1 - ss((u - o.c + d) / d) : ss((u - o.c - o.hold) / Math.max(.05, o.soft * 1.6)); } },
    whoosh: { name: 'سلو وبعدين ينطلق', f: function (u, o) { return u < o.c ? 0 : ss((u - o.c) / Math.max(.03, o.soft * .6)); } },
    double: { name: 'سلو موشن مرتين', f: function (u, o) { var a = o.c * .55, b = o.c + (1 - o.c) * .45, hw = o.hold / 3; return 1 - Math.max(plateau(u, a - hw, a + hw, o.soft * .7), plateau(u, b - hw, b + hw, o.soft * .7)); } },
    pulse: { name: 'نبضات على الإيقاع', f: function (u, o) { var x = (u * o.beats) % 1; return ss(x < .5 ? x * 2 : 2 - x * 2); } },
    steady: { name: 'سرعة ثابتة', f: function () { return 1; } }
  };
  var DEF = { curve: 'slowMid', slow: .25, fast: 3, c: .5, hold: .18, soft: .18, beats: 4, keep: true, blend: true, mblur: .7, off: true };
  var S = (function () { var o = {}, k, v = st.get('set', {}); for (k in DEF) o[k] = DEF[k]; for (k in v) o[k] = v[k]; return o; })();
  function save() { st.set('set', S); }

  /* the plan: clips laid end to end (virtual time), output length, and output t -> virtual x */
  function makePlan(clips, s) {
    var segs = [], L = 0;
    clips.forEach(function (c) { var len = c.end - c.start; segs.push({ c: c, v0: L, len: len }); L += len; });
    var N = 2400, fn = (CURVES[s.curve] || CURVES.slowMid).f, v = new Float64Array(N + 1), hh = new Float64Array(N + 1), mh = 0, mean = 0, i;
    for (i = 0; i <= N; i++) { hh[i] = cl(fn(i / N, s), 0, 1); mh += hh[i] / (N + 1); }
    var lo = s.slow, hi = s.fast;
    /* same length: keep the speed that is the point of the curve, the other one pays for it */
    if (s.keep && mh > .002 && mh < .998) {
      var slowLed = !/fastMid|up/.test(s.curve), F = lo + (1 - lo) / mh, s2 = (1 - hi * mh) / (1 - mh);
      if (slowLed && F >= 1 && F <= 12) hi = F; else if (!slowLed && s2 >= .05 && s2 <= 1) lo = s2; else if (F >= 1 && F <= 12) hi = F;
    }
    for (i = 0; i <= N; i++) { v[i] = lo + (hi - lo) * hh[i]; mean += v[i] / (N + 1); }
    var T = s.keep ? L : L / mean, k = L / (T * mean);   // k: scale so the whole stretch is used exactly
    var X = new Float64Array(N + 1); X[0] = 0;
    for (i = 1; i <= N; i++) X[i] = X[i - 1] + (v[i - 1] + v[i]) / 2 * k * (T / N);
    var fix = L / (X[N] || 1); for (i = 0; i <= N; i++) X[i] *= fix;
    return {
      L: L, T: T, segs: segs, vmin: Math.min.apply(null, v) * k, vmax: Math.max.apply(null, v) * k, N: N,
      x: function (t) { var u = cl(t / T, 0, 1) * N, j = Math.min(N - 1, Math.floor(u)), f = u - j; return X[j] + (X[j + 1] - X[j]) * f; },
      speed: function (t) { var u = cl(t / T, 0, 1) * N, j = Math.min(N - 1, Math.floor(u)); return v[j] * k; },
      at: function (x) {   // virtual x -> { seg index, media time }
        x = cl(x, 0, L - 1e-4);
        for (var q = 0; q < segs.length; q++) { var sg = segs[q]; if (x < sg.v0 + sg.len || q === segs.length - 1) return { i: q, m: (x - sg.v0) * (sg.c.speed || 1) }; }
      },
      tOf: function (x) { var lo = 0, hi = N; while (hi - lo > 1) { var m = (lo + hi) >> 1; if (X[m] < x) lo = m; else hi = m; } return lo / N * T; }
    };
  }

  /* frames of every clip at the sequence frame rate (media time) */
  function extract(plan, fps, maxSide, onP) {
    var dirs = [], i = 0;
    function next() {
      if (i >= plan.segs.length) return Promise.resolve(dirs);
      var sg = plan.segs[i], c = sg.c;
      if (onP) onP(i / plan.segs.length);
      return Sys.clipFrames(c.path, c.inPoint, sg.len * (c.speed || 1), fps, maxSide).then(function (d) {
        return Sys.probe(c.path).then(function (inf) { dirs.push({ dir: d, w: inf.w || 1920, h: inf.h || 1080 }); i++; return next(); });
      });
    }
    return next();
  }
  /* image cache */
  function Cache(max) {
    var m = {}, order = [];
    return function (key, url) {
      if (m[key]) return m[key];
      var p = new Promise(function (res) { var im = new Image(); im.onload = function () { res(im); }; im.onerror = function () { res(null); }; im.src = url; });
      m[key] = p; order.push(key);
      while (order.length > max) delete m[order.shift()];
      return p;
    };
  }
  function pad(n) { return ('0000' + n).slice(-5); }

  /* one output frame: the weighted frames under it, averaged */
  function frameAt(plan, src, fps, t, s, cache, scr, ctx, W, H, seqW) {
    var x = plan.x(t), v = plan.speed(t), parts = {}, keys = [];
    var n = s.mblur > 0 && v > 1.6 ? Math.min(10, Math.max(2, Math.round(v * s.mblur * 1.6))) : 1, span = n > 1 ? v / fps * Math.min(1, s.mblur) : 0;
    for (var q = 0; q < n; q++) {
      var xx = n > 1 ? x - span / 2 + span * (q + .5) / n : x, a = plan.at(xx), fi = a.m * fps, f0 = Math.floor(fi), fr = s.blend ? fi - f0 : 0;
      if (fr > .98) { f0++; fr = 0; }
      [[f0, 1 - fr], [f0 + 1, fr]].forEach(function (p) {
        if (p[1] < .02) return; var key = a.i + '|' + Math.max(0, p[0]);
        if (!parts[key]) { parts[key] = { i: a.i, f: Math.max(0, p[0]), w: 0 }; keys.push(key); }
        parts[key].w += p[1] / n;
      });
    }
    return Promise.all(keys.map(function (k) {
      var p = parts[k], d = src[p.i];
      return cache(k, Sys.url(Sys.join(d.dir, pad(p.f + 1) + '.jpg'))).then(function (im) {
        if (im) return im;
        return cache('b|' + p.i + '|' + p.f, Sys.url(Sys.join(d.dir, pad(Math.max(1, p.f)) + '.jpg')));   // the last frame of a clip
      });
    })).then(function (ims) {
      var acc = 0, sx = scr.getContext('2d');
      ctx.globalAlpha = 1; ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, H);
      keys.forEach(function (k, j) {
        var p = parts[k], im = ims[j]; if (!im) return;
        var c = plan.segs[p.i].c, d = src[p.i], f = W / seqW, sc = (c.scale || 100) / 100, P = c.pos || [.5, .5], A = c.anchor || [.5, .5];
        var dw = d.w * sc * f, dh = d.h * sc * f;
        sx.globalAlpha = 1; sx.fillStyle = '#000'; sx.fillRect(0, 0, W, H);
        sx.drawImage(im, P[0] * W - A[0] * dw, P[1] * H - A[1] * dh, dw, dh);
        acc += p.w; ctx.globalAlpha = p.w / acc; ctx.drawImage(scr, 0, 0);
      });
      ctx.globalAlpha = 1;
    });
  }

  /* ---------------- tab ---------------- */
  var ui = {}, ctl = {}, busy = false, stopReq = false, plan = null, clips = [], seq = { w: 1080, h: 1920, fps: 30 }, pv = { on: false, src: null, t: 0, raf: 0 }, last = st.get('last', null);
  function set(p) { for (var k in p) S[k] = p[k]; save(); replan(); }
  function sl(k, label, min, max, step, fmt) { var c = K.slider({ label: label, min: min, max: max, step: step, value: S[k], fmt: fmt, onInput: function (v) { var p = {}; p[k] = v; set(p); } }); ctl[k] = c; return c; }
  function pc(v) { return Math.round(v * 100) + '%'; }
  function replan() {
    var cs = clips.length ? clips : [{ start: 0, end: 4, speed: 1 }];
    plan = makePlan(cs, S); graph();
    ui.info.textContent = (clips.length ? clips.length + ' كليب = ' + plan.L.toFixed(2) + 'ث' : 'مفيش كليبات مختارة لسه') + ' ← المدة الجديدة ' + plan.T.toFixed(2) + 'ث · أبطأ ' + pc(plan.vmin) + ' · أسرع ' + pc(plan.vmax);
    K.show(ui.holdS, /slowMid|fastMid|hit|double/.test(S.curve)); K.show(ui.beatS, S.curve === 'pulse'); K.show(ui.cS, S.curve !== 'pulse' && S.curve !== 'steady');
  }
  function graph(tNow) {
    var cv = ui.graph, d = Math.min(2, G.devicePixelRatio || 1), W = cv.clientWidth * d || 300, H = 120 * d; cv.width = W; cv.height = H;
    var x = cv.getContext('2d'), top = Math.max(plan.vmax, 1.2), pad = 8 * d, gy = function (v) { return H - pad - (Math.log(1 + v) / Math.log(1 + top)) * (H - pad * 2); };
    x.fillStyle = 'rgba(255,255,255,.04)'; x.fillRect(0, 0, W, H);
    x.strokeStyle = 'rgba(255,255,255,.25)'; x.setLineDash([4 * d, 4 * d]); x.beginPath(); x.moveTo(0, gy(1)); x.lineTo(W, gy(1)); x.stroke(); x.setLineDash([]);
    x.fillStyle = 'rgba(255,255,255,.45)'; x.font = 10 * d + 'px sans-serif'; x.fillText('100%', 4 * d, gy(1) - 3 * d);
    /* clip boundaries */
    plan.segs.forEach(function (sg, i) { if (!i) return; var tx = plan.tOf(sg.v0) / plan.T * W; x.strokeStyle = 'rgba(77,210,255,.55)'; x.beginPath(); x.moveTo(tx, 0); x.lineTo(tx, H); x.stroke(); });
    var g = x.createLinearGradient(0, 0, 0, H); g.addColorStop(0, 'rgba(228,138,166,.55)'); g.addColorStop(1, 'rgba(228,138,166,.05)');
    x.beginPath(); x.moveTo(0, H);
    for (var i = 0; i <= 200; i++) { var t = i / 200 * plan.T; x.lineTo(i / 200 * W, gy(plan.speed(t))); }
    x.lineTo(W, H); x.closePath(); x.fillStyle = g; x.fill();
    x.beginPath(); for (i = 0; i <= 200; i++) { var t2 = i / 200 * plan.T, yy = gy(plan.speed(t2)); if (!i) x.moveTo(0, yy); else x.lineTo(i / 200 * W, yy); }
    x.strokeStyle = '#e48aa6'; x.lineWidth = 2 * d; x.stroke();
    if (tNow !== undefined) { var px = tNow / plan.T * W; x.fillStyle = '#ffd34d'; x.fillRect(px - d, 0, 2 * d, H); }
  }
  function load() {
    ui.status.show('busy', 'بقرا الكليبات المختارة…');
    return Sys.call('cr_clips', {}).then(function (r) {
      if (!r || !r.ok) throw new Error('افتح سيكوينس الأول.');
      seq = { w: r.w, h: r.h, fps: r.fps || 30 };
      var cs = (r.clips || []).filter(function (c) { return c.path; }).sort(function (a, b) { return a.start - b.start; }), out = [];
      cs.forEach(function (c) { if (!out.length || c.start >= out[out.length - 1].end - .01) out.push(c); });
      if (!out.length) throw new Error('اختار الكليبات (مشهد أو أكتر) في التايملاين.');
      clips = out; pv.src = null; replan();
      ui.status.show('ok', out.length > 1 ? out.length + ' مشاهد هيتعاملوا كأنهم مشهد واحد ✓' : 'مشهد واحد ✓');
      return out;
    });
  }
  function lock(on) { busy = on; ui.go.disabled = on; ui.prev.disabled = on; K.show(ui.stop, on); }
  function preview() {
    if (busy) return; stopPv();
    lock(true); stopReq = false;
    load().then(function () {
      ui.status.show('busy', 'بجهّز معاينة…');
      return extract(plan, seq.fps, 360, function (p) { ui.prog.set(p); });
    }).then(function (src) {
      pv.src = src; pv.cache = Cache(40); ui.status.show('ok', 'معاينة ✓ (الجودة الكاملة في الرندر)'); K.show(ui.pvBox, true); playPv();
    }).catch(function (e) { ui.status.show('err', e.message || String(e)); }).then(function () { lock(false); ui.prog.done(); });
  }
  function playPv() {
    if (!pv.src) return; pv.on = true; pv.t = 0; var t0 = Date.now(), cv = ui.pv, ar = seq.w / seq.h, Wd = Math.min(ui.pvBox.clientWidth || 300, 320), Hd = Math.round(Math.min(K.pvH(320) * .65, Wd / ar));
    cv.width = Math.round(Hd * ar); cv.height = Hd; var scr = G.document.createElement('canvas'); scr.width = cv.width; scr.height = cv.height;
    var busyF = false;
    function tick() {
      if (!pv.on) return; pv.raf = G.requestAnimationFrame(tick); if (busyF) return;
      var t = ((Date.now() - t0) / 1000) % (plan.T + .6); if (t > plan.T) t = plan.T;
      busyF = true; frameAt(plan, pv.src, seq.fps, t, S, pv.cache, scr, cv.getContext('2d'), cv.width, cv.height, seq.w).then(function () { busyF = false; graph(t); });
    }
    tick();
  }
  function stopPv() { pv.on = false; if (pv.raf) G.cancelAnimationFrame(pv.raf); pv.raf = 0; }
  function apply() {
    if (busy) return; stopPv(); lock(true); stopReq = false;
    var src = null, cache = Cache(48), scr = G.document.createElement('canvas'), cv = G.document.createElement('canvas'), P = null, refs = [];
    var SS = JSON.parse(JSON.stringify(S));
    load().then(function (cs) {
      P = makePlan(cs, SS); refs = cs.map(function (c) { return { type: 'v', track: c.track, id: c.id, start: c.start }; });
      ui.status.show('busy', 'بفك الفريمات…');
      return extract(P, seq.fps, Math.max(seq.w, seq.h), function (p) { ui.prog.set(p * .3); });
    }).then(function (s2) {
      src = s2;
      return Out.renderAndPlace({
        prefix: 'ENP_SpeedRamp', bin: 'ENP Speed Ramp', dur: P.T, at: cs0().start, replace: [],
        prepare: function (o) { cv.width = scr.width = o.w; cv.height = scr.height = o.h; },
        frame: function (t, i, o) { var x = cv.getContext('2d'); return frameAt(P, src, o.fps, t, SS, cache, scr, x, o.w, o.h, seq.w).then(function () { return x.getImageData(0, 0, o.w, o.h).data; }); },
        onProgress: function (p) { ui.prog.set(.3 + p * .7); ui.status.show('busy', 'برندر الرامب… ' + Math.round(p * 100) + '%'); },
        cancelled: function () { return stopReq; }
      });
    }).then(function (r) {
      last = { names: r.names }; st.set('last', last);
      return (SS.off ? Sys.call('cr_disable', { refs: refs }) : Promise.resolve(null)).then(function () {
        ui.status.show('ok', 'الرامب اتحط على ' + r.track + ' (' + P.T.toFixed(2) + 'ث)' + (SS.off ? ' والكليبات الأصلية اتقفلت' : '') + ' ✓');
      });
    }).catch(function (e) { ui.status.show(e && e.message === 'cancelled' ? 'warn' : 'err', Out.errText(e)); })
      .then(function () { lock(false); ui.prog.done(); });
  }
  function cs0() { return clips[0]; }
  function build(root) {
    ui.status = K.status(); ui.prog = K.progress(); ui.info = h('div', { class: 'hint' });
    ui.graph = h('canvas', { style: 'width:100%;height:120px;border-radius:8px;display:block;cursor:pointer' });
    ui.graph.addEventListener('pointerdown', function (e) { var r = ui.graph.getBoundingClientRect(); set({ c: cl((e.clientX - r.left) / r.width, .05, .95) }); if (ctl.c) ctl.c.setValue(S.c); });
    var chips = h('div', { class: 'chips' });
    function mark() { [].forEach.call(chips.children, function (b) { b.classList.toggle('on', b.getAttribute('data-v') === S.curve); }); }
    Object.keys(CURVES).forEach(function (k) { chips.appendChild(h('button', { type: 'button', class: 'chip', 'data-v': k, text: CURVES[k].name, onclick: function () { set({ curve: k }); mark(); if (pv.src && !pv.on) playPv(); } })); });
    ui.pv = h('canvas', { style: 'display:block;margin:0 auto;border-radius:8px;background:#000' });
    ui.pvBox = h('div', { style: 'margin-bottom:8px' }, [ui.pv]); K.show(ui.pvBox, false);
    ui.prev = K.btn('معاينة', { icon: 'play', onClick: preview });
    ui.go = K.btn('اعمل الرامب', { cls: 'pri', icon: 'spark', onClick: apply });
    ui.stop = K.btn('وقّف', { icon: 'stop', onClick: function () { stopReq = true; } }); K.show(ui.stop, false);
    ui.cS = sl('c', 'مكان اللحظة (أو دوس على الرسمة)', .05, .95, .01, pc);
    ui.holdS = sl('hold', 'طول السلو / السريع', 0, .7, .01, pc);
    ui.beatS = sl('beats', 'عدد النبضات', 1, 12, 1, String);
    [h('div', { class: 'hint intro', text: 'اختار مشهد أو أكتر في التايملاين — الرامب بيتطبق عليهم كأنهم مشهد واحد بمنحنى سرعة ناعم، والسلو موشن بيتعمل بدمج الفريمات والسريع بموشن بلور.' }),
      h('div', { class: 'adds' }, [K.btn('هات الكليبات المختارة', { icon: 'target', onClick: function () { if (!busy) load().catch(function (e) { ui.status.show('err', e.message || String(e)); }); } })]),
      h('div', { class: 'pv' }, [ui.pvBox, ui.graph, ui.info]),
      K.section('شكل الرامب', [chips], true, 'sr_curve'),
      K.section('السرعة', [sl('slow', 'أبطأ سرعة', .1, 1, .01, pc), sl('fast', 'أسرع سرعة', 1, 8, .05, pc), ui.cS, ui.holdS, ui.beatS,
        sl('soft', 'نعومة الانتقال', .03, .5, .01, pc), K.toggle('خلي المدة زي ما هي (يملى نفس المكان)', S.keep, function (v) { set({ keep: v }); })], true, 'sr_speed'),
      K.section('النعومة', [K.toggle('دمج الفريمات في السلو موشن', S.blend, function (v) { set({ blend: v }); }), sl('mblur', 'موشن بلور في السريع', 0, 1, .01, pc)], false, 'sr_smooth'),
      h('div', { class: 'out' }, [h('div', { class: 'adds' }, [ui.prev]), K.toggle('اقفل الكليبات الأصلية بعد الرامب', S.off, function (v) { S.off = v; save(); }),
        h('div', { class: 'hint', text: 'الصوت الأصلي مش بيتغيّر — الرامب للصورة بس (حط مزيكا أو ساوند إيفكت عليه).' }),
        h('div', { style: 'margin-top:10px' }, [ui.go]), h('div', { class: 'tk' }, [ui.stop]), ui.prog, ui.status])
    ].forEach(function (el) { root.appendChild(el); });
    mark(); replan();
    G.addEventListener('resize', function () { if (ui.graph.clientWidth) graph(); });
  }
  G.SpeedRampTab = { build: build, onHide: stopPv, onShow: function () { if (plan) setTimeout(function () { graph(); }, 0); }, _plan: makePlan, _frameAt: frameAt, CURVES: CURVES };
})(window);
