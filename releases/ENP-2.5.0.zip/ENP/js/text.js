/* Amar Studio — animated text tab. */
(function (G) {
  'use strict';
  var K = G.K, h = K.h, st = K.store('c3d_tx_'), FX = G.TextFX;
  var T = FX.norm(st.get('set', {}));
  var seq = { w: 1080, h: 1920 }, clock = { on: false, t: 0, last: 0 }, raf = 0, hoverPreset = null, busy = false, stop = false;
  var lastPlaced = st.get('last', null), ui = {}, ctl = {};
  function save() { st.set('set', T); }
  function set(p) { for (var k in p) T[k] = p[k]; save(); draw(); }

  /* ---------- preview ---------- */
  function fit() {
    var w = Math.max(160, ui.wrap.clientWidth || 300), ar = seq.w / seq.h, hh = Math.min(K.pvH(440), w / ar), ww = hh * ar;
    ui.stage.style.width = Math.round(ww) + 'px'; ui.stage.style.height = Math.round(hh) + 'px';
    var dpr = Math.min(2, G.devicePixelRatio || 1);
    ui.cv.width = Math.round(ww * dpr); ui.cv.height = Math.round(hh * dpr);
    draw();
  }
  function draw() { if (!raf) raf = (G.requestAnimationFrame || setTimeout)(paint); }
  function paint() {
    raf = 0;
    var now = Date.now();
    if (clock.on) { clock.t += Math.min(.1, (now - (clock.last || now)) / 1000); clock.last = now; if (clock.t > T.dur + .4) clock.t = 0; }
    var x = ui.cv.getContext('2d'); x.setTransform(1, 0, 0, 1, 0, 0); x.clearRect(0, 0, ui.cv.width, ui.cv.height);
    var tt = Object.assign({}, T); if (hoverPreset) tt.preset = hoverPreset;
    try { FX.draw(x, tt, ui.cv.width, ui.cv.height, Math.min(clock.t, T.dur)); } catch (e) { try { console.warn(e); } catch (x2) {} }
    ui.scrub.max = String(T.dur); ui.scrub.value = String(Math.min(clock.t, T.dur));
    ui.time.textContent = Math.min(clock.t, T.dur).toFixed(1) + ' / ' + (+T.dur).toFixed(1) + 's';
    if (clock.on || hoverPreset) draw();
  }
  function play(on) { clock.on = on; clock.last = Date.now(); ui.play.innerHTML = K.ICON[on ? 'stop' : 'play']; draw(); }
  function bindDrag() {
    var d = null;
    ui.cv.addEventListener('pointerdown', function (e) { try { ui.cv.setPointerCapture(e.pointerId); } catch (x) {} var r = ui.cv.getBoundingClientRect(); d = { x: e.clientX, y: e.clientY, tx: T.x, ty: T.y, w: r.width, h: r.height }; });
    ui.cv.addEventListener('pointermove', function (e) {
      if (!d) return;
      var nx = d.tx + (e.clientX - d.x) / d.w, ny = d.ty + (e.clientY - d.y) / d.h;
      if (Math.abs(nx - .5) < .012) nx = .5; if (Math.abs(ny - .5) < .012) ny = .5;   // snap to centre
      T.x = Math.max(-.2, Math.min(1.2, nx)); T.y = Math.max(-.2, Math.min(1.2, ny)); draw();
    });
    function end() { if (d) { d = null; save(); } }
    ui.cv.addEventListener('pointerup', end); ui.cv.addEventListener('pointercancel', end);
  }
  function underlay() {
    var on = !!st.get('eye', false); ui.eye.classList.toggle('on', on);
    if (!on) { ui.under.removeAttribute('src'); return; }
    Out.underFrame(seq.w / 2, seq.h / 2).then(function (p) { if (p) ui.under.src = Sys.url(p); }).catch(function () {});
  }
  function syncSeq() {
    Sys.call('cr_info').then(function (r) { if (r && r.ok && r.hasSequence && r.w && (r.w !== seq.w || r.h !== seq.h)) { seq = { w: r.w, h: r.h }; fit(); } });
  }

  /* ---------- presets grid ---------- */
  function presetGrid() {
    var box = h('div', { class: 'pgrid' });
    FX.PRESETS.forEach(function (p) {
      var b = h('button', { type: 'button', class: 'pbtn' + (T.preset === p.id ? ' on' : ''), 'data-id': p.id }, [
        h('span', { class: 'pu', text: p.unit === 'char' ? 'حروف' : p.unit === 'word' ? 'كلمات' : 'سطر' }), h('span', { text: p.name })]);
      b.addEventListener('click', function () { set({ preset: p.id }); [].forEach.call(box.children, function (x) { x.classList.toggle('on', x === b); }); clock.t = 0; play(true); });
      b.addEventListener('mouseenter', function () { hoverPreset = p.id; clock.t = 0; clock.on = true; clock.last = Date.now(); draw(); });
      b.addEventListener('mouseleave', function () { hoverPreset = null; draw(); });
      box.appendChild(b);
    });
    return box;
  }

  /* ---------- saved styles ---------- */
  function styles() {
    var box = h('div', { class: 'chips' });
    function fill() {
      box.innerHTML = '';
      var all = st.get('styles', {});
      Object.keys(all).forEach(function (name) {
        var c = h('button', { type: 'button', class: 'chip', text: name, title: 'دوسة = طبّق · كليك يمين = امسح' });
        c.addEventListener('click', function () { var txt = T.text; T = FX.norm(all[name]); T.text = txt; save(); syncAll(); });
        c.addEventListener('contextmenu', function (e) { e.preventDefault(); delete all[name]; st.set('styles', all); fill(); });
        box.appendChild(c);
      });
      var add = h('button', { type: 'button', class: 'chip', text: '+ احفظ الستايل ده' });
      add.addEventListener('click', function () {
        var base = FX.BY[T.preset].name + ' · ' + T.font, name = base, k = 2;
        while (all[name]) name = base + ' ' + (k++);
        var cp = Object.assign({}, T); delete cp.text; all[name] = cp; st.set('styles', all); fill();
      });
      box.appendChild(add);
    }
    fill(); return box;
  }

  /* ---------- controls ---------- */
  function sl(k, label, min, max, step, fmt) { var c = K.slider({ label: label, min: min, max: max, step: step, value: T[k], fmt: fmt, onInput: function (v) { var p = {}; p[k] = v; set(p); } }); ctl[k] = c; return c; }
  function col(k, label) {
    var inp = h('input', { type: 'color', value: T[k] }); inp.addEventListener('input', function () { var p = {}; p[k] = inp.value; set(p); });
    var l = h('label', { class: 'cfield' }, [inp, h('span', { text: label })]); l.setValue = function (v) { inp.value = v; }; ctl[k] = l; return l;
  }
  function tg(k, label) { var c = K.toggle(label, T[k], function (v) { var p = {}; p[k] = v; set(p); }); ctl[k] = c; return c; }
  function sg(k, items) { var c = K.seg({ items: items, value: T[k], onChange: function (v) { var p = {}; p[k] = v; set(p); } }); ctl[k] = c; return c; }
  function pct(v) { return Math.round(v * 100) + '%'; }
  function sec(v) { return (+v).toFixed(1) + ' ث'; }
  function weightSeg() {
    var box = h('div', { class: 'seg' });
    box.refresh = function () {
      box.innerHTML = '';
      var ws = Fonts.weights(T.font); if (ws.indexOf(+T.weight) < 0 && ws.length) { T.weight = ws.indexOf(700) >= 0 ? 700 : ws[ws.length - 1]; save(); }
      ws.forEach(function (w) {
        box.appendChild(h('button', { type: 'button', class: +T.weight === w ? 'on' : '', text: String(w), onclick: function () { T.weight = w; save(); box.refresh(); loadFont(); } }));
      });
    };
    ctl.weightSeg = box; return box;
  }
  function loadFont() { Fonts.ensure(T.font, +T.weight).then(draw); }
  function syncAll() {
    Object.keys(ctl).forEach(function (k) { var c = ctl[k]; if (c && c.setValue && T[k] !== undefined) c.setValue(T[k]); });
    if (ctl.weightSeg) ctl.weightSeg.refresh();
    ui.text.value = T.text;
    [].forEach.call(ui.grid.children, function (x) { x.classList.toggle('on', x.getAttribute('data-id') === T.preset); });
    loadFont(); draw();
  }

  /* ---------- output ---------- */
  function placeIt() {
    if (busy) return;
    busy = true; stop = false; ui.place.disabled = true; K.show(ui.stop, true); play(false);
    var cv = G.document.createElement('canvas'), x;
    Out.renderAndPlace({
      prefix: 'ENP_Text', bin: 'ENP Text', dur: T.dur,
      replace: st.get('replace', false) && lastPlaced ? lastPlaced.names : [],
      prepare: function (o) { cv.width = o.w; cv.height = o.h; x = cv.getContext('2d'); return Fonts.ensure(T.font, +T.weight); },
      frame: function (t) { x.setTransform(1, 0, 0, 1, 0, 0); x.clearRect(0, 0, cv.width, cv.height); FX.draw(x, T, cv.width, cv.height, t); return x.getImageData(0, 0, cv.width, cv.height).data; },
      onProgress: function (p) { ui.prog.set(p); ui.status.show('busy', 'برسم النص… ' + Math.round(p * 100) + '%'); },
      cancelled: function () { return stop; }
    }).then(function (r) {
      lastPlaced = { names: r.names }; st.set('last', lastPlaced); K.show(ui.remove, true);
      ui.status.show('ok', 'اتحط على ' + r.track + ' عند ' + K.tc(r.at, r.fps) + ' · خد ' + (r.ms / 1000).toFixed(1) + ' ث');
    }).catch(function (e) { ui.status.show(e && e.message === 'cancelled' ? 'warn' : 'err', Out.errText(e)); })
      .then(function () { busy = false; ui.place.disabled = false; K.show(ui.stop, false); ui.prog.done(); });
  }
  function removeLast() {
    if (!lastPlaced) return;
    Sys.call('cr_remove', { names: lastPlaced.names }).then(function (r) { if (r && r.ok) { ui.status.show('ok', 'اتشال ' + r.removed + ' من التايملاين'); lastPlaced = null; st.set('last', null); K.show(ui.remove, false); } });
  }

  /* ---------- build ---------- */
  function build(root) {
    ui.cv = h('canvas', { class: 'txcv' }); ui.under = h('img', { class: 'under', alt: '' });
    ui.stage = h('div', { class: 'stage over' }, [ui.under, ui.cv]); ui.wrap = h('div', { class: 'pvwrap' }, [ui.stage]);
    ui.play = h('button', { type: 'button', class: 'ibtn', html: K.ICON.play, onclick: function () { if (!clock.on && clock.t >= T.dur) clock.t = 0; play(!clock.on); } });
    ui.scrub = h('input', { type: 'range', class: 'scrub', min: 0, max: T.dur, step: .01, value: 0 });
    ui.scrub.addEventListener('input', function () { clock.t = parseFloat(ui.scrub.value) || 0; if (clock.on) play(false); draw(); });
    ui.time = h('span', { class: 'time' });
    ui.eye = h('button', { type: 'button', class: 'ibtn', title: 'المعاينة فوق الفيديو', html: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1.5 12S5.5 5 12 5s10.5 7 10.5 7-4 7-10.5 7S1.5 12 1.5 12z"/><circle cx="12" cy="12" r="3"/></svg>', onclick: function () { st.set('eye', !st.get('eye', false)); underlay(); } });
    bindDrag();

    ui.text = h('textarea', { class: 'txin', dir: 'auto', rows: '3' }); ui.text.value = T.text;
    ui.text.addEventListener('input', function () { T.text = ui.text.value; save(); draw(); });
    ui.grid = presetGrid();
    var picker = Fonts.picker({ value: T.font, onChange: function (f) { T.font = f; save(); ctl.weightSeg.refresh(); loadFont(); } });
    ctl.font = picker;

    ui.status = K.status(); ui.prog = K.progress();
    ui.place = K.btn('حطه على التايملاين', { cls: 'pri', icon: 'spark', onClick: placeIt });
    ui.stop = K.btn('وقّف', { icon: 'stop', onClick: function () { stop = true; } }); K.show(ui.stop, false);
    ui.remove = K.btn('شيل آخر نص', { cls: 'ghost', icon: 'undo', onClick: removeLast }); K.show(ui.remove, !!lastPlaced);

    [h('div', { class: 'hint intro', text: 'اكتب النص، اختار حركة من ' + FX.PRESETS.length + ' حركة، وظبّط الخط واللون. اسحب النص في المعاينة عشان تحرّكه، وعدّي على أي حركة عشان تشوفها.' }),
      h('div', { class: 'pv' }, [ui.wrap, h('div', { class: 'bar' }, [ui.play, ui.scrub, ui.time, ui.eye])]),
      K.section('النص', [ui.text, K.field('الخط', picker), K.field('التُخن', weightSeg()),
        sl('size', 'الحجم', .02, .2, .001, pct), h('div', { class: 'crow' }, [col('color', 'اللون'), col('color2', 'اللون التاني')]), tg('grad', 'تدرّج من اللون للتاني'),
        K.field('المحاذاة', sg('align', [{ v: 'right', label: 'يمين' }, { v: 'center', label: 'نص' }, { v: 'left', label: 'شمال' }])),
        sl('lineH', 'المسافة بين السطور', .9, 2, .01, function (v) { return v.toFixed(2); }), sl('maxW', 'أقصى عرض للسطر', .2, 1, .01, pct), tg('upper', 'حروف كابيتال (للإنجليزي)')], true, 'tx_text'),
      K.section('الحركة', [ui.grid], true, 'tx_anim'),
      K.section('التوقيت', [sl('dur', 'المدة', 1, 20, .1, sec), sl('inDur', 'مدة الدخول', .1, 4, .05, sec), sl('speed', 'سرعة التتابع', .4, 3, .05, function (v) { return v.toFixed(2) + '×'; }),
        sl('outDur', 'مدة الخروج', .1, 3, .05, sec),
        K.field('الخروج', (function () { var s = h('select', { class: 'sel' }, Object.keys(FX.OUTS).map(function (k) { return h('option', { value: k, text: FX.OUTS[k] }); })); s.value = T.outMode; s.addEventListener('change', function () { set({ outMode: s.value }); }); s.setValue = function (v) { s.value = v; }; ctl.outMode = s; return s; })())], false, 'tx_time'),
      K.section('الشكل', [sl('stroke', 'إطار حوالين الحروف', 0, 2, .05, function (v) { return v.toFixed(2); }), h('div', { class: 'crow' }, [col('strokeColor', 'لون الإطار')]),
        sl('shadow', 'ظل', 0, 1, .01, pct), sl('glow', 'توهج', 0, 1, .01, pct), h('div', { class: 'crow' }, [col('glowColor', 'لون التوهج')]),
        tg('box', 'خلفية ورا النص'), h('div', { class: 'crow' }, [col('boxColor', 'لون الخلفية')]), sl('boxAlpha', 'شفافية الخلفية', 0, 1, .01, pct),
        sl('boxPad', 'المسافة جوه الخلفية', 0, 1.5, .01, function (v) { return v.toFixed(2); }), sl('boxRadius', 'دوران الزوايا', 0, 1, .01, pct)], false, 'tx_style'),
      K.section('ستايلات محفوظة', [styles()], false, 'tx_styles'),
      h('div', { class: 'out' }, [K.toggle('بدّل آخر نص حطيته', st.get('replace', false), function (v) { st.set('replace', v); }), h('div', { style: 'margin-top:10px' }, [ui.place]),
        h('div', { class: 'tk' }, [ui.stop, ui.remove]), ui.prog, ui.status])
    ].forEach(function (el) { root.appendChild(el); });
    ctl.weightSeg.refresh();
    Fonts.scan().then(function () { ctl.weightSeg.refresh(); loadFont(); });
    G.addEventListener('resize', fit);
    G.addEventListener('focus', syncSeq);
    syncSeq(); fit(); underlay();
  }

  G.TextTab = { build: build, onHide: function () { play(false); } };
})(window);
