/* Amar Studio — Liquid Glass (Apple-style) panels over your video.
   The glass bends and frosts the actual picture under it: the clip under the
   playhead is read frame by frame and refracted in a WebGL shader. */
(function (G) {
  'use strict';
  var K = G.K, h = K.h, st = K.store('c3d_gl_');

  /* ---------------- renderer ---------------- */
  var VS = 'attribute vec2 aP; void main(){ gl_Position = vec4(aP, 0.0, 1.0); }';
  var FS = [
    'precision highp float;',
    'uniform sampler2D uBg; uniform vec2 uRes; uniform vec2 uC; uniform vec2 uHalf; uniform float uR;',
    'uniform float uBlur; uniform float uRefr; uniform float uEdge; uniform float uChroma; uniform vec3 uTint; uniform float uTintA;',
    'uniform float uSpec; uniform float uShadow; uniform float uAlpha; uniform float uSat; uniform float uBright; uniform float uHasBg; uniform float uMag;',
    'uniform int uShape; uniform float uRot; uniform float uK; uniform float uDepth; uniform vec2 uV[13]; uniform int uNV; uniform float uYaw; uniform float uSpin;',
    'float sdBox(vec2 p){ vec2 q = abs(p) - uHalf + uR; return length(max(q,0.0)) + min(max(q.x,q.y),0.0) - uR; }',
    'float sdPoly(vec2 p){ float d = 1e9; float s = 1.0;',
    '  for (int i = 0; i < 12; i++) { if (i >= uNV) break; vec2 a = uV[i], b = uV[i + 1], e = b - a, w = p - a;',
    '    vec2 q = w - e * clamp(dot(w, e) / dot(e, e), 0.0, 1.0); d = min(d, dot(q, q));',
    '    bvec3 c = bvec3(p.y >= a.y, p.y < b.y, e.x * w.y > e.y * w.x); if (all(c) || all(not(c))) s = -s; }',
    '  return s * sqrt(d); }',
    'float sdMoon(vec2 p, float d, float ra, float rb){ p.y = abs(p.y); float a = (ra*ra - rb*rb + d*d) / (2.0*d); float b = sqrt(max(ra*ra - a*a, 0.0));',
    '  if (d*(p.x*b - p.y*a) > d*d*max(b - p.y, 0.0)) return length(p - vec2(a, b)); return max(length(p) - ra, -(length(p - vec2(d, 0.0)) - rb)); }',
    'float sdHeart(vec2 p){ p.x = abs(p.x); if (p.y + p.x > 1.0) return length(p - vec2(0.25, 0.75)) - 0.35355;',
    '  return sqrt(min(dot(p - vec2(0.0, 1.0), p - vec2(0.0, 1.0)), dot(p - 0.5*max(p.x + p.y, 0.0), p - 0.5*max(p.x + p.y, 0.0)))) * sign(p.x - p.y); }',
    'float smin(float a, float b, float k){ float h = clamp(0.5 + 0.5*(b - a)/k, 0.0, 1.0); return mix(b, a, h) - k*h*(1.0 - h); }',
    'float sdTri(vec2 p, vec2 p0, vec2 p1, vec2 p2){ vec2 e0 = p1 - p0, e1 = p2 - p1, e2 = p0 - p2, v0 = p - p0, v1 = p - p1, v2 = p - p2;',
    '  vec2 q0 = v0 - e0*clamp(dot(v0,e0)/dot(e0,e0), 0.0, 1.0), q1 = v1 - e1*clamp(dot(v1,e1)/dot(e1,e1), 0.0, 1.0), q2 = v2 - e2*clamp(dot(v2,e2)/dot(e2,e2), 0.0, 1.0);',
    '  float s = sign(e0.x*e2.y - e0.y*e2.x); vec2 d = min(min(vec2(dot(q0,q0), s*(v0.x*e0.y - v0.y*e0.x)), vec2(dot(q1,q1), s*(v1.x*e1.y - v1.y*e1.x))), vec2(dot(q2,q2), s*(v2.x*e2.y - v2.y*e2.x)));',
    '  return -sqrt(d.x)*sign(d.y); }',
    'float rbox(vec2 p, vec2 b, float r){ vec2 q = abs(p) - b + r; return length(max(q,0.0)) + min(max(q.x,q.y),0.0) - r; }',
    'float sd0(vec2 p);',
    'float sd(vec2 p){ float cy = cos(uYaw); float ac = max(abs(cy), 0.035); return sd0(vec2(p.x / (cy < 0.0 ? -ac : ac), p.y)) * ac; }',
    'float sd0(vec2 p){',
    '  float c = cos(uRot), s = sin(uRot); p = vec2(c*p.x + s*p.y, -s*p.x + c*p.y);',
    '  if (uShape == 0) return sdBox(p);',
    '  float m = min(uHalf.x, uHalf.y); vec2 st = uHalf / m; vec2 q = p / st; float k = min(st.x, st.y);',
    '  float d;',
    '  if (uShape == 1) d = sdPoly(q / m) * m - uR;',
    '  else if (uShape == 2) d = sdMoon(vec2(-q.x, q.y) + vec2(m*0.25, 0.0), m*(0.35 + 0.5*uK), m, m*0.9);',
    '  else if (uShape == 3) { float z = m*2.05; d = sdHeart(vec2(q.x, -q.y)/z + vec2(0.0, 0.5)) * z - uR; }',
    '  else if (uShape == 4) d = abs(length(q) - m*(1.0 - uK*0.5)) - m*uK*0.5;',
    '  else if (uShape == 5) { d = smin(smin(length(q - vec2(-m*0.48, m*0.12)) - m*0.42, length(q - vec2(m*0.02, -m*0.2)) - m*0.56, m*0.2), length(q - vec2(m*0.52, m*0.14)) - m*0.4, m*0.2); d = smin(d, rbox(q - vec2(0.0, m*0.3), vec2(m*0.8, m*0.26), m*0.26), m*0.15); }',
    '  else { d = rbox(q - vec2(0.0, -m*0.12), vec2(m, m*0.66), m*0.38); d = smin(d, sdTri(q, vec2(-m*0.62, m*0.3), vec2(-m*0.12, m*0.4), vec2(-m*0.82, m*0.98)), m*0.06); }',
    '  return d * k;',
    '}',
    'vec3 bg(vec2 p, float bias){ vec2 uv = clamp(p / uRes, 0.0, 1.0); return texture2D(uBg, uv, bias).rgb; }',
    'vec3 frost(vec2 p){',
    '  float rad = uBlur * min(uHalf.x, uHalf.y) * 0.5; float bias = uBlur * 5.0;',
    '  vec3 s = bg(p, bias) * 0.2;',
    '  for (int i = 0; i < 8; i++) { float a = float(i) * 0.785398 + 0.3; vec2 o = vec2(cos(a), sin(a)) * rad * (0.55 + 0.45 * mod(float(i), 2.0)); s += bg(p + o, bias) * 0.1; }',
    '  return s;',
    '}',
    'void main(){',
    '  vec2 p = vec2(gl_FragCoord.x, uRes.y - gl_FragCoord.y);',
    '  vec2 lp = p - uC; float d = sd(lp);',
    '  float aa = 1.0;',
    '  if (d > aa && (uDepth > 0.0 || uSpin > 0.0)) {',  // the glass's own thickness: a side wall (3D slab); when it spins in 3D the wall shows on the turning side
    '    float m0 = min(uHalf.x, uHalf.y); float th = uDepth * m0 * 0.22; float thY = max(uDepth, 0.45) * m0 * 0.42 * uSpin;',
    '    vec2 side = vec2(th * 0.25 * (1.0 - uSpin) + sin(uYaw) * thY, th * (1.0 - uSpin * 0.7)); float dm = 1e9;',
    '    for (int i = 1; i <= 8; i++) { dm = min(dm, sd(lp - side * (float(i) / 8.0))); }',
    '    if (dm < 0.5) { vec3 wc = frost(uC + lp * 0.9) * 0.5 + vec3(0.06); float rimS = clamp(1.0 - abs(d) / (length(side) + 1.0), 0.0, 1.0);',
    '      wc *= 0.75 + 0.35 * abs(cos(uYaw));',
    '      wc += vec3(1.0) * pow(rimS, 3.0) * 0.18 * uSpec; gl_FragColor = vec4(clamp(wc, 0.0, 1.0), clamp(0.5 - dm, 0.0, 1.0) * uAlpha * 0.95); return; }',
    '  }',
    '  if (d > aa) {',  // outside: soft drop shadow only
    '    float ds = sd(lp - vec2(0.0, uHalf.y * 0.12 + 6.0));',
    '    float sh = uShadow * 0.55 * exp(-max(ds, 0.0) / (8.0 + min(uHalf.x, uHalf.y) * 0.35));',
    '    gl_FragColor = vec4(0.0, 0.0, 0.0, sh * uAlpha); return;',
    '  }',
    '  vec2 e2 = vec2(1.0, 0.0);',
    '  vec2 n = normalize(vec2(sd(lp + e2.xy) - sd(lp - e2.xy), sd(lp + e2.yx) - sd(lp - e2.yx)) + 1e-5);',
    '  float depth = clamp(-d / uEdge, 0.0, 1.0);',
    '  float bend = pow(1.0 - depth, 2.2) * uRefr;',
    '  vec2 q = uC + lp * (1.0 - uMag) - n * bend;',
    '  vec3 col;',
    '  if (uChroma > 0.0) {',
    '    vec2 ch = n * bend * uChroma;',
    '    col = vec3(frost(q - ch).r, frost(q).g, frost(q + ch).b);',
    '  } else col = frost(q);',
    '  col = mix(vec3(0.5), col, uHasBg);',
    '  float l = dot(col, vec3(0.299, 0.587, 0.114));',
    '  col = mix(vec3(l), col, uSat) * uBright;',
    '  col = mix(col, uTint, uTintA);',
    '  vec2 L = normalize(vec2(-0.55 + 1.1 * sin(uYaw) * uSpin, -0.85));',
    '  col += vec3(1.0) * uSpin * 0.18 * uSpec * pow(max(0.0, sin(uYaw * 2.0 + lp.x / max(uHalf.x, 1.0) * 1.5)), 6.0);',
    '  float rim = pow(1.0 - depth, 3.0);',
    '  float lit = max(dot(n, L), 0.0), dark = max(dot(n, -L), 0.0);',
    '  col += vec3(1.0) * rim * lit * uSpec * 1.1;',
    '  col += vec3(1.0) * pow(1.0 - clamp(-d / 1.6, 0.0, 1.0), 2.0) * 0.35 * uSpec;',
    '  col -= vec3(0.25) * rim * dark * uSpec;',
    '  float sheen = smoothstep(0.0, 1.0, 1.0 - (lp.y + uHalf.y) / (uHalf.y * 2.0)) * 0.06 * uSpec;',
    '  col += sheen;',
    '  col += vec3(1.0) * uDepth * 0.12 * smoothstep(0.0, 1.0, 1.0 - (lp.y + uHalf.y) / (uHalf.y * 1.2)) * (1.0 - depth * 0.5);',
    '  col -= vec3(0.12) * uDepth * smoothstep(0.4, 1.0, (lp.y + uHalf.y) / (uHalf.y * 2.0)) * rim;',
    '  float cover = clamp(0.5 - d, 0.0, 1.0);',
    '  float a = cover * uAlpha * mix(0.82, 1.0, uHasBg);',
    '  gl_FragColor = vec4(clamp(col, 0.0, 1.0), a);',
    '}'].join('\n');

  function pot(n) { var p = 1; while (p < n) p *= 2; return p; }
  function Renderer() {
    var cv = G.document.createElement('canvas');
    var gl = cv.getContext('webgl', { alpha: true, premultipliedAlpha: true, preserveDrawingBuffer: true, antialias: false });
    if (!gl) throw new Error('no_webgl');
    function sh(t, s) { var o = gl.createShader(t); gl.shaderSource(o, s); gl.compileShader(o); if (!gl.getShaderParameter(o, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(o)); return o; }
    var pr = gl.createProgram(); gl.attachShader(pr, sh(gl.VERTEX_SHADER, VS)); gl.attachShader(pr, sh(gl.FRAGMENT_SHADER, FS)); gl.linkProgram(pr); gl.useProgram(pr);
    var U = {}; ['uBg','uRes','uC','uHalf','uR','uBlur','uRefr','uEdge','uChroma','uTint','uTintA','uSpec','uShadow','uAlpha','uSat','uBright','uHasBg','uMag','uShape','uRot','uK','uDepth','uV','uNV','uYaw','uSpin'].forEach(function (n) { U[n] = gl.getUniformLocation(pr, n); });
    var b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1,-1, 1,-1, -1,1, 1,1]), gl.STATIC_DRAW);
    var a = gl.getAttribLocation(pr, 'aP'); gl.enableVertexAttribArray(a); gl.vertexAttribPointer(a, 2, gl.FLOAT, false, 0, 0);
    var tex = gl.createTexture(), scratch = G.document.createElement('canvas'), hasBg = 0;
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array([128, 128, 128, 255]));
    return {
      canvas: cv,
      setBg: function (src) {
        if (!src) { hasBg = 0; return; }
        var w = src.width, hh = src.height, tw = Math.min(2048, pot(w)), th = Math.min(2048, pot(hh));
        scratch.width = tw; scratch.height = th; scratch.getContext('2d').drawImage(src, 0, 0, tw, th);
        gl.bindTexture(gl.TEXTURE_2D, tex);
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, scratch);
        gl.generateMipmap(gl.TEXTURE_2D);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
        hasBg = 1;
      },
      /* g: geometry in pixels {cx,cy,hw,hh,r}, s: settings, alpha */
      draw: function (W, H, g, s, alpha) {
        if (cv.width !== W || cv.height !== H) { cv.width = W; cv.height = H; }
        gl.viewport(0, 0, W, H); gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT);
        gl.enable(gl.BLEND); gl.blendFuncSeparate(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA, gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
        var tc = hex(s.tint), m = Math.min(g.hw, g.hh);
        gl.uniform1i(U.uBg, 0); gl.uniform2f(U.uRes, W, H); gl.uniform2f(U.uC, g.cx, g.cy); gl.uniform2f(U.uHalf, g.hw, g.hh); gl.uniform1f(U.uR, Math.min(g.r, m));
        gl.uniform1f(U.uBlur, s.blur); gl.uniform1f(U.uRefr, s.refr * m * .9); gl.uniform1f(U.uEdge, Math.max(2, s.edge * m)); gl.uniform1f(U.uChroma, s.chroma);
        gl.uniform3f(U.uTint, tc[0], tc[1], tc[2]); gl.uniform1f(U.uTintA, s.tintA); gl.uniform1f(U.uSpec, s.spec); gl.uniform1f(U.uShadow, s.shadow);
        gl.uniform1f(U.uAlpha, alpha); gl.uniform1f(U.uSat, s.sat); gl.uniform1f(U.uBright, s.bright); gl.uniform1f(U.uHasBg, hasBg); gl.uniform1f(U.uMag, s.mag * .12);
        var SH = SHAPES[s.shape] || SHAPES.rect;
        gl.uniform1i(U.uShape, SH.kind); gl.uniform1f(U.uRot, ((s.rot || 0) + (g.rot || 0)) * Math.PI / 180); gl.uniform1f(U.uK, SH.k !== undefined ? SH.k : .5); gl.uniform1f(U.uDepth, s.depth || 0); gl.uniform1f(U.uYaw, g.yaw || 0); gl.uniform1f(U.uSpin, g.yaw !== undefined && s.spin3d > 0 ? 1 : 0);
        if (SH.kind === 1) { var vv = new Float32Array(26), V = SH.v; for (var i = 0; i <= V.length && i < 13; i++) { var pnt = V[i % V.length]; vv[i * 2] = pnt[0]; vv[i * 2 + 1] = pnt[1]; } gl.uniform2fv(U.uV, vv); gl.uniform1i(U.uNV, Math.min(12, V.length)); }
        else gl.uniform1i(U.uNV, 0);
        gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
      }
    };
  }
  /* shapes: kind 0 = rounded box (pill / rect / circle), 1 = polygon (unit radius, y down), 2 moon, 3 heart, 4 ring, 5 cloud, 6 speech bubble */
  function ngon(n, r0, rot) { var o = []; for (var i = 0; i < n; i++) { var a = (rot || -90) * Math.PI / 180 + i * 2 * Math.PI / n; o.push([Math.cos(a) * (r0 || 1), Math.sin(a) * (r0 || 1)]); } return o; }
  function star(n, inner) { var o = []; for (var i = 0; i < n * 2; i++) { var a = -Math.PI / 2 + i * Math.PI / n, r = i % 2 ? inner : 1; o.push([Math.cos(a) * r, Math.sin(a) * r]); } return o; }
  var SHAPES = {
    pill: { kind: 0, name: 'كبسولة' }, rect: { kind: 0, name: 'مستطيل' }, circle: { kind: 0, name: 'دايرة' },
    star5: { kind: 1, name: 'نجمة', v: star(5, .48) }, star4: { kind: 1, name: 'نجمة لمعة', v: star(4, .36) }, star6: { kind: 1, name: 'نجمة ٦', v: star(6, .55) },
    moon: { kind: 2, name: 'قمر', k: .35 }, heart: { kind: 3, name: 'قلب' }, ring: { kind: 4, name: 'حلقة', k: .32 }, cloud: { kind: 5, name: 'سحابة' }, bubble: { kind: 6, name: 'فقاعة كلام' },
    tri: { kind: 1, name: 'مثلث', v: ngon(3, 1.05) }, diamond: { kind: 1, name: 'معين', v: [[0, -1], [.72, 0], [0, 1], [-.72, 0]] }, pent: { kind: 1, name: 'خماسي', v: ngon(5) },
    hex: { kind: 1, name: 'سداسي', v: ngon(6, 1, 0) }, oct: { kind: 1, name: 'ثماني', v: ngon(8, 1, 22.5) },
    plus: { kind: 1, name: 'زائد', v: [[-.32, -1], [.32, -1], [.32, -.32], [1, -.32], [1, .32], [.32, .32], [.32, 1], [-.32, 1], [-.32, .32], [-1, .32], [-1, -.32], [-.32, -.32]] },
    arrow: { kind: 1, name: 'سهم', v: [[-1, -.32], [.15, -.32], [.15, -.75], [1, 0], [.15, .75], [.15, .32], [-1, .32]] },
    bolt: { kind: 1, name: 'برق', v: [[.2, -1], [-.62, .12], [-.06, .12], [-.3, 1], [.62, -.18], [.06, -.18]] },
    shield: { kind: 1, name: 'درع', v: [[0, -1], [.85, -.72], [.8, .05], [.45, .62], [0, 1], [-.45, .62], [-.8, .05], [-.85, -.72]] },
    tag: { kind: 1, name: 'تاج', v: [[-1, .7], [-1, -.55], [-.5, -.05], [0, -.75], [.5, -.05], [1, -.55], [1, .7]] },
    play: { kind: 1, name: 'تشغيل', v: [[-.7, -1], [1, 0], [-.7, 1]] }
  };
  function hex(c) { var n = parseInt(String(c || '#ffffff').slice(1, 7), 16) || 0; return [(n >> 16 & 255) / 255, (n >> 8 & 255) / 255, (n & 255) / 255]; }

  /* ---------------- settings & presets ---------------- */
  var DEF = {
    shape: 'pill', w: .7, h: .12, radius: .3, x: .5, y: .5,
    blur: .35, refr: .5, edge: .55, chroma: .25, tint: '#ffffff', tintA: .08, spec: .8, shadow: .35, sat: 1.2, bright: 1.05, mag: .3,
    text: '', font: 'Arial', weight: 700, tsize: .38, tcolor: '#ffffff',
    dur: 4, anim: 'jelly', inDur: .7, outDur: .45, outAnim: 'shrink', rot: 0, depth: 0, ox: .5, oy: 1.1, spinLoop: 0, spin3d: 0
  };
  var PRESETS = [
    { id: 'island', name: 'دايناميك آيلاند', set: { shape: 'pill', w: .42, h: .085, x: .5, y: .06, blur: .25, tintA: .15, tint: '#0a0a0a', text: 'تسجيل…', tsize: .42, anim: 'island' } },
    { id: 'notify', name: 'إشعار', set: { shape: 'rect', w: .9, h: .2, radius: .22, x: .5, y: .13, blur: .55, tintA: .1, text: 'رسالة جديدة', tsize: .26, anim: 'drop' } },
    { id: 'button', name: 'زرار', set: { shape: 'pill', w: .5, h: .13, x: .5, y: .82, blur: .3, text: 'تابعني', tsize: .4, anim: 'jelly' } },
    { id: 'lower', name: 'لوور ثيرد', set: { shape: 'rect', w: .88, h: .19, radius: .25, x: .5, y: .78, blur: .45, text: 'الاسم هنا', tsize: .3, anim: 'rise' } },
    { id: 'circle', name: 'دايرة عدسة', set: { shape: 'circle', w: .38, h: .38, x: .5, y: .45, blur: .02, refr: .9, mag: .9, edge: .8, chroma: .35, text: '', anim: 'jelly' } },
    { id: 'card', name: 'كارت', set: { shape: 'rect', w: .84, h: .55, radius: .1, x: .5, y: .5, blur: .6, tintA: .12, text: '', anim: 'rise' } },
    { id: 'tabbar', name: 'تاب بار', set: { shape: 'pill', w: .82, h: .15, x: .5, y: .93, blur: .5, text: '', anim: 'rise' } },
    { id: 'name2', name: 'اسم + وظيفة', set: { shape: 'rect', w: .82, h: .17, radius: .3, x: .5, y: .8, blur: .5, tintA: .12, text: 'الاسم هنا\nالمسمى الوظيفي', tsize: .3, anim: 'rise', outAnim: 'drop' } },
    { id: 'subscribe', name: 'اشترك', set: { shape: 'pill', w: .46, h: .1, x: .5, y: .84, blur: .3, tint: '#ff2d55', tintA: .45, text: 'اشترك', tsize: .45, anim: 'jelly' } },
    { id: 'handle', name: 'يوزرنيم', set: { shape: 'pill', w: .5, h: .075, x: .5, y: .12, blur: .35, tintA: .1, text: '@username', tsize: .42, anim: 'island', outAnim: 'island' } },
    { id: 'cta', name: 'اللينك في البايو', set: { shape: 'pill', w: .72, h: .09, x: .5, y: .9, blur: .4, tint: '#c9a26b', tintA: .3, text: 'اللينك في البايو ↓', tsize: .4, anim: 'rise' } },
    { id: 'chapter', name: 'عنوان فصل', set: { shape: 'rect', w: .8, h: .2, radius: .45, x: .5, y: .5, blur: .65, tintA: .15, text: 'الجزء الأول\nالبداية', tsize: .34, anim: 'pop', outAnim: 'shrink' } },
    { id: 'quote', name: 'اقتباس', set: { shape: 'rect', w: .86, h: .3, radius: .16, x: .5, y: .62, blur: .6, tintA: .12, text: '«الجملة المهمة هنا»\nاسم القائل', tsize: .17, anim: 'rise' } },
    { id: 'price', name: 'سعر / رقم', set: { shape: 'circle', w: .3, x: .78, y: .3, blur: .4, tint: '#c9a26b', tintA: .35, refr: .7, text: '99$', tsize: .3, anim: 'jelly' } },
    { id: 'place', name: 'مكان', set: { shape: 'pill', w: .5, h: .07, x: .5, y: .2, blur: .35, tintA: .1, text: '📍 القاهرة', tsize: .45, anim: 'drop', outAnim: 'rise' } },
    { id: 'star3d', name: 'نجمة 3D', set: { shape: 'star5', w: .42, h: .42, x: .5, y: .45, blur: .3, refr: .8, depth: .8, spec: 1.1, tint: '#ffd27a', tintA: .18, anim: 'from', ox: .5, oy: 1.05 , spin3d: .5 } },
    { id: 'moon3d', name: 'قمر', set: { shape: 'moon', w: .4, h: .4, x: .65, y: .25, blur: .35, refr: .7, depth: .7, spec: 1, tint: '#cfe3ff', tintA: .12, anim: 'spin', ox: 1.05, oy: .05 , spin3d: .5 } },
    { id: 'heart3d', name: 'قلب', set: { shape: 'heart', w: .38, h: .38, x: .5, y: .45, blur: .3, refr: .8, depth: .7, tint: '#ff4d7d', tintA: .25, anim: 'from', ox: .5, oy: 1.1 , spin3d: .5 } },
    { id: 'orb', name: 'كورة زجاج', set: { shape: 'circle', w: .45, x: .5, y: .45, blur: .05, refr: 1.1, mag: .8, edge: .9, chroma: .4, depth: .5, spec: 1.3, anim: 'from', ox: 0, oy: 1 } },
    { id: 'ring', name: 'حلقة', set: { shape: 'ring', w: .5, h: .5, x: .5, y: .45, blur: .3, refr: .7, depth: .6, anim: 'spin', ox: .5, oy: .5 , spin3d: .5 } },
    { id: 'bubble', name: 'فقاعة كلام', set: { shape: 'bubble', w: .6, h: .6, x: .55, y: .3, blur: .45, depth: .4, text: 'أهلاً!', tsize: .22, anim: 'from', ox: .2, oy: .6 } },
    { id: 'cloud', name: 'سحابة', set: { shape: 'cloud', w: .6, h: .6, x: .5, y: .25, blur: .55, depth: .5, tint: '#ffffff', tintA: .12, anim: 'from', ox: -.1, oy: .2 , spin3d: .5 } },
    { id: 'bolt', name: 'برق', set: { shape: 'bolt', w: .32, h: .32, x: .7, y: .3, blur: .25, refr: .9, depth: .8, tint: '#f2c26b', tintA: .3, anim: 'spin', ox: 1.1, oy: -.1 , spin3d: .5 } },
    { id: 'corner', name: 'شكل الركن', set: { shape: 'rect', w: .7, h: .3, radius: .45, x: .85, y: .78, blur: .5, refr: .5, depth: .3, anim: 'from', ox: 1.3, oy: .78 } },
    { id: 'lens', name: 'عدسة واضحة', set: { shape: 'rect', w: .6, h: .3, radius: .3, x: .5, y: .5, blur: 0, refr: .75, mag: .5, chroma: .5, text: '', anim: 'fade' } }
  ];
  var ANIMS = { from: 'طالع من نقطة', spin: 'طالع من نقطة وبيلف', jelly: 'جيلي', island: 'يتمد زي الآيلاند', drop: 'نازل من فوق', rise: 'طالع من تحت', pop: 'بوب', fade: 'يظهر بهدوء', none: 'من غير' };
  var OUTA = { shrink: 'يصغر', island: 'يتلم', fade: 'يختفي', rise: 'يطلع لفوق', drop: 'ينزل لتحت', none: 'من غير' };
  var S = (function () { var o = {}, k, v = st.get('set', {}); for (k in DEF) o[k] = DEF[k]; for (k in v) o[k] = v[k]; return o; })();
  function save() { st.set('set', S); }

  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function outCubic(x) { x = clamp(x, 0, 1); return 1 - Math.pow(1 - x, 3); }
  function outBack(x) { x = clamp(x, 0, 1); var c = 1.7; return 1 + (c + 1) * Math.pow(x - 1, 3) + c * Math.pow(x - 1, 2); }

  /* geometry at time t: center, half sizes, radius, alpha */
  function geo(s, W, H, t) {
    var bw = s.w * W, bh = (s.shape === 'circle' ? s.w : s.h) * W, r = s.shape === 'pill' || s.shape === 'circle' ? Math.min(bw, bh) / 2 : s.radius * Math.min(bw, bh);
    var cx = s.x * W, cy = s.y * H, sx = 1, sy = 1, a = 1, dur = Math.max(.3, s.dur), rot = 0;
    if (SHAPES[s.shape] && SHAPES[s.shape].kind !== 0) { bh = (s.h / s.w) * bw * (s.lockAspect === false ? 1 : 0) + (s.lockAspect === false ? 0 : bw); r = s.radius * Math.min(bw, bh) * .25; }
    var pi = s.anim === 'none' ? 1 : clamp(t / Math.max(.05, s.inDur), 0, 1), po = s.outAnim === 'none' ? 1 : clamp((dur - t) / Math.max(.05, s.outDur), 0, 1);
    function jelly(p) { var k = Math.exp(-5 * p) * Math.sin(p * 18); return [1 + k * .12, 1 - k * .12]; }
    switch (s.anim) {
      case 'jelly': { var e = outBack(pi), j = jelly(pi); sx = e * j[0]; sy = e * j[1]; a = clamp(pi * 4, 0, 1); break; }
      case 'island': { var e2 = outBack(pi); sx = (bh / bw) + (1 - bh / bw) * e2; var j2 = jelly(pi); sy = j2[1]; a = clamp(pi * 5, 0, 1); break; }
      case 'drop': { cy -= (1 - outBack(pi)) * (cy + bh); a = clamp(pi * 3, 0, 1); break; }
      case 'rise': { cy += (1 - outCubic(pi)) * bh * 1.4; a = outCubic(pi); var j3 = jelly(pi); sx *= j3[0]; sy *= j3[1]; break; }
      case 'pop': { var e3 = outBack(pi); sx = sy = e3; a = clamp(pi * 4, 0, 1); break; }
      case 'fade': { a = outCubic(pi); break; }
      case 'from': case 'spin': {   // flies out of the point the editor picked
        var e4 = outBack(pi), ox = (s.ox !== undefined ? s.ox : .5) * W, oy = (s.oy !== undefined ? s.oy : 1.1) * H;
        cx = ox + (cx - ox) * outCubic(pi); cy = oy + (cy - oy) * outCubic(pi); sx = sy = .08 + .92 * e4; a = clamp(pi * 3, 0, 1);
        if (s.anim === 'spin') rot = (1 - outCubic(pi)) * -260;
        var j4 = jelly(pi); sx *= j4[0]; sy *= j4[1]; break;
      }
    }
    switch (s.outAnim) {
      case 'shrink': { var q = outCubic(po); sx *= .5 + .5 * q; sy *= .5 + .5 * q; a *= po; break; }
      case 'island': { var q2 = outCubic(po); sx *= (bh / bw) + (1 - bh / bw) * q2; a *= clamp(po * 3, 0, 1); break; }
      case 'fade': a *= po; break;
      case 'rise': cy -= (1 - outCubic(po)) * bh * 1.5; a *= po; break;
      case 'drop': cy += (1 - outCubic(po)) * bh * 1.5; a *= po; break;
    }
    var hw = Math.max(1, bw * sx / 2), hh = Math.max(1, bh * sy / 2);
    if (s.spinLoop) rot += t * s.spinLoop * 30;
    var yaw; if (s.spin3d > 0) { var turns = Math.max(1, Math.round(s.spin3d * dur)); yaw = 2 * Math.PI * turns * clamp(t, 0, dur) / dur; }
    return { cx: cx, cy: cy, hw: hw, hh: hh, r: Math.min(r * Math.min(sx, sy) + 0 * hh, hw, hh), a: a, rot: rot, yaw: yaw, textA: clamp((pi - .45) / .4, 0, 1) * po };
  }

  /* everything on one 2D canvas: glass + text */
  function compose(ctx, R, s, W, H, t) {
    var g = geo(s, W, H, t);
    ctx.clearRect(0, 0, W, H);
    if (g.a <= .002) return;
    R.draw(W, H, g, s, g.a);
    ctx.drawImage(R.canvas, 0, 0);
    if (s.text && g.textA > .01) {
      var px = Math.max(6, g.hh * 2 * s.tsize);
      ctx.save(); ctx.globalAlpha = g.textA;
      ctx.font = s.weight + ' ' + px + 'px "' + s.font + '", "Segoe UI", Tahoma, Arial, sans-serif';
      ctx.fillStyle = s.tcolor; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.direction = /[֐-ࣿ]/.test(s.text) ? 'rtl' : 'ltr';
      ctx.shadowColor = 'rgba(0,0,0,.25)'; ctx.shadowBlur = px * .15;
      if (g.yaw !== undefined) { var cyw = Math.cos(g.yaw); ctx.translate(g.cx, 0); ctx.scale(Math.max(Math.abs(cyw), .03) * (cyw < 0 ? -1 : 1), 1); ctx.translate(-g.cx, 0); }
      ctx.beginPath(); ctx.rect(g.cx - g.hw, g.cy - g.hh, g.hw * 2, g.hh * 2); ctx.clip();
      /* first line is the title, the rest are a smaller subtitle */
      var lines = String(s.text).split('\n'), sub = .68, hs = lines.map(function (l, i) { return (i ? px * sub : px) * 1.18; }), tot = hs.reduce(function (a, b) { return a + b; }, 0), y = g.cy - tot / 2;
      lines.forEach(function (ln, i) {
        if (i === 1) { ctx.font = Math.max(400, s.weight - 200) + ' ' + px * sub + 'px "' + s.font + '", "Segoe UI", Tahoma, Arial, sans-serif'; ctx.globalAlpha = g.textA * .82; }
        ctx.fillText(ln, g.cx, y + hs[i] / 2); y += hs[i];
      });
      ctx.restore();
    }
  }

  /* the clip under the playhead drawn the way it sits in the sequence */
  function drawClip(ctx, img, clip, W, H, srcW, srcH) {
    var k = (clip.scale || 100) / 100, P = clip.pos || [.5, .5], A = clip.anchor || [.5, .5];
    var dw = srcW * k, dh = srcH * k;
    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, H);
    ctx.drawImage(img, P[0] * W - A[0] * dw, P[1] * H - A[1] * dh, dw, dh);
  }

  /* m = the glass clip's Motion in Premiere ({k, P, A}); the glass is drawn in its own (unmoved) frame,
     so the picture behind it is pulled through the inverse of that move */
  var scrCv = null;
  function bgLocal(bgx, img, info, W, H, srcW, srcH, m) {
    if (!m || (Math.abs(m.k - 1) < 1e-4 && Math.abs(m.P[0] - m.A[0]) < 1e-4 && Math.abs(m.P[1] - m.A[1]) < 1e-4)) { drawClip(bgx, img, info, W, H, srcW, srcH); return; }
    if (!scrCv) scrCv = G.document.createElement('canvas');
    if (scrCv.width !== W || scrCv.height !== H) { scrCv.width = W; scrCv.height = H; }
    drawClip(scrCv.getContext('2d'), img, info, W, H, srcW, srcH);
    bgx.setTransform(1, 0, 0, 1, 0, 0); bgx.fillStyle = '#000'; bgx.fillRect(0, 0, W, H);
    bgx.setTransform(1 / m.k, 0, 0, 1 / m.k, m.A[0] * W - m.P[0] * W / m.k, m.A[1] * H - m.P[1] * H / m.k);
    bgx.drawImage(scrCv, 0, 0); bgx.setTransform(1, 0, 0, 1, 0, 0);
  }

  /* ---------------- tab ---------------- */
  var ui = {}, ctl = {}, R = null, seq = { w: 1080, h: 1920 }, under = null, clock = { on: false, t: 1.2, last: 0 }, raf = 0, busy = false, stopReq = false, lastPlaced = st.get('last', null);
  var bgCv = null;
  function fit() {
    var w = Math.max(160, ui.wrap.clientWidth || 300), ar = seq.w / seq.h, hh = Math.min(K.pvH(440), w / ar), ww = hh * ar;
    ui.stage.style.width = Math.round(ww) + 'px'; ui.stage.style.height = Math.round(hh) + 'px';
    var dpr = Math.min(2, G.devicePixelRatio || 1);
    ui.cv.width = Math.round(ww * dpr); ui.cv.height = Math.round(hh * dpr);
    refreshBg(); draw();
  }
  function refreshBg() {
    if (!R) return;
    var W = ui.cv.width, H = ui.cv.height;
    if (!bgCv) bgCv = G.document.createElement('canvas');
    bgCv.width = W; bgCv.height = H;
    var x = bgCv.getContext('2d');
    if (under && under.img) { drawClip(x, under.img, under.clip, W, H, under.srcW * W / seq.w, under.srcH * W / seq.w); R.setBg(bgCv); }
    else {
      // no picture yet: plain black behind the glass
      x.fillStyle = '#000'; x.fillRect(0, 0, W, H);
      R.setBg(bgCv);
    }
    ui.bgImg.src = bgCv.toDataURL('image/jpeg', .8);
  }
  function draw() { if (!raf) raf = (G.requestAnimationFrame || setTimeout)(paint); }
  function paint() {
    raf = 0; if (!R) return;
    var now = Date.now();
    if (clock.on) { clock.t += Math.min(.1, (now - (clock.last || now)) / 1000); clock.last = now; if (clock.t > S.dur + .3) clock.t = 0; }
    var x = ui.cv.getContext('2d');
    // preview sizes are relative to the preview width, like the real frame
    compose(x, R, S, ui.cv.width, ui.cv.height, Math.min(clock.t, S.dur));
    ui.scrub.max = String(S.dur); ui.scrub.value = String(Math.min(clock.t, S.dur));
    ui.time.textContent = Math.min(clock.t, S.dur).toFixed(1) + ' / ' + (+S.dur).toFixed(1) + 's';
    if (clock.on) draw();
  }
  function play(on) { clock.on = on; clock.last = Date.now(); ui.play.innerHTML = K.ICON[on ? 'stop' : 'play']; draw(); }
  function grabUnder() {
    ui.status.show('busy', 'بجيب الفريم…');
    return Sys.call('cr_under2').then(function (r) {
      if (!r || !r.ok) throw new Error('افتح سيكوينس الأول.');
      if (r.w) seq = { w: r.w, h: r.h };
      if (r.none || !r.clip) { under = null; ui.status.show('warn', 'مفيش فيديو تحت المؤشر — الجلاس هيبقى من غير انكسار للصورة.'); fit(); return; }
      var c = r.clip;
      return Sys.probe(c.path).then(function (info) {
        var big = Math.max(info.w, info.h), dw = Math.round(info.w * 960 / big / 2) * 2, dh = Math.round(info.h * 960 / big / 2) * 2;
        return Sys.grabFrame(c.path, c.src, dw, dh).then(function (p) {
          return new Promise(function (res) { var im = new Image(); im.onload = function () { res(im); }; im.onerror = function () { res(null); }; im.src = Sys.url(p); });
        }).then(function (im) { under = { img: im, clip: c, srcW: info.w, srcH: info.h }; ui.status.show(c.keyed ? 'warn' : '', c.keyed ? 'الكليب ده عليه حركة/زووم — الانكسار هيتحسب على أول وضع ليه.' : ''); fit(); });
      });
    }).catch(function (e) { ui.status.show('err', e.message || String(e)); });
  }
  function bindDrag() {
    var d = null;
    ui.cv.addEventListener('pointerdown', function (e) {
      var r = ui.cv.getBoundingClientRect();
      if (ui.picking) { ui.picking = false; var px = (e.clientX - r.left) / r.width, py = (e.clientY - r.top) / r.height;
        /* near an edge = from outside the frame */
        if (px < .06) px = -.15; if (px > .94) px = 1.15; if (py < .06) py = -.15; if (py > .94) py = 1.15;
        set({ ox: px, oy: py, anim: S.anim === 'from' || S.anim === 'spin' ? S.anim : 'from' }); if (ctl.anim && ctl.anim.setValue) ctl.anim.setValue(S.anim); ui.status.show('ok', 'تمام — هيطلع من هنا.'); clock.t = 0; play(true); return; }
      try { ui.cv.setPointerCapture(e.pointerId); } catch (x) {} d = { x: e.clientX, y: e.clientY, sx: S.x, sy: S.y, w: r.width, h: r.height }; });
    ui.cv.addEventListener('pointermove', function (e) {
      if (!d) return; var nx = d.sx + (e.clientX - d.x) / d.w, ny = d.sy + (e.clientY - d.y) / d.h;
      if (Math.abs(nx - .5) < .012) nx = .5; S.x = clamp(nx, -.2, 1.2); S.y = clamp(ny, -.2, 1.2); draw();
    });
    function end() { if (d) { d = null; save(); liveKick(); } }
    ui.cv.addEventListener('pointerup', end); ui.cv.addEventListener('pointercancel', end);
    ui.cv.addEventListener('wheel', function (e) { e.preventDefault(); var f = Math.pow(1.0012, -e.deltaY); S.w = clamp(S.w * f, .05, 1.2); S.h = clamp(S.h * f, .03, 1.5); save(); syncAll(); }, { passive: false });
  }
  function set(p) { for (var k in p) S[k] = p[k]; save(); draw(); liveKick(); }
  function sl(k, label, min, max, step, fmt) { var c = K.slider({ label: label, min: min, max: max, step: step, value: S[k], fmt: fmt, onInput: function (v) { var p = {}; p[k] = v; set(p); } }); ctl[k] = c; return c; }
  function col(k, label) { var inp = h('input', { type: 'color', value: S[k] }); inp.addEventListener('input', function () { var p = {}; p[k] = inp.value; set(p); }); var l = h('label', { class: 'cfield' }, [inp, h('span', { text: label })]); l.setValue = function (v) { inp.value = v; }; ctl[k] = l; return l; }
  function sel(k, map) { var s = h('select', { class: 'sel' }, Object.keys(map).map(function (v) { return h('option', { value: v, text: map[v] }); })); s.value = S[k]; s.addEventListener('change', function () { var p = {}; p[k] = s.value; set(p); }); s.setValue = function (v) { s.value = v; }; ctl[k] = s; return s; }
  function pct(v) { return Math.round(v * 100) + '%'; }
  function sec(v) { return (+v).toFixed(1) + ' ث'; }
  function syncAll() { Object.keys(ctl).forEach(function (k) { if (ctl[k].setValue && S[k] !== undefined) ctl[k].setValue(S[k]); }); ui.text.value = S.text; Fonts.ensure(S.font, +S.weight).then(draw); draw(); }

  /* render a glass with settings SS; opts: { at (sequence s), replace: [names] } */
  function glassJob(SS, opts) {
    var out = G.document.createElement('canvas'), ox, RR = null, frameDir = null, info = null, srcW = 0, srcH = 0, bg = G.document.createElement('canvas');
    return {
      prefix: 'ENP_Glass', bin: 'ENP Glass', dur: SS.dur, at: opts.at, replace: opts.replace || [], w: opts.w, h: opts.h, fps: opts.fps, dir: opts.dir,
      prepare: function (o) {
        if (o.t === undefined) o.t = opts.at;
        out.width = o.w; out.height = o.h; ox = out.getContext('2d'); bg.width = o.w; bg.height = o.h; RR = Renderer();
        // the picture under the glass at the time it starts (not wherever the playhead is)
        return Fonts.ensure(SS.font, +SS.weight).then(function () { return Sys.call('cr_under2', { t: o.t }); }).then(function (r) {
          if (!r || !r.ok || r.none || !r.clip) return;
          info = r.clip;
          return Sys.probe(info.path).then(function (pi) {
            srcW = pi.w; srcH = pi.h;
            ui.status.show('busy', 'بجهّز فريمات الفيديو…');
            return Sys.clipFrames(info.path, info.src, SS.dur, o.fps, 1920).then(function (d) { frameDir = d; });
          });
        });
      },
      frame: function (t, i, o) {
        var go = function () { compose(ox, RR, SS, o.w, o.h, t); return ox.getImageData(0, 0, o.w, o.h).data; };
        if (!frameDir) { RR.setBg(null); return go(); }
        return new Promise(function (res) {
          var im = new Image();
          im.onload = function () { bgLocal(bg.getContext('2d'), im, info, o.w, o.h, srcW, srcH, opts.motion); RR.setBg(bg); res(go()); };
          im.onerror = function () { res(go()); };
          im.src = Sys.url(Sys.join(frameDir, ('0000' + (i + 1)).slice(-5) + '.jpg'));
        });
      },
      onProgress: opts.onProgress || function (p) { ui.prog.set(p); ui.status.show('busy', 'برسم الجلاس… ' + Math.round(p * 100) + '%'); },
      cancelled: opts.cancelled || function () { return stopReq; }
    };
  }
  function renderGlass(SS, opts) {
    busy = true; stopReq = false; ui.place.disabled = true; ui.relocate.disabled = true; K.show(ui.stop, true); play(false);
    return Out.renderAndPlace(glassJob(SS, opts)).then(function (r) {
      lastPlaced = { names: r.names }; st.set('last', lastPlaced); K.show(ui.remove, true);
      link = { name: r.names[0], sig: '' }; st.set('link', link); liveBadge();
      var made = st.get('renders', {}); r.names.forEach(function (n) { made[n] = JSON.parse(JSON.stringify(SS)); });
      var keys = Object.keys(made); if (keys.length > 60) keys.slice(0, keys.length - 60).forEach(function (k) { delete made[k]; });
      st.set('renders', made);
      return r;
    }).then(function (r) { ui.status.show('ok', 'اتحط على ' + r.track + ' عند ' + K.tc(r.at, r.fps) + ' · خد ' + (r.ms / 1000).toFixed(1) + ' ث'); }, function (e) { ui.status.show(e && e.message === 'cancelled' ? 'warn' : 'err', Out.errText(e)); })
      .then(function () { busy = false; ui.place.disabled = false; ui.relocate.disabled = false; K.show(ui.stop, false); ui.prog.done(); });
  }
  function placeIt() {
    if (busy) return;
    renderGlass(S, { replace: st.get('replace', false) && lastPlaced ? lastPlaced.names : [] });
  }
  /* the glass was moved / resized in Premiere: draw it again where it is now,
     so it bends what's really under its new place */
  function relocate() {
    if (busy) return;
    ui.status.show('busy', 'بدوّر على الجلاس…');
    Sys.call('cr_clips', { fallback: false }).then(function (r) {
      var pick = r && r.ok ? r.clips.filter(function (c) { return /^ENP_Glass_/.test(c.name); })[0] : null;
      if (pick) return pick;
      if (!lastPlaced) return null;
      return Sys.call('cr_findNamed', { names: lastPlaced.names }).then(function (x) { return x && x.ok ? x.clip : null; });
    }).then(function (c) {
      if (!c) throw new Error('اختار الجلاس في التايملاين الأول.');
      return Sys.call('cr_info').then(function (inf) {
        var W = inf.w || seq.w, H = inf.h || seq.h, made = st.get('renders', {}), base = made[c.name] || S;
        var SS = JSON.parse(JSON.stringify(base));
        var k = (c.scale || 100) / 100, P = c.pos || [.5, .5], A = c.anchor || [.5, .5];
        // where the glass centre ended up on screen after Premiere's Position / Scale
        var cx = P[0] * W + (SS.x * W - A[0] * W) * k, cy = P[1] * H + (SS.y * H - A[1] * H) * k;
        SS.x = cx / W; SS.y = cy / H; SS.w = SS.w * k; SS.h = SS.h * k;
        SS.dur = Math.max(.3, Math.min(SS.dur || 4, c.end - c.start + .001));
        var moved = Math.abs(SS.x - base.x) > .002 || Math.abs(SS.y - base.y) > .002 || Math.abs(k - 1) > .002;
        if (!moved) { ui.status.show('warn', 'الجلاس ده لسه في مكانه — حرّكه في بريمير (Position / Scale) الأول.'); return; }
        if (c.keyed) ui.status.show('warn', 'الجلاس عليه كيفريمز حركة — هرسمه في مكانه عند أول فريم.');
        S.x = SS.x; S.y = SS.y; S.w = SS.w; S.h = SS.h; save(); syncAll();   // the panel follows too
        return renderGlass(SS, { at: c.start, replace: [c.name] });
      });
    }).catch(function (e) { ui.status.show('err', e.message || String(e)); });
  }
  function removeLast() {
    if (!lastPlaced) return;
    Sys.call('cr_remove', { names: lastPlaced.names }).then(function (r) { if (r && r.ok) { ui.status.show('ok', 'اتشال ' + r.removed + ' من التايملاين'); lastPlaced = null; st.set('last', null); K.show(ui.remove, false); } });
  }

  /* ---------------- live: the placed glass follows the panel and its own moves ---------------- */
  var link = st.get('link', null), live = st.get('live', true), lv = { timer: 0, running: false, again: false, poll: 0, last: '' };
  function liveBadge() { if (ui.liveTag) { ui.liveTag.textContent = link ? (lv.running ? 'بيتحدّث…' : 'لايف ✓') : ''; K.show(ui.liveTag, !!(live && link)); } }
  function liveKick(delay) {
    if (!live || !link) return;
    clearTimeout(lv.timer); lv.timer = setTimeout(liveUpdate, delay || 700);
  }
  function liveUpdate() {
    if (!live || !link) return;
    if (lv.running || busy) { lv.again = true; return; }
    lv.running = true; liveBadge();
    var c = null;
    Sys.call('cr_findNamed', { names: [link.name] }).then(function (x) {
      c = x && x.ok ? x.clip : null;
      if (!c) { link = null; st.set('link', null); throw new Error('gone'); }
      return Sys.call('cr_info');
    }).then(function (inf) {
      var SS = JSON.parse(JSON.stringify(S)); SS.dur = Math.max(.3, c.end - c.start);
      var m = { k: (c.scale || 100) / 100, P: c.pos || [.5, .5], A: c.anchor || [.5, .5] };
      lv.last = sig(c);
      var dir = inf && inf.dir ? Sys.join(inf.dir, 'ENP Renders') : Sys.join(Sys.workDir(), 'renders');
      return Out.renderFile(glassJob(SS, { at: c.start, w: inf.w, h: inf.h, fps: inf.fps, dir: dir, motion: m, onProgress: function () {}, cancelled: function () { return false; } }))
        .then(function (f) { return Sys.call('cr_swapMedia', { name: link.name, path: f.path }).then(function (r) { if (!r || !r.ok) throw new Error('swap ' + (r && (r.error || r.detail))); if (link.file && link.file !== f.path) Sys.remove(link.file); link.file = f.path; st.set('link', link); }); });
    }).then(function () { if (c && c.keyed) ui.status.show('warn', 'الجلاس عليه كيفريمز حركة — الانكسار بيتحسب على أول وضع ليه.'); })
      .catch(function (e) { if (e && e.message !== 'gone') ui.status.show('warn', 'التحديث اللايف ماكملش [' + (e.message || e) + ']'); })
      .then(function () { lv.running = false; liveBadge(); if (lv.again) { lv.again = false; liveKick(200); } });
  }
  function sig(c) { return [c.start, c.end, c.scale, (c.pos || []).join(','), (c.anchor || []).join(',')].map(function (v) { return typeof v === 'number' ? v.toFixed(4) : String(v); }).join('|'); }
  /* watch the placed glass: moved / scaled / trimmed in Premiere -> draw it again */
  function livePoll() {
    if (!live || !link || lv.running || busy) return;
    Sys.call('cr_findNamed', { names: [link.name] }).then(function (x) {
      var c = x && x.ok ? x.clip : null; if (!c) return;
      var s2 = sig(c); if (!lv.last) { lv.last = s2; return; }
      if (s2 !== lv.last) { lv.last = s2; liveKick(400); }
    });
  }
  function build(root) {
    try { R = Renderer(); } catch (e) { root.appendChild(h('div', { class: 'notice', text: 'كارت الشاشة مش متاح للبانل.' })); return; }
    ui.cv = h('canvas', { class: 'glcv' }); ui.bgImg = h('img', { class: 'under', alt: '', style: 'opacity:1' });
    ui.stage = h('div', { class: 'stage' }, [ui.bgImg, ui.cv]); ui.wrap = h('div', { class: 'pvwrap' }, [ui.stage]);
    ui.play = h('button', { type: 'button', class: 'ibtn', html: K.ICON.play, onclick: function () { if (!clock.on && clock.t >= S.dur) clock.t = 0; play(!clock.on); } });
    ui.scrub = h('input', { type: 'range', class: 'scrub', min: 0, max: S.dur, step: .01, value: clock.t });
    ui.scrub.addEventListener('input', function () { clock.t = parseFloat(ui.scrub.value) || 0; if (clock.on) play(false); draw(); });
    ui.time = h('span', { class: 'time' });
    bindDrag();
    ui.status = K.status(); ui.prog = K.progress();
    var presets = h('div', { class: 'chips' });
    function isShape(k) { return SHAPES[k] && SHAPES[k].kind !== 0; }
    PRESETS.forEach(function (p) {
      presets.appendChild(h('button', { type: 'button', class: 'chip', 'data-m': isShape(p.set.shape) || p.id === 'orb' ? 'shapes' : 'glass', text: p.name, onclick: function () {
        var keep = { tint: S.tint, font: S.font, weight: S.weight, tcolor: S.tcolor, dur: S.dur };
        S = {}; var k; for (k in DEF) S[k] = DEF[k]; for (k in keep) S[k] = keep[k]; for (k in p.set) S[k] = p.set[k];
        save(); syncAll(); clock.t = 0; play(true);
      } }));
    });
    ui.text = h('textarea', { class: 'txin', dir: 'auto', rows: '2', placeholder: 'نص جوه الجلاس (اختياري)' }); ui.text.value = S.text;
    ui.text.addEventListener('input', function () { S.text = ui.text.value; save(); draw(); liveKick(); });
    var picker = Fonts.picker({ value: S.font, onChange: function (f) { S.font = f; save(); Fonts.ensure(f, +S.weight).then(draw); } });
    ui.place = K.btn('حطه على التايملاين', { cls: 'pri', icon: 'spark', onClick: placeIt });
    ui.stop = K.btn('وقّف', { icon: 'stop', onClick: function () { stopReq = true; } }); K.show(ui.stop, false);
    ui.remove = K.btn('شيل آخر جلاس', { cls: 'ghost', icon: 'undo', onClick: removeLast }); K.show(ui.remove, !!lastPlaced);
    ui.relocate = K.btn('ارسمه في مكانه الجديد', { icon: 'refresh', onClick: relocate });
    ui.liveTag = h('span', { class: 'livebadge' });
    var shapeSeg = h('div', { class: 'chips' }); shapeSeg.setValue = function (v) { [].forEach.call(shapeSeg.children, function (b) { b.classList.toggle('on', b.getAttribute('data-v') === v); }); };
    Object.keys(SHAPES).forEach(function (k) { shapeSeg.appendChild(h('button', { type: 'button', class: 'chip', 'data-v': k, 'data-m': isShape(k) ? 'shapes' : 'glass', text: SHAPES[k].name, onclick: function () {
      var p = { shape: k };
      if (isShape(k) && !isShape(S.shape)) { p.depth = S.depth || .7; p.spin3d = S.spin3d || .5; p.h = S.w; }   // a 3D shape: give it thickness and the loop spin
      set(p); syncAll(); shapeSeg.setValue(k); } })); });
    shapeSeg.setValue(S.shape); ctl.shape = shapeSeg;
    var mode = st.get('mode', isShape(S.shape) ? 'shapes' : 'glass');
    function applyMode(m) {
      mode = m; st.set('mode', m);
      [presets, shapeSeg].forEach(function (box) { [].forEach.call(box.children, function (b) { K.show(b, b.getAttribute('data-m') === m); }); });
      if (ui.sec3d) { K.show(ui.sec3d, m === 'shapes'); K.show(ui.hRow, m === 'glass'); K.show(ui.radRow, m === 'glass'); }
    }
    ui.modeSeg = K.seg({ items: [{ v: 'glass', label: 'زجاج ونصوص' }, { v: 'shapes', label: 'أشكال 3D' }], value: mode, onChange: applyMode });
    ui.modeSeg.style.marginBottom = '8px';
    ui.pickO = K.btn('حدد النقطة اللي هيطلع منها', { icon: 'target', onClick: function () { ui.picking = true; ui.status.show('ok', 'دوس على المعاينة في المكان اللي الشكل هيطلع منه (ممكن برا الكادر من الأطراف).'); } });

    [h('div', { class: 'hint intro', text: 'زجاج سايل زي أبل: بيكسر ويغبّش الفيديو اللي تحته بجد. دوس «هات الفريم» عشان تشوفه على الفيديو بتاعك، واسحبه في المعاينة، والعجلة بتكبّره.' }),
      h('div', { class: 'pv' }, [ui.wrap, h('div', { class: 'bar' }, [ui.play, ui.scrub, ui.time]),
        h('div', { class: 'adds', style: 'margin-top:8px' }, [K.btn('هات الفريم اللي تحت المؤشر', { icon: 'target', onClick: grabUnder })])]),
      ui.modeSeg,
      K.section('جاهز', [presets], true, 'gl_pre'),
      K.section('الشكل والمكان', [K.field('', shapeSeg), sl('w', 'العرض', .05, 1.2, .005, pct), ui.hRow = sl('h', 'الارتفاع', .03, 1.5, .005, pct), ui.radRow = sl('radius', 'دوران الزوايا', 0, .5, .01, pct),
        sl('x', 'يمين وشمال', 0, 1, .005, pct), sl('y', 'فوق وتحت', 0, 1, .005, pct), sl('rot', 'ميل', -180, 180, 1, function (v) { return Math.round(v) + '°'; })], true, 'gl_shape'),
      ui.sec3d = K.section('3D واللف', [sl('depth', 'سُمك 3D', 0, 1, .01, pct),
        sl('spin3d', 'لفة 3D حوالين نفسه (لفّة/ثانية)', 0, 2, .05, function (v) { return v > 0 ? v.toFixed(2) : 'مقفول'; }),
        h('div', { class: 'hint', text: 'اللفة 3D بتدور 360° حوالين نفسها طول مدة الظهور ولووب نضيف — عدد اللفات بيتظبط عشان آخر فريم يقفل على أول فريم.' }),
        sl('spinLoop', 'لف مسطّح على طول', -6, 6, .1, function (v) { return v.toFixed(1); })], true, 'gl_3d'),
      K.section('الزجاج', [sl('blur', 'تغبيش (فروستد)', 0, 1, .01, pct), sl('refr', 'انكسار الحواف', 0, 1.5, .01, pct), sl('edge', 'عرض الحافة', .05, 1, .01, pct),
        sl('mag', 'تكبير العدسة', 0, 1, .01, pct), sl('chroma', 'ألوان قوس قزح على الحافة', 0, 1, .01, pct), sl('spec', 'لمعة', 0, 1.5, .01, pct),
        sl('sat', 'تشبّع الألوان', 0, 2, .01, function (v) { return v.toFixed(2); }), sl('bright', 'إضاءة', .5, 1.6, .01, function (v) { return v.toFixed(2); }),
        h('div', { class: 'crow' }, [col('tint', 'لون الزجاج')]), sl('tintA', 'قوة اللون', 0, 1, .01, pct), sl('shadow', 'ظل', 0, 1, .01, pct)], false, 'gl_glass'),
      K.section('نص جوه الجلاس', [ui.text, K.field('الخط', picker), sl('tsize', 'حجم النص', .1, .9, .01, pct), h('div', { class: 'crow' }, [col('tcolor', 'لون النص')])], false, 'gl_text'),
      K.section('الحركة', [sl('dur', 'المدة', 1, 20, .1, sec), K.field('الدخول', sel('anim', ANIMS)), h('div', { class: 'adds' }, [ui.pickO]), sl('inDur', 'مدة الدخول', .1, 2.5, .05, sec),
        K.field('الخروج', sel('outAnim', OUTA)), sl('outDur', 'مدة الخروج', .1, 2.5, .05, sec)], false, 'gl_anim'),
      h('div', { class: 'out' }, [h('div', { class: 'hint', text: 'الجلاس بيترندر فوق الكليب اللي تحت المؤشر — لو غيّرت الكليب أو حرّكته اعمله تاني.' }),
        K.toggle('بدّل آخر جلاس حطيته', st.get('replace', false), function (v) { st.set('replace', v); }),
        K.toggle('لايف: أي تعديل هنا أو تحريك في بريمير يتطبق على الجلاس اللي على التايملاين', live, function (v) { live = v; st.set('live', v); liveBadge(); if (v) liveKick(100); }),
        h('div', { style: 'margin-top:10px' }, [ui.place, ui.liveTag]),
        h('div', { class: 'cam' }, [h('div', { text: 'حرّكته أو كبّرته في بريمير؟' }),
          h('div', { class: 'hint', text: 'الجلاس بيترسم على الصورة اللي تحته وقت الرسم. لو نقلته بـ Position أو Scale في بريمير، اختاره في التايملاين ودوس الزرار ده — هيترسم من جديد على اللي تحته في المكان الجديد ويتحط مكان القديم.' }),
          h('div', { class: 'adds', style: 'margin-top:6px' }, [ui.relocate])]),
        h('div', { class: 'tk' }, [ui.stop, ui.remove]), ui.prog, ui.status])
    ].forEach(function (el) { root.appendChild(el); });
    applyMode(mode);
    G.addEventListener('resize', fit);
    Sys.call('cr_info').then(function (r) { if (r && r.ok && r.hasSequence && r.w) { seq = { w: r.w, h: r.h }; fit(); } });
    fit(); Fonts.ensure(S.font, +S.weight).then(draw); liveBadge();
    if (!lv.poll) lv.poll = setInterval(livePoll, 1500);
  }

  G.GlassTab = { build: build, onHide: function () { if (clock.on) play(false); }, _Renderer: Renderer, _compose: compose, _S: function () { return S; } };
})(window);
