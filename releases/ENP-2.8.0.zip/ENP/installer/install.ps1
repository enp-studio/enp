# ENP - installer for Adobe Premiere Pro (no admin rights needed)
$ErrorActionPreference = 'Stop'
$src = Join-Path $PSScriptRoot 'ENP'
$root = Join-Path $env:APPDATA 'Adobe\CEP\extensions'
$dst = Join-Path $root 'ENP'
Write-Host ''
Write-Host '   ENP - Editing Power Tools for Premiere Pro' -ForegroundColor Magenta
Write-Host '   ---------------------------------------------'
if (-not (Test-Path (Join-Path $src 'CSXS\manifest.xml'))) { Write-Host '   Unzip everything first, then run this again.' -ForegroundColor Red; pause; exit 1 }
New-Item -ItemType Directory -Force -Path $root | Out-Null

# keep an ffmpeg we already have
$keep = $null
foreach ($c in @((Join-Path $dst 'runtime\ffmpeg.exe'), (Join-Path $root 'Carousel3D\runtime\ffmpeg.exe'))) { if (-not $keep -and (Test-Path $c)) { $keep = Join-Path $env:TEMP 'enp-ffmpeg.exe'; Copy-Item $c $keep -Force } }

Write-Host '   [1/3] Installing the panel...'
if (Test-Path $dst) { Get-ChildItem $dst -Force | Where-Object { $_.Name -ne '_backup' } | Remove-Item -Recurse -Force }
New-Item -ItemType Directory -Force -Path $dst | Out-Null
Copy-Item -Path (Join-Path $src '*') -Destination $dst -Recurse -Force
New-Item -ItemType Directory -Force -Path (Join-Path $dst 'runtime') | Out-Null
if ($keep) { Copy-Item $keep (Join-Path $dst 'runtime\ffmpeg.exe') -Force; Remove-Item $keep -Force }
# the old test build of this panel
$old = Join-Path $root 'Carousel3D'; if (Test-Path $old) { Remove-Item $old -Recurse -Force -ErrorAction SilentlyContinue }

Write-Host '   [2/3] Allowing the panel to load...'
foreach ($v in 9..14) {
  $k = "HKCU:\Software\Adobe\CSXS.$v"
  if (-not (Test-Path $k)) { New-Item -Path $k -Force | Out-Null }
  New-ItemProperty -Path $k -Name 'PlayerDebugMode' -Value '1' -PropertyType String -Force | Out-Null
}

Write-Host '   [3/3] ffmpeg...'
$ff = Join-Path $dst 'runtime\ffmpeg.exe'
if (-not (Test-Path $ff)) {
  $found = Get-ChildItem -Path $root -Recurse -Filter 'ffmpeg.exe' -ErrorAction SilentlyContinue | Where-Object { $_.Length -gt 20MB -and $_.FullName -notlike "$dst*" } | Select-Object -First 1
  if (-not $found) { $cmd = Get-Command ffmpeg.exe -ErrorAction SilentlyContinue; if ($cmd) { $found = Get-Item $cmd.Source } }
  if ($found) { Copy-Item $found.FullName $ff -Force }
}
if (-not (Test-Path $ff)) {
  $zip = Join-Path $env:TEMP 'enp-ffmpeg.zip'; $tmp = Join-Path $env:TEMP 'enp-ffmpeg'
  foreach ($u in @('https://github.com/enp-studio/enp/releases/download/engine/ffmpeg-win64.zip', 'https://github.com/GyanD/codexffmpeg/releases/download/7.1/ffmpeg-7.1-essentials_build.zip', 'https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip')) {
    Write-Host "         downloading: $u"
    & curl.exe -L --fail --progress-bar --connect-timeout 20 --speed-limit 20000 --speed-time 30 --retry 2 -o $zip $u
    if ($LASTEXITCODE -eq 0 -and (Test-Path $zip)) {
      try {
        if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
        Expand-Archive -Path $zip -DestinationPath $tmp -Force
        $exe = Get-ChildItem -Path $tmp -Recurse -Filter 'ffmpeg.exe' | Select-Object -First 1
        Copy-Item $exe.FullName $ff -Force; Remove-Item $zip -Force; Remove-Item $tmp -Recurse -Force; break
      } catch { }
    }
  }
}
if (Test-Path $ff) { Write-Host '         ready.' -ForegroundColor Green } else { Write-Host "         put ffmpeg.exe in: $dst\runtime" -ForegroundColor Yellow }
Write-Host ''
Write-Host '   Installed. Restart Premiere Pro, then: Window > Extensions > ENP' -ForegroundColor Green
Write-Host ''
pause
