/* Carousel 3D — small UI kit shared by the zoom, tracking and sound tabs. */
(function (G) {
  'use strict';
  var D = G.document;
  function h(tag, attrs, kids) {
    var el = D.createElement(tag);
    for (var a in (attrs || {})) {
      var v = attrs[a];
      if (v === undefined || v === null || v === false) continue;
      if (a === 'class') el.className = v; else if (a === 'text') el.textContent = v; else if (a === 'html') el.innerHTML = v;
      else if (a.slice(0, 2) === 'on') el.addEventListener(a.slice(2), v); else el.setAttribute(a, v);
    }
    (kids || []).forEach(function (k) { if (k) el.appendChild(typeof k === 'string' ? D.createTextNode(k) : k); });
    return el;
  }
  var ICON = {
    play: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M7 4.5v15l13-7.5z"/></svg>',
    stop: '<svg viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="6" width="12" height="12" rx="1.5"/></svg>',
    star: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/></svg>',
    starF: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/></svg>',
    plus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>',
    folder: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h6l2 2h10v11H3z"/></svg>',
    refresh: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 4v7h-7"/></svg>',
    undo: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M9 14 4 9l5-5"/><path d="M4 9h10a6 6 0 0 1 0 12h-3"/></svg>',
    spark: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l2.2 6.6L21 11l-6.8 2.4L12 20l-2.2-6.6L3 11l6.8-2.4z"/></svg>',
    target: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3"/></svg>',
    x: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg>'
  };
  function store(prefix) {
    return {
      get: function (k, d) { try { var v = G.localStorage.getItem(prefix + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
      set: function (k, v) { try { G.localStorage.setItem(prefix + k, JSON.stringify(v)); } catch (e) {} }
    };
  }
  /* slider({label, min, max, step, value, fmt, onInput}) */
  function slider(o) {
    var val = h('b'), inp = h('input', { type: 'range', min: o.min, max: o.max, step: o.step });
    var box = h('div', { class: 'sld' }, [h('div', { class: 'top' }, [h('span', { text: o.label }), val]), inp]);
    var fmt = o.fmt || String;
    box.setValue = function (v) { inp.value = v; val.textContent = fmt(+v); };
    box.getValue = function () { return parseFloat(inp.value); };
    inp.addEventListener('input', function () { var v = parseFloat(inp.value); val.textContent = fmt(v); if (o.onInput) o.onInput(v); });
    box.setValue(o.value);
    return box;
  }
  /* seg({items:[{v,label}], value, onChange}) */
  function seg(o) {
    var box = h('div', { class: 'seg' });
    o.items.forEach(function (it) {
      box.appendChild(h('button', { type: 'button', 'data-v': String(it.v), text: it.label, onclick: function () { box.setValue(it.v); if (o.onChange) o.onChange(it.v); } }));
    });
    box.setValue = function (v) { box.value = v; [].forEach.call(box.children, function (b) { b.classList.toggle('on', b.getAttribute('data-v') === String(v)); }); };
    box.setValue(o.value);
    return box;
  }
  function toggle(label, val, onChange) {
    var el = h('div', { class: 'tg' + (val ? ' on' : '') }, [h('span', { text: label }), h('span', { class: 'sw' })]);
    el.value = !!val;
    el.addEventListener('click', function () { el.value = !el.value; el.classList.toggle('on', el.value); if (onChange) onChange(el.value); });
    el.setValue = function (v) { el.value = !!v; el.classList.toggle('on', el.value); };
    return el;
  }
  function btn(label, opt) {
    opt = opt || {};
    var b = h('button', { type: 'button', class: 'btn ' + (opt.cls || ''), title: opt.title, html: (opt.icon ? ICON[opt.icon] : '') + '<span></span>' });
    b.querySelector('span').textContent = label || '';
    if (opt.onClick) b.addEventListener('click', opt.onClick);
    b.setText = function (s) { b.querySelector('span').textContent = s; };
    return b;
  }
  function field(label, el) { return h('div', { class: 'field' }, [label ? h('span', { class: 'lbl', text: label }) : null, el]); }
  function section(title, kids, open, key) {
    var st = store('c3d_sec_'), box = h('div', { class: 'sec' });
    var isOpen = st.get(key || title, open !== false);
    if (!isOpen) box.classList.add('closed');
    box.appendChild(h('div', { class: 'sh', text: title, onclick: function () { box.classList.toggle('closed'); st.set(key || title, !box.classList.contains('closed')); } }));
    box.appendChild(h('div', { class: 'sb' }, kids));
    return box;
  }
  function status() {
    var el = h('div', { class: 'status' });
    el.show = function (kind, msg) { el.className = 'status ' + (kind || ''); el.textContent = msg || ''; };
    return el;
  }
  function progress() {
    var bar = h('i'), el = h('div', { class: 'prog hide' }, [bar]);
    el.set = function (p) { el.classList.remove('hide'); bar.style.width = Math.round(Math.max(0, Math.min(1, p)) * 100) + '%'; };
    el.done = function () { el.classList.add('hide'); bar.style.width = '0'; };
    return el;
  }
  function show(el, on) { if (el) el.classList.toggle('hide', !on); }
  function tc(sec, fps) {
    fps = Math.round(fps || 30); var f = Math.floor(sec * fps + 1e-6), ff = f % fps, s = Math.floor(f / fps);
    function p2(n) { return ('0' + n).slice(-2); }
    return p2(Math.floor(s / 3600)) + ':' + p2(Math.floor(s / 60) % 60) + ':' + p2(s % 60) + ':' + p2(ff);
  }
  function mmss(sec) { sec = Math.max(0, sec || 0); var m = Math.floor(sec / 60), s = sec - m * 60; return m + ':' + (s < 10 ? '0' : '') + s.toFixed(1); }
  /* run fn over a list in chunks so the panel can show progress */
  function chunks(list, size, fn, onProg) {
    var i = 0;
    function next() {
      if (i >= list.length) return Promise.resolve();
      var part = list.slice(i, i + size); i += part.length;
      return Promise.resolve(fn(part, i)).then(function () { if (onProg) onProg(i / list.length); return next(); });
    }
    return next();
  }

  function openUrl(u) {
    if (!/^https?:\/\//.test(u)) u = 'https://' + u;
    try { if (G.cep && G.cep.util && G.cep.util.openURLInDefaultBrowser) return G.cep.util.openURLInDefaultBrowser(u); } catch (e) {}
    try { var rq = (G.cep_node && G.cep_node.require) || G.require; rq('child_process').spawn(/^win/i.test(G.navigator.platform) ? 'explorer' : 'open', [u], { windowsHide: true }); } catch (e) { try { G.open(u); } catch (e2) {} }
  }
  var IG = 'https://www.instagram.com/amar_enp', IG_OFFICIAL = 'https://www.instagram.com/enp_tool';
  /* "still in testing" note on a tab */
  function beta(text) {
    return h('div', { class: 'beta' }, [h('b', { text: 'تحت التجربة' }), h('span', { text: ' ' + (text || 'الأداة دي لسه تحت التجربة ومش الشكل النهائي — هتتظبط أكتر في التحديثات الجاية.') + ' تابع ' }),
      h('a', { href: '#', text: '@enp_tool', onclick: function (e) { e.preventDefault(); openUrl(IG_OFFICIAL); } }), h('span', { text: ' على إنستجرام لأي جديد.' })]);
  }
  G.K = { openUrl: openUrl, beta: beta, IG: IG, IG_OFFICIAL: IG_OFFICIAL, h: h, ICON: ICON, store: store, slider: slider, seg: seg, toggle: toggle, btn: btn, field: field, section: section,
    status: status, progress: progress, show: show, tc: tc, mmss: mmss, chunks: chunks };
})(window);
