/* ENP — safe self-update.
   latest.json: { version, url, sha256, notes }. The zip must match its sha256 and
   contain a complete panel of that version; the current version is kept in
   _backup first, and boot.js puts it back if the new one doesn't start. */
(function (G) {
  'use strict';
  var S = G.Sys, K = G.K, req = S.req, st = K.store('enp_up_');
  var fs = req ? req('fs') : null, path = req ? req('path') : null, os = req ? req('os') : null, cp = req ? req('child_process') : null, crypto = req ? req('crypto') : null;
  var CFG = (G.License && G.License.cfg) || { version: '0.0.0' };
  var ext = S.extDir();
  function cmp(a, b) { a = String(a).split('.').map(Number); b = String(b).split('.').map(Number); for (var i = 0; i < 3; i++) if ((a[i] || 0) !== (b[i] || 0)) return (a[i] || 0) - (b[i] || 0); return 0; }
  function feed() { var b = G.License ? G.License.base() : ''; return b ? b + 'latest.json' : ''; }
  var footStatus = null, bar = G.document.getElementById('update-bar');
  function note(msg, kind) { if (footStatus) footStatus.show(kind, msg); }

  function check(manual) {
    if (!feed() || !S.httpGet) { if (manual) note('رابط التحديثات لسه متحطش.', 'warn'); return Promise.resolve(null); }
    return S.httpGet(feed() + '?t=' + Date.now()).then(function (r) {
      var info = JSON.parse(r.body); st.set('checked', Date.now());
      if (info.version && cmp(info.version, CFG.version) > 0) { banner(info); return info; }
      if (manual) note('عندك آخر نسخة (' + CFG.version + ').', 'ok');
      return null;
    }).catch(function (e) { if (manual) note('مقدرتش أوصل للتحديثات [' + e.message + ']', 'err'); return null; });
  }
  var SKIP = { _backup: 1, _update: 1, runtime: 1 };
  function copyDir(src, dst, top) {
    fs.readdirSync(src, { withFileTypes: true }).forEach(function (it) {
      if (top && SKIP[it.name]) return;
      var a = path.join(src, it.name), b = path.join(dst, it.name);
      if (it.isDirectory()) { try { fs.mkdirSync(b, { recursive: true }); } catch (e) {} copyDir(a, b, false); } else fs.copyFileSync(a, b);
    });
  }
  function rmrf(p) { try { fs.rmSync(p, { recursive: true, force: true }); } catch (e) { try { if (fs.rmdirSync) fs.rmdirSync(p, { recursive: true }); } catch (e2) {} } }
  function findRoot(dir, depth) {
    if (fs.existsSync(path.join(dir, 'CSXS', 'manifest.xml'))) return dir;
    if (depth > 3) return '';
    var items = fs.readdirSync(dir, { withFileTypes: true });
    for (var i = 0; i < items.length; i++) if (items[i].isDirectory()) { var r = findRoot(path.join(dir, items[i].name), depth + 1); if (r) return r; }
    return '';
  }
  function sha256(file) { return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'); }
  function unzip(zip, to) {
    return new Promise(function (res, rej) {
      var p = S.isWin ? cp.spawn('powershell', ['-NoProfile', '-Command', 'Expand-Archive -LiteralPath "' + zip + '" -DestinationPath "' + to + '" -Force'], { windowsHide: true })
        : cp.spawn('unzip', ['-o', '-q', zip, '-d', to]);
      p.on('close', function (c) { c === 0 ? res() : rej(new Error('unzip ' + c)); }); p.on('error', rej);
    });
  }
  function install(info) {
    var tmp = path.join(os.tmpdir(), 'ENP-update'), zip = path.join(os.tmpdir(), 'ENP-update.zip');
    note('بنزّل التحديث ' + info.version + '…', 'busy');
    return S.httpGet(info.url, zip).then(function () {
      if (!info.sha256 || sha256(zip).toLowerCase() !== String(info.sha256).toLowerCase()) throw new Error('الملف اللي اتنزّل مش مطابق — ماتحدّثش حاجة');
      rmrf(tmp); fs.mkdirSync(tmp, { recursive: true });
      return unzip(zip, tmp);
    }).then(function () {
      var root = findRoot(tmp, 0);
      if (!root) throw new Error('الملف مش فيه البلاجن');
      ['index.html', 'js/app.js', 'js/tabs.js', 'jsx/host.jsx', 'enp.json', 'license.pub'].forEach(function (f) { if (!fs.existsSync(path.join(root, f))) throw new Error('التحديث ناقص: ' + f); });
      var nv = JSON.parse(fs.readFileSync(path.join(root, 'enp.json'), 'utf8')).version;
      if (nv !== info.version) throw new Error('رقم النسخة مش مطابق');
      var oldM = fs.readFileSync(path.join(ext, 'CSXS', 'manifest.xml'), 'utf8'), newM = fs.readFileSync(path.join(root, 'CSXS', 'manifest.xml'), 'utf8');
      // keep the current version, then lay the new one over it
      var bk = path.join(ext, '_backup'); rmrf(bk); fs.mkdirSync(bk, { recursive: true }); copyDir(ext, bk, true);
      copyDir(root, ext, true);
      fs.mkdirSync(path.join(ext, '_update'), { recursive: true });
      fs.writeFileSync(path.join(ext, '_update', 'state.json'), JSON.stringify({ pending: true, attempts: 0, from: CFG.version, to: info.version, at: Date.now() }));
      try { fs.unlinkSync(zip); } catch (e) {} rmrf(tmp);
      if (oldM !== newM) { note('التحديث اتنزّل ✓ اقفل بريمير وافتحه عشان يشتغل.', 'ok'); return; }
      note('التحديث اتنزّل ✓ ببدأ من جديد…', 'ok');
      var hostPath = path.join(ext, 'jsx', 'host.jsx').replace(/\\/g, '/');
      try { G.__adobe_cep__.evalScript('$.evalFile("' + hostPath + '")', function () { setTimeout(function () { G.location.reload(); }, 500); }); } catch (e) { setTimeout(function () { G.location.reload(); }, 500); }
    }).catch(function (e) { note('التحديث ماتمّش — النسخة الحالية زي ما هي. [' + (e.message || e) + ']', 'err'); });
  }
  function banner(info) {
    if (!bar) return;
    bar.innerHTML = ''; bar.className = 'upbar';
    bar.appendChild(K.h('div', {}, [K.h('b', { text: 'تحديث جديد ' + info.version }), info.notes ? K.h('div', { class: 'hint', text: info.notes }) : null]));
    bar.appendChild(K.btn('نزّله', { cls: 'pri sm', onClick: function () { install(info); } }));
  }
  function buildFoot() {
    var foot = G.document.getElementById('foot'); if (!foot) return;
    footStatus = K.status();
    var hasBk = fs && fs.existsSync(path.join(ext, '_backup', 'index.html'));
    var rb = K.btn('ارجع للنسخة اللي قبلها', { cls: 'ghost', icon: 'undo', onClick: function () { if (G.ENPRollback && G.ENPRollback('manual')) { note('رجعت للنسخة اللي قبلها…', 'ok'); setTimeout(function () { G.location.reload(); }, 600); } } });
    K.show(rb, !!hasBk);
    var dev = G.License ? G.License.deviceId() : '';
    foot.appendChild(K.h('div', { class: 'footrow' }, [
      K.h('span', { class: 'hint', text: 'ENP ' + CFG.version }),
      K.btn('دوّر على تحديث', { cls: 'ghost', icon: 'refresh', onClick: function () { check(true); } })
    ]));
    foot.appendChild(K.h('div', { class: 'footrow', style: 'margin-top:6px' }, [
      K.h('span', { class: 'hint', style: 'direction:ltr;text-align:right', text: 'Device: ' + dev }),
      K.btn('انسخ', { cls: 'ghost', onClick: function () { if (G.License) G.License.copy(dev); note('كود الجهاز اتنسخ ✓', 'ok'); } }), rb
    ]));
    var bs = G.ENPBootState && G.ENPBootState();
    if (bs && bs.rolledBack && !st.get('rbSeen' + bs.at)) { st.set('rbSeen' + bs.at, 1); setTimeout(function () { note('التحديث الأخير ماشتغلش، فرجعت للنسخة اللي قبله تلقائي ✓', 'warn'); }, 500); }
    foot.appendChild(K.h('div', { class: 'footrow igrow', style: 'margin-top:8px' }, [
      K.h('span', { class: 'hint', text: 'الصفحة الرسمية لـ ENP على إنستجرام' }),
      K.h('a', { href: '#', class: 'iglink', text: '@enp_tool', onclick: function (e) { e.preventDefault(); K.openUrl(K.IG_OFFICIAL); } })
    ]));
    foot.appendChild(K.h('div', { class: 'footrow igrow', style: 'margin-top:4px' }, [
      K.h('span', { class: 'hint', text: 'وتابعني لأي جديد' }),
      K.h('a', { href: '#', class: 'iglink', text: '@amar_enp', onclick: function (e) { e.preventDefault(); K.openUrl(K.IG); } })
    ]));
    foot.appendChild(footStatus);
  }
  buildFoot();
  if (S.hasNode && feed() && Date.now() - st.get('checked', 0) > 4 * 3600 * 1000) setTimeout(function () { check(false); }, 3000);
  G.Updater = { check: check, version: CFG.version, install: install };
})(window);
