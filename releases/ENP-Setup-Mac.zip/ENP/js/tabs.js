/* ENP — tab switching; each tab is built the first time it's opened. */
(function (G) {
  'use strict';
  var D = G.document, built = { carousel: true }, cur = null;
  var MOD = { text: 'TextTab', glass: 'GlassTab', fx: 'FxTab', path: 'PathTab', cut: 'CutTab', caption: 'CaptionTab', curves: 'CurvesTab', zoom: 'ZoomTab', track: 'TrackTab', sfx: 'SfxTab', clean: 'AudioCleanTab', ramp: 'SpeedRampTab', safe: 'SafeTab', admin: 'AdminTab' };
  if (G.AdminTab) {
    var b = D.createElement('button'); b.type = 'button'; b.setAttribute('data-tab', 'admin'); b.textContent = 'التحكم'; b.className = 'admbtn';
    D.getElementById('tabs').appendChild(b);
  }
  function show(id) {
    if (cur === id) return;
    if (cur && MOD[cur] && G[MOD[cur]] && G[MOD[cur]].onHide) G[MOD[cur]].onHide();
    if (cur === 'carousel' && G.Carousel3D && G.Carousel3D.clock.on) G.Carousel3D.play(false);
    cur = id;
    [].forEach.call(D.querySelectorAll('#tabs button'), function (b) { b.classList.toggle('on', b.getAttribute('data-tab') === id); });
    [].forEach.call(D.querySelectorAll('.tab'), function (t) { t.classList.toggle('hide', t.id !== 'tab-' + id); });
    if (!built[id] && MOD[id] && G[MOD[id]]) { built[id] = true; try { G[MOD[id]].build(D.getElementById('tab-' + id)); } catch (e) { D.getElementById('tab-' + id).textContent = String(e && e.stack || e); } }
    if (MOD[id] && G[MOD[id]] && G[MOD[id]].onShow) G[MOD[id]].onShow();
    try { G.localStorage.setItem('enp_tab', id); } catch (e) {}
    G.scrollTo(0, 0);
    setTimeout(function () { G.dispatchEvent(new Event('resize')); }, 0);
  }
  [].forEach.call(D.querySelectorAll('#tabs button'), function (b) { b.addEventListener('click', function () { show(b.getAttribute('data-tab')); }); });
  var first = 'carousel'; try { first = G.localStorage.getItem('enp_tab') || 'carousel'; } catch (e) {}
  if (first !== 'carousel' && !(MOD[first] && G[MOD[first]])) first = 'carousel';
  show(first);
  /* the panel started fine: an update that just went in is confirmed */
  setTimeout(function () { if (G.ENPBootOK) G.ENPBootOK(); }, 5000);
})(window);
