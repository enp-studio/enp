/* ENP — After Effects side. Loaded on top of host.jsx when the panel runs in AE: every cr_* the graphics tools use,
   done with After Effects' own scripting (the active composition plays the part of Premiere's sequence).
   Times are comp seconds; positions handed to the panel are 0..1 of the comp, like Premiere's Motion. */

function ae__comp() { var c = app.project ? app.project.activeItem : null; return (c && c instanceof CompItem) ? c : null; }
function ae__noComp() { return cr__json({ ok: false, error: 'no_sequence' }); }
function ae__dir() { try { return app.project.file ? app.project.file.parent.fsName : ''; } catch (e) { return ''; } }
function ae__folder(name) {
  var root = app.project.rootFolder;
  for (var i = 1; i <= root.numItems; i++) { var it = root.item(i); if (it instanceof FolderItem && it.name === name) return it; }
  return app.project.items.addFolder(name);
}
function ae__import(path, folderName) {
  var f = new File(path); if (!f.exists) return null;
  var io = new ImportOptions(f), it = null;
  try { it = app.project.importFile(io); } catch (e) { return null; }
  try { if (folderName) it.parentFolder = ae__folder(folderName); } catch (e2) {}
  try { if (it.mainSource && it.mainSource.hasAlpha) it.mainSource.alphaMode = AlphaMode.STRAIGHT; } catch (e3) {}
  return it;
}
function ae__isFootage(l) { try { return l.source && (l.source instanceof FootageItem) && l.source.file; } catch (e) { return false; } }
function ae__srcTime(l, t) { var st = 100; try { st = l.stretch || 100; } catch (e) {} return (t - l.startTime) * 100 / st; }
function ae__activeAt(l, t) { return l.enabled && l.inPoint <= t + 0.0005 && l.outPoint > t; }
function ae__ours(l) { var n = ''; try { n = l.source ? l.source.name : l.name; } catch (e) {} return /^(Carousel3D|AmarText|AmarGlass|ENP)_/.test(n); }
/* a layer as the panel knows a clip: Motion scale %, position / anchor 0..1 */
function ae__info(l, comp) {
  var o = { track: l.index, id: '', name: l.name, start: l.inPoint, end: l.outPoint, path: '', speed: 1 };
  try { o.id = String(l.id); } catch (e) { o.id = 'i' + l.index; }
  try { if (ae__isFootage(l)) o.path = l.source.file.fsName; } catch (e) {}
  try { o.speed = 100 / (l.stretch || 100); } catch (e) {}
  o.inPoint = ae__srcTime(l, l.inPoint);
  try {
    var tr = l.property('ADBE Transform Group'), t = comp.time;
    var sc = tr.property('ADBE Scale').valueAtTime(t, false), ps = tr.property('ADBE Position').valueAtTime(t, false), an = tr.property('ADBE Anchor Point').valueAtTime(t, false);
    var sw = l.source ? l.source.width : comp.width, sh = l.source ? l.source.height : comp.height;
    o.scale = sc[1]; o.uniform = Math.abs(sc[0] - sc[1]) < 0.01; if (!o.uniform) o.scalew = sc[0];
    o.pos = [ps[0] / comp.width, ps[1] / comp.height]; o.anchor = [an[0] / sw, an[1] / sh];
    o.rot = tr.property('ADBE Rotate Z').valueAtTime(t, false); o.opacity = tr.property('ADBE Opacity').valueAtTime(t, false);
    o.keyed = tr.property('ADBE Scale').numKeys > 0 || tr.property('ADBE Position').numKeys > 0;
  } catch (e2) { o.noMotion = true; }
  return o;
}
function ae__find(comp, ref) {
  if (!ref) return null;
  for (var i = 1; i <= comp.numLayers; i++) { var l = comp.layer(i); try { if (ref.id && String(l.id) === String(ref.id)) return l; } catch (e) {} }
  if (ref.track && ref.track <= comp.numLayers) return comp.layer(ref.track);
  return null;
}
function ae__topAt(comp, t, any) {
  for (var i = 1; i <= comp.numLayers; i++) { var l = comp.layer(i); if (!ae__activeAt(l, t) || ae__ours(l)) continue; if (ae__isFootage(l) && l.hasVideo) return l; if (any) return l; }
  return null;
}
function ae__removeNamed(comp, names) {
  var set = {}, n = 0; for (var k = 0; k < (names || []).length; k++) set[names[k]] = 1;
  for (var i = comp.numLayers; i >= 1; i--) { var l = comp.layer(i), nm = ''; try { nm = l.source ? l.source.name : ''; } catch (e) {} if (set[nm] || set[l.name]) { l.remove(); n++; } }
  return n;
}
function ae__lay(comp, item, t0, dur) {
  var l = comp.layers.add(item); l.startTime = t0;
  try { if (dur > 0 && !(item instanceof FootageItem && item.duration > 0 && item.duration < dur)) l.outPoint = t0 + dur; } catch (e) {}
  return l;
}

function ae__undo(name, fn) { app.beginUndoGroup(name); try { return fn(); } finally { try { app.endUndoGroup(); } catch (e) {} } }

/* ---------------- the calls ---------------- */
function cr_info() {
  try {
    var c = ae__comp(), dir = ae__dir();
    if (!c) return cr__json({ ok: true, hasSequence: false, dir: dir, ae: true });
    return cr__json({ ok: true, hasSequence: true, t: c.time, w: c.width, h: c.height, fps: c.frameRate, dir: dir, name: c.name, ae: true });
  } catch (e) { return cr__fail(e); }
}
function cr_appInfo(s) {
  try {
    var o = { ok: true, app: 'After Effects', version: String(app.version || ''), build: '', project: '', saved: false, seq: false, seqName: '', w: 0, h: 0 };
    try { o.project = app.project.file ? app.project.file.fsName : ''; o.saved = !!o.project; } catch (e) {}
    var c = ae__comp(); if (c) { o.seq = true; o.seqName = c.name; o.w = c.width; o.h = c.height; }
    return cr__json(o);
  } catch (e) { return cr__fail(e); }
}
function cr_place(s) {
  try {
    var a = cr__args(s), comp = ae__comp(); if (!comp) return ae__noComp();
    return ae__undo('ENP', function () {
      if (a.replace && a.replace.length) ae__removeNamed(comp, a.replace);
      var front = ae__import(a.front, a.bin || 'ENP'), back = a.back ? ae__import(a.back, a.bin || 'ENP') : null;
      if (!front || (a.back && !back)) return cr__json({ ok: false, error: 'import_failed' });
      var t0 = Number(a.at) || 0, dur = Number(a.duration) || 1, res = { ok: true, names: [front.name], backAbove: false };
      /* the back layer goes under the speaker (the lowest picture at that moment), like Premiere's track below */
      var speaker = null; for (var si = comp.numLayers; si >= 1 && !speaker; si--) { var sl = comp.layer(si); if (ae__activeAt(sl, t0 + 0.001) && !ae__ours(sl) && ae__isFootage(sl) && sl.hasVideo) speaker = sl; }
      if (back) { var bl = ae__lay(comp, back, t0, dur); if (speaker) { try { bl.moveAfter(speaker); } catch (e) {} } else res.backAbove = true; res.back = 'Layer ' + bl.index; res.names.push(back.name); }
      var fl = ae__lay(comp, front, t0, dur); try { fl.moveToBeginning(); } catch (e2) {}
      res.track = 'Layer ' + fl.index; try { res.ref = { track: fl.index, start: t0, id: String(fl.id) }; } catch (e3) {}
      return cr__json(res);
    });
  } catch (e) { return cr__fail(e); }
}
function cr_placeSeq(s) {
  try {
    var a = cr__args(s), comp = ae__comp(); if (!comp) return ae__noComp();
    return ae__undo('ENP', function () {
      if (a.replace && a.replace.length) ae__removeNamed(comp, a.replace);
      var names = [];
      for (var k = 0; k < (a.items || []).length; k++) {
        var itd = a.items[k], it = ae__import(itd.path, a.bin || 'ENP'); if (!it) { names.push(''); continue; }
        var l = ae__lay(comp, it, Number(itd.at) || 0, Number(itd.dur) || 0); l.moveToBeginning(); names.push(it.name);
        if (a.pos) { try { var tr = l.property('ADBE Transform Group'); var p = a.pos; tr.property('ADBE Position').setValue([p[0] <= 1.5 ? p[0] * comp.width : p[0], p[1] <= 1.5 ? p[1] * comp.height : p[1]]); tr.property('ADBE Scale').setValue([100, 100]); } catch (e2) {} }
      }
      return cr__json({ ok: true, track: 'Layers', ti: 1, names: names });
    });
  } catch (e) { return cr__fail(e); }
}
function cr_remove(s) {
  try { var a = cr__args(s), comp = ae__comp(); if (!comp) return ae__noComp(); return cr__json({ ok: true, removed: ae__undo('ENP', function () { return ae__removeNamed(comp, a.names || []); }) }); } catch (e) { return cr__fail(e); }
}
function cr_seek(s) { try { var a = cr__args(s), comp = ae__comp(); if (!comp) return ae__noComp(); comp.time = Number(a.t) || 0; return cr__json({ ok: true }); } catch (e) { return cr__fail(e); } }
function cr_under(s) {
  try {
    var comp = ae__comp(); if (!comp) return ae__noComp();
    var l = ae__topAt(comp, comp.time); if (!l) return cr__json({ ok: true, none: true });
    return cr__json({ ok: true, path: l.source.file.fsName, src: ae__srcTime(l, comp.time) });
  } catch (e) { return cr__fail(e); }
}
function cr_under2(s) {
  try {
    var a = cr__args(s), comp = ae__comp(); if (!comp) return ae__noComp();
    var t = (a.t !== undefined && a.t !== null) ? Number(a.t) + 0.001 : comp.time, l = ae__topAt(comp, t);
    if (!l) return cr__json({ ok: true, none: true, t: t, w: comp.width, h: comp.height, fps: comp.frameRate });
    var o = ae__info(l, comp); o.src = ae__srcTime(l, t);
    return cr__json({ ok: true, clip: o, t: t, w: comp.width, h: comp.height, fps: comp.frameRate });
  } catch (e) { return cr__fail(e); }
}
function cr_layersAt(s) {
  try {
    var a = cr__args(s), comp = ae__comp(); if (!comp) return ae__noComp();
    var t = (a.t !== undefined && a.t !== null) ? Number(a.t) + 0.001 : comp.time, out = [], gfx = 0;
    for (var i = comp.numLayers; i >= 1; i--) {
      var l = comp.layer(i); if (!ae__activeAt(l, t)) continue;
      try { if (l.adjustmentLayer || l.guideLayer || l.nullLayer || !l.hasVideo) continue; } catch (e) {}
      if (ae__isFootage(l)) { var o = ae__info(l, comp); o.src = ae__srcTime(l, t); out.push(o); } else gfx++;
    }
    return cr__json({ ok: true, layers: out, gfx: gfx, t: t, w: comp.width, h: comp.height, fps: comp.frameRate });
  } catch (e) { return cr__fail(e); }
}
/* the composition exactly as it looks at the playhead — AE writes the PNG in the background */
function cr_snapFrame(s) {
  try {
    var a = cr__args(s), comp = ae__comp(); if (!comp) return ae__noComp();
    comp.saveFrameToPng(comp.time, new File(a.base + '.png'));
    return cr__json({ ok: true, t: comp.time, fmt: 'png' });
  } catch (e) { return cr__fail(e); }
}
function cr_clips(s) {
  try {
    var a = cr__args(s), comp = ae__comp(); if (!comp) return ae__noComp();
    var out = [], sel = comp.selectedLayers || [];
    for (var i = 0; i < sel.length; i++) if (ae__isFootage(sel[i]) && sel[i].hasVideo) out.push(ae__info(sel[i], comp));
    if (!out.length && a.fallback !== false) { var top = ae__topAt(comp, comp.time); if (top) out.push(ae__info(top, comp)); }
    return cr__json({ ok: true, clips: out, t: comp.time, w: comp.width, h: comp.height, fps: comp.frameRate, selected: sel.length });
  } catch (e) { return cr__fail(e); }
}
function cr_selclips() {
  try {
    var comp = ae__comp(); if (!comp) return ae__noComp();
    var sel = comp.selectedLayers || [], out = [];
    for (var i = 0; i < sel.length; i++) { if (ae__ours(sel[i])) continue; out.push({ at: sel[i].inPoint, dur: sel[i].outPoint - sel[i].inPoint, name: sel[i].name }); }
    out.sort(function (x, y) { return x.at - y.at; });
    return cr__json({ ok: true, count: out.length, clips: out });
  } catch (e) { return cr__fail(e); }
}
function cr_sel1() {
  try {
    var comp = ae__comp(); if (!comp) return ae__noComp();
    var sel = comp.selectedLayers || [], pick = null, n = 0;
    for (var i = 0; i < sel.length; i++) if (ae__isFootage(sel[i])) { n++; if (!pick) pick = sel[i]; }
    if (!pick) return cr__json({ ok: false, error: 'no_selection' });
    var id = ''; try { id = String(pick.id); } catch (e) {}
    return cr__json({ ok: true, count: n, path: pick.source.file.fsName, name: pick.source.name, at: pick.inPoint, dur: pick.outPoint - pick.inPoint, ref: { id: id } });
  } catch (e) { return cr__fail(e); }
}
function cr_findNamed(s) {
  try {
    var a = cr__args(s), comp = ae__comp(); if (!comp) return ae__noComp();
    var set = {}; for (var k = 0; k < (a.names || []).length; k++) set[a.names[k]] = 1;
    for (var i = 1; i <= comp.numLayers; i++) { var l = comp.layer(i), nm = ''; try { nm = l.source ? l.source.name : ''; } catch (e) {} if (set[nm]) return cr__json({ ok: true, clip: ae__info(l, comp) }); }
    return cr__json({ ok: true, clip: null });
  } catch (e) { return cr__fail(e); }
}
function cr_markers(s) {
  try {
    var a = cr__args(s), comp = ae__comp(), out = []; if (!comp) return ae__noComp();
    try { var mp = comp.markerProperty; for (var i = 1; i <= mp.numKeys; i++) { var t = mp.keyTime(i); if (t >= a.from - 0.001 && t <= a.to + 0.001) out.push(t); } } catch (e) {}
    return cr__json({ ok: true, markers: out });
  } catch (e) { return cr__fail(e); }
}
/* zoom & friends: Premiere's Motion keys → the layer's Transform (scale %, position 0..1 → pixels) */
function ae__prop(l, which) { var tr = l.property('ADBE Transform Group'); return (which === 'scale' || which === 'scalew') ? tr.property('ADBE Scale') : which === 'pos' ? tr.property('ADBE Position') : which === 'rot' ? tr.property('ADBE Rotate Z') : which === 'anchor' ? tr.property('ADBE Anchor Point') : null; }
function ae__val(comp, which, v, p, t) {
  if (which === 'scale' || which === 'scalew') {
    var cur = null; try { cur = p ? (t != null ? p.valueAtTime(t, true) : p.value) : null; } catch (e) {}
    if (which === 'scalew') return [Number(v), cur ? cur[1] : Number(v)];
    if (cur && Math.abs(cur[0] - cur[1]) > 0.01) return [cur[0], Number(v)];
    return [Number(v), Number(v)];
  }
  if (which === 'pos') return [v[0] <= 1.5 ? v[0] * comp.width : v[0], v[1] <= 1.5 ? v[1] * comp.height : v[1]];
  return v;
}
function cr_keys(s) {
  try {
    var a = cr__args(s), comp = ae__comp(); if (!comp) return ae__noComp();
    var l = ae__find(comp, a.clip); if (!l) return cr__json({ ok: false, error: 'clip_moved' });
    var p = ae__prop(l, a.prop); if (!p) return cr__json({ ok: false, error: 'no_motion' });
    return ae__undo('ENP', function () {
      if (a.reset && a.prop !== 'scalew') while (p.numKeys > 0) p.removeKey(1);
      if (a.value !== undefined && a.value !== null && !(a.keys && a.keys.length)) p.setValue(ae__val(comp, a.prop, a.value, p));
      var keys = a.keys || [];
      for (var i = 0; i < keys.length; i++) p.setValueAtTime(keys[i][0], ae__val(comp, a.prop, keys[i][1], p, keys[i][0]));
      return cr__json({ ok: true, n: keys.length });
    });
  } catch (e) { return cr__fail(e); }
}
function cr_unkey(s) {
  try {
    var a = cr__args(s), comp = ae__comp(); if (!comp) return ae__noComp();
    var l = ae__find(comp, a.clip); if (!l) return cr__json({ ok: false, error: 'clip_moved' });
    var props = a.props || ['scale', 'pos'];
    ae__undo('ENP', function () { for (var i = 0; i < props.length; i++) { var p = ae__prop(l, props[i]); if (!p) continue; while (p.numKeys > 0) p.removeKey(1); if (a.base && a.base[props[i]] != null) p.setValue(ae__val(comp, props[i], a.base[props[i]], p)); } });
    return cr__json({ ok: true });
  } catch (e) { return cr__fail(e); }
}
/* the sound in the comp, for captions / waves / zoom */
function cr_audioClips(s) {
  try {
    var comp = ae__comp(); if (!comp) return ae__noComp();
    var tracks = [], clips = [], sel = comp.selectedLayers || [], a0 = 1e9, b0 = -1e9;
    for (var i = 1; i <= comp.numLayers; i++) {
      var l = comp.layer(i), ok = false;
      try { ok = ae__isFootage(l) && l.hasAudio; } catch (e) {}
      if (!ok) continue;
      var on = true; try { on = l.audioEnabled; } catch (e2) {}
      if (on) clips.push({ track: i, start: l.inPoint, end: l.outPoint, inPoint: ae__srcTime(l, l.inPoint), path: l.source.file.fsName, speed: 100 / (l.stretch || 100), name: l.name });
      tracks.push({ i: i, name: l.name, muted: !on, n: on ? 1 : 0 });
    }
    for (var k = 0; k < sel.length; k++) { if (sel[k].inPoint < a0) a0 = sel[k].inPoint; if (sel[k].outPoint > b0) b0 = sel[k].outPoint; }
    var inout = null; try { if (comp.workAreaStart > 0.01 || comp.workAreaDuration < comp.duration - 0.05) inout = [comp.workAreaStart, comp.workAreaStart + comp.workAreaDuration]; } catch (e3) {}
    return cr__json({ ok: true, name: comp.name, id: String(comp.id), fps: comp.frameRate, w: comp.width, h: comp.height, end: comp.duration, t: comp.time,
      sel: sel.length && b0 > a0 ? [a0, b0] : null, inout: inout, tracks: tracks, clips: clips });
  } catch (e) { return cr__fail(e); }
}
function cr_importLay(s) {
  try {
    var a = cr__args(s), it = ae__import(a.path, a.bin || 'ENP Items');
    if (!it) return cr__json({ ok: false, error: 'import_failed' });
    if (!a.place) return cr__json({ ok: true, imported: true, name: it.name });
    var comp = ae__comp(); if (!comp) return cr__json({ ok: true, imported: true, name: it.name, noSeq: true });
    var l = ae__undo('ENP', function () { return ae__lay(comp, it, a.at != null ? Number(a.at) : comp.time, Number(a.dur) || 0); });
    return cr__json({ ok: true, imported: true, name: it.name, track: 'Layer ' + l.index });
  } catch (e) { return cr__fail(e); }
}
function cr_newItem(s) {
  try {
    var a = cr__args(s), comp = ae__comp(); if (!comp) return ae__noComp();
    var dur = Number(a.dur) || 5, t0 = comp.time, l = null;
    ae__undo('ENP', function () {
      if (a.kind === 'adjust') { l = comp.layers.addSolid([1, 1, 1], 'ENP Adjustment Layer', comp.width, comp.height, comp.pixelAspect, dur); l.adjustmentLayer = true; }
      else if (a.kind === 'black') l = comp.layers.addSolid([0, 0, 0], 'ENP Black', comp.width, comp.height, comp.pixelAspect, dur);
      else if (a.kind === 'transparent') l = comp.layers.addNull(dur);
      if (l) { l.startTime = t0; l.outPoint = t0 + dur; }
    });
    if (!l) return cr__json({ ok: false, error: 'no_qe' });
    return cr__json({ ok: true, track: 'Layer ' + l.index, name: l.name });
  } catch (e) { return cr__fail(e); }
}
/* glass templates: the After Effects project that lives inside each .mogrt is opened as a comp in your project */
function ae__walk(folder, fn) { for (var i = 1; i <= folder.numItems; i++) { var it = folder.item(i); fn(it); if (it instanceof FolderItem) ae__walk(it, fn); } }
function cr_mogrt(s) {
  try {
    var a = cr__args(s), comp = ae__comp(); if (!comp) return ae__noComp();
    if (!a.aep) return cr__json({ ok: false, error: 'no_aep' });
    var f = new File(a.aep); if (!f.exists) return cr__json({ ok: false, error: 'import_failed' });
    return ae__undo('ENP', function () {
      var fold = app.project.importFile(new ImportOptions(f)), main = null, best = -1;
      try { fold.parentFolder = ae__folder('ENP Templates'); } catch (e) {}
      ae__walk(fold, function (it) {
        if (!(it instanceof CompItem)) return; var n = 0; try { n = it.motionGraphicsTemplateControllerCount; } catch (e) {}
        var named = false; try { named = !!it.motionGraphicsTemplateName; } catch (e) {}
        var score = (named ? 1000 : 0) + n; if (score > best) { best = score; main = it; }
      });
      if (!main) return cr__json({ ok: false, error: 'import_failed' });
      var t0 = (a.at !== undefined && a.at !== null) ? Number(a.at) : comp.time, l = comp.layers.add(main); l.startTime = t0;
      if (Number(a.dur) > 0) { try { l.outPoint = t0 + Number(a.dur); } catch (e2) {} }
      if (a.move) { try { var tr = l.property('ADBE Transform Group'), k = Number(a.move.k) || 1; tr.property('ADBE Scale').setValue([100 * k, 100 * k]);
        var p = tr.property('ADBE Position').value; tr.property('ADBE Position').setValue([p[0] + (Number(a.move.dx) || 0) * main.width, p[1] + (Number(a.move.dy) || 0) * main.height]); } catch (e3) {} }
      /* the panel's look → the template's Essential Properties, by control name */
      var setN = 0, miss = [];
      if (a.set && a.set.length) {
        var ep = null; try { ep = l.essentialProperty; } catch (e4) {} if (!ep) { try { ep = l.property('ADBE Layer Overrides'); } catch (e5) {} }
        for (var q = 0; q < a.set.length; q++) {
          var it = a.set[q], pr = null;
          if (ep) { try { pr = ep.property(it.name); } catch (e6) {} }
          if (!pr) { miss.push(it.name); continue; }
          try { if (it.color) pr.setValue([it.color[0] / 255, it.color[1] / 255, it.color[2] / 255, 1]); else pr.setValue(typeof it.value === 'boolean' ? (it.value ? 1 : 0) : it.value); setN++; } catch (e7) { miss.push(it.name); }
        }
      }
      l.moveToBeginning();
      return cr__json({ ok: true, track: 'Layer ' + l.index, name: main.name, at: t0, dur: l.outPoint - l.inPoint, set: setN, miss: miss, ae: true });
    });
  } catch (e) { return cr__fail(e); }
}
function cr_srtCaptions(s) { return cr__json({ ok: false, error: 'not_in_ae' }); }
function cr_projSave(s) { try { if (app.project.file) app.project.save(); return cr__json({ ok: true }); } catch (e) { return cr__fail(e); } }
function cr_projInfo(s) { try { return cr__json({ ok: true, path: app.project.file ? app.project.file.fsName : '', ae: true }); } catch (e) { return cr__fail(e); } }

/* sound effects / cleaned voice: an audio layer at the playhead */
function cr_sfx(s) {
  try {
    var a = cr__args(s), comp = ae__comp(); if (!comp) return ae__noComp();
    var it = ae__import(a.path, 'SFX'); if (!it) return cr__json({ ok: false, error: 'import_failed' });
    var t0 = (a.at !== undefined && a.at !== null) ? Number(a.at) : comp.time;
    var l = ae__undo('ENP', function () { var x = comp.layers.add(it); x.startTime = t0; try { x.moveToEnd(); } catch (e) {} return x; });
    return cr__json({ ok: true, track: 'Layer ' + l.index, at: t0 });
  } catch (e) { return cr__fail(e); }
}
function cr_selAudio(s) {
  try {
    var comp = ae__comp(); if (!comp) return ae__noComp();
    var sel = comp.selectedLayers || [], out = [];
    for (var i = 0; i < sel.length; i++) {
      var l = sel[i], ok = false; try { ok = ae__isFootage(l) && l.hasAudio; } catch (e) {}
      if (!ok) continue;
      out.push({ track: l.index, idx: 0, id: String(l.id), start: l.inPoint, end: l.outPoint, inPoint: ae__srcTime(l, l.inPoint), path: l.source.file.fsName, speed: 100 / (l.stretch || 100), name: l.name, on: l.audioEnabled !== false });
    }
    return cr__json({ ok: true, clips: out, t: comp.time, n: comp.numLayers });
  } catch (e) { return cr__fail(e); }
}
function cr_placeClean(s) {
  try {
    var a = cr__args(s), comp = ae__comp(); if (!comp) return ae__noComp();
    var placed = 0, muted = 0, names = [];
    ae__undo('ENP', function () {
      for (var k = 0; k < (a.items || []).length; k++) {
        var itd = a.items[k], it = ae__import(itd.path, 'ENP Clean Audio'); if (!it) continue;
        var l = comp.layers.add(it); l.startTime = Number(itd.at) || 0; placed++; names.push(it.name);
        if (a.mute && itd.src) { var o = ae__find(comp, { id: itd.src.id, track: itd.src.track }); if (o) { try { o.audioEnabled = false; muted++; } catch (e) {} } }
      }
    });
    return cr__json({ ok: true, track: 'Layers', placed: placed, muted: muted, names: names });
  } catch (e) { return cr__fail(e); }
}
/* glass «live link»: point the imported footage at the newly rendered file */
function cr_swapMedia(s) {
  try {
    var a = cr__args(s), hit = null;
    ae__walk(app.project.rootFolder, function (it) { if (!hit && it instanceof FootageItem && it.name === a.name) hit = it; });
    if (!hit) return cr__json({ ok: false, error: 'not_found' });
    hit.replace(new File(a.path)); try { hit.name = a.name; hit.mainSource.alphaMode = AlphaMode.STRAIGHT; } catch (e) {}
    return cr__json({ ok: true });
  } catch (e) { return cr__fail(e); }
}
/* the media behind the selection: project panel items, or the selected layers in the comp */
function cr_pick(s) {
  try {
    var a = cr__args(s), out = [], seen = {};
    if (a.from === 'project') {
      var sel = app.project.selection || [];
      for (var i = 0; i < sel.length; i++) { var it = sel[i]; try { if (it instanceof FootageItem && it.file && !seen[it.file.fsName]) { seen[it.file.fsName] = 1; out.push({ path: it.file.fsName, name: it.name }); } } catch (e) {} }
      return cr__json({ ok: true, items: out });
    }
    var comp = ae__comp(); if (!comp) return ae__noComp();
    var ls = comp.selectedLayers || [];
    for (var j = 0; j < ls.length; j++) { var l = ls[j]; if (!ae__isFootage(l) || !l.hasVideo) continue; out.push({ path: l.source.file.fsName, from: ae__srcTime(l, l.inPoint), at: l.inPoint, name: l.name }); }
    out.sort(function (x, y) { return x.at - y.at; });
    return cr__json({ ok: true, items: out });
  } catch (e) { return cr__fail(e); }
}
function cr_disable(s) {
  try {
    var a = cr__args(s), comp = ae__comp(); if (!comp) return ae__noComp();
    var n = 0, refs = a.refs || [];
    for (var i = 0; i < refs.length; i++) { var l = ae__find(comp, refs[i]); if (l) { try { l.enabled = a.on === false; n++; } catch (e) {} } }
    return cr__json({ ok: true, n: n });
  } catch (e) { return cr__fail(e); }
}

/* keyframe curves: every animated number on the selected layers (Transform, effects, text…) */
function ae__walkProps(g, path, fn) {
  for (var i = 1; i <= g.numProperties; i++) {
    var p = g.property(i); if (!p) continue;
    var pp = path.concat([i]);
    if (p.propertyType === PropertyType.PROPERTY) fn(p, pp); else ae__walkProps(p, pp, fn);
  }
}
function ae__propAt(l, path) { var p = l; for (var i = 0; i < path.length; i++) { p = p.property(path[i]); if (!p) return null; } return p; }
function ae__num(v) { if (typeof v === 'number') return true; if (v && v.length) { for (var i = 0; i < v.length; i++) if (typeof v[i] !== 'number') return false; return true; } return false; }
function cr_kfList(s) {
  try {
    var comp = ae__comp(); if (!comp) return ae__noComp();
    var sel = comp.selectedLayers || [], out = [];
    for (var i = 0; i < sel.length; i++) {
      var l = sel[i], ref = { id: String(l.id), track: l.index, name: l.name, start: 0, inPoint: 0 };
      ae__walkProps(l, [], function (p, path) {
        try { if (p.numKeys < 2) return; } catch (e) { return; }
        var keys = [];
        for (var k = 1; k <= p.numKeys; k++) { var v = p.keyValue(k); if (!ae__num(v)) return; var vv = typeof v === 'number' ? v : []; if (typeof v !== 'number') for (var q = 0; q < v.length; q++) vv.push(v[q]); keys.push([p.keyTime(k), vv]); }
        var gname = ''; try { gname = p.parentProperty.name; } catch (e) {}
        out.push({ clip: ref, comp: path.join('.'), prop: 0, cname: gname || 'Layer', pname: p.name, keys: keys });
      });
    }
    return cr__json({ ok: true, params: out, t: comp.time, fps: comp.frameRate, selected: sel.length });
  } catch (e) { return cr__fail(e); }
}
function ae__kfParam(a) {
  var comp = ae__comp(); if (!comp) return null;
  var l = ae__find(comp, a.clip); if (!l) return null;
  var path = String(a.comp).split('.'); for (var i = 0; i < path.length; i++) path[i] = Number(path[i]);
  return ae__propAt(l, path);
}
function cr_kfAdd(s) {
  try {
    var a = cr__args(s), p = ae__kfParam(a); if (!p) return cr__json({ ok: false, error: 'clip_moved' });
    var keys = a.keys || [];
    ae__undo('ENP', function () {
      for (var i = 0; i < keys.length; i++) {
        var v = keys[i][1], val = (v && v.length === 1 && p.propertyValueType === PropertyValueType.OneD) ? v[0] : v;
        var k = p.addKey(keys[i][0]); p.setValueAtKey(k, val);
        if (a.linear) { try { p.setInterpolationTypeAtKey(k, KeyframeInterpolationType.LINEAR, KeyframeInterpolationType.LINEAR); } catch (e) {} }
      }
    });
    return cr__json({ ok: true, n: keys.length });
  } catch (e) { return cr__fail(e); }
}
function cr_kfRemove(s) {
  try {
    var a = cr__args(s), p = ae__kfParam(a); if (!p) return cr__json({ ok: false, error: 'clip_moved' });
    var n = 0, ts = a.times || [];
    ae__undo('ENP', function () {
      for (var i = 0; i < ts.length; i++) { if (!p.numKeys) break; var k = p.nearestKeyIndex(ts[i]); if (Math.abs(p.keyTime(k) - ts[i]) < 0.0005) { p.removeKey(k); n++; } }
    });
    return cr__json({ ok: true, n: n });
  } catch (e) { return cr__fail(e); }
}
