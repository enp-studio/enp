#!/bin/bash
# ENP — installer for DaVinci Resolve Studio on macOS (asks for your Mac password once)
cd "$(dirname "$0")"
SRC="$(pwd)/ENP-Resolve"
SUP="/Library/Application Support/Blackmagic Design/DaVinci Resolve"
ROOT="$SUP/Workflow Integration Plugins"
DST="$ROOT/ENP"
echo ""
echo "   ENP - Editing Power Tools for DaVinci Resolve"
echo "   ------------------------------------------------"
if [ ! -f "$SRC/main.js" ]; then echo "   Unzip everything first, then run this again."; read -n1 -r -p "   Press any key..."; exit 1; fi
if [ ! -d "$SUP" ]; then echo "   DaVinci Resolve was not found on this Mac (install it and open it once first)."; read -n1 -r -p "   Press any key..."; exit 1; fi
echo "   [1/3] Installing the plugin (your Mac password may be asked)..."
sudo mkdir -p "$DST"
sudo find "$DST" -mindepth 1 -maxdepth 1 ! -name "_backup" ! -name "runtime" -exec rm -rf {} +
sudo cp -R "$SRC/." "$DST/"
sudo mkdir -p "$DST/runtime"
sudo chown -R "$(id -un)" "$DST"
xattr -dr com.apple.quarantine "$DST" 2>/dev/null
echo "   [2/3] Connecting it to DaVinci Resolve..."
NODE="$SUP/Developer/Workflow Integrations/Examples/SamplePlugin/WorkflowIntegration.node"
if [ -f "$NODE" ]; then cp "$NODE" "$DST/WorkflowIntegration.node"; echo "         ready."; else echo "         Resolve's plugin bridge was not found: Workflow Integration plugins need DaVinci Resolve STUDIO."; fi
echo "   [3/3] ffmpeg..."
FF="$DST/runtime/ffmpeg"
if [ ! -x "$FF" ]; then for c in "$HOME/Library/Application Support/Adobe/CEP/extensions/ENP/runtime/ffmpeg" /opt/homebrew/bin/ffmpeg /usr/local/bin/ffmpeg /opt/local/bin/ffmpeg; do if [ -x "$c" ]; then cp "$c" "$FF"; chmod +x "$FF"; break; fi; done; fi
if [ -x "$FF" ]; then echo "         ready."; else echo "         ENP will download it by itself the first time you render."; fi
echo ""
echo "   Installed. Restart DaVinci Resolve, then: Workspace > Workflow Integrations > ENP"
echo ""
read -n1 -r -p "   Press any key to close..."
