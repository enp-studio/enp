/* Carousel 3D — Premiere Pro side (ExtendScript).
   Every function takes one JSON string and returns a JSON string. */

function cr__q(s) {
  return '"' + String(s).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\r/g, '\\r').replace(/\n/g, '\\n').replace(/\t/g, '\\t') + '"';
}
function cr__json(v) {
  if (v === null || v === undefined) return 'null';
  var t = typeof v;
  if (t === 'number') return isFinite(v) ? String(v) : 'null';
  if (t === 'boolean') return v ? 'true' : 'false';
  if (t === 'string') return cr__q(v);
  if (v instanceof Array) { var a = []; for (var i = 0; i < v.length; i++) a.push(cr__json(v[i])); return '[' + a.join(',') + ']'; }
  var o = [];
  for (var k in v) if (v.hasOwnProperty(k)) o.push(cr__q(k) + ':' + cr__json(v[k]));
  return '{' + o.join(',') + '}';
}
function cr__args(s) { try { return s ? eval('(' + s + ')') : {}; } catch (e) { return {}; } }
function cr__fail(e) { return cr__json({ ok: false, error: String(e && e.message ? e.message : e) }); }
function cr__norm(p) { return String(p || '').replace(/\\/g, '/').toLowerCase(); }
function cr__fps(seq) {
  try { var tb = Number(seq.timebase); if (tb > 0) return 254016000000 / tb; } catch (e) {}
  try { var st = seq.getSettings(); return 1 / st.videoFrameRate.seconds; } catch (e2) {}
  return 30;
}

/* sequence, playhead, frame size, frame rate, project folder */
function cr_info() {
  try {
    var seq = app.project.activeSequence, dir = '';
    try { var pp = String(app.project.path || ''); dir = pp.replace(/[\\\/][^\\\/]*$/, ''); } catch (e) {}
    if (!seq) return cr__json({ ok: true, hasSequence: false, dir: dir });
    return cr__json({
      ok: true, hasSequence: true, t: seq.getPlayerPosition().seconds,
      w: Number(seq.frameSizeHorizontal), h: Number(seq.frameSizeVertical), fps: cr__fps(seq), dir: dir, name: seq.name
    });
  } catch (e) { return cr__fail(e); }
}

/* pictures / clips the editor has selected */
function cr_pick(s) {
  try {
    var a = cr__args(s), out = [], seen = {};
    if (a.from === 'project') {
      var sel = app.getCurrentProjectViewSelection ? app.getCurrentProjectViewSelection() : null;
      if (sel) for (var i = 0; i < sel.length; i++) {
        var pi = sel[i], mp = '';
        try { mp = pi.getMediaPath(); } catch (e) {}
        if (mp && !seen[mp]) { seen[mp] = 1; out.push({ path: mp, name: pi.name }); }
      }
      return cr__json({ ok: true, items: out });
    }
    var seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var items = seq.getSelection(), list = [];
    for (var j = 0; j < items.length; j++) {
      var ti = items[j], p2 = '';
      try { if (ti.mediaType && ti.mediaType !== 'Video') continue; } catch (e) {}
      try { p2 = ti.projectItem ? ti.projectItem.getMediaPath() : ''; } catch (e) {}
      if (!p2) continue;
      var key = p2 + '|' + ti.inPoint.seconds;
      if (seen[key]) continue; seen[key] = 1;
      list.push({ path: p2, from: ti.inPoint.seconds, at: ti.start.seconds, name: ti.name });
    }
    list.sort(function (x, y) { return x.at - y.at; });
    return cr__json({ ok: true, items: list });
  } catch (e) { return cr__fail(e); }
}

/* the single video clip the editor has selected on the timeline — used by "عدّل في ENP".
   returns its media path, start, duration and a ref so the edit can replace it in place. */
function cr_sel1() {
  try {
    var seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var items = seq.getSelection(), pick = null, n = 0;
    for (var j = 0; j < items.length; j++) {
      var ti = items[j];
      try { if (ti.mediaType && ti.mediaType !== 'Video') continue; } catch (e) {}
      var mp = ''; try { mp = ti.projectItem ? ti.projectItem.getMediaPath() : ''; } catch (e2) {}
      if (!mp) continue;
      n++; if (!pick) pick = ti;
    }
    if (!pick) return cr__json({ ok: false, error: 'no_selection' });
    var path = ''; try { path = pick.projectItem.getMediaPath(); } catch (e3) {}
    var id = ''; try { id = String(pick.nodeId); } catch (e4) {}
    var name = ''; try { name = pick.projectItem.name; } catch (e5) {}
    return cr__json({
      ok: true, count: n, path: path, name: name,
      at: pick.start.seconds, dur: pick.end.seconds - pick.start.seconds,
      ref: { id: id }
    });
  } catch (e) { return cr__fail(e); }
}

/* drop a .mogrt on the timeline above everything at `at` (or the playhead). If `dur` is given
   (e.g. "طبّق على القطع المحددة") the graphic is trimmed/extended to exactly that length.
   The result stays a live Essential Graphics clip: everything is editable in Premiere. */
function cr_mogrt(s) {
  try {
    var a = cr__args(s), seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    if (!seq.importMGT) return cr__json({ ok: false, error: 'no_mgt_api' });
    var t0 = (a.at !== undefined && a.at !== null) ? Number(a.at) : seq.getPlayerPosition().seconds;
    var guess = Number(a.dur) > 0 ? Number(a.dur) : 5;
    var vt = seq.videoTracks, top = -1;
    for (var i = 0; i < vt.numTracks; i++) if (!cr__free(vt[i], t0, t0 + guess)) top = i;
    var vi = cr__trackAbove(seq, top, t0, t0 + guess);
    if (vi < 0) return cr__json({ ok: false, error: 'no_free_track' });
    var ticks = String(Math.round(t0 * 254016000000));
    var item = seq.importMGT(String(a.path), ticks, vi, 0);
    if (!item) return cr__json({ ok: false, error: 'import_failed' });
    if (Number(a.dur) > 0) {
      try { var e = new Time(); e.seconds = t0 + Number(a.dur); item.end = e; } catch (e2) {}
    }
    var nm = ''; try { nm = item.name; } catch (e3) {}
    return cr__json({ ok: true, track: 'V' + (vi + 1), name: nm, at: t0, dur: item.end.seconds - item.start.seconds });
  } catch (e) { return cr__fail(e); }
}

/* every video clip (cut) the editor has selected on the timeline, each with its start + duration.
   used by "طبّق على الشوتات المحددة": one text (or effect) per selected cut, timed to that cut.
   skips clips ENP itself placed, so re-running over a section doesn't stack on old ENP clips. */
function cr_selclips() {
  try {
    var seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var items = seq.getSelection(), out = [], seen = {};
    for (var j = 0; j < items.length; j++) {
      var ti = items[j];
      try { if (ti.mediaType && ti.mediaType !== 'Video') continue; } catch (e) {}
      var nm = ''; try { nm = ti.projectItem ? ti.projectItem.name : ''; } catch (e2) {}
      if (/^(Carousel3D|AmarText|AmarGlass|ENP)[_ ]/.test(nm)) continue;   // skip ENP's own renders
      var a = ti.start.seconds, b = ti.end.seconds, k = a.toFixed(3) + '|' + b.toFixed(3);
      if (seen[k]) continue; seen[k] = 1;
      out.push({ at: a, dur: b - a, name: nm });
    }
    out.sort(function (x, y) { return x.at - y.at; });
    return cr__json({ ok: true, count: out.length, clips: out });
  } catch (e) { return cr__fail(e); }
}

/* sequence markers between two times */
function cr_markers(s) {
  try {
    var a = cr__args(s), seq = app.project.activeSequence, out = [];
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var ms = seq.markers, m = ms.getFirstMarker(), guard = 0;
    while (m && guard++ < 2000) {
      var t = m.start.seconds;
      if (t >= a.from - 0.001 && t <= a.to + 0.001) out.push(t);
      m = ms.getNextMarker(m);
    }
    out.sort(function (x, y) { return x - y; });
    return cr__json({ ok: true, markers: out });
  } catch (e) { return cr__fail(e); }
}

/* the picture under the playhead (top clip that isn't one of ours) */
function cr_under(s) {
  try {
    var seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var t = seq.getPlayerPosition().seconds, vt = seq.videoTracks;
    for (var i = vt.numTracks - 1; i >= 0; i--) {
      var tr = vt[i];
      for (var j = 0; j < tr.clips.numItems; j++) {
        var c = tr.clips[j];
        if (c.start.seconds <= t && c.end.seconds > t && c.projectItem) {
          if (/^(Carousel3D|AmarText|AmarGlass|ENP)_/.test(c.projectItem.name)) continue;
          var p = ''; try { p = c.projectItem.getMediaPath(); } catch (e) {}
          if (!p) continue;
          return cr__json({ ok: true, path: p, src: t - c.start.seconds + c.inPoint.seconds });
        }
      }
    }
    return cr__json({ ok: true, none: true });
  } catch (e) { return cr__fail(e); }
}

function cr__bin(name) {
  var root = app.project.rootItem;
  for (var i = 0; i < root.children.numItems; i++) {
    var c = root.children[i];
    if (c.name === name && c.type === 2) return c;   // 2 = bin
  }
  return root.createBin(name);
}
function cr__findItem(bin, p) {
  var want = cr__norm(p);
  for (var i = bin.children.numItems - 1; i >= 0; i--) {
    var c = bin.children[i], mp = '';
    try { mp = c.getMediaPath(); } catch (e) {}
    if (cr__norm(mp) === want) return c;
  }
  return null;
}
function cr__free(track, a, b) {
  for (var i = 0; i < track.clips.numItems; i++) {
    var c = track.clips[i];
    if (c.start.seconds < b - 0.001 && c.end.seconds > a + 0.001) return false;
  }
  return true;
}
function cr__addTrack(seq) {
  try {
    app.enableQE();
    var q = qe.project.getActiveSequence();
    q.addTracks(1, seq.videoTracks.numTracks, 0);
    return true;
  } catch (e) { return false; }
}
/* first free track above index `above`, adding one when needed */
function cr__trackAbove(seq, above, a, b) {
  for (var i = above + 1; i < seq.videoTracks.numTracks; i++) if (cr__free(seq.videoTracks[i], a, b)) return i;
  if (cr__addTrack(seq)) {
    var n = seq.videoTracks.numTracks - 1;
    if (n > above && cr__free(seq.videoTracks[n], a, b)) return n;
  }
  return -1;
}
function cr__removeNamed(seq, names) {
  var n = 0, set = {};
  for (var k = 0; k < names.length; k++) set[names[k]] = 1;
  for (var i = 0; i < seq.videoTracks.numTracks; i++) {
    var tr = seq.videoTracks[i];
    for (var j = tr.clips.numItems - 1; j >= 0; j--) {
      var c = tr.clips[j];
      try { if (c.projectItem && set[c.projectItem.name]) { c.remove(false, true); n++; } } catch (e) {}
    }
  }
  return n;
}

/* import the rendered file(s) and lay them on the timeline at `at` */
function cr_place(s) {
  try {
    var a = cr__args(s), seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    if (a.replace && a.replace.length) cr__removeNamed(seq, a.replace);
    var bin = cr__bin(a.bin || 'ENP Carousel');
    var paths = [a.front]; if (a.back) paths.push(a.back);
    app.project.importFiles(paths, true, bin, false);
    var front = cr__findItem(bin, a.front), back = a.back ? cr__findItem(bin, a.back) : null;
    if (!front || (a.back && !back)) return cr__json({ ok: false, error: 'import_failed' });

    var t0 = Number(a.at) || 0, t1 = t0 + (Number(a.duration) || 1);
    var vt = seq.videoTracks, top = -1, under = -1;
    for (var i = 0; i < vt.numTracks; i++) {
      if (!cr__free(vt[i], t0, t1)) top = i;
      if (under < 0) {
        for (var j = 0; j < vt[i].clips.numItems; j++) { var c = vt[i].clips[j]; if (c.start.seconds <= t0 + 0.001 && c.end.seconds > t0) { under = i; break; } }
      }
    }
    var at = new Time(); at.seconds = t0;
    var res = { ok: true, names: [front.name], backAbove: false };

    if (back) {
      /* the back layer goes under the speaker's clip if there is a free track below it */
      var speaker = under >= 0 ? under : top, bi = -1;
      for (var b = speaker - 1; b >= 0; b--) if (cr__free(vt[b], t0, t1)) { bi = b; break; }
      if (bi < 0) {
        bi = cr__trackAbove(seq, top, t0, t1);
        if (bi < 0) return cr__json({ ok: false, error: 'no_free_track' });
        res.backAbove = true;
      }
      seq.videoTracks[bi].overwriteClip(back, at);
      res.back = 'V' + (bi + 1); res.names.push(back.name);
      if (bi > top) top = bi;
    }
    var fi = cr__trackAbove(seq, top, t0, t1);
    if (fi < 0) return cr__json({ ok: false, error: 'no_free_track' });
    seq.videoTracks[fi].overwriteClip(front, at);
    res.track = 'V' + (fi + 1);
    try { var placed = cr__findClip(seq, { track: fi, start: t0 }); if (placed) res.ref = { track: fi, start: placed.start.seconds, id: String(placed.nodeId) }; } catch (e) {}
    return cr__json(res);
  } catch (e) { return cr__fail(e); }
}

function cr_remove(s) {
  try {
    var a = cr__args(s), seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    return cr__json({ ok: true, removed: cr__removeNamed(seq, a.names || []) });
  } catch (e) { return cr__fail(e); }
}

/* ===================== shared: clips, Motion, keyframes ===================== */
function cr_seek(s) {
  try {
    var a = cr__args(s), seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    seq.setPlayerPosition(String(Math.round(Number(a.t) * 254016000000)));
    return cr__json({ ok: true });
  } catch (e) { return cr__fail(e); }
}
function cr__motion(clip) {
  for (var i = 0; i < clip.components.numItems; i++) {
    var c = clip.components[i];
    try { if (c.matchName === 'AE.ADBE Motion') return c; } catch (e) {}
  }
  for (var j = 0; j < clip.components.numItems; j++) if (clip.components[j].displayName === 'Motion') return clip.components[j];
  return null;
}
/* Motion parameters by position: 0 Position, 1 Scale, 2 Scale Width, 3 Uniform, 4 Rotation, 5 Anchor Point */
function cr__param(clip, which) {
  var m = cr__motion(clip); if (!m) return null;
  var idx = { pos: 0, scale: 1, scalew: 2, uniform: 3, rot: 4, anchor: 5 }[which];
  return m.properties[idx];
}
function cr__clipInfo(clip, ti) {
  var o = { track: ti, start: clip.start.seconds, end: clip.end.seconds, inPoint: clip.inPoint.seconds, name: clip.name, id: '', path: '' };
  try { o.id = String(clip.nodeId); } catch (e) {}
  try { o.path = clip.projectItem ? clip.projectItem.getMediaPath() : ''; } catch (e) {}
  o.speed = cr__speed(clip);
  try {
    var ps = cr__param(clip, 'scale'), pp = cr__param(clip, 'pos'), pa = cr__param(clip, 'anchor');
    o.keyed = !!(ps.isTimeVarying() || pp.isTimeVarying());
    o.scale = ps.getValue();
    if (ps.isTimeVarying()) { try { o.scale = ps.getValueAtTime(clip.inPoint.seconds); } catch (e3) {} }
    if (typeof o.scale !== 'number' || !(o.scale > 0)) o.scale = 100;
    try { var pu = cr__param(clip, 'uniform'); o.uniform = pu ? !!pu.getValue() : true; if (!o.uniform) { var pw = cr__param(clip, 'scalew'); o.scalew = pw.isTimeVarying() ? pw.getValueAtTime(clip.inPoint.seconds) : pw.getValue(); } } catch (eu) { o.uniform = true; }
    var pv = pp.getValue(), av = pa.getValue();
    o.pos = [pv[0], pv[1]]; o.anchor = [av[0], av[1]];
    try { var pr = cr__param(clip, 'rot'); if (!pr.isTimeVarying()) o.rot = pr.getValue(); } catch (e4) {}
    try { for (var oi = 0; oi < clip.components.numItems; oi++) { var oc = clip.components[oi]; if (oc.matchName === 'AE.ADBE Opacity') { var opp = oc.properties[0]; if (!opp.isTimeVarying()) o.opacity = opp.getValue(); break; } } } catch (e5) {}
  } catch (e2) { o.noMotion = true; }
  return o;
}
function cr__findClip(seq, ref) {
  var tr = seq.videoTracks[ref.track];
  if (tr) {
    for (var i = 0; i < tr.clips.numItems; i++) {
      var c = tr.clips[i];
      try { if (ref.id && String(c.nodeId) === ref.id) return c; } catch (e) {}
    }
    for (var j = 0; j < tr.clips.numItems; j++) if (Math.abs(tr.clips[j].start.seconds - ref.start) < 0.002) return tr.clips[j];
  }
  return null;
}
function cr__topAt(seq, t, a) {
  for (var i = seq.videoTracks.numTracks - 1; i >= 0; i--) {
    var tr = seq.videoTracks[i];
    for (var j = 0; j < tr.clips.numItems; j++) {
      var c = tr.clips[j];
      if (c.start.seconds <= t + 0.0005 && c.end.seconds > t && c.projectItem) {
        var mp = ''; try { mp = c.projectItem.getMediaPath(); } catch (e) {}
        if (/^(Carousel3D|AmarText|AmarGlass|ENP)_/.test(c.projectItem.name)) continue;
        if (mp || (a && a.nested)) return { clip: c, track: i };
      }
    }
  }
  return null;
}
/* selected video clips; if none, the top clip under the playhead */
function cr_clips(s) {
  try {
    var a = cr__args(s), seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var out = [], sel = seq.getSelection(), seen = {};
    for (var i = 0; i < sel.length; i++) {
      var ti = sel[i];
      try { if (ti.mediaType && ti.mediaType !== 'Video') continue; } catch (e) {}
      for (var k = 0; k < seq.videoTracks.numTracks; k++) {
        var tr = seq.videoTracks[k];
        for (var j = 0; j < tr.clips.numItems; j++) {
          var c = tr.clips[j];
          if (Math.abs(c.start.seconds - ti.start.seconds) < 0.0005 && c.name === ti.name && !seen[k + '|' + j]) { seen[k + '|' + j] = 1; out.push(cr__clipInfo(c, k)); }
        }
      }
    }
    var t = seq.getPlayerPosition().seconds;
    if (!out.length && a.fallback !== false) { var top = cr__topAt(seq, t, { nested: true }); if (top) out.push(cr__clipInfo(top.clip, top.track)); }
    return cr__json({
      ok: true, clips: out, t: t, w: Number(seq.frameSizeHorizontal), h: Number(seq.frameSizeVertical), fps: cr__fps(seq), selected: sel.length
    });
  } catch (e) { return cr__fail(e); }
}
/* the clip under the playhead, for tracking */
function cr_under2(s) {
  try {
    var a = cr__args(s), seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var t = (a.t !== undefined && a.t !== null) ? Number(a.t) + 0.001 : seq.getPlayerPosition().seconds, top = cr__topAt(seq, t);
    if (!top) return cr__json({ ok: true, none: true, t: t });
    var o = cr__clipInfo(top.clip, top.track);
    var spd = 1; try { spd = top.clip.getSpeed(); if (!(spd > 0)) spd = 1; } catch (e) {}
    o.speed = spd; o.src = (t - top.clip.start.seconds) * spd + top.clip.inPoint.seconds;
    return cr__json({ ok: true, clip: o, t: t, w: Number(seq.frameSizeHorizontal), h: Number(seq.frameSizeVertical), fps: cr__fps(seq) });
  } catch (e) { return cr__fail(e); }
}
function cr__addKey(p, kt) { try { p.addKey(kt); } catch (e) { var tm = new Time(); tm.seconds = kt; p.addKey(tm); } }
function cr__setKey(p, kt, v, ui) { try { p.setValueAtKey(kt, v, ui); } catch (e) { var tm = new Time(); tm.seconds = kt; p.setValueAtKey(tm, v, ui); } }
/* keys: [[seqSeconds, value], ...]; value = number (scale) or [x, y] (position, 0..1 of the frame)
   reset: wipe the parameter's keyframes first. Key times are in the clip's media time. */
function cr_keys(s) {
  try {
    var a = cr__args(s), seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var clip = cr__findClip(seq, a.clip);
    if (!clip) return cr__json({ ok: false, error: 'clip_moved' });
    var p = cr__param(clip, a.prop);
    if (!p) return cr__json({ ok: false, error: 'no_motion' });
    if (a.reset) { if (p.isTimeVarying()) p.setTimeVarying(false); }
    if (a.value !== undefined && a.value !== null) p.setValue(a.value, true);
    var keys = a.keys || [];
    if (keys.length) {
      if (!p.isTimeVarying()) p.setTimeVarying(true);
      /* sequence time -> the clip's media time (speed changes included) */
      var st0 = clip.start.seconds, in0 = clip.inPoint.seconds, spd = cr__speed(clip), n = 0;
      for (var i = 0; i < keys.length; i++) {
        var kt = in0 + (keys[i][0] - st0) * spd;
        cr__addKey(p, kt); cr__setKey(p, kt, keys[i][1], i === keys.length - 1); n++;
      }
      return cr__json({ ok: true, n: n });
    }
    return cr__json({ ok: true, n: 0 });
  } catch (e) { return cr__fail(e); }
}
/* back to how it was: no keyframes, the saved values */
function cr_unkey(s) {
  try {
    var a = cr__args(s), seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var clip = cr__findClip(seq, a.clip);
    if (!clip) return cr__json({ ok: false, error: 'clip_moved' });
    var props = a.props || ['scale', 'pos'];
    for (var i = 0; i < props.length; i++) {
      var p = cr__param(clip, props[i]); if (!p) continue;
      if (p.isTimeVarying()) p.setTimeVarying(false);
      if (a.base && a.base[props[i]] !== undefined && a.base[props[i]] !== null) p.setValue(a.base[props[i]], true);
    }
    return cr__json({ ok: true });
  } catch (e) { return cr__fail(e); }
}

/* ===================== sound effects ===================== */
function cr_sfx(s) {
  try {
    var a = cr__args(s), seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var bin = cr__bin('SFX'), item = cr__findItem(bin, a.path);
    if (!item) { app.project.importFiles([a.path], true, bin, false); item = cr__findItem(bin, a.path); }
    if (!item) return cr__json({ ok: false, error: 'import_failed' });
    var t0 = a.at !== undefined && a.at !== null ? Number(a.at) : seq.getPlayerPosition().seconds;
    var dur = Number(a.dur) || 0;
    try { if (!dur) dur = item.getOutPoint().seconds - item.getInPoint().seconds; } catch (e) {}
    if (!(dur > 0)) dur = 1;
    var at = seq.audioTracks, idx = -1;
    for (var i = 0; i < at.numTracks; i++) if (cr__free(at[i], t0, t0 + dur)) { idx = i; break; }
    if (idx < 0) {
      try { app.enableQE(); qe.project.getActiveSequence().addTracks(0, 0, 1, 1, at.numTracks); } catch (e) {}
      for (var j = 0; j < seq.audioTracks.numTracks; j++) if (cr__free(seq.audioTracks[j], t0, t0 + dur)) { idx = j; break; }
    }
    if (idx < 0) return cr__json({ ok: false, error: 'no_free_track' });
    var tm = new Time(); tm.seconds = t0;
    seq.audioTracks[idx].overwriteClip(item, tm);
    return cr__json({ ok: true, track: 'A' + (idx + 1), at: t0 });
  } catch (e) { return cr__fail(e); }
}

/* ===================== keyframe curves ===================== */
function cr__isNumVal(v) {
  if (typeof v === 'number') return isFinite(v);
  if (v && v.length !== undefined && v.length > 0 && v.length <= 4) { for (var i = 0; i < v.length; i++) if (typeof v[i] !== 'number') return false; return true; }
  return false;
}
function cr__trackItemRef(seq, ti) {
  var groups = [['v', seq.videoTracks], ['a', seq.audioTracks]];
  for (var g = 0; g < groups.length; g++) {
    var tracks = groups[g][1];
    for (var k = 0; k < tracks.numTracks; k++) {
      var tr = tracks[k];
      for (var j = 0; j < tr.clips.numItems; j++) {
        var c = tr.clips[j];
        if (Math.abs(c.start.seconds - ti.start.seconds) < 0.0005 && c.name === ti.name) {
          var id = ''; try { id = String(c.nodeId); } catch (e) {}
          return { type: groups[g][0], track: k, start: c.start.seconds, inPoint: c.inPoint.seconds, end: c.end.seconds, id: id, name: c.name, clip: c };
        }
      }
    }
  }
  return null;
}
function cr__findAny(seq, ref) {
  var tracks = ref.type === 'a' ? seq.audioTracks : seq.videoTracks, tr = tracks[ref.track];
  if (!tr) return null;
  for (var i = 0; i < tr.clips.numItems; i++) { var c = tr.clips[i]; try { if (ref.id && String(c.nodeId) === ref.id) return c; } catch (e) {} }
  for (var j = 0; j < tr.clips.numItems; j++) if (Math.abs(tr.clips[j].start.seconds - ref.start) < 0.002) return tr.clips[j];
  return null;
}
function cr__secs(t) { return (t && t.seconds !== undefined) ? t.seconds : Number(t); }
function cr_kfList(s) {
  try {
    var seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var sel = seq.getSelection(), out = [], seen = {};
    for (var i = 0; i < sel.length; i++) {
      var ref = cr__trackItemRef(seq, sel[i]); if (!ref) continue;
      var key = ref.type + ref.track + '|' + ref.start; if (seen[key]) continue; seen[key] = 1;
      var c = ref.clip; delete ref.clip;
      for (var ci = 0; ci < c.components.numItems; ci++) {
        var comp = c.components[ci];
        for (var pi = 0; pi < comp.properties.numItems; pi++) {
          var p = comp.properties[pi], tv = false;
          try { tv = p.isTimeVarying(); } catch (e) {}
          if (!tv) continue;
          var ks = []; try { ks = p.getKeys() || []; } catch (e) { ks = []; }
          if (ks.length < 2) continue;
          var keys = [], okv = true;
          for (var k = 0; k < ks.length; k++) {
            var v; try { v = p.getValueAtKey(ks[k]); } catch (e) { okv = false; break; }
            if (!cr__isNumVal(v)) { okv = false; break; }
            var vv = typeof v === 'number' ? v : []; if (typeof v !== 'number') for (var q = 0; q < v.length; q++) vv.push(v[q]);
            keys.push([cr__secs(ks[k]), vv]);
          }
          if (!okv) continue;
          out.push({ clip: ref, comp: ci, prop: pi, cname: comp.displayName, pname: p.displayName, keys: keys });
        }
      }
    }
    return cr__json({ ok: true, params: out, t: seq.getPlayerPosition().seconds, fps: cr__fps(seq), selected: sel.length });
  } catch (e) { return cr__fail(e); }
}
function cr__param2(seq, a) {
  var c = cr__findAny(seq, a.clip); if (!c) return null;
  var comp = c.components[a.comp]; if (!comp) return null;
  return comp.properties[a.prop] || null;
}
function cr_kfAdd(s) {
  try {
    var a = cr__args(s), seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var p = cr__param2(seq, a); if (!p) return cr__json({ ok: false, error: 'clip_moved' });
    var keys = a.keys || [];
    for (var i = 0; i < keys.length; i++) {
      cr__addKey(p, keys[i][0]); cr__setKey(p, keys[i][0], keys[i][1], i === keys.length - 1);
      if (a.linear) { try { p.setInterpolationTypeAtKey(keys[i][0], 0, false); } catch (e) {} }
    }
    return cr__json({ ok: true, n: keys.length });
  } catch (e) { return cr__fail(e); }
}
function cr_kfRemove(s) {
  try {
    var a = cr__args(s), seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var p = cr__param2(seq, a); if (!p) return cr__json({ ok: false, error: 'clip_moved' });
    var n = 0, ts = a.times || [];
    for (var i = 0; i < ts.length; i++) {
      try { p.removeKey(ts[i]); n++; } catch (e) { try { var tm = new Time(); tm.seconds = ts[i]; p.removeKey(tm); n++; } catch (e2) {} }
    }
    return cr__json({ ok: true, n: n });
  } catch (e) { return cr__fail(e); }
}

/* ===================== smart cut (silences) ===================== */
function cr_clone(s) {
  try {
    var seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var name = seq.name;
    seq.clone();
    return cr__json({ ok: true, name: name + ' Copy' });
  } catch (e) { return cr__fail(e); }
}
function cr__tc(seq, sec) {
  var t = new Time(); t.seconds = sec;
  var st = seq.getSettings();
  return t.getFormatted(st.videoFrameRate, st.videoDisplayFormat);
}
function cr__locked(tr) { try { return tr.isLocked(); } catch (e) { return false; } }
/* Smart cut, in two steps so nothing depends on Premiere's ripple / sync-lock settings:
   1) cr_cutRazor: split every track at each cut's edges and delete what lies inside (no ripple)
   2) cr_cutCompact: slide every clip left by the time removed before it, checking each one landed */
function cr_cutMarkers(s) {
  try {
    var a = cr__args(s), seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var cuts = a.cuts || [], n = 0;
    for (var m = 0; m < cuts.length; m++) {
      var mk = seq.markers.createMarker(cuts[m][0]);
      try { mk.name = 'سكتة'; var et = new Time(); et.seconds = cuts[m][1]; mk.end = et; } catch (e) {}
      try { mk.setColorByIndex(1); } catch (e2) {}
      n++;
    }
    return cr__json({ ok: true, done: n });
  } catch (e) { return cr__fail(e); }
}
function cr__groups(seq) {
  app.enableQE();
  var q = qe.project.getActiveSequence();
  return [[seq.videoTracks, function (i) { return q.getVideoTrackAt(i); }], [seq.audioTracks, function (i) { return q.getAudioTrackAt(i); }]];
}
function cr_cutRazor(s) {
  try {
    var a = cr__args(s), seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var cuts = a.cuts || [], eps = 0.0005, groups = cr__groups(seq), removed = 0;
    for (var c = 0; c < cuts.length; c++) {
      var t0 = cuts[c][0], t1 = cuts[c][1];
      if (!(t1 - t0 > 0.01)) continue;
      var tc0 = cr__tc(seq, t0), tc1 = cr__tc(seq, t1);
      for (var g = 0; g < groups.length; g++) {
        var tracks = groups[g][0];
        for (var i = 0; i < tracks.numTracks; i++) {
          var tr = tracks[i]; if (cr__locked(tr)) continue;
          var sp0 = false, sp1 = false;
          for (var j = 0; j < tr.clips.numItems; j++) {
            var cl = tr.clips[j];
            if (cl.start.seconds < t0 - eps && cl.end.seconds > t0 + eps) sp0 = true;
            if (cl.start.seconds < t1 - eps && cl.end.seconds > t1 + eps) sp1 = true;
          }
          var qt = groups[g][1](i);
          if (sp1) qt.razor(tc1);
          if (sp0) qt.razor(tc0);
          for (var k = tr.clips.numItems - 1; k >= 0; k--) {
            var it = tr.clips[k];
            if (it.start.seconds >= t0 - eps && it.end.seconds <= t1 + eps) { it.remove(false, false); removed++; }
          }
        }
      }
    }
    return cr__json({ ok: true, removed: removed });
  } catch (e) { return cr__fail(e); }
}
function cr_cutCompact(s) {
  try {
    var a = cr__args(s), seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var cuts = (a.cuts || []).slice().sort(function (x, y) { return x[0] - y[0]; }), eps = 0.0005;
    function shiftAt(t) { var sh = 0; for (var i = 0; i < cuts.length; i++) if (cuts[i][1] <= t + eps) sh += cuts[i][1] - cuts[i][0]; return sh; }
    var all = [seq.videoTracks, seq.audioTracks], plan = [];
    for (var g = 0; g < all.length; g++) {
      for (var i = 0; i < all[g].numTracks; i++) {
        var tr = all[g][i]; if (cr__locked(tr)) continue;
        for (var j = 0; j < tr.clips.numItems; j++) {
          var st0 = tr.clips[j].start.seconds, sh = shiftAt(st0);
          if (sh > 0.0005) plan.push({ tr: tr, k: j, orig: st0, want: st0 - sh });
        }
      }
    }
    /* earliest first, across all tracks, so a clip never lands on one that hasn't moved yet */
    plan.sort(function (x, y) { return x.orig - y.orig; });
    var moved = 0;
    for (var p = 0; p < plan.length; p++) {
      var P = plan[p], it = P.tr.clips[P.k], delta = P.want - it.start.seconds;
      if (Math.abs(delta) < 0.001) continue;          // already there (it moved with its linked clip)
      var tm = new Time(); tm.seconds = delta; it.move(tm);   // move() shifts by an offset
      if (Math.abs(P.tr.clips[P.k].start.seconds - P.want) > 0.002) {
        // stop before anything gets overwritten; the gaps stay and can be closed by hand
        return cr__json({ ok: false, error: 'move_failed', moved: moved });
      }
      moved++;
    }
    return cr__json({ ok: true, moved: moved });
  } catch (e) { return cr__fail(e); }
}

/* a clip we placed, by its project item name */
function cr_findNamed(s) {
  try {
    var a = cr__args(s), seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var set = {}; for (var i = 0; i < (a.names || []).length; i++) set[a.names[i]] = 1;
    for (var k = 0; k < seq.videoTracks.numTracks; k++) {
      var tr = seq.videoTracks[k];
      for (var j = 0; j < tr.clips.numItems; j++) { var c = tr.clips[j]; try { if (c.projectItem && set[c.projectItem.name]) return cr__json({ ok: true, clip: cr__clipInfo(c, k) }); } catch (e) {} }
    }
    return cr__json({ ok: true, clip: null });
  } catch (e) { return cr__fail(e); }
}

/* captions: put an .srt in as Premiere's own caption track (2021+), or just import it */
function cr_srtCaptions(s) {
  try {
    var a = cr__args(s), seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var bin = cr__bin('ENP Captions');
    app.project.importFiles([a.path], true, bin, false);
    var item = cr__findItem(bin, a.path);
    if (!item) return cr__json({ ok: false, error: 'import_failed' });
    var at = new Time(); at.seconds = Number(a.at) || 0;
    try {
      var fmt = (typeof Sequence !== 'undefined' && Sequence.CAPTION_FORMAT_SUBTITLE !== undefined) ? Sequence.CAPTION_FORMAT_SUBTITLE : 'Subtitle';
      seq.createCaptionTrack(item, at.seconds, fmt);
      return cr__json({ ok: true, track: true });
    } catch (e) { return cr__json({ ok: true, track: false, detail: String(e) }); }
  } catch (e) { return cr__fail(e); }
}

/* ===================== v2.2: sequence audio, first cut, presets, live glass ===================== */
function cr__inout(seq) {
  var a = null, b = null;
  try { a = seq.getInPointAsTime().seconds; b = seq.getOutPointAsTime().seconds; } catch (e) {
    try { a = Number(seq.getInPoint()); b = Number(seq.getOutPoint()); } catch (e2) {}
  }
  return [a, b];
}
function cr__speed(c) { try { var s = c.getSpeed(); if (typeof s === 'number' && s > 0) return s; } catch (e) {} return 1; }
function cr__enabled(c) { try { if (c.disabled === true) return false; } catch (e) {} return true; }
function cr__muted(tr) { try { return !!tr.isMuted(); } catch (e) { return false; } }
function cr__selRange(seq) {
  var sel = seq.getSelection(), a = Infinity, b = -Infinity;
  for (var i = 0; i < sel.length; i++) { try { if (sel[i].start.seconds < a) a = sel[i].start.seconds; if (sel[i].end.seconds > b) b = sel[i].end.seconds; } catch (e) {} }
  return sel.length && b > a ? [a, b] : null;
}
/* every clip that makes sound, per audio track, plus the ranges the editor may mean */
function cr_audioClips(s) {
  try {
    var seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var tracks = [], clips = [], end = 0, at = seq.audioTracks;
    for (var i = 0; i < at.numTracks; i++) {
      var tr = at[i], n = 0;
      for (var j = 0; j < tr.clips.numItems; j++) {
        var c = tr.clips[j], p = '';
        try { p = c.projectItem ? c.projectItem.getMediaPath() : ''; } catch (e) {}
        if (c.end.seconds > end) end = c.end.seconds;
        if (!p || !cr__enabled(c)) continue;
        clips.push({ track: i, start: c.start.seconds, end: c.end.seconds, inPoint: c.inPoint.seconds, path: p, speed: cr__speed(c), name: c.name });
        n++;
      }
      var nm = ''; try { nm = tr.name; } catch (e) {}
      tracks.push({ i: i, name: nm || ('A' + (i + 1)), muted: cr__muted(tr), n: n });
    }
    for (var k = 0; k < seq.videoTracks.numTracks; k++) { var vt = seq.videoTracks[k]; for (var q = 0; q < vt.clips.numItems; q++) if (vt.clips[q].end.seconds > end) end = vt.clips[q].end.seconds; }
    var io = cr__inout(seq), inout = null;
    if (io[1] !== null && io[1] > io[0] + 0.05 && !(io[0] < 0.01 && Math.abs(io[1] - end) < 0.05) && io[1] < end + 1000) inout = [Math.max(0, io[0]), Math.min(end, io[1])];
    return cr__json({ ok: true, name: seq.name, id: String(seq.sequenceID), fps: cr__fps(seq), w: Number(seq.frameSizeHorizontal), h: Number(seq.frameSizeVertical),
      end: end, t: seq.getPlayerPosition().seconds, sel: cr__selRange(seq), inout: inout, tracks: tracks, clips: clips });
  } catch (e) { return cr__fail(e); }
}
/* everything on the sequence, for rebuilding it (first cut) */
function cr_seqDump(s) {
  try {
    var seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var out = { ok: true, name: seq.name, id: String(seq.sequenceID), fps: cr__fps(seq), w: Number(seq.frameSizeHorizontal), h: Number(seq.frameSizeVertical), v: [], a: [], skipped: 0 };
    try { var st = seq.getSettings(); out.sr = Number(st.audioSampleRate.seconds ? 1 / st.audioSampleRate.seconds : st.audioSampleRate) || 48000; } catch (e) { out.sr = 48000; }
    if (!(out.sr > 8000 && out.sr < 200000)) out.sr = 48000;
    var groups = [['v', seq.videoTracks], ['a', seq.audioTracks]];
    for (var g = 0; g < 2; g++) {
      var tracks = groups[g][1];
      for (var i = 0; i < tracks.numTracks; i++) {
        var tr = tracks[i], list = [];
        for (var j = 0; j < tr.clips.numItems; j++) {
          var c = tr.clips[j], p = '', id = '';
          try { p = c.projectItem ? c.projectItem.getMediaPath() : ''; } catch (e) {}
          try { id = String(c.nodeId); } catch (e) {}
          if (!p) { out.skipped++; continue; }
          list.push({ j: j, start: c.start.seconds, end: c.end.seconds, inPoint: c.inPoint.seconds, outPoint: c.outPoint.seconds, path: p, name: c.name, id: id, speed: cr__speed(c), on: cr__enabled(c) });
        }
        var nm = ''; try { nm = tr.name; } catch (e) {}
        out[groups[g][0]].push({ i: i, name: nm, locked: cr__locked(tr), muted: g === 1 ? cr__muted(tr) : false, clips: list });
      }
    }
    return cr__json(out);
  } catch (e) { return cr__fail(e); }
}
function cr__seqById(id) {
  var sq = app.project.sequences;
  for (var i = 0; i < sq.numSequences; i++) if (String(sq[i].sequenceID) === String(id)) return sq[i];
  return null;
}
/* import an FCP XML and open the sequence in it */
function cr_importXml(s) {
  try {
    var a = cr__args(s), before = {}, sq = app.project.sequences;
    for (var i = 0; i < sq.numSequences; i++) before[String(sq[i].sequenceID)] = 1;
    var bin = cr__bin(a.bin || 'ENP First Cut');
    app.project.importFiles([a.path], true, bin, false);
    var found = null; sq = app.project.sequences;
    for (var k = 0; k < sq.numSequences; k++) if (!before[String(sq[k].sequenceID)]) { if (!found || sq[k].name === a.name) found = sq[k]; }
    if (!found) return cr__json({ ok: false, error: 'import_failed' });
    try { if (a.name) found.name = a.name; } catch (e) {}
    try { app.project.openSequence(found.sequenceID); } catch (e) {}
    return cr__json({ ok: true, id: String(found.sequenceID), name: found.name });
  } catch (e) { return cr__fail(e); }
}
function cr__qeItem(isVideo, ti, startSec) {
  try {
    app.enableQE();
    var q = qe.project.getActiveSequence(), tr = isVideo ? q.getVideoTrackAt(ti) : q.getAudioTrackAt(ti);
    for (var i = 0; i < tr.numItems; i++) {
      var it = tr.getItemAt(i); if (!it || it.type === 'Empty') continue;
      var st = it.start && it.start.secs !== undefined ? Number(it.start.secs) : NaN;
      if (Math.abs(st - startSec) < 0.02) return it;
    }
  } catch (e) {}
  return null;
}
function cr__comp(clip, match, disp) {
  for (var i = 0; i < clip.components.numItems; i++) { var c = clip.components[i]; try { if (c.matchName === match) return c; } catch (e) {} }
  if (disp) for (var j = 0; j < clip.components.numItems; j++) if (clip.components[j].displayName === disp) return clip.components[j];
  return null;
}
var CR_FXNAMES = { 'AE.ADBE Gaussian Blur 2': ['Gaussian Blur', 'Flou gaussien', 'Gaußscher Weichzeichner', 'Desenfoque gaussiano', 'Sfocatura gaussiana'] };
function cr__addFx(clip, isVideo, ti, match, disp) {
  var have = cr__comp(clip, match); if (have) return have;
  var it = cr__qeItem(isVideo, ti, clip.start.seconds); if (!it) return null;
  var names = (CR_FXNAMES[match] || []).slice(); if (disp) names.unshift(disp);
  for (var k = 0; k < names.length; k++) {
    try { var fx = isVideo ? qe.project.getVideoEffectByName(names[k]) : qe.project.getAudioEffectByName(names[k]); if (fx) { isVideo ? it.addVideoEffect(fx) : it.addAudioEffect(fx); var c = cr__comp(clip, match, names[k]); if (c) return c; } } catch (e) {}
  }
  return null;
}
function cr__copyComp(src, dst) {
  var n = 0;
  for (var i = 0; i < src.properties.numItems && i < dst.properties.numItems; i++) {
    var p = src.properties[i], q = dst.properties[i];
    try { if (p.isTimeVarying()) continue; var v = p.getValue(); if (v === undefined || v === null) continue; q.setValue(v, true); n++; } catch (e) {}
  }
  return n;
}
/* after a first cut: give every new piece the look of the clip it came from (static values only) */
function cr_copyParams(s) {
  try {
    var a = cr__args(s), src = cr__seqById(a.src), dst = cr__seqById(a.dst);
    if (!src || !dst) return cr__json({ ok: false, error: 'no_sequence' });
    var done = 0, fx = 0, map = a.map || [];
    for (var m = 0; m < map.length; m++) {
      var M = map[m], isV = M.type === 'v';
      var st = isV ? src.videoTracks[M.track] : src.audioTracks[M.track], dt = isV ? dst.videoTracks[M.track] : dst.audioTracks[M.track];
      if (!st || !dt) continue;
      var sc = null; for (var i = 0; i < st.clips.numItems; i++) { var c = st.clips[i]; try { if (String(c.nodeId) === M.id) { sc = c; break; } } catch (e) {} if (Math.abs(c.start.seconds - M.srcStart) < 0.002) sc = c; }
      if (!sc) continue;
      var pieces = M.pieces || [];
      for (var k = 0; k < pieces.length; k++) {
        var dc = null; for (var j = 0; j < dt.clips.numItems; j++) if (Math.abs(dt.clips[j].start.seconds - pieces[k]) < 0.02) { dc = dt.clips[j]; break; }
        if (!dc) continue;
        for (var ci = 0; ci < sc.components.numItems; ci++) {
          var comp = sc.components[ci], mn = ''; try { mn = comp.matchName; } catch (e) {}
          var target = cr__comp(dc, mn, comp.displayName);
          if (!target && ci >= 2 && a.effects !== false) { target = cr__addFx(dc, isV, M.track, mn, comp.displayName); if (target) fx++; }
          if (target) cr__copyComp(comp, target);
        }
        done++;
      }
    }
    return cr__json({ ok: true, done: done, fx: fx });
  } catch (e) { return cr__fail(e); }
}
/* write keyframes for a timeline preset. a.p = { opacity:[[t,v]], scale, scaleW, rot, pos:[[t,[x,y]]], blur, uniform, anchor, posStatic }
   times are sequence seconds. Props named in a.reset lose their old keyframes first. */
function cr__motionP(clip, idx) { var m = cr__motion(clip); return m ? m.properties[idx] : null; }
function cr__keysOn(p, list, off) {
  if (!p || !list || !list.length) return 0;
  if (!p.isTimeVarying()) p.setTimeVarying(true);
  for (var i = 0; i < list.length; i++) { var kt = list[i][0] + off; cr__addKey(p, kt); cr__setKey(p, kt, list[i][1], i === list.length - 1); }
  return list.length;
}
function cr__clear(p, v) { if (!p) return; try { if (p.isTimeVarying()) p.setTimeVarying(false); } catch (e) {} if (v !== undefined && v !== null) { try { p.setValue(v, true); } catch (e) {} } }
function cr_fx(s) {
  try {
    var a = cr__args(s), seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var clip = cr__findClip(seq, a.clip);
    if (!clip) return cr__json({ ok: false, error: 'clip_moved' });
    var P = a.p || {}, B = a.base || {}, off = clip.inPoint.seconds - clip.start.seconds, n = 0, warn = '';
    var op = cr__comp(clip, 'AE.ADBE Opacity', 'Opacity'), opP = op ? op.properties[0] : null;
    var pos = cr__motionP(clip, 0), sc = cr__motionP(clip, 1), scw = cr__motionP(clip, 2), uni = cr__motionP(clip, 3), rot = cr__motionP(clip, 4), anc = cr__motionP(clip, 5);
    /* back to the clip's own values first */
    cr__clear(pos, B.pos); cr__clear(sc, B.scale !== undefined ? B.scale : null); cr__clear(scw, B.scale !== undefined ? B.scale : null); cr__clear(rot, B.rot !== undefined ? B.rot : 0);
    cr__clear(opP, B.opacity !== undefined ? B.opacity : 100); if (B.anchor) cr__clear(anc, B.anchor);
    if (uni) { try { uni.setValue(P.uniform === false ? false : true, true); } catch (e) {} }
    var bl = cr__comp(clip, 'AE.ADBE Gaussian Blur 2');
    if (bl) { cr__clear(bl.properties[0], 0); }
    if (a.clearOnly) return cr__json({ ok: true, n: 0 });
    if (P.anchor) { try { anc.setValue(P.anchor, true); } catch (e) {} }
    if (P.posStatic) { try { pos.setValue(P.posStatic, true); } catch (e) {} }
    n += cr__keysOn(opP, P.opacity, off); n += cr__keysOn(pos, P.pos, off); n += cr__keysOn(sc, P.scale, off);
    if (P.uniform === false) n += cr__keysOn(scw, P.scaleW, off);
    n += cr__keysOn(rot, P.rot, off);
    if (P.blur && P.blur.length) {
      if (!bl) bl = cr__addFx(clip, true, a.clip.track, 'AE.ADBE Gaussian Blur 2', 'Gaussian Blur');
      if (bl) { try { bl.properties[2] && bl.properties[2].setValue(true, true); } catch (e) {} n += cr__keysOn(bl.properties[0], P.blur, off); } else warn = 'no_blur';
    }
    return cr__json({ ok: true, n: n, warn: warn });
  } catch (e) { return cr__fail(e); }
}
/* live glass: point the clip's project item at a freshly rendered file */
function cr_swapMedia(s) {
  try {
    var a = cr__args(s), root = app.project.rootItem, hit = null;
    function walk(b) {
      for (var i = 0; i < b.children.numItems && !hit; i++) {
        var c = b.children[i];
        if (c.type === 2) walk(c); else if (c.name === a.name) hit = c;
      }
    }
    walk(root);
    if (!hit) return cr__json({ ok: false, error: 'not_found' });
    try { if (hit.canChangeMediaPath && !hit.canChangeMediaPath()) return cr__json({ ok: false, error: 'locked' }); } catch (e) {}
    var ok = hit.changeMediaPath(a.path, true);
    try { hit.name = a.name; } catch (e) {}
    return cr__json({ ok: ok !== false });
  } catch (e) { return cr__fail(e); }
}

/* ===================== audio clean-up ===================== */
/* selected clips on the audio tracks (a linked video+audio selection counts) */
function cr_selAudio(s) {
  try {
    var seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var out = [], at = seq.audioTracks;
    for (var i = 0; i < at.numTracks; i++) {
      var tr = at[i];
      for (var j = 0; j < tr.clips.numItems; j++) {
        var c = tr.clips[j], sel = false, p = '';
        try { sel = c.isSelected(); } catch (e) {}
        if (!sel) continue;
        try { p = c.projectItem ? c.projectItem.getMediaPath() : ''; } catch (e) {}
        var id = ''; try { id = String(c.nodeId); } catch (e) {}
        out.push({ track: i, idx: j, id: id, start: c.start.seconds, end: c.end.seconds, inPoint: c.inPoint.seconds, path: p, speed: cr__speed(c), name: c.name, on: cr__enabled(c) });
      }
    }
    return cr__json({ ok: true, clips: out, t: seq.getPlayerPosition().seconds, n: at.numTracks });
  } catch (e) { return cr__fail(e); }
}
/* items: [{path, at, dur, src: {track, id, start}}]; all cleaned files go on one free audio track; mute: switch the originals off */
function cr_placeClean(s) {
  try {
    var a = cr__args(s), seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var items = a.items || [], bin = cr__bin('ENP Clean Audio'), at = seq.audioTracks, idx = -1, i, k;
    function freeAll(tr) { for (var q = 0; q < items.length; q++) if (!cr__free(tr, items[q].at, items[q].at + items[q].dur)) return false; return true; }
    for (i = 0; i < at.numTracks; i++) { if (freeAll(at[i])) { idx = i; break; } }
    if (idx < 0) {
      try { app.enableQE(); qe.project.getActiveSequence().addTracks(0, 0, 1, 1, at.numTracks); } catch (e) {}
      for (i = 0; i < seq.audioTracks.numTracks; i++) if (freeAll(seq.audioTracks[i])) { idx = i; break; }
    }
    if (idx < 0) return cr__json({ ok: false, error: 'no_free_track' });
    var placed = 0, muted = 0, names = [];
    for (k = 0; k < items.length; k++) {
      var it = items[k], item = cr__findItem(bin, it.path);
      if (!item) { app.project.importFiles([it.path], true, bin, false); item = cr__findItem(bin, it.path); }
      if (!item) continue;
      var tm = new Time(); tm.seconds = it.at;
      seq.audioTracks[idx].overwriteClip(item, tm); placed++; names.push(item.name);
      if (a.mute && it.src) {
        var c = cr__findAny(seq, { type: 'a', track: it.src.track, id: it.src.id, start: it.src.start });
        if (c) { try { c.disabled = true; muted++; } catch (e) {} }
      }
    }
    return cr__json({ ok: true, track: 'A' + (idx + 1), placed: placed, muted: muted, names: names });
  } catch (e) { return cr__fail(e); }
}

/* switch clips off / on: refs [{type:'v'|'a', track, id, start}] */
function cr_disable(s) {
  try {
    var a = cr__args(s), seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var n = 0, refs = a.refs || [];
    for (var i = 0; i < refs.length; i++) { var c = cr__findAny(seq, refs[i]); if (c) { try { c.disabled = a.on === false ? false : true; n++; } catch (e) {} } }
    return cr__json({ ok: true, n: n });
  } catch (e) { return cr__fail(e); }
}

/* ===================== project organizer ===================== */
function cr__kindOf(it) {
  try { if (it.isSequence && it.isSequence()) return 'seq'; } catch (e) {}
  var nm = String(it.name || ''), mp = '';
  if (/^(ENP|Carousel3D|AmarText|AmarGlass)_/.test(nm)) return 'enp';
  try { mp = it.getMediaPath() || ''; } catch (e) {}
  var ext = (/\.([a-z0-9]+)$/i.exec(mp || nm) || ['', ''])[1].toLowerCase();
  if (!mp) return 'gfx';
  if (/^(mp4|mov|mxf|avi|mkv|m4v|mts|m2ts|webm|r3d|braw|mpg|mpeg|wmv|3gp|dv|vob|ts|crm|ari)$/.test(ext)) return 'video';
  if (/^(wav|mp3|aac|m4a|aif|aiff|flac|ogg|wma|opus|bwf)$/.test(ext)) return 'audio';
  if (/^(jpg|jpeg|png|gif|bmp|tif|tiff|psd|webp|heic|tga|exr|svg|ai|dpx|jfif)$/.test(ext)) return 'image';
  if (/^(mogrt|aegraphic|aep|prtl)$/.test(ext)) return 'gfx';
  return 'other';
}
function cr__usedSet() {
  var used = {}, seqs = app.project.sequences;
  for (var s = 0; s < seqs.numSequences; s++) {
    var sq = seqs[s], groups = [sq.videoTracks, sq.audioTracks];
    for (var g = 0; g < 2; g++) for (var t = 0; t < groups[g].numTracks; t++) {
      var tr = groups[g][t];
      for (var c = 0; c < tr.clips.numItems; c++) { try { var pi = tr.clips[c].projectItem; if (pi) used[String(pi.nodeId)] = 1; } catch (e) {} }
    }
    try { if (sq.projectItem) used[String(sq.projectItem.nodeId)] = 1; } catch (e) {}
  }
  return used;
}
/* a: { scope: 'loose' | 'all', unused: bool, offline: bool, colors: bool, empty: bool, dry: bool, names: {kind: binName} } */
function cr_organize(s) {
  try {
    var a = cr__args(s), root = app.project.rootItem;
    if (!root) return cr__json({ ok: false, error: 'no_project' });
    var names = a.names || {}, items = [], used = a.unused ? cr__usedSet() : null, plan = {}, n = 0, i;
    var top = {}; for (var k in names) top[names[k]] = 1;
    function walk(bin, depth) {
      for (var j = 0; j < bin.children.numItems; j++) {
        var it = bin.children[j], isBin = false;
        try { isBin = it.type === ProjectItemType.BIN; } catch (e) { isBin = it.type === 2; }
        if (isBin) {
          if (depth === 0 && top[it.name]) continue;                  // our own bins: already sorted
          if (a.scope === 'all') walk(it, depth + 1);
          else if (/^ENP|^SFX$/.test(it.name) && depth === 0) items.push({ it: it, kind: 'enpbin' });
          continue;
        }
        items.push({ it: it, kind: null });
      }
    }
    walk(root, 0);
    for (i = 0; i < items.length; i++) {
      var x = items[i], kind = x.kind || cr__kindOf(x.it);
      if (x.kind !== 'enpbin') {
        if (a.offline) { var off = false; try { off = x.it.isOffline(); } catch (e) {} if (off) kind = 'offline'; }
        if (used && kind !== 'seq' && kind !== 'offline' && !used[String(x.it.nodeId)]) kind = 'unused';
      } else kind = 'enp';
      x.kind = kind; plan[kind] = (plan[kind] || 0) + 1; n++;
    }
    if (a.dry) return cr__json({ ok: true, dry: true, plan: plan, total: n });
    var bins = {}, LABEL = { seq: 4, video: 1, audio: 5, image: 7, gfx: 3, enp: 0, unused: 15, offline: 2, other: 12 };
    function binFor(kind) {
      var nm = names[kind] || kind;
      if (bins[nm]) return bins[nm];
      for (var q = 0; q < root.children.numItems; q++) { var c = root.children[q]; if (c.name === nm) { try { if (c.type === ProjectItemType.BIN || c.type === 2) return (bins[nm] = c); } catch (e) {} } }
      return (bins[nm] = root.createBin(nm));
    }
    var moved = 0, colored = 0;
    for (i = 0; i < items.length; i++) {
      var y = items[i], tb = binFor(y.kind);
      try { y.it.moveBin(tb); moved++; } catch (e) {}
      if (a.colors && y.kind !== 'enpbin' && LABEL[y.kind] !== undefined) { try { y.it.setColorLabel(LABEL[y.kind]); colored++; } catch (e) {} }
    }
    var removed = 0;
    if (a.empty) {
      var clean = function (bin) {
        for (var j = bin.children.numItems - 1; j >= 0; j--) {
          var c = bin.children[j], isB = false;
          try { isB = c.type === ProjectItemType.BIN || c.type === 2; } catch (e) {}
          if (!isB) continue;
          clean(c);
          if (c.children.numItems === 0) { try { c.deleteBin(); removed++; } catch (e) {} }
        }
      };
      clean(root);
    }
    return cr__json({ ok: true, plan: plan, moved: moved, colored: colored, removed: removed });
  } catch (e) { return cr__fail(e); }
}
function cr_projInfo(s) {
  try { return cr__json({ ok: true, path: String(app.project.path || ''), name: String(app.project.name || '') }); } catch (e) { return cr__fail(e); }
}
function cr_projSave(s) {
  try { app.project.save(); return cr__json({ ok: true, path: String(app.project.path || '') }); } catch (e) { return cr__fail(e); }
}

/* ===================== transitions: the cut nearest the playhead ===================== */
function cr_cutAt(s) {
  try {
    var a = cr__args(s), seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var t = seq.getPlayerPosition().seconds, best = null;
    for (var i = seq.videoTracks.numTracks - 1; i >= 0; i--) {
      var tr = seq.videoTracks[i];
      for (var j = 0; j + 1 < tr.clips.numItems; j++) {
        var A = tr.clips[j], B = tr.clips[j + 1];
        if (Math.abs(A.end.seconds - B.start.seconds) > 0.02) continue;
        var mpA = '', mpB = ''; try { mpA = A.projectItem.getMediaPath(); mpB = B.projectItem.getMediaPath(); } catch (e) {}
        if (!mpA || !mpB) continue;
        var d = Math.abs(B.start.seconds - t);
        if (!best || d < best.d - 1e-6) best = { d: d, a: A, b: B, track: i };
      }
      if (best && best.d < 0.05) break;
    }
    if (!best || best.d > (a.within || 3)) return cr__json({ ok: true, none: true, t: t });
    return cr__json({ ok: true, cut: best.b.start.seconds, track: best.track, a: cr__clipInfo(best.a, best.track), b: cr__clipInfo(best.b, best.track),
      w: Number(seq.frameSizeHorizontal), h: Number(seq.frameSizeVertical), fps: cr__fps(seq) });
  } catch (e) { return cr__fail(e); }
}

/* ---------- Premiere items: adjustment layer, black / transparent video, bars, imported files ---------- */
function cr__walk(bin, fn) {
  for (var i = 0; i < bin.children.numItems; i++) {
    var c = bin.children[i];
    if (fn(c) === true) return c;
    if (c.type === 2) { var r = cr__walk(c, fn); if (r) return r; }
  }
  return null;
}
function cr__isAdjust(it) {
  try { if (it.type === 2) return false; if (it.isSequence && it.isSequence()) return false; } catch (e) {}
  var mp = ''; try { mp = it.getMediaPath() || ''; } catch (e) {}
  if (mp) return false;
  try { if (it.isAdjustmentLayer && it.isAdjustmentLayer()) return true; } catch (e) {}
  return /adjust|طبقة الضبط|einstellungsebene|calque d.?effets|capa de ajuste|livello di regolazione/i.test(String(it.name || ''));
}
function cr__snapshotIds(bin, set) { set = set || {}; for (var i = 0; i < bin.children.numItems; i++) { var c = bin.children[i]; try { set[String(c.nodeId)] = 1; } catch (e) {} if (c.type === 2) cr__snapshotIds(c, set); } return set; }
function cr__newSince(bin, set) { return cr__walk(bin, function (c) { var id = ''; try { id = String(c.nodeId); } catch (e) {} return c.type !== 2 && !set[id]; }); }
/* lay a project item on the first free track above everything at [t0, t1] and cut it to that length */
function cr__lay(seq, item, t0, dur) {
  var t1 = t0 + dur, vt = seq.videoTracks, top = -1;
  for (var i = 0; i < vt.numTracks; i++) if (!cr__free(vt[i], t0, t1)) top = i;
  var ti = cr__trackAbove(seq, top, t0, t1);
  if (ti < 0) return { ok: false, error: 'no_free_track' };
  var at = new Time(); at.seconds = t0;
  seq.videoTracks[ti].overwriteClip(item, at);
  var placed = null, tr = seq.videoTracks[ti];
  for (var j = 0; j < tr.clips.numItems; j++) if (Math.abs(tr.clips[j].start.seconds - t0) < 0.01) placed = tr.clips[j];
  if (placed && dur > 0) { try { var e = new Time(); e.seconds = t1; placed.end = e; } catch (x) {} }
  return { ok: true, track: 'V' + (ti + 1) };
}
function cr_newItem(s) {
  try {
    var a = cr__args(s), seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    var w = Number(seq.frameSizeHorizontal), h = Number(seq.frameSizeVertical), t0 = seq.getPlayerPosition().seconds, dur = Number(a.dur) || 5;
    var root = app.project.rootItem, bin = cr__bin('ENP Items'), item = null;
    if (a.kind === 'adjust') {
      item = cr__walk(root, cr__isAdjust);
      if (!item && a.template) {
        var before = cr__snapshotIds(root);
        try { app.project.importFiles([a.template], true, bin, false); } catch (e) {}
        item = cr__walk(root, function (c) { var id = ''; try { id = String(c.nodeId); } catch (e) {} return !before[id] && cr__isAdjust(c); });
      }
      if (!item) return cr__json({ ok: false, error: 'need_adjust' });
    } else {
      app.enableQE();
      var set = cr__snapshotIds(root), fn = { black: 'newBlackVideo', transparent: 'newTransparentVideo', bars: 'newBarsAndTone' }[a.kind];
      if (!fn || !qe.project[fn]) return cr__json({ ok: false, error: 'no_qe' });
      var tries = [[w, h, 0, 1, 1], [w, h, 1, 1], [w, h]];
      for (var k = 0; k < tries.length && !item; k++) { try { qe.project[fn].apply(qe.project, tries[k]); } catch (e) {} item = cr__newSince(root, set); }
      if (!item) return cr__json({ ok: false, error: 'no_qe' });
      try { item.moveBin(bin); } catch (e) {}
    }
    var r = cr__lay(seq, item, t0, dur); r.name = item.name;
    return cr__json(r);
  } catch (e) { return cr__fail(e); }
}
/* import any file into a bin and (optionally) lay it at the playhead */
function cr_importLay(s) {
  try {
    var a = cr__args(s), seq = app.project.activeSequence, bin = cr__bin(a.bin || 'ENP Items');
    app.project.importFiles([a.path], true, bin, false);
    var it = cr__findItem(bin, a.path);
    if (!it) return cr__json({ ok: false, error: 'import_failed' });
    if (!a.place) return cr__json({ ok: true, imported: true, name: it.name });
    if (!seq) return cr__json({ ok: true, imported: true, name: it.name, noSeq: true });
    var t0 = a.at != null ? Number(a.at) : seq.getPlayerPosition().seconds;
    var r = cr__lay(seq, it, t0, Number(a.dur) || 0); r.name = it.name; r.imported = true;
    return cr__json(r);
  } catch (e) { return cr__fail(e); }
}
/* the picture of the whole sequence at the playhead, as a PNG (Premiere adds the .png) */
function cr_snapFrame(s) {
  try {
    var a = cr__args(s), seq = app.project.activeSequence;
    if (!seq) return cr__json({ ok: false, error: 'no_sequence' });
    app.enableQE();
    var q = qe.project.getActiveSequence(), tc = q.CTI.timecode;
    q.exportFramePNG(tc, a.base);
    return cr__json({ ok: true, t: seq.getPlayerPosition().seconds });
  } catch (e) { return cr__fail(e); }
}
function cr_appInfo(s) {
  try {
    var o = { ok: true, version: String(app.version || ''), build: '', project: '', saved: false, seq: false, seqName: '', w: 0, h: 0 };
    try { o.build = String(app.build || ''); } catch (e) {}
    try { o.project = String(app.project.path || ''); o.saved = !!o.project && !/Untitled/i.test(o.project); } catch (e) {}
    try { var q = app.project.activeSequence; if (q) { o.seq = true; o.seqName = q.name; o.w = Number(q.frameSizeHorizontal); o.h = Number(q.frameSizeVertical); } } catch (e) {}
    return cr__json(o);
  } catch (e) { return cr__fail(e); }
}
